/**
 * 营销稽查相关js
 * author: hw
 * data: 2014/06/19
 */
//加载平台工具箱
business_com.loadToolKit();
$(function(){
	$("header p:eq(1)").html(localStorage.area+"-"+localStorage.user_name_str+"-"+localStorage.user_name);
})

// var timeout = 10;
// for(var i = 1;i<4;i++){
// 	(function($,i){
//  		setTimeout(function(){
// 		var temp_obj = $('.list'+i);
// 		temp_obj.addClass('list'+i+'f');
// 		setTimeout(function(){
// 			$(".list"+i+">div").removeClass("listfontf");
// 			i++;
// 			},1000)
// 		},timeout);
// 		timeout+=500;
//  	})(jQuery,i);
// }
$(".exlist2 .float:nth-child(3) .span:nth-child(1)").removeClass("sfladd");
	setTimeout(function(){$(".exlist2 .float:nth-child(3) .span:nth-child(2)").removeClass("sfladd")},200);
	setTimeout(function(){$(".exlist2 .float:nth-child(3) .span:nth-child(3)").removeClass("sfladd")},400);
	setTimeout(function(){$(".exlist2 .float:nth-child(2) .span:nth-child(1)").removeClass("sfladd")},600);
	setTimeout(function(){$(".exlist2 .float:nth-child(2) .span:nth-child(2)").removeClass("sfladd")},800);
	setTimeout(function(){$(".exlist2 .float:nth-child(2) .span:nth-child(3)").removeClass("sfladd")},1000);

	setTimeout(function(){$(".exlist2 .float:nth-child(1) .span:nth-child(1)").removeClass("sfladd")},1200);
	setTimeout(function(){$(".exlist2 .float:nth-child(1) .span:nth-child(2)").removeClass("sfladd")},1400);
	setTimeout(function(){$(".exlist2 .float:nth-child(1) .span:nth-child(3)").removeClass("sfladd")},1600);

	$(".exlist1 .float:nth-child(3) .span:nth-child(1)").removeClass("sfladd");
	setTimeout(function(){$(".exlist1 .float:nth-child(3) .span:nth-child(2)").removeClass("sfladd")},1600);
	setTimeout(function(){$(".exlist1 .float:nth-child(3) .span:nth-child(3)").removeClass("sfladd")},1400);
	setTimeout(function(){$(".exlist1 .float:nth-child(2) .span:nth-child(1)").removeClass("sfladd")},120);
	setTimeout(function(){$(".exlist1 .float:nth-child(2) .span:nth-child(2)").removeClass("sfladd")},1000);
	setTimeout(function(){$(".exlist1 .float:nth-child(2) .span:nth-child(3)").removeClass("sfladd")},800);

	setTimeout(function(){$(".exlist1 .float:nth-child(1) .span:nth-child(1)").removeClass("sfladd")},600);
	setTimeout(function(){$(".exlist1 .float:nth-child(1) .span:nth-child(2)").removeClass("sfladd")},400);
	setTimeout(function(){$(".exlist1 .float:nth-child(1) .span:nth-child(3)").removeClass("sfladd")},200);

	setTimeout(function(){$(".exlist1 .font").removeClass("fontfla")},1800)
	setTimeout(function(){$(".exlist2 .font").removeClass("fontfla")},2300)

// $("#list1").on({
// 	"touchstart": listtouch,
// 	"touchend": listend
// });

function listtouch() {
	$("#list1").css({
		"width": "90%",
		"margin": "5%",
		"opacity": ".6"
	})
};

function listend() {
	$("#list1").css({
		"width": "100%",
		"margin": "0%",
		"opacity": ".8"
	})
};
//页面返回跳转
/**
 *pagejumpno=0;从list返回到模块选择界面
 *pagejumpno=1;从1级页面返回到模块list界面
 *pagejumpno=2;从2级页面返回到模块list界面
 */
var pagejumpno = 0,confirm_flag_s=true;

$("header .flex:eq(0)").click(function() {
	var dom = $("header").find(".btn");
	confirm_flag_s = true;
	switch (pagejumpno) {
		case 0:
			//window.location.href = "../../../../Platform/Plat/html/index.html";
			confirm_flag_s = false;
			closeTools();
			break;
		case 1:
			$(document.body).off();
			dom.hide().unbind("click");
			$("header").find("img").attr("src", "../../images/home.png");
			$('header .content >p:first-child').html('营销稽查');
			$(".moveContent:first-child").removeClass("moveToleft");
			delete inspectListObj;
			delete CurrFileName[pagejumpno+1];
			pagejumpno = 0;
			if(operationObj.chectIntervalTime !=null){
				clearInterval(operationObj.chectIntervalTime);
			}
			if(operationObj.queryIntervalTime !=null){
				clearInterval(operationObj.queryIntervalTime);
			}
			//返回到首页时删除掉get_barcode方法定义,进入各自模块时再定义使用
			if(window.get_barcode){
				delete window.get_barcode;
			}
			delete window.onresize;
			break;
		case 2:
		    var curr_txt = $('header .content >p:first-child').html();
		    if(curr_txt.match('稽查现场作业-新建')){
		    	//获取页面上的工单个数
  	            var num = $("#new_JobScroll li").length;
  	            if(num!=0){
		    	    confirm_flag_s = false;
  	            	navigator.notification.confirm("确定要放弃新建工单吗?", confirm_callback_s, "提示", "确认,取消");
		    		function confirm_callback_s(index){
		    			if(index==1){
		    			   gotoMajor();
		    			   setTimeout(function() {
		    			   	  $("#new_JobScroll li").remove();
		                      $(".moveContent:last-child").remove();
	                       }, 500);
		    			}
		    		}
  	            }else{
  	            	gotoMajor();
  	            }
		    }else{
		    	gotoMajor();
		    } 
		    function gotoMajor(){
		    	$('header .content >p:first-child').html('稽查现场作业');
			    $(".moveContent:eq(1)").removeClass("moveToleft");
			    delete inspectDetailObj, delete operationObj;
					delete CurrFileName[pagejumpno+1];
			    pagejumpno = 1;
			    //返回到首页时删除掉get_barcode方法定义,进入各自模块时再定义使用
				if(window.get_barcode){
					delete window.get_barcode;
				}
		    }
				delete window.onresize;
			break;
		case 3:
		    if(typeof mxHasCheckAll == 'function'){
		    	var check_result = mxHasCheckAll();
		    	if(!check_result){
		    		//暂时注释掉,正式代码启用
		    		return;
		    	}
		    	 $("#detailsList li").remove();
		    }
			$('header .content >p:first-child').html('稽查现场作业-新建任务');
			$(".moveContent:eq(2)").removeClass("moveToleft");
			delete operationEditObj;
			delete CurrFileName[pagejumpno+1];
			pagejumpno = 2;
			delete window.onresize;
			break;
		case 4:
			$('header .content >p:first-child').html('稽查现场作业详细页面');
			$(".moveContent:eq(2)").removeClass("moveToleft");
			delete CurrFileName[pagejumpno+1];
			pagejumpno = 2;
			if(operationObj.chectIntervalTime !=null){
				clearInterval(operationObj.chectIntervalTime);
			}
			if(operationObj.queryIntervalTime !=null){
				clearInterval(operationObj.queryIntervalTime);
			}
			delete window.onresize;
			break;
	}
	ReSize();
	//remove model
	
	if(confirm_flag_s){
		setTimeout(function() {
		   $(".moveContent:last-child").remove();
	   }, 500);
	}
});

//当前文件名
var CurrFileName = new Object();
	CurrFileName.add = function(key, value) {
		this[key] = value;
	};
	CurrFileName.get = function(key) {
		return this[key];
	};

function goToModel(obj, url, value, num) {
	CurrFileName.add(num,url.slice(url.lastIndexOf('/')+1,url.lastIndexOf('.')));
	pagejumpno = num;
	var target = $(obj).closest('.moveContent');
	target.after('<div class="moveContent stayOnRight"></div>');
	target.next().load(url, function() {
		//修改header
		$('header .content >p:first-child').html(value);
		$($('header img:first-child')[0]).attr("src", "../../images/back.png");
		//加载动画
		target.addClass("moveToleft");
		target.next().removeClass('stayOnRight');
	});
}

document.addEventListener("deviceready",function(){
	//进行蓝牙连接
	bluetooth_conn(function(e){
		if(e.msg == 1){
			showToast("设备已连接");
		}else if(e.msg==3){
			showToast("扫描设备未设置");
		}else{
			showToast("连接失败");	
		}
	});
},false);

//模块控制
setTimeout(function(){
  $(".maincont").on("click","div[id^=list]",function() {
	var index = $("div[id^=list]").index(this);
	switch (index) {
		//用电体检
		case 0:
			goToModel(this, '../examination/html/examination.html', '用电体检', 1);
			setTimeout(function(){initExcepHtml(0)},500);
			break;
		//稽查作业列表页面
		case 1:
			goToModel(this, '../inspectList/html/inspectList.html', '稽查现场作业', 1);
			break;
	}
  });
},500);

//页面大小改变
window.onresize = function(){ReSize();} 
function ReSize(){
	var name = CurrFileName.get(pagejumpno);
	switch(name){
		//用电体检
		case 'examination':
			$('#checkCont').height(plat_common.getHeight()-105-234-20-32);
			scrolltask.refresh();
		break;
		//稽查作业列表页
		case 'inspectList':
			$('#inspectListScroll').height(plat_common.getHeight()-205);
			inspectListObj.inspectScroll.refresh();
		break;
		//稽查作业详细页
		case 'inspectDetail':
			$('#inspectDetailScroll').height(plat_common.getHeight()-205);
			inspectDetailObj.inspectDetailScroll.refresh();
			$('#porjectListPop').height((plat_common.getHeight()*0.8)-71-106-46);
			inspectDetailObj.porjectListPopScroll.refresh();
		break;
		//新建任务
		case 'operation':
			$('#new_JobScroll').height(plat_common.getHeight()-205);
			operationObj.scrollPop.refresh();
		break;
		//编辑工单
		case 'operation_edit':
			$('#detailsList').height(plat_common.getHeight()-205);
			operationEditObj.scrollPop.refresh();
		break;
	}
}