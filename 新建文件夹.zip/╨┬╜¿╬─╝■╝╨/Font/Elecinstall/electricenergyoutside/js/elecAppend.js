elecHtml = function() {
	this.dealCount = 0;
	this.scanData = "";
	this.tempScanData = [];
	this.lookPic = "../../Util/Images/but_ck01_h.png";
	this.noLookPic = "../../Util/Images/but_ck01.png";
	this.unAddCheckBox = "../../Util/Images/radioboxoff.png";
	this.AddCheckBox = "../../Util/Images/radioboxon.png";
	this.unAddCheckBox1 = "electricenergyoutside/images/checkbox_un1.png";
	this.AddCheckBox1 = "../../Util/Images/checkbox_on.png";

	this.doIt = "electricenergyoutside/images/already.png";
	this.upIt = "electricenergyoutside/images/donePic.png";
	this.haveNot = "electricenergyoutside/images/have_not.png";
	this.heryCheckBox = "electricenergyoutside/images/radioboxon3.png";
	//记录新增电能表为空的数组
	this.newEmpty = [];
}
elecHtml.prototype = {
	getResult : function(a, b) {
		var strArray = new Array();
		for(var i in a) {
			var s = "{";
			for(var x in a[i]) {
				var number = 0;
				if(number == 0) {
					number = 1;
					s += '"' + x + '":"' + a[i][x] + '",';
				}
			}
			s += '"mt":[';
			for(var j in b) {
				if(a[i].mp_scheme_id == b[j].mp_scheme_id) {
					s += "{";
					for(var y in b[j]) {
						s += '"' + y + '":"' + b[j][y] + '",';
					}
					s = s.substring(0, s.length - 1);
					s += "},"
				}
			}
			s = s.substring(0, s.length - 1);
			s = s + "]}";
			strArray.push(s);
		}
		this.resultHtml(strArray);
	},
	resultHtml : function(data) {
		this.scanData = data;
		//开始填充数据
		var rueslt = "";
		mpschemeArray = [];
		getGpsTen = [];
		eh.dealCount = 0;
		$("#electricenergyoutsid_ins_name_number").html(data.length);
		$("#electricenergyoutsid_ins_name_numbers").html(0);
		//记录处理中的前十个坐标
		this.newEmpty = [];
		for(var i = 0; i < data.length; i++) {
			mpschemeArray[i] = JSON.parse(data[i]);
			getGpsTen.push(mpschemeArray[i].longitude + "-" + mpschemeArray[i].latitude + "-" + mpschemeArray[i].already_do + "-" + i);
			var temp = JSON.parse(data[i]);
			rueslt += "<div><div><div onclick='electricClick(" + i + ",this.id)' id='electricAll" + i + "' class='inspect_clause2 userlist'><div class='seqencingtwo span_margin lab'>" + (i + 1) + "</div><span class='aspk fontsizeforue'>" + temp.cons_name + "</span><br /><span class='aspk fontsizeseaven span_maneryyer address_stype userAdd'>" + temp.mp_addr + "</span><div class='have_not'><img id='readyDo" + i + "' src='" + eh.readyDo(temp.already_do) + "'/></div><div style='clear:both'></div></div></div><div class='row-content measure' id='mtitList" + i + "'><div class='accordion_child accordion'><span class='fontsizeseaven'>户号:</span><span class='fontsizeseaven'>" + temp.cons_no + "</span><span class='fontsizeseaven radio_margin_ml'>计量方式:</span><span class='fontsizeseaven'>" + temp.meas_mode + "</span><span><img onclick='stopUserList(" + i + ")' src='electricenergyoutside/images/stop_01.png' /></span></div><div class='dianline_out'><div class='dianline'></div></div><div class='eclectr_linherghw tab_tdwidth2 tab_tdbgcolor1 fontsizeseaven widthmeasure' id='containid" + i + "' onclick='containClick(" + i + ",this.id)'><div class='measuretile'>" + temp.container_flag + "</div><div class='measureCenter'><input class='measInput' id='containerAssetNo" + i + "' readonly='readonly' value='" + temp.container_asset_no + "' /></div><div class='measurespan measureCenter measuresplit' id='containerFloor" + i + "'>" + this.returnRatioFloor(temp.floor) + "</div><div class='measurefloor'>楼</div><div style='clear:both; float:none'></div>";
			var mt = temp.mt, itHmtl = "", mtHtml = "", mtLen = 0, itLen = 0, mtNum = 0, itNum = 0;
			var stt = new Array();
			var sttr = new Array();
			if(mt.length > 0) {
				for(var j = 0; j < mt.length; j++) {
					if(stt.indexOf(mt[j].MTid) == -1 && mt[j].MTid) {
						if(mtLen == 0) {
							mtLen = 1;
							mtHtml += "<div class='tab_tdwidth2 tab_tdbgcolor1 fontsizeseaven ammeter'><span class='ammetertitle'>电能表</span></div>";
						}
						this.newEmpty.push(mt[j].MTid + "-" + mt[j].MTchg_desc + "-" + i + "-" + j);
						mtHtml += this.appendMtHtml(mt[j], mtNum, i);
						stt.push(mt[j].MTid);
						mtNum++;
					}
					if(sttr.indexOf(mt[j].scheme_id) == -1 && mt[j].scheme_id) {
						if(itLen == 0) {
							itLen = 1;
							itHmtl += "<div class='tab_tdwidth2 tab_tdbgcolor1 fontsizeseaven ammeter'><span class='ammetertitle'>互感器</span></div>";
						}
						itHmtl += this.appendItHtml(mt[j], itNum, i);
						sttr.push(mt[j].scheme_id);
						itNum++;
					}
				}
			}
			rueslt += "<div style='clear:both;float:none'></div></div><div style='clear:both;float:none'></div>" + mtHtml + itHmtl + "<div style='width:100%; background-color:#EEE;'><div style='width:98%;height:60px; margin:3px auto 10px auto;'><img src='../../Util/Images/but_pz01.png' class='img_ectryet' onclick='takeClick(" + i + ")'/><img src='../../Util/Images/but_ck01_h.png' id='imgLooklist" + i + "' style='margin-right:5%;margin-left:5%' onclick='lookClick(" + i + ")' class='img_ectryet'/><img onclick='eh.gotoArcgis()' src='../../Util/Images/map_ck01.png' style='margin-right:5%;' class='img_ectryet'/><img  src='../../Util/Images/print.png' onclick='printClick(" + i + ")' class='img_ectryet'/></div><div style='clear:both;float:none'></div></div></div><div class='addCheck' id='addCheck" + i + "' onclick='checkonoff(" + i + ")'><img src='" + eh.unAddCheckBox1 + "' width='31' height='31' /></div><div style='clear:both;float:none'></div></div><div style='clear:both;float:none'></div>";
		}
		eo.pathMark(getGpsTen);
		o.openWait("数据加载完成", 2);
		$("#elecSchemesID").html(rueslt);
		if($("#dropUl2").css("display") == "block") {
			eo.addclassWithList();
		} else {
			eo.delclassWithList();
		}
		if(sessionStorage.findCode == 1) {
			//如果是扫描进来的,则进行电能表匹对
			for(var i = 0; i < data.length; i++) {
				for(var j = 0; j < JSON.parse(data[i]).mt.length; j++) {
					if(JSON.parse(data[i]).mt[j].asset_no == sessionStorage.barCodeInti) {
						electricClick(i, "electricAll" + i, j, 1);
						return;
					}
				}
			}
		}
	},
	appendItHtml : function(data, j, i) {
		return "<div class='ammeter_list' onclick='ammeterClick(" + j + ",1," + i + "," + data.scheme_id + ")'><div class='typeClass typeone iAmType" + j + "' style='text-align:left' id='IamTypeMtchgDescID" + i + "s" + j + "' content='" + data.scheme_id + "'>" + data.ITchg_desc + "</div><div class='typeClass typetwo iAmType" + j + "'><input class='typeinput' id='IammeterInput" + i + "s" + j + "' value='" + this.returnRatioFloor(data.ITasset_no) + "' readonly='readonly' /></div><div class='typeClass typethree iAmType" + j + "'>" + this.returnRatio(data.ITvolt_ratio_code) + "</div><div class='typeClass typefour iAmType" + j + "'>" + this.returnRatio(data.ITcurrent_ratio_code) + "</div><div style='clear:both;float:none'></div><div class='aGolist' id='aGolist" + i + "s" + j + "'><div class='typeammeter fontsizeforue span_margin'>类别:" + this.returnRatio(data.ITsort_code) + "</div><div class='typeammeter fontsizeforue span_margin'>计量点名称:" + this.returnRatio(data.ITmp_name) + "</div><div class='typeammeter fontsizeforue span_margin'>相别:" + this.returnRatio(data.ITphase_code) + "</div></div><div style='clear:both;float:none'></div></div><div style='clear:both;float:none'></div>";
	},
	appendMtHtml : function(data, j, i) {
		return "<div class=' ammeter_list' onclick='ammeterClick(" + j + ",2," + i + "," + data.MTid + ")' id='ammeter_list" + j + "'><div class='typeClass typeone amType" + j + "' style='text-align:left' id='amTypeMtchgDescID" + i + "s" + j + "' content='" + data.MTid + "' >" + data.MTchg_desc + "</div><div class='typeClass typetwo amType" + j + "'><input id='ammeterInput" + i + "s" + j + "' class='typeinput' value='" + data.asset_no + "' readonly='readonly'/></div><div class='typeClass typethree amType" + j + "'>" + data.MTvolt_code + "</div><div class='typeClass typefour amType" + j + "'>" + data.MTcurrent_code + "</div><div style='clear:both;float:none'></div><div class='golist' id='golist" + i + "s" + j + "'><div class='typeammeter fontsizeforue span_margin'>类别:" + data.MTsort_code + "</div><div class='typeammeter fontsizeforue span_margin'>准确度等级:" + data.MTaccuracy_code + "</div><div class='typeammeter fontsizeforue span_margin'>计量点名称:" + data.MTmp_name + "</div><div class='typeammeter fontsizeforue span_margin'>接线方式:" + data.MTwiring_mode + "</div></div></div><div style='clear:both;float:none'></div>";
	},
	popHtml : function(itValue, getLoc, i) {
		return "<div class='round_up_top'><div class='bar_code_tm'><div class='top_headlinemge'><span class='span_headlinemge'>&nbsp;&nbsp;计量箱/柜信息</span><span style='float:right; padding-right:10px;margin-top:1px'><img onclick='measureCancle()' src='../../Util/Images/cancel_1.png' class='img_cancel_1'/></span></div><div class='bottom_message'><table  border='0' cellspacing='0' cellpadding='0' ><tr><td colspan='2' height='10px'></td></tr><tr><td width='30%' class='fontalign'>&nbsp;&nbsp;资产编号：</td><td class='allinputnine fontalign'><input id='getAssetno' maxlength='32' value='" + itValue + "' /></td></tr><tr><td colspan='2' height='10px'></td></tr><tr><td width='30%' class='fontalign'>&nbsp;&nbsp;楼<span class='lespacing'>&nbsp;&nbsp;</span>层：</td><td class='allinputnine fontalign'><input id='getLoc' maxlength='8' value='" + getLoc + "' type='text' onChange='getLocSelf(this)' /></td></tr><tr><td colspan='2' height='20px'></td></tr><tr><td colspan='2' ><div style='margin:10px;color:black; text-align:center; font-size:24px;' id='returngps" + sessionStorage.electMeas + "'>" + eo.returnGpsType(sessionStorage.electMeas) + "</div></td></tr></table></div><img src='../../Util/Images/enter.png' class='img_enter_el' onclick='measureOk(" + i + "," + '"' + itValue + '"' + ")' />&nbsp;&nbsp;<img class='img_enter_el' src='electricenergyoutside/images/orient.png' onclick='eo.autoMeasScan(" + i + ")' /></div>";
	},
	returnRatioFloor : function(e) {
		if(e == "" || e == "undefined" || !e)
			return " ";
		return e;
	},
	returnRatio : function(e) {
		if(e == "" || e == "undefined" || !e)
			return "无";
		return e;
	},
	readyDo : function(e) {
		if(e == 1) {
			eh.dealCount++;
			$("#electricenergyoutsid_ins_name_numbers").html(eh.dealCount);
			return this.doIt;
		} else if(e == 2) {
			eh.dealCount++;
			$("#electricenergyoutsid_ins_name_numbers").html(eh.dealCount);
			return this.upIt;
		} else {
			return this.haveNot;
		}
	},
	//根据用户名进行排序
	compareFun : function(a, b) {
		if(a.CONS_NAME > b.CONS_NAME) {
			return 0;
		} else {
			return 1;
		}
	},
	same_last_read : function() {
		$("#confirm_the_same").show();
	},
	all_ufty : function(len) {
		returnFlag = 0;
		$("#pop").html("");
		var title1 = "";
		var title2 = "";
		title1 += "<div class='round_up_top_input' style='position:relative; width:98%; margin:auto;'><div class='bar_code'><div class='top_headlinemge'><span style='float:right; padding-right:10px;margin-top:1px'><img onclick='LockCancle()' src='../../Util/Images/cancel_1.png' class='img_cancel_1'/></span><div class='span_topmainmege'>用户名：" + sessionStorage.mpUserName + "</div><div class='span_topmainmege'>地<span class='lespacing'>&nbsp;</span>址：" + sessionStorage.mpUserAddr + "</div><div class='span_topmainmege'>电表资产号：<span class='allinputnine fontalign'>";
		if(sessionStorage.chgDesc == "新增") {
			title1 += "<span><input id='modify_mtscheme' style='width:50%;' maxlength='32' value='" + sessionStorage.amIput + "' type='text' /></span></span></div></div><div class='bottom_message'><div class='bottom_messagediv'><div style='clear:both;float:none'></div>";
			// alert('电表资产号： ' + sessionStorage.amIput);
		} else {
			title1 += "<span>" + sessionStorage.amIput + "</span>";
			title1 += "</span></div></div><div class='bottom_message'><div class='bottom_messagediv'><div style='width:26%; float:left'>示数类型</div><div style=' width:26%; float:left'>上次示数</div><div style=' width:26%; float:left'>本次示数</div><div style=' width:21%; float:left'>翻转状态</div></div>";
			//循环填充示数
			for(var i = 0; i < eo.read_type_code_all.length; i++) {
				title2 += "<div class='bo_divtr bofont'><div class='bo_divtr_td bofonttr bofont' id='bo_divter" + i + "'>" + eo.read_type_code_all[i] + "</div><div class='bo_divtr_td bofonttr'><input style='text-align:right;background-color:#ccc' id='style_new_checks" + i + "' value='" + eo.irread_id_last[i] + "' readonly='readonly' /></div><div class='bo_divtr_td bofonttr'><input type='text' maxlength='16' id='style_new_check" + eo.sect_value97_angle[i] + "' onChange='youDoSelf(this)' style=' text-align:right' value='" + eh.returnHuoQu(eo.huoqu_arr[i]) + "' content='" + i + "'/></div><div class='bo_divtr_td bofont' style='width:21%' id='returnStyleID" + i + "'>" + eh.returnExpType(eo.img_check_type[i]) + "</div></div>";
			}
		}
		if(len > 0) {
			title1 += "<div class='popScroll' style='height:350px;'>";
		} else {
			title1 += "<div style='overflow-y:scroll; height:100px;'>";
		}
		if(sessionStorage.chgDesc == "新增") {
			title2 += "</div></div><div class='bo_divtr2'></div><div class='bottomEnter'><div style='width:80%;margin:0 auto 0 auto;'><div class='bottomE1'><div style='width:183px;'><img src='../../Util/Images/enter_el.png' width='183' height='50' onclick='ammeterModify(" + len + ")' /></div></div><div class='bottomE1'><div style='width:183px;'><img src='../../Util/Images/xzsaomiao_03.png' width='183' height='50' onclick='eo.autoAmmeterScan()' /></div></div>";
		} else {
			title2 += "</div></div><div class='bo_divtr2'></div><div class='bottomEnter'><div style='width:90%;margin:0 auto 0 auto;'><div class='bottomE2'><div style='width:183px;'><img src='../../Util/Images/enter_el.png' width='183' height='50' onclick='ammeterModify(" + len + ")' /></div></div><div class='bottomE2'><div style='width:183px;'><img src='../../Util/Images/shishu.png' width='183' height='50' onclick='getLastData(" + len + ")' /></div></div><div class='bottomE2'><div style='width:183px;'><img src='../../Util/Images/shishu_history.png' width='183' height='50' onclick='eo.queryThreeData()'/></div></div>";
		}
		title2 += "</div></div></div></div><div style='width:98%;display:none; margin-top=-5px;' id='errlog'></div></div>";
		$("#pop").html(title1 + title2 + "<div style='clear:both;float:none'></div><div id='tcPop' style='width:100%; margin-top:40px; display:none;'><div id='tcs' style='width:20px; height:20px;-webkit-transform:rotate(-45deg); margin-left:45%; background-color:#ccc;position:absolute;'></div><div id='tc' style='width:98%; font-size:24px;line-height:36px; height:150px;border-radius:10px;background-color:#ccc; overflow:auto; margin-top:10px; margin-left:10px; z-index:99;position:absolute;'></div></div>");
	},
	returnExpType : function(type) {
		if(type == "08") {
			return "是";
		} else {
			return "否";
		}
	},
	returnHuoQu : function(s) {
		if(s) {
			return s;
		} else {
			return "";
		}
	},
	preEnter : function() {
		sessionStorage.m = 1;
		$("#uplogin").hide();
		$("#Pop_up_tops").slideDown();
	},
	clearArray : function() {
		eo.huoqu_arr = new Array();
		eo.irread_id = new Array();
		eo.irread_id_last = new Array();
		eo.img_check_type = new Array();
		eo.read_type_code_all = new Array();
		eo.code_value = new Array();
		eo.sect_value97 = new Array();
		eo.sect_value07 = new Array();
		eo.sect_value97_angle = new Array();
		eo.sect_value07_angle = new Array();
	},
	//互感器信息
	displayItScheme : function(i, schemeID, asset) {
		if(sessionStorage.chgDesc == "新增") {
			$("#Pop_up_tops").slideDown();
			$("#Pop_up_tops").html("<div class='round_up_top'><div class='bar_code_tm'><div class='top_headlinemge'><span class='span_headlinemge'>&nbsp;&nbsp;互感器</span><span style='float:right; padding-right:10px;margin-top:1px'><img onclick='induceCancle()' src='../../Util/Images/cancel_1.png' class='img_cancel_1'/></span></div><div class='bottom_message'><table cellpadding='0' cellspacing='0' border='0' width='100%' align='center'><tr><td height='10px'></td></tr><tr><td class='allinputnine'><input id='sort_itmt' style='width:60%;text-align:left;' type='text' value='" + asset + "'/></td></tr><tr><td height='10px'></td></tr></table></div><img src='../../Util/Images/enter.png' class='img_enter_el' onclick='induceOK(this)' tel='"+asset+"' /><img src='../../Util/Images/jsaomiao.png' class='img_enter_el' onclick='eo.induceCancleScan()' /></div>");
		}
	},
	//选择上装信息
	appendChoseCount : function(type1, type2, type3) {
		$("#Pop_up_tops").show();
		$("#Pop_up_tops").html("<div class='round_up_top'><div class='bar_code_tm'><div class='top_headlinemge'><span class='span_headlinemge'>&nbsp;&nbsp;选择上装用户</span><span style='float:right; padding-right:10px;margin-top:1px'><img onclick='eh.upLoadCancle()' src='../../Util/Images/cancel_1.png' class='img_cancel_1'/></span></div><div class='bottom_message'><table cellpadding='0' cellspacing='0' border='0' width='80%' style='margin-left:50px; text-align:left'><tr><td height='10px'></td></tr><tr><td>当前用户总数:<span id='usercountid' style='margin-left:30px'>" + eh.returnUserNumber(type1) + "</span></td></tr><tr><td>已处理用户数:<span id='doid' style='margin-left:30px'>" + eh.returnUserNumber(type2) + "</span></td></tr><tr><td>已上装用户数:<span id='uprealid' style='margin-left:30px'>" + eh.returnUserNumber(type3) + "</span></td></tr><tr><td>选择上装户数:<input id='choseCountid' style='width:15%;text-align:center;' " + eh.returndisabled() + " type='text' value='" + eh.returnNumber() + "'/></td></tr><tr><td><span style='color:red;font-size:22px;'>*上装限制为500个用户,如果超过需要分批上装</span></td></tr><tr style='text-algin:left;'><td height='10px'></td></tr></table></div><img src='electricenergyoutside/images/nextEnter.png' class='img_enter_el' onclick='eh.upLoadChose()' /></div></div></div>");
		clearInterval(timeInterval);
	},
	returndisabled : function() {
		if($("#dropUl2").css("display") == "block") {
			return "disabled";
		} else {
			return "";
		}
	},
	returnUserNumber : function(e) {
		if(e) {
			return e;
		} else {
			return 0;
		}
	},
	returnNumber : function() {
		eo.tempFun();
		if($("#dropUl2").css("display") == "block") {
			//$("#choseCountid").removeAttr("disabled");
			return tempAddCeckArray.length;
		} else {
			if(sessionStorage.m == 1) {
				return sessionStorage.LoadChoseCount;
			}
			var type = 0;
			for(var i = 0; i < mpschemeArray.length; i++) {
				if($("#readyDo" + i).attr("src") == eh.doIt) {
					type++;
				}
			}
			if(type > 500) {
				return 500;
			} else {
				return type;
			}
			return type;
		}
	},
	upLoadCancle : function(type) {
		returnFlag = 0;
		$("#Pop_up_tops").hide();
	},
	upLoadChose : function() {
		//上一步变量
		sessionStorage.LoadChoseCount = $("#choseCountid").val();
		var amp = 0;
		for(var i = 0; i < mpschemeArray.length; i++) {
			if($("#readyDo" + i).attr("src") == eo.eoNot) {
				//已上装
				amp++;
			}
		}
		if(amp != mpschemeArray.length) {
			if($("#doid").html() == 0) {
				o.openWait("还没有处理用户，不能上装!", 0);
				return;
			}
			// if($("#dropUl2").css("display")!="block"){
			if($("#choseCountid").val() == "" || $("#choseCountid").val() == 0) {
				o.openWait("请选择上装个数!", 0);
				return;
			}

			// }
			if($("#choseCountid").val() > 500) {
				o.openWait("超过上装限制,请重新设置上装个数!", 0);
				return;
			}
			if($("#choseCountid").val())
				var s = /^([0-9]*[.0-9])$/;
			if(!(s.test(Number($("#choseCountid").val())))) {
				o.openWait("上装个数只能为正整数!", 0);
				return;
			}
		}
		var count = $("#choseCountid").val();
		sessionStorage.countChose = count;
		$("#Pop_up_tops").hide();
		$("#uplogin").slideDown();
		$("#textarea_input").removeAttr("disabled");
		$("#textarea_input").css("background", "");
		$("#uploadInfoType1").attr("src", eo.urlOpen);
		$("#uploadInfoType2").attr("src", eo.urlClose);
		$("#uploadInfoType3").attr("src", eo.urlClose);
	},
	//显示申请原因
	getCause : function(a, b) {
		var e = b.rows.item;
		if(e(0).cause) {
			$("#Pop_up_tops").slideDown();
			$("#Pop_up_tops").html("<div class='round_up_top'><div class='bar_code_tm'><div class='top_headlinemge'><span class='span_headlinemge'>申请原因</span></div><div class='bottom_message'><span class='span_barcodeemge'>" + e(0).cause + "</span></div><div style='text-align:center'><img  src='../../Util/Images/enter.png' class='img_enter_el' onclick='enterCanel()' /></div></div>");
		} else {
			o.openWait("该工单暂无申请原因", 0);
		}
	},
	//需要翻转的弹出框
	appendOverReturn : function(data) {
		$("#Pop_up_tops").show();
		var html = "";
		for(var i = 0; i < data.length; i++) {
			html += "<tr><td>" + eo.typeValue2[data[i]] + ":<span id='overReturn" + i + "' onclick='eh.changeReturn(" + i + ")' style='margin-left:30px; line-height:31px;'><img src='" + eh.unAddCheckBox1 + "' width='31' height='31' />翻转</span></td></tr>";
		}
		$("#Pop_up_tops").html("<div class='round_up_top'><div class='bar_code_tm'><div class='top_headlinemge'><span class='span_headlinemge'>&nbsp;&nbsp;请选择翻转状态</span><span style='float:right; padding-right:10px;margin-top:1px'><img onclick='eh.upLoadCancle(" + data.length + ")' src='../../Util/Images/cancel_1.png' class='img_cancel_1'/></span></div><div class='bottom_message' style='overflow:auto; height:400px;'><div><table cellpadding='0' cellspacing='0' border='0' width='80%' style='margin-left:50px; text-align:left'><tr><td height='10px'></td></tr>" + html + "<tr style='text-algin:left;'><td height='10px'></td></tr></table></div></div><hr /><div style='float:left; margin-left:50px;color:red;font-size:28px'>*异常示数必须翻转或修改后才能保存!</div><div style='clear:both;float:none;'></div><hr /><div style='float:left; margin-left:50px;'><span onclick='eh.turnImgClick(this,1)' id='spanturnid1' style='font-size:36px; margin-right:20px;' class='img_enter_el'><img style='vertical-align: middle;' src='" + eh.unAddCheckBox1 + "' width='31' height='31'  id='overReturnID' />全选</span><span onclick='eh.turnImgClick(this,2)' id='spanturnid2' class='img_enter_el' style='font-size:36px;padding-left:25px;'><img style='vertical-align: middle;' width='31' height='31'  src='" + eh.unAddCheckBox1 + "' id='overUnreturnID'/>反选</span></div><div style='clear:both;float:none;'></div><img src='../../Util/Images/enter.png' class='img_enter_el' onclick='eh.overReturnChose()' /></div>");
	},
	turnImgClick : function(obj, type) {
		var img = $("#" + obj.id).find("img");
		$("#overReturnID").attr("src", eh.unAddCheckBox1);
		$("#overUnreturnID").attr("src", eh.unAddCheckBox1);
		img.attr("src", eh.AddCheckBox1);
		if(type == 1) {
			for(var i = 0; i < eo.NotOverReturn.length; i++) {
				$("#overReturn" + i).find("img").attr("src", eh.AddCheckBox1);
			}
		} else {
			for(var i = 0; i < eo.NotOverReturn.length; i++) {
				if($("#overReturn" + i).find("img").attr("src") == eh.AddCheckBox1) {
					$("#overReturn" + i).find("img").attr("src", eh.unAddCheckBox1);
				} else {
					$("#overReturn" + i).find("img").attr("src", eh.AddCheckBox1);
				}
			}
		}
	},
	returnLookType : function(i) {
		return this.lookPic;
	},
	changeReturn : function(i) {
		var img = $("#overReturn" + i).find("img");
		if(img.attr("src") == eh.unAddCheckBox1) {
			img.attr("src", eh.AddCheckBox1);
		} else {
			img.attr("src", eh.unAddCheckBox1);
		}
	},
	//确定翻转
	overReturnChose : function() {
		var t1 = [], t2 = [], t3 = [];
		eo.theOtherReturn = [];
		if(eo.NotOverReturn.length == 0) {
			if(eo.overReturn != 0) {
				t3 = eo.overReturn;
			}
		} else {
			for(var i = 0; i < eo.NotOverReturn.length; i++) {
				var img = $("#overReturn" + i).find("img");
				if(img.attr("src") == eh.AddCheckBox1) {
					t1.push(eo.typeValue1[eo.NotOverReturn[i]]);
					t2.push(eo.typeValue2[eo.NotOverReturn[i]]);
					eo.overReturn.sort();
					if((eo.overReturn).indexOf(eo.NotOverReturn[i]) == -1) {
						eo.overReturn.push(eo.NotOverReturn[i]);
					}
					$("#returnStyleID" + eo.NotOverReturn[i]).html("是");
				} else {
					//没有翻转的,但还是小于上次示数的
					eo.theOtherReturn.push(Number(eo.NotOverReturn[i]));
				}
			}
			t3 = eo.overReturn;
			eo.NotOverReturn = eo.theOtherReturn;
		}
		es.updateOverReturn(t1, t2, t3);
		$("#Pop_up_tops").hide();
		//o.openWait("已翻转,请再保存一次",0);

	},
	scanFromBrd : function(barcode) {
		//如果是扫描进来的,则进行电能表匹对
		for(var i = 0; i < this.scanData.length; i++) {
			for(var j = 0; j < JSON.parse(this.scanData[i]).mt.length; j++) {
				if(mpschemeArray[i].mt[j].asset_no == sessionStorage.barCodeInti) {
					electricClick(i, "electricAll" + i, j, 1);
					//o.openWait("",2);
					return;
				}
			}
		}
	},
	gotoArcgis : function() {
		var longit = mpschemeArray[sessionStorage.electMeas].longitude, latit = mpschemeArray[sessionStorage.electMeas].latitude;
		if(longit != "" && latit != "") {
			var value = {
				"ends_x" : [longit],
				"ends_y" : [latit]
			};
			multipointNavi(function(data) {
				//data.code==100成功
				if(data.code == "101") {
					o.openWait("定位失败,正在打开地图...", 0);
					setTimeout(function() {
						openMap()
					}, 2000);
				} else if(data.code == "102") {
					o.openWait("传递地图参数错误", 0);
					setTimeout(function() {
						openMap()
					}, 2000);
				}
			}, value);
		} else {
			openMap();
		}
	},
	historyIread : function(data) {
		var e = data; pend1 = "", pend2 = "", pend3 = "";
		var IREAD_PAP_R = {
			PAP_R : "正有功总",
			PAP_R1 : "正有功尖",
			PAP_R2 : "正有功峰",
			PAP_R3 : "正有功平",
			PAP_R4 : "正有功谷",
			PRP_R : "反有功总",
			PRP_R1 : "反有功尖",
			PRP_R2 : "反有功峰",
			PRP_R3 : "反有功平",
			PRP_R4 : "反有功谷",
			RAP_R : "正无功总",
			RAP_R1 : "正无功尖",
			RAP_R2 : "正无功峰",
			RAP_R3 : "正无功平",
			RAP_R4 : "正无功谷",
			RRP_R : "反无功总",
			RRP_R1 : "反无功尖",
			RRP_R2 : "反无功峰",
			RRP_R3 : "反无功平",
			RRP_R4 : "反无功谷"
		}
		for(var i = 0; i < e.length; i++) {
			for(var j in e[i]) {
				var P = j.split("_")[0];
				if(P == "PAP" || P == "PRP" || P == "RAP" || P == "RRP") {
					eh.funPend(i, IREAD_PAP_R[j], e[i][j]);
				}
			}
		}
		$("#Pop_up_tops").show();
		var html = "<div class='round_up_top'><div class='outpadding'><div class='bar_code_tm outshadow'><div class='top_headlinemge headtext'>历史抄表示数</div><div class='headdate'><ul class='float'>";
		for(var s=0;s<e.length;s++){
			html+="<li class='flex' onclick='eh.ChangeIreadDate(this,"+s+")'>" + e[s].DATA_DATE + "</li><li><img src='electricenergyoutside/images/border.png'></li>";
		}
		html+="</ul></div><div class='middleContent'><div class='middleInner'><ul id='changeIreadID'>" + pend1 + "</ul></div></div><div class='bottombtn' onclick='eh.closeIreadHistory()'><div>关　闭</div></div></div></div></div>";
		$("#Pop_up_tops").html(html);
	},
	funPend : function(s, key, value) {
		if(s == 0) {
			if(eo.read_type_code_all.indexOf(key) != -1) {
				pend1 += "<li class='irreadFloat'>" + key + ":" + (value == "" ? "" : value) + "</li>";
			}
		} else if(s == 1) {
			if(eo.read_type_code_all.indexOf(key) != -1) {
				pend2 += "<li class='irreadFloat'>" + key + ":" + (value == "" ? "" : value) + "</li>";
			}
		} else if(s == 2) {
			if(eo.read_type_code_all.indexOf(key) != -1) {
				pend3 += "<li class='irreadFloat'>" + key + ":" + (value == "" ? "" : value) + "</li>";
			}
		}
	},
	ChangeIreadDate : function(obj, type) {
		//切换日期
		$(obj).parent().find("li").removeClass('active');
		$(obj).addClass("active");
		if(type == 0) {
			$("#changeIreadID").html(pend1);
		} else if(type == 1) {
			$("#changeIreadID").html(pend2);
		} else if(type == 2) {
			$("#changeIreadID").html(pend3);
		}
	},
	closeIreadHistory : function() {
		$("#Pop_up_tops").hide();
	}
}