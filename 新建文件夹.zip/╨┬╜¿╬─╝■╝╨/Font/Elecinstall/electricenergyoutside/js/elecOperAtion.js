var elecOper=function(){
	this.pkg="";
	this.urlClose="../../Util/Images/checkboxoff.png";
	this.urlOpen="../../Util/Images/checkboxon.png";
	this.readyDoImg="electricenergyoutside/images/already.png";
	this.eoNot="electricenergyoutside/images/donePic.png";
	this.gotoBack="Businesslist/html/business_list.html";
	this.huoqu_arr=new Array();
	this.irread_id=new Array();
	this.irread_id_last=new Array();
	this.img_check_type=new Array();
	this.read_type_code_all=new Array();
	this.code_value=new Array();
	this.sect_value97=new Array();
	this.sect_value07=new Array();
	this.sect_value97_angle=new Array();
	this.sect_value07_angle=new Array();
	//电表示数位数
	this.digitArray=[];
	
	this.typeValue1=[];
	this.typeValue2=[];
	this.typeValue3=[];
	this.typeValue4=[];
	//记录远大于上次示数的记录
	this.remeberArray=[];
	//记录大于十万的示数记录
	this.remeberBigArray=[];
	//记录需要翻转的示数位置
	this.overReturn=[];
	//记录红外抄出来示数已经翻转过的示数
	this.readReturn=[];
	//记录不需要提示的翻转项
	this.NotOverReturn=[];
	//第一次选择翻转之后,剩下没翻转的
	this.theOtherReturn=[];
	//记录打印数据
	this.strArray=[];
	this.strArrayImage="";
	this.numberImg=0;
	this.rembGet=0;
	this.imageTrue=0;
}
elecOper.prototype={
	elecClickDown:function(username,app_no,ins_id){
		this.pkg='{"MOD":"02","FUN":"01","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG_TYPE":"0","PKG":{"USR":"'+username+'","APP_NO":"'+app_no+'","INSTANCE_ID":"'+ins_id+'","APP_INFO":"1","MP_SCHEME":"1","MT_SCHEME":"1","IT_SCHEME":"1","MT_BOX":"1","IRREAD":"1","DEVICE_PICTURE_FILES":"1"}}';
		send_data("0000","2002",this.pkg,eo.clickDown,eo.clickDownFail);
	},
	clickDown:function(data){
		data=JSON.parse(data);
		if(data.RET!="00"){
			if(data.RET=="01"){
				//会话失效,自动重新登录
				o.openWait("会话失效,需重新登录...",0);
				setTimeout(function(){
					window.location.replace("../../Platform/Login/html/welcome.html");
				},3000);
			}else{
				o.openWait(sa.getErrorCode(data.RET),0);
			}
		}else{
			if(data.PKG.RET!="01"){
				o.openWait(sa.getErrorMsg(data.PKG.RET),0);
			}else{
				if(data.PKG.PKG.URL){
					//数据包下载
					var sgets=data.PKG.PKG.URL.substring(data.PKG.PKG.URL.lastIndexOf("/")+1,data.PKG.PKG.URL.length).replace(".zip",".txt");
					sessionStorage.downfilename=sgets;
					donwloadAndZip(sessionStorage.DOWN_URL+"/"+data.PKG.PKG.URL,"",eo.inTheMpPage);
				}else{
					//数据下载
					if(data.PKG.PKG.MP_SCHEME==""){
						o.openWait("暂无计量数据！",0);
						es.updateDownType(sessionStorage.mpAppNo);
					}else{
						var num=0;
						var num_arr=new Array();
						for(var i in data.PKG.PKG){
							num++;
							if(num>=2){
								num_arr.push([i,data.PKG.PKG[i]]);
							}
						}
						eo.insertDb(num_arr);
					}
				}
			}
		}
		
	},
	inTheMpPage:function(zipmsg){
		if(zipmsg.msg==1){
			//包含的文件名
			 read(sessionStorage.downfilename,function(data){
			 	if(data.msg==1){
			 		var num=0;
						var num_arr=new Array();
						for(var i in JSON.parse(data.context)){
							num++;
							if(num>=2){
								num_arr.push([i,JSON.parse(data.context)[i]]);
							}
						}
						eo.insertDb(num_arr);
			 	}else{
			 		o.openWait("读取文件失败",0);
			 	}
			 })
		}else{
			switch(zipmsg.msg){
				case 2:
					o.openWait("表示下载数据包失败",0);
				break;
				case 3:
					o.openWait("解压数据包失败",0);
				break;
				case 4:
					o.openWait("删除压缩包失败",0);
				break;
				case 0:
					o.openWait("其他错误",0);
				break;
				case 5:
					o.openWait("服务器文件不存在",0);
				break;
				
			}
 		}
	},
	clickDownFail:function(){
		o.openWait("网络连接失败",0);
	},
	insertDb:function(pkg){
		var s1=[];
		for(var i=0;i<pkg.length;i++){
			var t=pkg[i][0];
			if(pkg[i][0]=="DEVICE_PICTURE_FILES"){
				t=pkg[i][0];
			}else{
				t="YX_"+pkg[i][0];
			}
			var temp=this.getInsertSql(t,pkg[i][1]);
			var tempData=temp.split(";");
			if(temp!=""){
				for(var j=0;j<tempData.length;j++){
					s1.push(tempData[j]);
				}
			}
		}
		db_batch_data("dbzj.db",s1,[],function(){
			es.selectElecAllData(sessionStorage.mpAppNo);
			es.updateDownType(sessionStorage.mpAppNo);
		},null);
	},
	getInsertSql:function(table,data){
		var values="";
		if(data.length!=0){
			for(var i=0;i<data.length;i++){
				var insert="insert into "+table+"(";
				var param="values(";
				var cloume=data[i];
				var k=0;
				for(var p in cloume){
					insert+=(p+",");
					param+="'"+cloume[p]+"',";
				}
				insert=insert.substring(0,insert.length-1);
				param=param.substring(0,param.length-1);
				values+=insert+") "+param+");";
				//values[i+1]=value;
				k=null;
				value=null;
				cloume=null;
			}
		}
		values=values.substring(0,values.length-1);
		return values;
	},
	doUserList:function(id,i){
		// var n=0;
		// n=$("#"+id).html();
		// n++;
		var n=Number($("#"+id).html());
		$("#"+id).html(n+1);
	},
	displayIrread:function(i,mtid){
		es.selectIrreadList(mtid);
	},
	//填充上装信息
	appendAppinfoPage:function(a,b){
		var e=b.rows.item;
		$("#emp_name_id").html(e(0).EMP_NAME);
		//$("#update").val(e(0).IR_DATE);
		$("#textarea_input").val(e(0).MEMO);
	},
	//获取电能表示数
	getIrread:function(a,b){
		var len = b.rows.length;
		var e = b.rows.item;
		sessionStorage.allUftyI=len;
		eh.clearArray();
		eo.readReturn=[];
		for(var i=0;i<len;i++){
			eo.huoqu_arr[i]=e(i).this_read;
			eo.irread_id[i]=e(i).meter_scheme_id;
			eo.irread_id_last[i]=e(i).last_read;
			eo.img_check_type[i]=e(i).excp_handle_code;
			eo.read_type_code_all[i]=e(i).read_type_code;
			eo.code_value[i]=e(i).value;
			eo.sect_value97[i]=e(i).content2;
			eo.sect_value07[i]=e(i).content4;
			eo.sect_value97_angle[i]=e(i).content1;
			eo.sect_value07_angle[i]=e(i).content3;
			//记录抄表限制位数
			eo.digitArray[i]=e(i).mr_digit;
		}
		$("#pop").slideDown();
		eh.all_ufty(len);
	},
	//修改电能表示数
	modifyAmmeter:function(len){
		if(len!=0){
			//如果是关闭翻转提示框之后再点确定来保存示数
			if(returnFlag==1){
				if(eo.theOtherReturn.length!=0){
					//o.openWait("请选择需要翻转的示数",0);
					//如果还有没有翻转的示数，则再提进行翻转
					eh.appendOverReturn(eo.theOtherReturn);
					return;
				}else{
					o.openWait("正在保存....",1);
					eo.check2(len);
					return;
				}
				return;
			}
			this.remeberArray=[];
			this.remeberBigArray=[];
			this.clearIrread();
			//eo.overReturn=[];
			eo.NotOverReturn=[];
			for(var i=0;i<len;i++){
				$("#style_new_check"+this.sect_value97_angle[i]).css("border","");
				if($("#style_new_check" + this.sect_value97_angle[i]).val() ==""){
					$("#style_new_check" + this.sect_value97_angle[i]).css("border","1px solid red");
					o.openWait("本次示数不能为空",0);
					return;
				}
				if(parseFloat($("#style_new_check" + this.sect_value97_angle[i]).val())<parseFloat(eo.irread_id_last[i])){
					if($("#bo_divter"+i).html().indexOf("需量")==-1){
						$("#style_new_check" +this.sect_value97_angle[i]).css("border","1px solid red");
						if((eo.readReturn).indexOf(this.sect_value97_angle[i])!=-1){
							//记录通过扫描翻转的示数
							eo.overReturn.push(i);
						}else{
							eo.NotOverReturn.push(i);
						}
					}else{
						o.openWait("友情提示:"+$("#bo_divter"+i).html()+"示数小于上次示数!",0);
					}
				}
				if(parseFloat($("#style_new_check" +this.sect_value97_angle[i]).val())>parseFloat(eo.irread_id_last[i])*2){
					if(parseFloat($("#style_new_check" +this.sect_value97_angle[i]).val())>100000){
						this.remeberBigArray.push($("#bo_divter"+i).html());
					}else{
						this.remeberArray.push($("#bo_divter"+i).html());
					}
				}
				this.typeValue1[i]=eo.irread_id[i];
				this.typeValue2[i]=eo.read_type_code_all[i];
				this.typeValue3[i]=$("#style_new_check" + this.sect_value97_angle[i]).val();
			}
			//如果示数小于上次示数，并且没有翻转的，则弹出需要翻转的提示框
			eo.tter(eo.NotOverReturn,len);
		}else{
			sessionStorage.newChgDesc=undefined;
			$("#pop").hide();
		}
	},
	tter:function(data,len){
		//判断是否有翻转的
		for(var i=0;i<data.length;i++){
			if($("#returnStyleID"+data[i]).html()=="是"){
				eo.NotOverReturn.splice(i,1);
				i--;
			}
		}
		if(eo.NotOverReturn.length!=0){
			//o.openWait("请选择需要翻转的示数",0);
			returnFlag=1;
			eh.appendOverReturn(eo.NotOverReturn);
		}else{
			o.openWait("正在保存....",1);
			returnFlag=0;
			if(eo.remeberArray!=""){
				navigator.notification.confirm("("+eo.remeberArray+")示数远大于上次示数,是否继续？", function(index) {
					if (index == 1) {
						eo.check2(len);
					}else{
						o.openWait("取消保存",0,2);
					}
				},"温馨提示","是,否");
			}else{
				eo.check2(len);
			}
		}
	},
	changeOverReturn:function(len){
		//如果是红外读取并翻转的,则做翻转处理
		if(eo.overReturn.length!=0){
			eo.check2(len);
		}else{
			if(eo.remeberArray!=""){
				navigator.notification.confirm("("+eo.remeberArray+")示数远大于上次示数,是否继续？", function(index) {
					if (index == 1) {
						eo.check2(len);
					}else{
						o.openWait("取消保存",0,2);
					}
				},"温馨提示","是,否");
			}else{
				eo.check2(len);
			}
		}
	},
	check2:function(len){
		var miq=eo.CheckIrreadRigid(len);
		if(miq!=""){
			navigator.notification.confirm(miq+",请核查示数是否异常,如无异常请继续!", function(index) {
				if (index == 1) {
					$("#pop").hide();
					sessionStorage.newChgDesc=undefined;
					es.operIrread(eo.typeValue1,eo.typeValue2,eo.typeValue3,eo.typeValue4);
				}else{
					o.openWait("取消保存",0,2);
					return ;
				}
			},"温馨提示","是,否");
		}else{
			$("#pop").hide();
			sessionStorage.newChgDesc=undefined;
			es.operIrread(eo.typeValue1,eo.typeValue2,eo.typeValue3);
		}
	},
	//示数强力验证
	CheckIrreadRigid:function(len){
		var s1=[],s2=[],s3=[],s4=[],s5=[],errAr=[];
		for(var i=0;i<len;i++){
			if($("#bo_divter"+i).html().indexOf("正有")!=-1)
				s1.push($("#bo_divter"+i).html());
			else if($("#bo_divter"+i).html().indexOf("正无")!=-1)
				s2.push($("#bo_divter"+i).html());
			else if($("#bo_divter"+i).html().indexOf("反有")!=-1)
				s3.push($("#bo_divter"+i).html());
			else if($("#bo_divter"+i).html().indexOf("反无")!=-1)
				s4.push($("#bo_divter"+i).html());
			else if($("#bo_divter"+i).html().indexOf("需量")!=-1)
				s5.push($("#bo_divter"+i).html());
		}
		var arv=0;
		if(s1!=""){
			arv++;
			check(s1);
		}
		if(s2!=""){
			arv++;
			check(s2);
		}
		if(s3!=""){
			arv++;
			check(s3);
		}
		if(s4!=""){
			arv++
			check(s4);
		}
		if(s5!=""){
			arv++
			check(s5);
		}
		function check(obj){
			var zong="",other=[],sum=0,name="",others=[],sums=0;
			for(var i=0;i<obj.length;i++){
				var tempD=Number((arv-1)*obj.length)+Number(i);
				if(obj[i].indexOf("总")!=-1){
					name=obj[i];
					zong=$("#style_new_check"+eo.sect_value97_angle[tempD]).val();
				}else{
					other.push($("#style_new_check"+eo.sect_value97_angle[tempD]).val());
					others.push($("#style_new_checks"+tempD).val());
				}
			}
			for(var i=0;i<other.length;i++){
				sum+=Number(other[i]);
			}
			for(var i=0;i<others.length;i++){
				sums+=Number(others[i]);
			}
			if(sum!=0){
				sum=sum.toFixed(2);
			}
			if(sum==0&&other.length==0){
				return;
			}else{
				if(!(sum==0&&sums==0)){
					//如果上次示数和本次示数其他值相加都为零，则不处理
					if(zong-sum<0||zong-sum>0.1){
						errAr.push("["+name.replace("总","")+"]示数异常");
					}
				}
			}
			
		}
		return errAr;
	},
	//采用上次示数
	setLastData:function(len){
		$("#confirm_the_same").show();
	},
	modifyAmmeter1:function(scheme){
		//保存新增电表资产号
		var old_asset_no = sessionStorage.amIput == undefined ? '' : sessionStorage.amIput;
		if($("#modify_mtscheme").val()==""){
			o.openWait("资产编号不能为空！",0);
		}else{
			sessionStorage.newChgDesc=undefined;
			es.updateModifyNew($("#modify_mtscheme").val(), scheme, old_asset_no);
			//修改电表之后,添加到扫描事件里面去sessionStorage.ammeterI,sessionStorage.ammeterJ
			mpschemeArray[sessionStorage.ammeterI].mt[sessionStorage.ammeterJ].asset_no=$("#modify_mtscheme").val();
		}
	},
	//拍照
	cameraPhoto:function(mpschemID,asset){
		dbzj_camera_photo({"suffix":".jpg","childFolder":"/photo/2002/"+eo.proImgOrg(sessionStorage.ORG_NO)+"/"+asset +"/","childName":asset+"_","JSFUN":"save_photo"},null, null);
	},
	proImgOrg:function(e){
		if(e.length > 5)
			return e.substring(0, 5);
		else
			return e;
	},
	openPrint:function(i){
		es.selectIrreadPrint(sessionStorage.mpAppNo);
	},
	printSet1:function(a,b){
		var e=b.rows.item;
		if(b.rows.length!=0){
			sessionStorage.irDate=e(0).ir_date;
			es.selectIrreadPrint2(sessionStorage.mpSchemeID);
		}
		
	},
	readIrreadType:function(){
		$("#tc").html("");
		lostIrread=[];
		if($('#waitlogin').css('display')=="block"){
			return;
		}
		testDataappend="";
		var asset_no_07_dbzj ="",asset_no_97_dbzj ="",asset_no_97_dbzj_angle="",asset_no_07_dbzj_angle="",sect_value = "",meter_addr="",fanyou07="",fanyou97="";
		meter_addr=(sessionStorage.barCodeInti).replace(/[a-z|A-Z]/g, "0");
		for(var i=0;i<this.sect_value97.length;i++){
			if(this.sect_value97[i] != sect_value){
				asset_no_97_dbzj +=((i==0)?"":",")+ this.sect_value97[i];
				sect_value = this.sect_value97[i];
				asset_no_07_dbzj +=((i==0)?"":",")+ this.sect_value07[i];
			}
		}
		for(var j=0;j<this.sect_value97_angle.length;j++){
			if(this.sect_value97_angle[j] != sect_value){
				asset_no_97_dbzj_angle +=((j==0)?"":",")+ this.sect_value97_angle[j];
				sect_value = this.sect_value97_angle[j];
				asset_no_07_dbzj_angle +=((j==0)?"":",")+ this.sect_value07_angle[j];
			}
		}
		if(asset_no_07_dbzj.indexOf("0002FF00")==-1){
			fanyou07="00020000";
		}else{
			fanyou07="";
		}
		if(asset_no_97_dbzj.indexOf("902F")==-1){
			fanyou97="9020";
		}else{
			fanyou97="";
		}
		o.openWait("正在读取示数...",1);
		// setTimeout(function(){
			// o.openWait("正在读取示数...",0);
		// },10000)
		send_Bt_Instruct_New('{"nameSpace":"testJs","code07":"'+asset_no_07_dbzj+','+fanyou07+'","code97":"'+asset_no_97_dbzj+','+fanyou97+'","address":"00'+meter_addr+'"}',null,null);
		
	},
	getIrreadDate:function(a,b){
		var len=b.rows.length;
		var e=b.rows.item;
		var arr = "     电能计量装置装拆工单,户    名：" + sessionStorage.mpUserName + ",装拆日期：" + $("#update").val() + ",户    号：" + sessionStorage.mpConsNo + ",用电地址：" + sessionStorage.mpUserAddr + ",计量方式：" + sessionStorage.measMode + ",\n";
		var readNewOld="";
		for(var i=0;i<len;i++){
			if(e(i).chg_desc=="新增"){
				arr += "装    拆: " + e(i).chg_desc + ",资产编号：" + e(i).asset_no + ",表 类 型：" + e(i).sort_code + ",电    压：" + e(i).volt_code + ",电    流：" + e(i).current_code + ",";
			}else{
				if((e(i).read_type_code).indexOf("总")!=-1){
					readNewOld+=e(i).read_type_code+",     上次示数: " + e(i).last_read + ",     本次示数: " +e(i).this_read + ",";
				}
			}
		}
		arr += readNewOld+"\n装拆人员签名：\n\n,用户签名：\n,      " + sessionStorage.area;
		printer_info(arr, function(e) {
			//打印成功
			if(e.msg == 1){
				sessionStorage.printer = e.conn ;
				if(e.conn == 1){
					sessionStorage.scan = 0 ;
				}
			}
		});
	},
	//上装
	operAtionUpload:function(){
		if($("#uploadInfoType1").attr("src")==this.urlOpen){
			$("#uplogin").slideUp();
			//信息上装
			this.operFinsh();
		}
		if($("#uploadInfoType2").attr("src")==this.urlOpen&&$("#uploadInfoType1").attr("src")==this.urlClose&&$("#uploadInfoType3").attr("src")==this.urlClose){
			//图片上装
			$("#uplogin").slideUp();
			eo.UpLoadImageUrl();
		}
		if($("#uploadInfoType3").attr("src")==this.urlOpen && $("#uploadInfoType1").attr("src")==this.urlClose){
			this.referInfos();
			$("#uplogin").slideUp();
		}
		if($("#uploadInfoType1").attr("src")==this.urlClose&&$("#uploadInfoType2").attr("src")==this.urlClose && $("#uploadInfoType3").attr("src")==this.urlClose){
			o.openWait("没有上装选项",0);
		}
	},
	selectImgTimeSuccess:function(a,b){
		var e = b.rows.item;
		if(b.rows.length==0) {
			o.openWait("没有可下载图片!",0);
			return;
		}
		var datatime = (e(0).file_create_time).split(" ")[0];
		var timeyear = datatime.split("-")[0];
		var timemonth = datatime.split("-")[1];
		var timeday = datatime.split("-")[2];
		eo.downloadImages(timeyear,timemonth,timeday);
	},
	StatSuccess:function(a,b){
		var do1=0,do2=0,number=0;
		if(b.rows.length>0){
			var e=b.rows.item;
			do1=e(0).allcount;
			do2=e(0).docount;
			$("#doid").html(e(0).docount);
			$("#usercountid").html(e(0).allcount);
		}
		for(var i=0;i<mpschemeArray.length;i++){
			if($("#readyDo"+i).attr("src")==eo.eoNot){
				//已上装
				number++;
			}
		}
		eh.appendChoseCount(do1,do2,number);
		//$("#uprealid").html(number);
	},
	downloadImages:function(timeyear,timemonth,timeday){
		var pkg = "{'MOD':'00','FUN':'03','ORG_NO':'" + sessionStorage.ORG_NO + "','PKG':{'NAME':'" + sessionStorage.amIput + "_.jpg','URL':'" + eo.proImgOrg(sessionStorage.ORG_NO) + '/2002/' + timeyear + "/" + timemonth + "/" + timeday + "/" + sessionStorage.mpAppNo + "/'}}";
		send_data("0000", "2002", pkg, function(res) {
			var r = JSON.parse(res);
			if(r.PKG.RET == "00") {
				download(eo.proImgOrg(sessionStorage.ORG_NO) + '/2002/' + timeyear + "/" + timemonth + "/" + timeday + "/" + sessionStorage.mpAppNo + "/" + sessionStorage.amIput + "_.jpg", "/mnt/sdcard/photo/2002/" + eo.proImgOrg(sessionStorage.ORG_NO) + "/" + sessionStorage.amIput + "/", function(res) {
					if(res == 4) {
						o.openWait("服务器没有文件",0);
					} else if(res == 0) {
						o.openWait("网络连接失败!",0);
					} else if(res == 1) {
						o.openWait("图片下载成功",0);
						$("#imgLooklist" + sessionStorage.electMeas).attr("src", "../../Util/Images/but_ck01.png");

						getGallery({
							"path" : "/photo/2002/" + eo.proImgOrg(sessionStorage.ORG_NO) + "/" + sessionStorage.amIput + "/",
							"JSFUN" : "check_ptsuccess"
						},null, null);
					}
				});
			} else {
				o.openWait(r.PKG.PKG.MSG,0);
			}
		}, function(err) {
			o.openWait("网络连接失败，请重试",0);
		})
	},
	UpLoadImageUrl:function(){
		if($("#uploadInfoType1").attr("src")==this.urlOpen){
			this.imageTrue=1;
		}else{
			this.imageTrue=0;
		}
		this.rembGet=0;
		eo.strArrayImage=[];
		eo.tempFun();
		es.devicePicture(sessionStorage.mpAppNo,tempAddCeckArray,sessionStorage.countChose);
	},
	gotoOpGetAsset:function(a,b){
		if(b.rows.length>0){
			o.openWait("图片上装中...",1);
			var e=b.rows.item;
			eo.strArray=[];
			eo.strArrayImage=[];
			for(var i=0;i<b.rows.length;i++){
				eo.strArrayImage.push('{"NAME":"' + e(i).asset_no + '_.jpg",' + '"path":"2002/' + eo.proImgOrg(sessionStorage.ORG_NO) + '/' + e(i).asset_no + '","INFO":"' + eo.proImgOrg(sessionStorage.ORG_NO) + '/2002/' + sessionStorage.mpAppNo + '"}');
			}
			//eo.strArrayImage=eo.strArrayImage.substring(0,eo.strArrayImage.length-1);
			var data = '{"FUN":"02","ORG_NO":"' + sessionStorage.ORG_NO + '","MOD":"2002",' + '"SSN":"' + sessionStorage.SSN + '","FILE":' + '['+eo.strArrayImage+']}';
			uploadImage(data, eo.forUploadImg);
		}
	},
	forUploadImg:function(e){
		if(eo.imageTrue==1){
			//信息选中状态
			if(e.msg=="0"){
				o.openWait("上传服务器失败!数据上装中...",1);
			}else if(e.msg=="2"){
				o.openWait("暂无对应上装图片,数据上装中...",1);
			}else if(e.msg=="3"){
				o.openWait("网络连接失败!",0);
			}else{
				//e={"REQ":"1","RET":"99"}
				if(e.RET=="00"){
					o.openWait(e.PKG.MSG+",信息上装中...",1);
				}else{
					o.openWait("文件上装失败,信息上装中...",1);
				}
			}
		}else if(eo.imageTrue==0){
			//信息没有选中状态
			if(e.msg=="0"){
				o.openWait("上传服务器失败!",0);
			}else if(e.msg=="2"){
				o.openWait("暂无对应上装图片！",0);
			}else if(e.msg=="3"){
				o.openWait("网络连接失败!",0);
			}else{
				if(e.RET=="00"){
					o.openWait(e.PKG.MSG,0);
				}else{
					o.openWait("图片上装失败",0);
				}
			}
		}
		eo.imageTrue=0;
	},
	operFinsh:function(){
		o.openWait("数据正在上装....",1);
		es.updateAppInfos([$("#update").val(),$("#textarea_input").val(),sessionStorage.mpAppNo]);
	},
	returnAppInfos:function(){
		eo.tempFun();
		es.getUpLoadinfos(sessionStorage.mpAppNo,tempAddCeckArray,sessionStorage.countChose);
	},
	tempFun:function(){
		tempAddCeckArray=[];
		if($("#dropUl2").css("display")=="block"){
			for(var i=0;i<mpschemeArray.length;i++){
				if($("#addCheck"+i).find("img").attr("src")==eh.AddCheckBox1){
					tempAddCeckArray.push(mpschemeArray[i].mp_scheme_id);
				}
			}
		}else{
			for(var i=0;i<mpschemeArray.length;i++){
				tempAddCeckArray.push(mpschemeArray[i].mp_scheme_id);
			}
		}
	},
	//上装报文
	upLoadDateImgInfos:function(){
		var getinfos1="",getinfos2="",infoirread="",infomtscheme="",infoitscheme="",infobox="";
		
		for(var i=0;i<getUpBoxScheme.length;i++){
			if(getUpBoxScheme[i].CONTAINER_ASSET_NO==""){
				eo.imageTrue=0;
				o.openWait("上装信息中,计量箱编号不能为空",0);
				return;
			}
			if (getUpBoxScheme[i].OLD_ASSET_NO == undefined) {
				getUpBoxScheme[i].IS_UPDATE = '0';
			} else if (getUpBoxScheme[i].CONTAINER_ASSET_NO != getUpBoxScheme[i].OLD_ASSET_NO||getUpBoxScheme[i].OLD_ASSET_NO=="") {
				getUpBoxScheme[i].IS_UPDATE = '1';
			} else {
				getUpBoxScheme[i].IS_UPDATE = '0';
			}
		}
		for(var j=0;j<getUpMtScheme.length;j++){
			if(getUpMtScheme[j].ASSET_NO==""){
				eo.imageTrue=0;
				o.openWait("上装电能表资产号不能为空！",0);
				return;
			}
			if (getUpMtScheme[j].CHG_DESC == '01') {
				// alert('getUpMtScheme[j].OLD_ASSET_NO: ' + getUpMtScheme[j].OLD_ASSET_NO);
				// alert('getUpMtScheme[j].ASSET_NO : ' + getUpMtScheme[j].ASSET_NO);
				// alert(getUpMtScheme[j].ASSET_NO == getUpMtScheme[j].OLD_ASSET_NO);

				if (getUpMtScheme[j].OLD_ASSET_NO == undefined) {
					getUpMtScheme[j].IS_UPDATE = '0';
				}else if(getUpMtScheme[j].OLD_ASSET_NO==""){
					getUpMtScheme[j].IS_UPDATE = '1';
				} else if (getUpMtScheme[j].ASSET_NO != getUpMtScheme[j].OLD_ASSET_NO) {
					getUpMtScheme[j].IS_UPDATE = '1';
				} else {
					getUpMtScheme[j].IS_UPDATE = '0';
				}
			}
			// alert('上装电能表: ' + JSON.stringify(getUpMtScheme[j]));
		}
		for(var i=0;i<getUpItScheme.length;i++){
			if(getUpItScheme[i].ASSET_NO==""){
				eo.imageTrue=0;
				o.openWait("上装互感器资产号不能为空！",0);
				return;
			}
			if (getUpItScheme[i].OLD_ASSET_NO == undefined) {
				getUpItScheme[i].IS_UPDATE = '0';
			} else if (getUpItScheme[i].ASSET_NO != getUpItScheme[i].OLD_ASSET_NO||getUpItScheme[i].OLD_ASSET_NO=="") {
				getUpItScheme[i].IS_UPDATE = '1';
			} else {
				getUpItScheme[i].IS_UPDATE = '0';
			}
			// alert('上装互感器: ' + JSON.stringify(getUpItScheme[i]));
		}
		if($("#update").val()=="请输入上装日期"){
			eo.imageTrue=0;
			o.openWait("上装日期不能为空!",0);
			return;
		}
		for(var i=0;i<getUpIrread.length;i++){
			if(getUpIrread[i].THIS_READ==""){
				eo.imageTrue=0;
				o.openWait("上装示数不能为空!",0);
				return;
			}
		}
		//是否为空
		if(getUpGpsInfos==""){
			getinfos1='';
		}else{
			getinfos1=','+'"MPGPS_INFOS":' + JSON.stringify(getUpGpsInfos);
		}
		if(getUpDevinfos==""||$("#uploadInfoType2").attr("src")==eo.urlClose){
			getinfos2='';
		}else{
			getinfos2=','+'"DEVICE_PICTURE_FILES":' + JSON.stringify(getUpDevinfos);
		}
		if(getUpMtScheme==''){
			infomtscheme="";
			// alert('infomtscheme: ' + infomtscheme);
		}else{
			infomtscheme=','+'"MT_SCHEME":' + JSON.stringify(getUpMtScheme);
			// alert('infomtscheme: ' + infomtscheme);
		}
		if(getUpItScheme==''){
			infoitscheme='';
			// alert('infoitscheme: ' + infoitscheme);
		}else{
			infoitscheme=','+'"IT_SCHEME":' + JSON.stringify(getUpItScheme);
			// alert('infoitscheme: ' + infoitscheme);
		}
		if(getUpBoxScheme==""){
			infobox='';
		}else{
			infobox=','+'"MT_BOX":' + JSON.stringify(getUpBoxScheme);
		}
		if(getUpIrread==""){
			infoirread='';
		}else{
			infoirread=','+'"IRREAD":' + JSON.stringify(getUpIrread);
		}
		if(localStorage.CHECKIREADUP==""||!localStorage.CHECKIREADUP){
			modifyRead='';
		}else{
			var t=JSON.parse(localStorage.CHECKIREADUP),tcheck=[];
			for(var j=0;j<t.length;j++){
				if(t[j].APP_NO==sessionStorage.mpAppNo){
					tcheck.push(t[j]);
				}
			}
			modifyRead=','+'"CHECK_IREAD":' + JSON.stringify(tcheck);
		}
		if(getUpMtScheme==''&&getUpItScheme==''&&getUpBoxScheme==""&&getUpIrread==""){
			eo.imageTrue=0;
			o.openWait("没有可上装用户信息,请处理用户之后再上装！",0);
			return;
		}

		//验证没有问题,则进行图片是否上装功能
		if($("#uploadInfoType2").attr("src")==this.urlOpen){
			//图片上装
			eo.imageTrue=1;
			$("#uplogin").slideUp();
			eo.UpLoadImageUrl();
		}
		var pkg = '{"MOD":"02","FUN":"02","ORG_NO":"' + sessionStorage.ORG_NO + '","PKG_TYPE":"0","PKG":{"USR":"' + sessionStorage.user_name + '","APP_NO":"' + sessionStorage.mpAppNo +'","INFLAT":"0","APP_INFO":' + JSON.stringify(getUpAppInfo) + infomtscheme + infoitscheme + infobox + infoirread + getinfos1 + getinfos2 +modifyRead+'}}';
		send_data("0000","2002",pkg,eo.upLoadCallBack,function(){
			o.openWait("上装失败，网络连接失败",0);
			//更改上装状态,1:上装成功;2:上装失败;3:已上装 提交工作流失败;
			es.updateTypeUpload(sessionStorage.mpAppNo,2);
		});
	},
	//信息上装调用方法
	upLoadCallBack:function(data){
		data=JSON.parse(data);
		if(data.RET!="00"){
			if(data.RET=="01"){
				//会话失效,自动重新登录
				o.openWait("会话失效,需重新登录...",0);
				setTimeout(function(){
					window.location.replace("../../Platform/Login/html/welcome.html");
				},3000);
			}else{
				o.openWait(sc.getErrorCode(data.RET),0,3);
			}
			//修改上装状态为失败
			//更改上装状态,1:上装成功;2:上装失败;3:已上装 提交工作流失败;
			es.updateTypeUpload(sessionStorage.mpAppNo,2);
		}else{
			if(data.PKG.RET!="01"){
				//sc.getMsgCode(str.RET)
				o.openWait(data.PKG.PKG.MSG,0);
				//更改上装状态,1:上装成功;2:上装失败;3:已上装 提交工作流失败;
				es.updateTypeUpload(sessionStorage.mpAppNo,2);
			}else{
				// //修改上装状态为已上装
				 if($("#uploadInfoType3").attr("src")==eo.urlOpen){
					// //工作流提交
					 o.openWait("上装成功,正在提交工作流....",1);
					// eo.referInfos();
				 }else{
				 	if(eo.imageTrue==1){
				 		o.openWait(data.PKG.PKG.MSG+"图片上装中...",1);
				 	}else{
					 	o.openWait(data.PKG.PKG.MSG,0,3);
				 	}
				 }
				//上装成功，更改为工单为上装状态
				es.tempReadyUploadId(sessionStorage.mpAppNo,tempAddCeckArray,sessionStorage.countChose);
				//更改上装状态,1:上装成功;2:上装失败;3:已上装 提交工作流失败;
				es.updateTypeUpload(sessionStorage.mpAppNo,1);
				
				for (var i = 0; i < getUpBoxScheme.length; i++) {
					var sql = "update yx_mt_box set old_asset_no='" + getUpBoxScheme[i].CONTAINER_ASSET_NO + "' where  container_asset_no='" + getUpBoxScheme[i].CONTAINER_ASSET_NO + "' and mp_scheme_id='" + getUpBoxScheme[i].MP_SCHEME_ID + "'";
					db_execut_oneSQL("dbzj.db", sql, [], null, null);
				}
				for (var m = 0; m < getUpMtScheme.length; m++) {
					var mtsql = "update yx_mt_scheme set old_asset_no='" + getUpMtScheme[m].ASSET_NO + "' where asset_no='" + getUpMtScheme[m].ASSET_NO + "' and id=" + getUpMtScheme[m].ID;
					db_execut_oneSQL("dbzj.db", mtsql, [], null, null);
				}
				for (var n = 0; n < getUpItScheme.length; n++) {
					var itsql = "update yx_it_scheme set old_asset_no='" + getUpItScheme[n].ASSET_NO + "' where asset_no='" + getUpItScheme[n].ASSET_NO + "'";
					db_execut_oneSQL("dbzj.db", itsql, [], null, null);
				}
			}
		}
		eo.imageTrue=0;
	},
	//提交工作流
	referInfos:function(){
		//查询上装人员信息
		es.selectBeforeAppInfos([$("#update").val(),$("#textarea_input").val(),sessionStorage.mpAppNo],sessionStorage.mpAppNo);
	},
	TODOreferInfos:function(a,b){
		var len=b.rows.length,e=b.rows.item;
		if(len>0){
			getUpAppInfo=[];
			for(var i = 0; i < len; i++) {
				getUpAppInfo[i] = e(i);
			}
		}
		//如果没有全部上装则不予提交工作流
		var getUpItNumber=0;
		for(var i=0;i<mpschemeArray.length;i++){
			if($("#readyDo"+i).attr("src")==eh.upIt){
				getUpItNumber++;
			}
		}
		if(getUpItNumber<mpschemeArray.length){
			o.openWait("工单没有全部上装，不能提交工作流",0);
			return;
		}
		o.openWait("工作流提交中...",1);
		//return;
		var pkgInstance='{"MOD":"01","FUN":"03","PKG_TYPE":"0","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"USR":"' + sessionStorage.user_name + '","APP_NO":"' + sessionStorage.mpAppNo + '","ORG_NO":"'+sessionStorage.ORG_NO+'","INSTANCE_ID":"'+sessionStorage.instanceIdDb+'","APP_INFO":'+JSON.stringify(getUpAppInfo)+'}}';
		send_data("0000", "2002", pkgInstance, function(e){
			var str_gzl = JSON.parse(e);
			if(str_gzl.RET!="00"){
				if(str_gzl.RET=="01"){
					//会话失效,自动重新登录
					o.openWait("会话失效,需重新登录...",0);
					setTimeout(function(){
						window.location.replace("../../Platform/Login/html/welcome.html");
					},3000);
				}else{
					o.openWait(sc.getErrorCode(str_gzl.RET),0,3);
					//更改上装状态,1:上装成功;2:上装失败;3:已上装 提交工作流失败;
					es.updateTypeUpload(sessionStorage.mpAppNo,3);
				}
			}else{
				if(str_gzl.PKG.RET!="01"){
					o.openWait(str_gzl.PKG.PKG.MSG,0,3);
					//更改上装状态,1:上装成功;2:上装失败;3:已上装 提交工作流失败;
					es.updateTypeUpload(sessionStorage.mpAppNo,3);
				}else{
					eo.imageTrue=2;
					o.openWait(str_gzl.PKG.PKG.MSG,0);
					//工作流提交成功之后删除相关数据
					setTimeout(function(){
						es.deleteDoneUserList(sessionStorage.mpAppNo);
						changepage("Businesslist/html/business_list.html");
					},2000);
					
				}
			}
		}, function(){
			o.openWait("提交工作流失败，请重新提交！",0);
		});
	},
	setCheckBox:function(i){
		sessionStorage.srcNum=i;
		//i=1,信息上装;i=2,图片上装;3,工作流提交
		var doc=$("#uploadInfoType"+i);
		if(doc.attr("src")==this.urlClose){
			doc.attr("src",this.urlOpen);
		}else{
			doc.attr("src",this.urlClose);
		}
	},
	getTypeofType:function(a,b){
		var e=b.rows.item;
		var supload_type=e(0).UPLOAD_TYPE;
		if(supload_type!=1){
			o.openWait("该工单没有上装过,不能提交<br/>请同时选择信息上装",0);
		}else{
			if($("#uploadInfoType"+sessionStorage.srcNum).attr("src")==eo.urlClose){
				$("#uploadInfoType"+sessionStorage.srcNum).attr("src", eo.urlOpen);
			}else{
				$("#uploadInfoType"+sessionStorage.srcNum).attr("src", eo.urlClose);
			}
		}
	},
	//设置上装时间
	setLoadTime:function(){
		get_sx_date(this.setTimeBack,this.setTimeBack);
	},
	setTimeBack:function(e){
		if(e == 0) {
			$("#update").val("请输入上装日期");
		} else {
			var data=new Date(),t1=e;
			var t2=data.getFullYear()+"-"+((data.getMonth()+1)<10?"0"+(data.getMonth()+1):(data.getMonth()+1))+"-"+(data.getDate()<10?"0"+data.getDate():data.getDate());
			t1=t1.replace(/\-/g,"");
			t2=t2.replace(/\-/g,"");
			var t3=Number(t1)-Number(t2);
			if(t3>0){
				o.openWait("上装时间不能大于当前日期！",0);
			}else{
				$("#update").val(e);
			}
		}
	},
	changeImgToUpDone:function(){
		//上装之后工单更改为已上装状态
		//sessionStorage.countChose
		var j=0;
		if($("#dropUl2").css("display")!="block"){
			for(var i=0;i<mpschemeArray.length;i++){
				if($("#readyDo"+i).attr("src")==this.readyDoImg){
					j++;
					if(j<=sessionStorage.countChose){
						$("#readyDo"+i).attr("src",this.eoNot);
						//var ert=$("#electricenergyoutsid_ins_name_numbers").html();
						//ert--;
						//$("#electricenergyoutsid_ins_name_numbers").html(ert);
					}
				}
			}
		}else{
			var j=0;
			for(var i=0;i<mpschemeArray.length;i++){
				if($("#readyDo"+i).attr("src")==this.readyDoImg){
					if($("#addCheck"+i).find("img").attr("src")==eh.AddCheckBox1){
						$("#readyDo"+i).attr("src",this.eoNot);
						//var ert=$("#electricenergyoutsid_ins_name_numbers").html();
						//ert--;
						//$("#electricenergyoutsid_ins_name_numbers").html(ert);
						$("#addCheck"+i).find("img").attr("src",eh.unAddCheckBox1);
					}
				}
			}
		}
		//修改上装状态为已上装
		if($("#uploadInfoType3").attr("src")==eo.urlOpen){
			//工作流提交
			o.openWait("上装成功,正在提交工作流....",1);
			eo.referInfos();
		}
	},
	//路径规划
	pathMark:function(data){
		//{ends_x:[118.850236,118.790584,118.8800254],ends_y:[31.950253,32.019990,31.330220]}
		var strx=[],stry=[],comparex=[],comparey=[],sdat=[];
		sessionStorage.sessGpsXy='{"ends_x":[],"ends_y":[]}';
		for(var i=0;i<data.length;i++){
			if(i<10){
				if(data[i].split("-")[2]!=2){
					if(data[i].split("-")[0]!=""){
						if(comparex.indexOf(data[i].split("-")[0])==-1&&comparey.indexOf(data[i].split("-")[1])==-1){
							strx.push(data[i].split("-")[0]);
							stry.push(data[i].split("-")[1]);
							comparex.push(data[i].split("-")[0]);
							comparey.push({"name":""+mpschemeArray[data[i].split("-")[3]].cons_name+"","address":""+mpschemeArray[data[i].split("-")[3]].mp_addr+"",x:data[i].split("-")[0],y:data[i].split("-")[1],"no":""+mpschemeArray[data[i].split("-")[3]].cons_no+"","index":i,"type":""});
							comparey.push(data[i].split("-")[1]);
						}
						//sdat.push({"name":""+mpschemeArray[data[i].split("-")[2]].cons_name+"","address":""+mpschemeArray[data[i].split("-")[2]].mp_addr+"",x:parseInt(Number(data[i].split("-")[0])*1000000),y:parseInt(Number(data[i].split("-")[1])*1000000),"no":""+mpschemeArray[data[i].split("-")[2]].cons_no+"","index":i,"type":""});
					}
				}
			}
		}
		// sessionStorage.sessGpsXy='{"content":'+JSON.stringify(sdat)+',"click":"","longClick":"","currentX":"","currentY":""}';
		sessionStorage.sessGpsXy='{"ends_x":['+strx+'],"ends_y":['+stry+']}';
	},
	returnGpsType:function(i){
		if(mpschemeArray[i].longitude!=""&&mpschemeArray[i].latitude!=""){
			return "*当前计量箱<span style='font-size:36px; color:green'>已</span>获取GPS坐标，点定位可重新获取";
		}else{
			return "*当前计量箱<span style='font-size:36px; color:red'>未</span>获取GPS坐标，点定位获取";
		}
	},
	//添加长按事件
	addclassWithList:function(){
		//记录选择状态
		$("#dropUl1").hide();
		$("#dropUl2").show();
		$(".row-content").hide();
		$(".inspect_clause2").removeClass("header_highlight");
		$(".addCheck").show();
		$(".userlist").css({"width":"90%","float":"right","border-left":"none"});
	},
	delclassWithList:function(){
		$(".addCheck").hide();
		$("#dropUl1").show();
		$("#dropUl2").hide();
		$(".userlist").css({"width":"100%","float":"none","border-left":"1px solid #999"});
	},
	checkTheBox:function(type){
		for(var i=0;i<mpschemeArray.length;i++){
			if(type==1){
				if($("#readyDo"+i).attr("src")==eh.haveNot||$("#readyDo"+i).attr("src")==eo.eoNot){
					//o.openWait("waitcontent","loginMsg","用户没有处理或者已上装,处理后才能选择",0);
				}else{
					$("#addCheck"+i).find("img").attr("src",eh.AddCheckBox1);
				}
			}else{
				if($("#addCheck"+i).find("img").attr("src")==eh.AddCheckBox1){
					$("#addCheck"+i).find("img").attr("src",eh.unAddCheckBox1);
				}else{
					if($("#readyDo"+i).attr("src")==eh.haveNot||$("#readyDo"+i).attr("src")==eo.eoNot){
					}else{
						$("#addCheck"+i).find("img").attr("src",eh.AddCheckBox1);
					}
				}
			}
		}
	},
	//获取新增电表GPS
	getGpsArcgis:function(e,x,y){
		//e:mp_scheme_id,x,longitude,y:latitude
		//查找前面列表是否存在相同计量箱，如果存在再判断是否有坐标，如果存在提示：是否选择上次坐标，否则直接定位
		if(gpsFlag==0){
			gpsFlag=1;
			if(sessionStorage.electMeas==0){
				eo.getGpsReal(e,x,y);
			}else{
				if(mpschemeArray[sessionStorage.electMeas-1].longitude){
					//如果存在再判断是否有坐标
					navigator.notification.confirm("是否选择计量箱为:"+mpschemeArray[sessionStorage.electMeas-1].container_asset_no+"的坐标？", function(index) {
						if(index==1){
							//防止多次点击状态取消
							gpsFlag=0;
							for(var j=sessionStorage.electMeas;j<mpschemeArray.length;j++){
								if($("#containerAssetNo"+sessionStorage.electMeas).val()==$("#containerAssetNo"+j).val()){
									mpschemeArray[j].longitude=mpschemeArray[sessionStorage.electMeas-1].longitude;
									mpschemeArray[j].latitude=mpschemeArray[sessionStorage.electMeas-1].latitude;
								}
							}
							$("#returngps"+sessionStorage.electMeas).html("*当前计量箱<span style='font-size:36px; color:green'>已</span>获取GPS坐标，点定位可重新获取");
							es.saveMpgpsInfos(mpschemeArray[sessionStorage.electMeas-1].longitude,mpschemeArray[sessionStorage.electMeas-1].latitude,sessionStorage.mpAppNo,sessionStorage.electMeas,$("#containerAssetNo"+sessionStorage.electMeas).val());
						}else{
							//防止多次点击状态取消
							eo.getGpsReal(e,x,y);
						}
					},"温馨提示","是,否");
				}else{
					eo.getGpsReal(e,x,y);
				}
			}
		}
	},
	getGpsReal:function(e,x,y){
		if(!e){
			x="";
			y="";
		}
		//防止多次点击状态取消
		gpsFlag=0;
		o.openWait("正在定位...",1);
		get_GPS_info(60, function(data) {
			times=0;
			var arr = new Array();
			arr = data.split(",");
			s1 = arr[0];
			s2 = arr[1];
			if(x==""||y==""){
				eo.newGisMeas(s1,s2);
			}else{
				var warp=eo.computeDistanceAndBearing(s2,s1,y,x);
				if(warp<10){
					eo.newGisMeas(s1,s2);
				}else{
					navigator.notification.confirm("GPS坐标偏移大于10米，是否打开地图校验？", function(index) {
						if (index == 1) {
							//传入两个点查看地图
							eo.compareGisMeas(s1,s2,x,y);
							navigator.notification.confirm("是否覆盖当前坐标？", function(index) {
								if (index == 1) {
									eo.newGisMeas(s1,s2);
								}else{
									o.openWait("取消覆盖",0,2);
								}
							},"温馨提示","是,否");
						}else{
							navigator.notification.confirm("GPS坐标偏移大于10米，是否覆盖当前坐标？", function(index) {
								if (index == 1) {
									eo.newGisMeas(s1,s2);
								}else{
									o.openWait("取消保存",0,2);
								}
							},"温馨提示","是,否");
						}
					},"温馨提示","是,否");
					return;
				}
			}
		},function(e){
			var goingTime=setTimeout(function(){
				times++;
				if(times<=10){
					//调用获取GPS坐标方法
					eo.getGpsReal();
				}else{
					times=0;
					o.openWait(e,0);
				}
			},2000);
		});
	},
	compareGisMeas:function(s1,s2,x,y){
		var value = {"content":[{"name":"旧点","x":x,"y":y},{"name":"新点","x":s1,"y":s2}],"disableLocated":true};
    	drawPoints(function(data){
			//data.code , data.desc
		},value);
	},
	newGisMeas:function(s1,s2){
		$("#returngps"+sessionStorage.electMeas).html("*当前计量箱<span style='font-size:36px; color:green'>已</span>获取GPS坐标，点定位可重新获取");
		mpschemeArray[sessionStorage.electMeas].longitude=s1;
		mpschemeArray[sessionStorage.electMeas].latitude=s2;
		//getGpsTen.push(mpschemeArray[i].longitude + "-" + mpschemeArray[i].latitude + "-" + mpschemeArray[i].already_do + "-" + i);
		getGpsTen[sessionStorage.electMeas]=s1+"-"+s2+"-"+mpschemeArray[sessionStorage.electMeas].already_do+"-"+sessionStorage.electMeas;
		o.openWait("GPS已定位,并已保存",0);
		var coverflag=true;
		for(var i=sessionStorage.electMeas;i<mpschemeArray.length;i++){
			if($("#containerAssetNo"+sessionStorage.electMeas).val()==$("#containerAssetNo"+i).val()){
				mpschemeArray[i].longitude=s1;
				mpschemeArray[i].latitude=s2;
				getGpsTen[i]=s1+"-"+s2+"-"+mpschemeArray[i].already_do+"-"+i;
			}
		}
		//重新设置路劲规划
		eo.pathMark(getGpsTen);
		es.saveMpgpsInfos(s1,s2,sessionStorage.mpAppNo,sessionStorage.electMeas,$("#containerAssetNo"+sessionStorage.electMeas).val());
	},
	installMpgpsType:function(a,b){
		var e=b.rows.item;
		if(e(0).UP_GPS_TYPE==0){
			var lng=e(0).LONGITUDE;
			var lat=e(0).LATITUDE;
			if(lng==""||lat==""){
				lng=0;
				lat=0;
			}
			var pkg='{"FUN":"01","ORG_NO":"'+sessionStorage.ORG_NO+'","MOD":"04","PKG_TYPE":"0","PKG":{"APP_NO":"'+sessionStorage.mpAppNo+'",CONS_NO:"'+sessionStorage.consNoUnify+'","FLOOR":"'+e(0).FLOOR+'","LONGITUDE":"'+lng+'","LATITUDE":"'+lat+'","ZT":"01"}}';
			send_data("0000", "2001", pkg, null, null);
		}
	},
	//按钮计量箱扫描
	measureScan:function(i){
		//填充计量箱
		read_Barcode(null,null);
	},
	autoAmmeterScan:function(){
		//新增电能表
		read_Barcode(null,null);
	},
	//定位计量箱
	autoMeasScan:function(i){
		eo.getGpsArcgis(mpschemeArray[i].mp_scheme_id,mpschemeArray[i].longitude,mpschemeArray[i].latitude);
	},
	induceCancleScan:function(){
		read_Barcode(null,null);
	},
	//快速录入
	// fastUpload:function(){
		// $("#main_list_up").hide();
		// $("#dbzj_electricenergyoutside_js").show();
		// $("#Pop-up-layer2_mc").hide();
		// $(".commen_foot").hide();
		// $("#electricenergyoutsidInsName").html("快速录入");
	// },
	doMpschemething:function(i,mpschemeId){
		if($("#readyDo"+i).attr("src")==eh.haveNot||$("#readyDo"+i).attr("src")==eh.upIt){
			if($("#readyDo"+i).attr("src")==eh.haveNot){
				eo.doUserList("electricenergyoutsid_ins_name_numbers",i);
			}
			es.dealMpschem(mpschemeId);
			$("#readyDo"+i).attr("src",eo.readyDoImg);
			// alert($("#readyDo"+i).attr("src")+"-----"+eh.haveNot)
		}
	},
	//去除添加样式
	clearIrread:function(){
		this.typeValue1=[];
		this.typeValue2=[];
		this.typeValue3=[];
		this.typeValue4=[];
	},
	//计算实际坐标偏差距离
	computeDistanceAndBearing:function(lat1, lon1, lat2, lon2){
		var MAXITERS = 20;
		// Convert lat/long to radians
		lat1=lat1 * Math.PI / 180.0;
		lat2=lat2 * Math.PI / 180.0;
		lon1=lon1 * Math.PI / 180.0;
		lon2=lon2 * Math.PI / 180.0;
		var results=[];
		var a = 6378137.0; // WGS84 major axis
		var b = 6356752.3142; // WGS84 semi-major axis
		var f = (a - b) / a;
		var aSqMinusBSqOverBSq = (a * a - b * b) / (b * b);
	
		var L = lon2 - lon1;
		var A = 0.0;
		var U1 = Math.atan((1.0 - f) * Math.tan(lat1));
		var U2 = Math.atan((1.0 - f) * Math.tan(lat2));
	
		var cosU1 = Math.cos(U1);
		var cosU2 = Math.cos(U2);
		var sinU1 = Math.sin(U1);
		var sinU2 = Math.sin(U2);
		var cosU1cosU2 = cosU1 * cosU2;
		var sinU1sinU2 = sinU1 * sinU2;
	
		var sigma = 0.0;
		var deltaSigma = 0.0;
		var cosSqAlpha = 0.0;
		var cos2SM = 0.0;
		var cosSigma = 0.0;
		var sinSigma = 0.0;
		var cosLambda = 0.0;
		var sinLambda = 0.0;
	
		var lambda = L;
		for (var iter = 0; iter < MAXITERS; iter++) {
			var lambdaOrig = lambda;
			cosLambda = Math.cos(lambda);
			sinLambda = Math.sin(lambda);
			var t1 = cosU2 * sinLambda;
			var t2 = cosU1 * sinU2 - sinU1 * cosU2 * cosLambda;
			var sinSqSigma = t1 * t1 + t2 * t2;
			sinSigma = Math.sqrt(sinSqSigma);
			cosSigma = sinU1sinU2 + cosU1cosU2 * cosLambda;
			sigma = Math.atan2(sinSigma, cosSigma);
			var sinAlpha = (sinSigma == 0) ? 0.0 : cosU1cosU2 * sinLambda / sinSigma;
			cosSqAlpha = 1.0 - sinAlpha * sinAlpha;
			cos2SM = (cosSqAlpha == 0) ? 0.0 : cosSigma - 2.0 * sinU1sinU2 / cosSqAlpha;
	
			var uSquared = cosSqAlpha * aSqMinusBSqOverBSq;
			A = 1 + (uSquared / 16384.0) *(4096.0 + uSquared *(-768 + uSquared * (320.0 - 175.0 * uSquared)));
			var B = (uSquared / 1024.0) * (256.0 + uSquared *(-128.0 + uSquared * (74.0 - 47.0 * uSquared)));
			var C = (f / 16.0) *cosSqAlpha *(4.0 + f * (4.0 - 3.0 * cosSqAlpha));
			var cos2SMSq = cos2SM * cos2SM;
			deltaSigma = B * sinSigma *	(cos2SM + (B / 4.0) * (cosSigma * (-1.0 + 2.0 * cos2SMSq) - (B / 6.0) * cos2SM * (-3.0 + 4.0 * sinSigma * sinSigma) * (-3.0 + 4.0 * cos2SMSq)));
			lambda = L +(1.0 - C) * f * sinAlpha *(sigma + C * sinSigma * (cos2SM + C * cosSigma * (-1.0 + 2.0 * cos2SM * cos2SM)));
			var delta = (lambda - lambdaOrig) / lambda;
			if (Math.abs(delta) < 1.0e-12) {
				break;
			}
		}
		var distance =(b * A * (sigma - deltaSigma));
		results[0] = distance;
		if (results.length > 1) {
			var initialBearing = Math.atan2(cosU2 * sinLambda,cosU1 * sinU2 - sinU1 * cosU2 * cosLambda);
			initialBearing *= 180.0 / Math.PI;
			results[1] = initialBearing;
			if (results.length > 2) {
				var finalBearing = Math.atan2(cosU1 * sinLambda,-sinU1 * cosU2 + cosU1 * sinU2 * cosLambda);
				finalBearing *= 180.0 / Math.PI;
				results[2] = finalBearing;
			}
		}
		return results;
	},
	tempDigitFun:function(data){
		var s=data.split(".");
		var tempNumber="9999999999";
		return tempNumber.substring(0,s[0])+"."+tempNumber.substring(0,s[1]);
	},
	fixedIrread:function(y){
		var tval=y,x="";
		var str=y.toString();
		var spt=str.split("."),len=0;
		if(spt.length>=2){
			len=spt[1].length;
			if(len>=3){
				x=Number(tval).toFixed(3);
				return x;
			}else{
				return tval;
			}
		}else{
			return tval;
		}
		
	},
	irreadDeals:function(type,code,value){
		var obj=[];
		for(var i=0;i<eo.read_type_code_all.length;i++){
			if(type=="97"){
				obj=obj97;
			}else{
				obj=obj07;
			}
			if(obj["_"+code].split(";")[0]==eo.read_type_code_all[i]){
				var tempDigit=eo.digitArray[i];
				var getDigit=eo.tempDigitFun(tempDigit);
				if(Number(value)>Number(getDigit)){
					if(eo.readReturn.indexOf(code)==-1){
						eo.readReturn.push(code);
					}
					var ar=Number(value)-Number(getDigit);
					var value1=eo.fixedIrread(ar);
					//alert("1:"+value1)
					if(type!="97"){
						$("#style_new_check" + obj["_"+code].split(";")[1]).val(value1);
						//删除手动修改记录
						eo.deleteCheckIread(i);
					}else{
						$("#style_new_check" + code).val(value1);
						eo.deleteCheckIread(i);
						//删除手动修改记录
					}
					$("#returnStyleID"+i).html("是");
				}else{
					var value2=eo.fixedIrread(value);
					//alert("2:"+value2)
					if(type!="97"){
						$("#style_new_check" + obj["_"+code].split(";")[1]).val(value2);
						//删除手动修改记录
						eo.deleteCheckIread(i);
					}else{
						$("#style_new_check" + code).val(value2);
						//删除手动修改记录
						eo.deleteCheckIread(i);
					}
				}
			}
		}
	},
	deleteCheckIread:function(i){
		var number=eo.returnCheckIread(checkIread,i);
		if(number!=undefined){
			checkIread.splice(number,1);
		}
		//存储修改记录
		localStorage.CHECKIREAD=JSON.stringify(checkIread);
		checkIreadUp=[];
		//如果是当前用户，则重新push到新数组，以便上装传递
		for(var j=0;j<checkIread.length;j++){
			if(checkIread[j].SYS_USER_NAME==sessionStorage.user_name&&checkIread[j].APP_NO==sessionStorage.mpAppNo){
				checkIreadUp.push(checkIread[j]);
			}
		}
	},
	//删除所有当前用户下的全局手动修改记录，并删除需要上装的手动修改示数记录
	deleteCheckIreadArray:function(){
		for(var j=0;j<checkIread.length;j++){
			if(checkIread[j].SYS_USER_NAME==sessionStorage.user_name){
				checkIread.splice(j,1);
				j--;
			}
		}
		checkIreadUp=[];
		localStorage.CHECKIREAD=JSON.stringify(checkIread);
		//如果是当前用户，则重新push到新数组，以便上装传递
		for(var j=0;j<checkIread.length;j++){
			if(checkIread[j].SYS_USER_NAME==sessionStorage.user_name&&checkIread[j].APP_NO==sessionStorage.mpAppNo){
				checkIreadUp.push(checkIread[j]);
			}
		}
		localStorage.CHECKIREADUP=JSON.stringify(checkIreadUp);
	},
	//存储手动修改记录
	returnCheckIread:function(checkIread,t){
		for(var s=0;s<checkIread.length;s++){
			if(checkIread[s].ASSET_NO==t.ASSET_NO&&checkIread[s].READ_TYPE_CODE==t.READ_TYPE_CODE){
				return s;
			}
		}
	},
	//上装字段选择
	returnCheckIreadUp:function(a,b){
		for(var i=0;i<a.length;i++){
			if(a[i].ASSET_NO==b.ASSET_NO&&a[i].READ_TYPE_CODE==b.READ_TYPE_CODE){
				return i;
			}
		}
	},
	//查询前三日当前电表示数
	queryThreeData:function(){
		o.openWait("正在查询...",1);
		var pkg='{"FUN":"12","ORG_NO":"'+localStorage.ORG_NO+'","MOD":"02","PKG_TYPE":"0","PKG":{"ASSET_NOS":'+sessionStorage.amIput+'}}';
		send_data("0000","2002",pkg,function(data){
			data=JSON.parse(data);
			if(data.RET!="00"){
				//外包返回失败码
				o.openWait(sc.getErrorCode(data.RET),0);
			}else{
				data.PKG.RET="01";
				if(data.PKG.RET!="01"){
					//o.openWait(sc.getMsgCode(data.PKG.RET),0);
					o.openWait("查询最近电表示数失败！",0);
				}else{
					o.openWait("查询成功！",2);
					//成功则返回   
					if(data.PKG.PKG.METER_IREAD==""){
						o.openWait("暂无历史数据！",0);
					}else{
						eh.historyIread(data.PKG.PKG.METER_IREAD);
					}
					//eh.historyIread();
				}
			}
		},function(){
			o.openWait("网络连接失败",0);
		});
	}
}
/**
 * 扫描返回方法
 * code：当前命令
 * data：数据信息
 * flag：是否扫描结束（end时本次扫描结束）
 * next：下一个即将扫描的命令
 * errCode：错误码（-1：无错误，
 *                0:请检查电能表是否通电或表以损坏,
 *                1:未抄到数据，请对准红外接口,
 *                2:为测试电表型号时使用,
 *                3:命令错误,
 *                4:未得到数据(可能是红外传输异常导致)） 
 * type:97表示1997表，07表示2007表
 */
var rtEmptyId=0;
var testDataappend="";
var testJs = {};
var lostIrread=[];
//抄表变量
var asset_no_97_dbzj="";
var asset_no_07_dbzj="";
var asset_no_97_dbzj_angle="";
var asset_no_07_dbzj_angle="";
var testGetFun=-1;
testJs.returnSendDataFun = function(code,data,flag,next,errCode,type){
	if(code==''&& data ==''){
	}else{
		if(errCode==-1){
			if(type=="97"){
				var sdata=data.split(";");
				if(sdata.length==1){
					eo.irreadDeals("97",code,sdata[0]);
				}else{
					for(var i=0;i<sdata.length;i++){
						//如果返回示数类型为9020（反有工总）,单独显示出来
						if(sdata[i].split(":")[0]=="9020"){
							$("#tcPop").show();
							$("#tc").append(obj97["_"+sdata[i].split(":")[0]].split(";")[0]+":"+sdata[i].split(":")[1]+"<br />");
						}
						eo.irreadDeals("97",sdata[i].split(":")[0],sdata[i].split(":")[1]);
						
					}
				}
			}else{
				var sdata=data.split(";");
				if(sdata.length==1){
					eo.irreadDeals("07",code,sdata[0]);
				}else{
					for(var i=0;i<sdata.length;i++){
						if(sdata[i].split(":")[0]=="00020000"){
							$("#tcPop").show();
							$("#tc").append(obj07["_"+sdata[i].split(":")[0]].split(";")[0]+":"+sdata[i].split(":")[1]+"<br />");
						}
						eo.irreadDeals("07",sdata[i].split(":")[0],sdata[i].split(":")[1]);
					}
				}
			}
		}else if(errCode==6){
			//没有对准电表
			o.openWait("未抄到数据，请对准红外接口！",0);
		}else if(errCode==5){
			lostIrread.push(code+"_"+type);
		}else{
			//如果当前电能表没有反有功总命令数据条，并且本次抄读又是反有功数据条返回的数据，则停止本次操作，继续下一个命令抄读
			if(asset_no_07_dbzj.indexOf("0002FF00")==-1&&code=="00020000"){
				//o.openWait("",2);
				return;
			}
			if(asset_no_97_dbzj.indexOf("902F")==-1&&code=="9020"){
				//o.openWait("",2);
				return;
			}
			if(code==""){
				testDataappend+=data+"<br />";
			}else{
				if(type=="97"){
					if(obj97["_"+code]){
						testDataappend+=obj97["_"+code].split(";")[0]+":"+data+"<br />";
					}else{
						testDataappend+=data+"<br />";
					}
				}else{
					if(obj07["_"+code]){
						testDataappend+=obj07["_"+code].split(";")[0]+":"+data+"<br />";
					}else{
						testDataappend+=data+"<br />";
					}
				}
			}
			$("#tcPop").show();
			$("#tc").append(testDataappend);
			o.openWait(data,1);
		}
	}
	if(flag=="end"&&errCode!=6){
		if(rtEmptyId==0&&lostIrread.length!=0){
			rtEmptyId=1;
			var meter_addr = (sessionStorage.barCodeInti).replace(/[a-z|A-Z]/g, "0");
			if(meter_addr.length==9){
				meter_addr="0"+meter_addr;
			}
			o.openWait("有遗漏示数没有抄到,再次抄读...",1);
			send_Bt_Instruct_New('{"nameSpace":"testJs","code07":"'+eo.sect_value07_angle+'","code97":"'+eo.sect_value97_angle+'","address":"00'+meter_addr+'"}',null,null);
		}else{
			//关闭蒙版
			rtEmptyId=0;
			o.openWait(data==""?"抄表结束":data,0);
		}
	}else{
		if(next==""){
			o.openWait(data==""?"抄表终止":data,0);
			return;
		}
		$("#electricener_laoding_view").show();
		$("#typeElectricener").css("font-size","36px");
		if(type=="97"){
			o.openWait("正在读取："+obj97["_"+next].split(";")[0]+"...",1);
		}else{
			o.openWait("正在读取："+obj07["_"+next].split(";")[0]+"..."+"...",1);
		}
	}
}