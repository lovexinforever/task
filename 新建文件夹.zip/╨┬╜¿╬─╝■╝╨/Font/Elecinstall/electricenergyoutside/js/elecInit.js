var sc = new handle(), es = new connectSql(), eh = new elecHtml(), o = new Operation(), eo = new elecOper(), mpschemeArray = [], getGpsTen = [], sa = new handle(), device_picture = new Array(), getUpAppInfo = [], getUpMtScheme = [], getUpItScheme = [], getUpBoxScheme = [], getUpIrread = [], getUpGpsInfos = [], getUpDevinfos = [], tempAddCeckArray = [], checkIread = [], checkIreadUp = [], returnFlag = 0, pend1 = "", pend2 = "", pend3 = "", coverLongitude = 0, times = 0;
var lookFlag = 0, stopFlag = 0, gpsFlag = 0;
//定义排序变量
var taxisForChange = 0;
//sessionStorage.newChgDesc==1 新增电能表
//sessionStorage.newChgDesc==2 拆除电能表
//sessionStorage.newChgDesc==3 计量箱
//sessionStorage.newChgDesc==4 新增互感器
//sessionStorage.newChgDesc==5 拆除互感器
//sessionStorage.newChgDesc==undefined 没有选中任何设备
//页面跳转标量赋值
var parendID = $("#getparentID_elect").parent().attr("id");
var parendidf;
if(parendID == "contentPageOne") {
	parendidf = "contentPageTwo";
} else {
	parendidf = "contentPageOne";
}
//显示表头信息
$("#electricenergyoutsidInsName").html(sessionStorage.insIdDbzj);
//进入计量点信息先查询所有需要查询的数据，并用数组形式存储
es.selectElecAllData(sessionStorage.mpAppNo);
//查询前十条有GPS信息的计量点
//es.selectHaveGpsTopTen(sessionStorage.mpAppNo);
//查询上装人员信息并填充
es.selectAppInfos(sessionStorage.mpAppNo);
//长按计量信息
var time = 0;
var timeInterval = 0;
document.getElementById("elecSchemesID").addEventListener("touchstart", touchLong, false)
function touchLong(e) {
	clearInterval(timeInterval);
	timeInterval = setInterval(function() {
		time += 10;
		if(time >= 200) {
			time = 0;
			clearInterval(timeInterval);
			//添加选择框
			if($(".addCheck").css("display") == "none") {
				eo.addclassWithList();
			} else {
				eo.delclassWithList();
			}
		}
	}, 100);
}

document.getElementById("elecSchemesID").addEventListener("touchend", function(e) {
	time = 0;
	clearInterval(timeInterval);
}, false)
document.getElementById("elecSchemesID").addEventListener("touchmove", function(e) {
	time = 0;
	clearInterval(timeInterval);
}, false)
function checkonoff(i) {
	if($("#addCheck" + i).find("img").attr("src") == eh.unAddCheckBox1) {
		if($("#readyDo" + i).attr("src") == eh.haveNot || $("#readyDo" + i).attr("src") == eo.eoNot) {
			o.openWait("需要处理该用户才能选择上装！", 0);
		} else {
			$("#addCheck" + i).find("img").attr("src", eh.AddCheckBox1);
		}
	} else {
		$("#addCheck" + i).find("img").attr("src", eh.unAddCheckBox1);
	}
}

//点击计量点
function electricClick(i, id, m, type) {
	time = 0;
	clearInterval(timeInterval);
	if($("#dropUl2").css("display") == "block") {
		if($("#addCheck" + i).find("img").attr("src") == eh.unAddCheckBox1) {
			if($("#readyDo" + i).attr("src") == eh.haveNot || $("#readyDo" + i).attr("src") == eo.eoNot) {
				o.openWait("需要处理该用户才能选择上装！", 0);
			} else {
				$("#addCheck" + i).find("img").attr("src", eh.AddCheckBox1);
			}
		} else {
			$("#addCheck" + i).find("img").attr("src", eh.unAddCheckBox1);
		}
	} else {
		var notice = 0;
		if($("#mtitList" + i).css("display") == "block") {
			notice = 1;
		} else {
			notice = 0;
		}
		//记录当前点击的是第几个计量点
		sessionStorage.electMeas = i;
		sessionStorage.electAmmeterJ = m;
		//隐藏其他计量点信息
		$(".row-content").hide();
		//去除计量箱样式
		$(".widthmeasure").removeClass("changeCssAmmeter");
		$(".golist").hide();
		$(".aGolist").hide();
		$(".typeClass").removeClass("changeCssAmmeter");
		sessionStorage.lookAssetID = undefined;
		sessionStorage.newChgDesc = undefined;
		//清楚点击电能表记录
		sessionStorage.ammeterJ = undefined;
		sessionStorage.ammeterI = undefined;
		sessionStorage.ammeterMD = undefined;
		$("#imgLooklist" + i).attr("src", "../../Util/Images/but_ck01_h.png");
		$(".inspect_clause2").removeClass("header_highlight");
		//显示当前点击计量点信息
		sessionStorage.consNoUnify = mpschemeArray[i].cons_no;
		if(notice == 0) {
			sessionStorage.mpUserName = mpschemeArray[i].cons_name;
			sessionStorage.mpUserAddr = mpschemeArray[i].mp_addr;
			sessionStorage.mpSchemeID = mpschemeArray[i].mp_scheme_id;
			//记录打印数据
			sessionStorage.mpConsNo = mpschemeArray[i].cons_no;
			sessionStorage.measMode = mpschemeArray[i].meas_mode;
			$("#mtitList" + i).slideDown();
			$("#" + id).addClass("header_highlight");
			//o.openWait("",2);
			if(type && type != 3 && type != 2) {
				//if(mpschemeArray[i].mt[m].MTchg_desc=="新增"){
				//	eo.getGpsArcgis(mpschemeArray[i].mp_scheme_id);
				//}
				ammeterClick(m, 2, i, $("#amTypeMtchgDescID" + i + "s" + m).attr("content"));
			}
			if(type == 2) {
				setTimeout(function() {
					$("#ammeterInput" + i + "s" + m).val(sessionStorage.barCodeInti);
				}, 500)
			}
			var s = $("#elecSchemesID").scrollTop() + ($("#mtitList" + i).position().top - 260);
			$("#elecSchemesID").scrollTop(s);
		} else {
			if(!type) {
				sessionStorage.consNoUnify = undefined;
				$("#mtitList" + i).slideUp();
			} else if(type != 3 && type != 2) {
				//蓝牙终端打开电能表
				$("#mtitList" + i).slideDown();
				$("#" + id).addClass("header_highlight");
				//o.openWait("",2);
				var s = $("#elecSchemesID").scrollTop() + ($("#mtitList" + i).position().top - 260);
				$("#elecSchemesID").scrollTop(s);
				ammeterClick(m, 2, i, $("#amTypeMtchgDescID" + i + "s" + m).attr("content"));
			} else {
				//扫描到空的新增电表并填充条码并且选中;
				$("#" + id).addClass("header_highlight");
				$("#mtitList" + i).slideDown();
				var s = $("#elecSchemesID").scrollTop() + ($("#mtitList" + i).position().top - 260);
				$("#elecSchemesID").scrollTop(s);
			}
			if(type == 2) {
				setTimeout(function() {
					$("#ammeterInput" + i + "s" + m).val(sessionStorage.barCodeInti);
				}, 500)
			}
		}
	}
}

//点击计量箱
function containClick(i, id) {
	time = 0;
	clearInterval(timeInterval);
	//关闭长按事件
	sessionStorage.keyD = 3;
	sessionStorage.newChgDesc = 3;
	$("#" + id).addClass("changeCssAmmeter");
	$(".golist").hide();
	$(".aGolist").hide();
	$(".typeClass").removeClass("changeCssAmmeter");
	sessionStorage.lookAssetID = undefined;
	sessionStorage.ammeterJ = undefined;
	sessionStorage.ammeterI = undefined;
	$("#imgLooklist" + i).attr("src", "../../Util/Images/but_ck01_h.png");
	//弹出计量箱修改框
	$("#Pop_up_tops").html(eh.popHtml($("#containerAssetNo" + i).val(), $("#containerFloor" + i).html(), i));
	$("#Pop_up_tops").show();
	//点击计量箱，处理当前用户
	eo.doMpschemething(i, mpschemeArray[i].mp_scheme_id);
	document.ontouchmove = function(e) {
		event.preventDefault();
	}
}

//确定修改
function measureOk(i, oldAsset) {
	time = 0;
	clearInterval(timeInterval);
	var containerID = ($("#getAssetno").val()).replace(/\s+/g, "");
	if(containerID == "") {
		o.openWait("计量箱资产号不能为空", 0);
		return;
	}
	$("#containerAssetNo" + i).val(containerID);
	$("#containerFloor" + i).html($("#getLoc").val());
	if($("#containerAssetNo" + i).val() != oldAsset) {
		mpschemeArray[i].longitude = "";
		mpschemeArray[i].latitude = "";
		getGpsTen.splice(i, 1);
	}
	es.updateLoc(containerID, $("#getLoc").val(), sessionStorage.mpAppNo, mpschemeArray[i].mp_scheme_id, oldAsset);
	$("#readyDo" + i).attr("src", "electricenergyoutside/images/already.png");
	var tempj = 0;
	for(var j = i; j < mpschemeArray.length; j++) {
		if($("#containerAssetNo" + j).val() == oldAsset) {
			$("#containerAssetNo" + j).val(containerID);
			$("#containerFloor" + j).html($("#getLoc").val());
			if($("#readyDo" + j).attr("src") == eh.haveNot) {
				var nameNumber = $("#electricenergyoutsid_ins_name_numbers").html();
				nameNumber++;
				$("#electricenergyoutsid_ins_name_numbers").html(nameNumber);
			}
			$("#readyDo" + j).attr("src", "electricenergyoutside/images/already.png");
			es.dealMpschem(mpschemeArray[j].mp_scheme_id);
			if(oldAsset != containerID) {
				//如果是第一个
				if(tempj == 0) {
					tempj = j;
				}
				getGpsTen.splice(tempj, 1);
				tempj = j;
				tempj--;
				mpschemeArray[j].longitude = "";
				mpschemeArray[j].latitude = "";
				//$("#containerAssetNo"+j).val()
				es.updateUnionAsset(mpschemeArray[j].mp_scheme_id, oldAsset, containerID);
			}
		}
	}
	//重新设置路劲规划
	eo.pathMark(getGpsTen);
	document.ontouchmove = function(e) {
	}
	$("#Pop_up_tops").slideUp();
	sessionStorage.newChgDesc = undefined;
}

//关闭计量箱修改框
function measureCancle() {
	eo.pathMark(getGpsTen);
	$("#Pop_up_tops").slideUp();
	sessionStorage.newChgDesc = undefined;
	document.ontouchmove = function(e) {
	}
}

//点击电能表、互感器
function ammeterClick(j, type, i, mtid) {
	time = 0;
	clearInterval(timeInterval);
	$("#tcPop").hide();
	$("#tc").html("");
	sessionStorage.ammeterJ = j;
	sessionStorage.ammeterI = i;
	sessionStorage.ammeterMD = mtid;
	//点击电能表做样式处理
	eo.doMpschemething(i, mpschemeArray[i].mp_scheme_id);
	$(".widthmeasure").removeClass("changeCssAmmeter");
	$(".golist").hide();
	$(".aGolist").hide();
	$(".typeClass").removeClass("changeCssAmmeter");
	if(type == 1) {
		sessionStorage.lookAssetID = undefined;
		$("#imgLooklist" + j).attr("src", "../../Util/Images/but_ck01_h.png");
		//sessionStorage.amIput=$("#IammeterInput"+i).val();
		sessionStorage.chgDesc = $("#IamTypeMtchgDescID" + i + "s" + j).html();
		if(sessionStorage.chgDesc == "新增") {
			sessionStorage.newChgDesc = 4;
		} else {
			sessionStorage.newChgDesc = 5;
		}
		eh.displayItScheme(j, $("#amTypeMtchgDescID" + i + "s" + j).attr("content"), $("#IammeterInput" + i + "s" + j).val());
		$("#aGolist" + i + "s" + j).show();
		$(".iAmType" + j).addClass("changeCssAmmeter");
		//$("#main_list_up").hide();
		//打开互感器新增
	} else if(type == 2) {
		$("#golist" + i + "s" + j).fadeIn();
		sessionStorage.amIput = $("#ammeterInput" + i + "s" + j).val();
		sessionStorage.amIputI = i + "s" + j;
		//mpschemeArray[i].mt[j].MTchg_desc;
		sessionStorage.chgDesc = $("#amTypeMtchgDescID" + i + "s" + j).html();
		if(sessionStorage.chgDesc == "新增") {
			sessionStorage.newChgDesc = 1;
		} else {
			sessionStorage.newChgDesc = 2;
		}
		sessionStorage.mtTempID = mtid;
		sessionStorage.lookAssetID = $("#ammeterInput" + i + "s" + j).val();
		$(".amType" + j).addClass("changeCssAmmeter");
		//弹出示数
		eo.displayIrread(j, mtid);
		//是否存在图片
		checkIsPicOrNot(i, j);
		controlPopScroll();
	}
	setTimeout(function() {
		clearInterval(timeInterval);
	}, 1000);
}

//保存互感器
function induceOK(obj) {
	var old_assetNo=$(obj).attr('tel');
	old_assetNo = old_assetNo == undefined ? '' : old_assetNo;
	var curr_assetNo = $("#sort_itmt").val();
	es.updateItAsset($("#IamTypeMtchgDescID" + sessionStorage.ammeterI + "s" + sessionStorage.ammeterJ).attr("content"), curr_assetNo, old_assetNo);
	$("#IammeterInput" + sessionStorage.ammeterI + "s" + sessionStorage.ammeterJ).val(curr_assetNo);
	$("#Pop_up_tops").hide();
}

function checkIsPicOrNot(i, m) {
	//如果存在图片,则更改图片
	sessionStorage.lookAssetID = $("#ammeterInput" + i + "s" + m).val();
	file_exist("/photo/2002/" + eo.proImgOrg(sessionStorage.ORG_NO) + "/" + sessionStorage.lookAssetID + "/", function(e) {
		if(e == 1) {
			$("#imgLooklist" + i).attr("src", "../../Util/Images/but_ck01.png");
		} else {
			$("#imgLooklist" + i).attr("src", "../../Util/Images/but_ck01_h.png");
		}
	});
}

//修改电能表示数
function ammeterModify(len) {
	if(sessionStorage.chgDesc == "新增") {
		eo.modifyAmmeter1(sessionStorage.mtTempID);
	} else {
		if(len != 0) {
			if($("#Pop_up_tops").css("display") == "block") {
				//returnFlag==1;
				//$("#Pop_up_tops").hide();
			} else {
				//o.openWait("正在保存....",1);
				setTimeout(function() {
					eo.modifyAmmeter(len);
				}, 50)
			}
		} else {
			sessionStorage.newChgDesc = undefined;
			$("#pop").hide();
		}
	}
	document.ontouchmove = function(e) {
	};
}

//采用上次示数
function getLastData(len) {
	eo.setLastData(len);
}

function sametolast() {
	returnFlag = 0;
	for(var i = 0; i < eo.irread_id.length; i++) {
		$("#returnStyleID" + i).html("否");
	}
	es.typeCode01(eo.img_check_type);
	$("#confirm_the_same").hide();
	for(var i = 0; i < eo.irread_id_last.length; i++) {
		$("#style_new_check" + eo.sect_value97_angle[i]).val(eo.irread_id_last[i]);
		eo.deleteCheckIread(i);
	}
}

function sametolast_concle() {
	$("#confirm_the_same").hide();
}

function newassetFun() {
	$("#ammeterInput" + sessionStorage.amIputI).val($("#modify_mtscheme").val());
	$("#pop").hide();
}

//终止当前用户

function stopUserList(i) {
	if(stopFlag == 0) {
		stopFlag = 1;
		navigator.notification.confirm("是否确定终止用户？", function(index) {
			if(index == 1) {
				stopFlag = 0;
				o.openWait("正在终止...", 1);
				es.deleteUser(mpschemeArray[i].mp_scheme_id);
			} else {
				stopFlag = 0;
			}
		}, "温馨提示", "是,否");
	}
}

function reLoadElect() {
	//刷新用户
	sessionStorage.stopRef = 1;
	es.selectElecAllData(sessionStorage.mpAppNo);
}

//拍照
function takeClick(i) {
	if($("#golist" + sessionStorage.amIputI).css("display") == "block") {
		o.openWait("打开拍照功能", 0, 2);
		eo.cameraPhoto(mpschemeArray[i].mp_scheme_id, $("#ammeterInput" + sessionStorage.amIputI).val());
	} else {
		o.openWait("请选择电能表", 0, 2);
	}
}

function noCamera() {
	//没有照片返回
	o.openWait("取消拍照", 0, 2);
	checkIsPicOrNot(sessionStorage.ammeterI, sessionStorage.ammeterJ);
}

function save_photo(e) {
	device_picture = new Array();
	var data = JSON.parse(e);
	if(data.size != "0") {
		var datatime = (data.date).split(" ")[0];
		var timeyear = datatime.split("-")[0];
		var timemonth = datatime.split("-")[1];
		var timeday = datatime.split("-")[2];
		device_picture[0] = sessionStorage.mpAppNo;
		device_picture[1] = sessionStorage.mpSchemeID;
		device_picture[2] = sessionStorage.consNoUnify;
		device_picture[3] = "01";
		device_picture[4] = sessionStorage.lookAssetID;
		device_picture[5] = "JPG";
		device_picture[6] = data.size;
		device_picture[7] = data.date;
		device_picture[8] = eo.proImgOrg(sessionStorage.ORG_NO) + '/2002/' + timeyear + "/" + timemonth + "/" + timeday + "/" + sessionStorage.mpAppNo + "/" + sessionStorage.lookAssetID + "_.jpg"
		device_picture[9] = sessionStorage.lookAssetID + "_.jpg";
		device_picture[10] = "";
		es.deletePicture(sessionStorage.lookAssetID);
	} else {
		checkIsPicOrNot(sessionStorage.ammeterI, sessionStorage.ammeterJ);
	}
}

function saveImgInfosUccess(a, b) {
	checkIsPicOrNot(sessionStorage.ammeterI, sessionStorage.ammeterJ);
	//o.openWait("图片信息已保存",0);
}

//读取示数
function prepare_readAmmeter() {
	if($('#waitlogin').css('display') == "block") {
		return;
	}
	if(sessionStorage.ammeterJ && sessionStorage.ammeterI) {
		sessionStorage.barCodeInti = $("#ammeterInput" + sessionStorage.ammeterI + "s" + sessionStorage.ammeterJ).val()
		if(sessionStorage.newChgDesc == 2) {
			eo.readIrreadType();
		}
	}
}

//查看图片
function lookClick(i) {
	time = 0;
	clearInterval(timeInterval);
	if(lookFlag == 0) {
		lookFlag = 1;
		if(sessionStorage.lookAssetID && sessionStorage.lookAssetID != "undefined") {
			lookFlag = 0;
			var filepath = "/photo/2002/" + eo.proImgOrg(sessionStorage.ORG_NO) + "/" + sessionStorage.lookAssetID + "/";
			getGallery({
				"path" : filepath,
				"JSFUN" : "checkPtsuccess"
			}, null, function(e) {
				navigator.notification.confirm("本地没有图片,是否下装该图片？", function(index) {
					if(index == 1) {
						o.openWait("正在下装...", 1);
						es.selectImageInfos(sessionStorage.amIput);
					} else {
						o.openWait("取消下装", 0, 2);
					}
				}, "温馨提示", "是,否");
			});
		} else {
			lookFlag = 0;
			o.openWait("请选择对应电能表进行查看!", 0, 2);
		}
	} else {
		lookFlag = 0;
	}
}

//打印
function printClick(i) {
	eo.openPrint(i);
}

//上装用户信息
function upLoadDate() {
	clearInterval(timeInterval);
	var Uploadtype = 0;
	for(var i = 0; i < mpschemeArray.length; i++) {
		if($("#readyDo" + i).attr("src") == eh.upIt) {
			Uploadtype++;
		}
	}
	if(Uploadtype == mpschemeArray.length) {
		$("#uplogin").slideDown();
		return;
	}
	sessionStorage.m = 0;
	es.selectInfoStat(sessionStorage.mpAppNo);
}

function LockCheckForm() {
	eo.numberImg = 0;
	eo.operAtionUpload();
}

function LockCheckCancle() {
	$("#uplogin").slideUp();
}

//上装复选框
function uploadInfoType(i) {
	eo.setCheckBox(i);
}

//上装时间设置
function uploadAppData() {
	eo.setLoadTime();
}

function enterCanel() {
	$("#Pop_up_tops").slideUp();
}

function LockCancle() {
	$("#pop").slideUp();
	sessionStorage.newChgDesc = undefined;
	document.ontouchmove = function(e) {
	}
}

function induceCancle() {
	$("#Pop_up_tops").slideUp();
}

//长按界面显示选择界面
function selectAllMp() {
	selectOption("allnumber1");
	eo.checkTheBox(1);
}

function UnselectAllMp() {
	selectOption("allnumber2");
	eo.checkTheBox(2);
}

function cancleDrop() {
	clearInterval(timeInterval);
	eo.delclassWithList();
}

function selectOption(id) {
	$("#allnumber1").attr("src", eh.unAddCheckBox);
	$("#allnumber2").attr("src", eh.unAddCheckBox);
	$("#" + id).attr("src", eh.AddCheckBox);
}

//判断是否手动更改过示数
var doSelf = [], yourHand = 0;
function youDoSelf(obj) {
	yourHand = 1;
	returnFlag = 0;
	var i = $("#" + obj.id).attr("content");
	obj = (obj.id).split("style_new_check")[1];
	var value = $("#style_new_check" + obj).val();

	var str = /^[0-9]+([.]{1}[0-9]+){0,1}$/g;
	var t = str.test(value);
	if(!t) {
		$("#style_new_check" + obj).val("");
		o.openWait("请输入正确的示数", 0);
		return;
	}

	var tempDigits = eo.digitArray[i];
	//将临界值转换为十进制最大值
	var getDigits = eo.tempDigitFun(tempDigits);
	$("#returnStyleID" + i).html("否");
	es.updateExplor(i);
	if(Number(value) > Number(getDigits)) {
		$("#style_new_check" + obj).val("");
		$("#style_new_check" + obj).css("border", "1px solid red");
		o.openWait("输入示数超过最大值,请手动修改", 0);
		return;
	} else {
		$("#style_new_check" + obj).css("border", "");
	}
	var exp = "01";
	if($("#returnStyleID" + i).html() == "否") {
		exp = "01";
	} else {
		exp = "08";
	}
	/********************************手动修改记录********************************/
	var date = new Date();
	var dateCheck = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate() + " " + (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ":" + (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ":" + (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds());
	//记录当前示数类型电表示数
	var numberLen = 0, t = {
		PDA_SN : localStorage.TID,
		SYS_USER_NAME : sessionStorage.user_name,
		APP_NO : sessionStorage.mpAppNo,
		CONS_NO : sessionStorage.consNoUnify,
		ASSET_NO : sessionStorage.amIput,
		READ_TYPE_CODE : eo.read_type_code_all[i],
		MR_PQ : value,
		EXCP_HANDLE_CODE : "",
		MR_DATE : dateCheck,
		MR_DIG_IT : eo.digitArray[i]
	};
	//判断是否有缓存的全局示数手动修改记录
	if(localStorage.CHECKIREAD) {
		checkIread = JSON.parse(localStorage.CHECKIREAD);
	}
	//处理手动修改记录,如果存在则先删除后push
	var getCheck = eo.returnCheckIread(checkIread, t);
	if(getCheck != undefined) {
		checkIread.splice(getCheck, 1);
	}
	checkIread.push(t);
	//存储修改记录
	localStorage.CHECKIREAD = JSON.stringify(checkIread);
	//判断是否缓存需要上装的示数手动修改记录
	if(localStorage.CHECKIREADUP) {
		checkIreadUp = JSON.parse(localStorage.CHECKIREADUP);
	}
	//如果是当前用户，则重新push到新数组，以便上装传递
	for(var j = 0; j < checkIread.length; j++) {
		if(checkIread[j].SYS_USER_NAME == sessionStorage.user_name && checkIread[j].APP_NO == sessionStorage.mpAppNo) {
			var getCheckUp = eo.returnCheckIreadUp(checkIreadUp, checkIread[j]);
			if(getCheckUp != undefined) {
				checkIreadUp.splice(getCheckUp, 1);
			}
			checkIreadUp.push(checkIread[j]);
		}
	}
	//存储需要上装的手动修改示数记录
	localStorage.CHECKIREADUP = JSON.stringify(checkIreadUp);
	/********************************手动修改记录********************************/
}

function newFastpage() {
	if($("#dbsy_sqyy").attr("src") != "../../Util/Images/arrangements.png") {
		//window.open("FastUpload/html/index.html");
		eo.fastUpload();
	}
}

//返回工单列表
function dbzjLoginuserBack() {
	if($("#main_list_up").css("display") == "none") {
		$("#main_list_up").show();
		$("#dbzj_electricenergyoutside_js").hide();
		$(".commen_foot").show();
		$("#electricenergyoutsidInsName").html(sessionStorage.insIdDbzj);
		//document.ontouchmove = function(e){ }// 启动滚动
	} else {
		//临时删除localStorage值
		//delete localStorage.CHECKIREAD;
		//delete localStorage.CHECKIREADUP;
		changepage("Businesslist/html/business_list.html");
		$("#uploadInfoType1").attr("src", eo.urlOpen);
		$("#uploadInfoType2").attr("src", eo.urlClose);
		$("#uploadInfoType3").attr("src", eo.urlClose);
		//$("#dbsy_sqyy").attr("src", "../../Util/Images/plxz.png");
		$("#dbsy_sqyy").attr("src","../../Util/Images/arrangements.png");
		$("#textarea_input").val("");
		sessionStorage.refreshTrue = 1;
		sessionStorage.stopRef = undefined;
		sessionStorage.lookAssetID = undefined;
		//清除页面扫描
		sessionStorage.findCode = undefined;
		sessionStorage.newChgDesc = undefined;
		sessionStorage.electMeas = undefined;
		//取消统一视图变量
		sessionStorage.consNoUnify = undefined;
		$("#textarea_input").removeAttr("disabled");
		$("#textarea_input").css("background", "");
	}
}

function controlPopScroll() {
	var popisscroll = false;
	$('.popScroll:eq(0)').live('touchstart', function() {
		popisscroll = true;
	});
	$('.middleInner:eq(0)').live('touchstart', function() {
		popisscroll = true;
	});
	$('#pop').live('touchstart', function() {
		if(!popisscroll) {
			document.ontouchmove = function(e) {
				event.preventDefault();
			}
		} else {
			document.ontouchmove = function(e) {
			}
		}
		popisscroll = false;
	});
}

//用户排序
var selIndexs=0;
function order_btn() {
	var content_array = ['默认排序', '户号排序', '户名排序','地址排序']
	plat_common.invokePopup('排序', content_array, ['取消', '确定'], ['orderCancle', 'orderOK'], sessionStorage.taxis?sessionStorage.taxis:0);
}

function orderCancle(selIndex, selContent, popObj) {
	popObj.remove();
}

function orderOK(selIndex, selContent, popObj) {
	if(selContent == '默认排序') {
		selIndexs=0;
		sessionStorage.taxis = 0;
	}
	if(selContent == '户号排序') {
		selIndexs=1;
		sessionStorage.taxis = 1;
	}
	if(selContent == '户名排序') {
		selIndexs=2;
		sessionStorage.taxis = 2;
	}
	if(selContent == '地址排序') {
		selIndexs=3;
		sessionStorage.taxis = 3;
	}
	//刷新页面
	o.openWait("排序中,请稍等...", 1);
	sessionStorage.findCode=undefined;
	es.selectElecAllData(sessionStorage.mpAppNo);
	popObj.remove();
}