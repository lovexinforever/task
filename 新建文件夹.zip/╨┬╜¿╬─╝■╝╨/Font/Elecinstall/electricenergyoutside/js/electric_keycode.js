var amtypeKey=0;
//点击确定
function ft_key_ok(){
	if($('#waitlogin').css('display')=="block"){
		return;
	}
	if($("#Pop_up_tops").css("display")=="block"){
		var str=$(".headtext").html();
		if(str=="修改电表"){
			//$("#noBottomOk").click(function() {
				ns.modify($("#newModifyInputID").val(), sessionStorage.mtModifyId);
			//})
			//$("#newModifyInputID").val(barcode);
		}else if(str=="新增电表"){
			//$("#newAddInputID").val(barcode);
			//$("#nsBottomOk").click(function() {
				ns.selectAssetBox($("#newAddInputID").val(), sessionStorage.mtNewConsNo);
			//})
		}else if(str=="新增表箱"){
			//$("#nsBottomOk").click(function() {
				//ns.selectAssetBox($("#newAddInputID").val(), sessionStorage.mtNewConsNo);
			//})
			sessionStorage.plMeater = 1;
			nop.AddBoxBarcode($("#newBoxInputID").val());
		}
		
	}
	//关闭
	if(sessionStorage.electMeas||sessionStorage.electMeas!="undefined"){
		if(sessionStorage.newChgDesc==1||sessionStorage.newChgDesc==2){
			//电能表
			if($("#pop").css("display")=="block"){
				ammeterModify(sessionStorage.allUftyI);
			}
		}else if(sessionStorage.newChgDesc==3){
			//触发确定按钮关闭计量箱
			if($("#Pop_up_tops").css("display")=="block"){
				measureOk(sessionStorage.electMeas,$("#containerAssetNo"+sessionStorage.electMeas).val());
			}else{
				containClick(sessionStorage.electMeas,"containid"+sessionStorage.electMeas);
			}
		}else if(sessionStorage.newChgDesc==4||sessionStorage.newChgDesc==5){
			//新增互感器
			if($("#Pop_up_tops").css("display")=="none"){
				ammeterClick(sessionStorage.ammeterJ,1,sessionStorage.ammeterI,$("#IamTypeMtchgDescID"+sessionStorage.electMeas+"s"+sessionStorage.ammeterJ).attr("content"));
			}else{
				induceOK();
				$("#Pop_up_tops").css("display","none");
			}
		}else{
			//弹出
			if(sessionStorage.ammeterJ||sessionStorage.ammeterJ=="undefined"){
				if($("#golist"+sessionStorage.electMeas+"s"+sessionStorage.ammeterJ).css("display")=="block"){
					ammeterClick(sessionStorage.ammeterJ,2,sessionStorage.electMeas,$("#amTypeMtchgDescID"+sessionStorage.electMeas+"s"+sessionStorage.ammeterJ).attr("content"));
				}else if($("#containid"+sessionStorage.electMeas).attr("class").indexOf("changeCssAmmeter")!=-1){
					containClick(sessionStorage.electMeas,"containid"+sessionStorage.electMeas);
				}else{
					//互感器
					ammeterClick(sessionStorage.ammeterJ,1,sessionStorage.electMeas,$("#IamTypeMtchgDescID"+sessionStorage.electMeas+"s"+sessionStorage.ammeterJ).attr("content"));
				}
			}
		}
	}
}
function ft_key_left(){
	if($('#waitlogin').css('display')=="block"){
		return;
	}
	//关闭
	//清除上下键
	sessionStorage.keyD=undefined;
	amtypeKey=0;
	if(sessionStorage.newChgDesc==3){
		//触发确定按钮左
		var loc=$("#getLoc").val();
		if(loc==""){
			loc=0;
		}else{
			loc=Number(loc);
		}
		if(isNaN(lc)||!lc){
			lc=0;
		}
		loc--;
		$("#getLoc").val(loc);
	}else{
		if($("#pop").css("display")=="none"){
			//电能表
			if(!sessionStorage.electMeas||sessionStorage.electMeas=="undefined"){
				sessionStorage.electMeas=mpschemeArray.length-1;
			}else{
				if(sessionStorage.electMeas!=0){
					sessionStorage.electMeas--;
				}else{
					sessionStorage.electMeas=mpschemeArray.length-1;
				}
			}
			electricClick(sessionStorage.electMeas,"electricAll"+sessionStorage.electMeas,sessionStorage.electAmmeterJ,3);
		}
	}
}
function ft_key_right(){
	if($('#waitlogin').css('display')=="block"){
		return;
	}
	//关闭
	//清除上下键
	sessionStorage.keyD=undefined;
	amtypeKey=0;
	if(sessionStorage.newChgDesc==3){
		//触发确定按钮右
		var loc=$("#getLoc").val();
		if(loc==""){
			loc=0;
		}else{
			loc=Number(loc);
		}
		if(lc="NaN"||!lc){
			lc=0;
		}
		loc++;
		$("#getLoc").val(loc);
		
	}else{
		if($("#pop").css("display")=="none"){
			//电能表
			if(!sessionStorage.electMeas||sessionStorage.electMeas=="undefined"){
				sessionStorage.electMeas=0;
			}else{
				if(sessionStorage.electMeas!=(mpschemeArray.length-1)){
					sessionStorage.electMeas++;
				}else{
					sessionStorage.electMeas=0;
				}
			}
			electricClick(sessionStorage.electMeas,"electricAll"+sessionStorage.electMeas,sessionStorage.electAmmeterJ,3);
		}
	}
}
function ft_key_down(){
	if($('#waitlogin').css('display')=="block"){
		return;
	}
	eo.doMpschemething(sessionStorage.electMeas,mpschemeArray[sessionStorage.electMeas].mp_scheme_id);
	//如果计量点打开状态
	if($("#pop").css("display")=="none"&&$("#Pop_up_tops").css("display")=="none"){
		if(sessionStorage.electMeas&&$("#mtitList"+sessionStorage.electMeas).css("display")=="block"){
			var mpsNumber=0;
			var itNumber=0;
			var stt=new Array();
			var sttr=new Array();
			var mmlt=mpschemeArray[sessionStorage.electMeas].mt;
			for(var i=0;i<mmlt.length;i++){
				if(i>=0){
					if(stt.indexOf(mmlt[i].MTid)==-1&&mmlt[i].MTid){
						mpsNumber++;
						stt.push(mmlt[i].MTid);
					}
					if(sttr.indexOf(mmlt[i].scheme_id)==-1&&mmlt[i].scheme_id){
						itNumber++;
						sttr.push(mmlt[i].scheme_id);
					}
				}
			}
			clearClassKey();
			sessionStorage.newChgDesc=undefined;
			//如果什么设备都没选中，则从计量箱开始
			if(sessionStorage.keyD!=3&&sessionStorage.keyD!=4&&sessionStorage.keyD&&sessionStorage.keyD=="undefined"){
				//选中当前计量箱
				$("#containid"+sessionStorage.electMeas).addClass("changeCssAmmeter");
				sessionStorage.keyD=3;
				amtypeKey=0;
			}else if(sessionStorage.keyD==3){
				//选中电能表
				//判断有多少电能表
				//去除计量箱的样式
				if(mpschemeArray[sessionStorage.electMeas].mt.length==0){
					return;
				}
				$("#containid"+sessionStorage.electMeas).removeClass("changeCssAmmeter");
				//给电能表样式
				if(mpsNumber==0&&itNumber==0){
					return;
				}else if(mpsNumber==0&&itNumber!=0){
					$("#aGolist"+sessionStorage.electMeas+"s0").fadeIn();
					$(".iAmType0").addClass("changeCssAmmeter");
					sessionStorage.keyD=4;
				}else if(mpsNumber!=0){
					if(amtypeKey==mpsNumber){
						if(itNumber==0){
							$("#containid"+sessionStorage.electMeas).addClass("changeCssAmmeter");
							sessionStorage.newChgDesc=undefined;
							sessionStorage.keyD=3;
						}else{
							$("#aGolist"+sessionStorage.electMeas+"s0").fadeIn();
							$(".iAmType0").addClass("changeCssAmmeter");
							sessionStorage.ammeterJ=0;
							sessionStorage.keyD=4;
						}
						amtypeKey=0;
					}else{
						//判断电能表是否有照片
						checkIsPicOrNot(sessionStorage.electMeas,amtypeKey);
						$("#golist"+sessionStorage.electMeas+"s"+amtypeKey).fadeIn();
						$(".amType"+amtypeKey).addClass("changeCssAmmeter");
						//提供按OK键需要的变量
						sessionStorage.allUftyI=mpsNumber;
						sessionStorage.ammeterJ=amtypeKey;
						sessionStorage.newChgDesc=undefined;
						amtypeKey++;
					}
				}
			}else if(sessionStorage.keyD==4){
				//如果是第一个互感器
				if(itNumber==1){
					sessionStorage.keyD=3;
				}else{
					if((amtypeKey+1)==itNumber){
						amtypeKey=0;
						$("#containid"+sessionStorage.electMeas).addClass("changeCssAmmeter");
						sessionStorage.newChgDesc=undefined;
						sessionStorage.keyD=3;
					}else{
						//如果是最后一个互感器，则选中计量箱
						sessionStorage.allUftyI=mpsNumber;
						sessionStorage.ammeterJ=(amtypeKey+1);
						sessionStorage.newChgDesc=undefined;
						$("#aGolist"+sessionStorage.electMeas+"s"+(amtypeKey+1)).fadeIn();
						$(".iAmType"+(amtypeKey+1)).addClass("changeCssAmmeter");
						amtypeKey++;
					}
				}
			}
		}
	}
}

function ft_key_up(){
	if($('#waitlogin').css('display')=="block"){
		return;
	}
	eo.doMpschemething(sessionStorage.electMeas,mpschemeArray[sessionStorage.electMeas].mp_scheme_id);
	if($("#pop").css("display")=="none"&&$("#Pop_up_tops").css("display")=="none"){
		//如果计量点打开状态
		if(sessionStorage.electMeas&&$("#mtitList"+sessionStorage.electMeas).css("display")=="block"){
			//如果什么设备都没选中，则从计量箱开始
			var mpsNumber=0;
			var itNumber=0;
			var stt=new Array();
			var sttr=new Array();
			var mmlt=mpschemeArray[sessionStorage.electMeas].mt;
			for(var i=0;i<mmlt.length;i++){
				if(i>=0){
					if(stt.indexOf(mmlt[i].MTid)==-1&&mmlt[i].MTid){
						mpsNumber++;
						stt.push(mmlt[i].MTid);
					}
					if(sttr.indexOf(mmlt[i].scheme_id)==-1&&mmlt[i].scheme_id){
						itNumber++;
						sttr.push(mmlt[i].scheme_id);
					}
				}
			}
			sessionStorage.keyD=undefined;
			clearClassKey();
			if(itNumber==1){
				$("#aGolist"+sessionStorage.electMeas+"s"+(itNumber-amtypeKey-1)).fadeIn();
				$(".iAmType"+(itNumber-amtypeKey-1)).addClass("changeCssAmmeter");
				sessionStorage.keyD=4;
			}else if(itNumber-amtypeKey>0){
				$("#aGolist"+sessionStorage.electMeas+"s"+(itNumber-amtypeKey-1)).fadeIn();
				$(".iAmType"+(itNumber-amtypeKey-1)).addClass("changeCssAmmeter");
				amtypeKey++;
			}else if(itNumber-amtypeKey==0){
				//电能表
				if(mpsNumber-amtypeKey1>0){
					//判断电能表是否有照片
					checkIsPicOrNot(sessionStorage.electMeas,mpsNumber-amtypeKey1-1);
					$("#golist"+sessionStorage.electMeas+"s"+(mpsNumber-amtypeKey1-1)).fadeIn();
					$(".amType"+(mpsNumber-amtypeKey1-1)).addClass("changeCssAmmeter");
					sessionStorage.ammeterJ=mpsNumber-amtypeKey1-1;
					amtypeKey1++;
				}else if(mpsNumber-amtypeKey1==0){
					$("#containid"+sessionStorage.electMeas).addClass("changeCssAmmeter");
					sessionStorage.newChgDesc=undefined;
					amtypeKey=0;
					amtypeKey1=0;
				}
			}else if(itNumber==0){
				if(mpsNumber-amtypeKey1>0){
					//判断电能表是否有照片
					checkIsPicOrNot(sessionStorage.electMeas,mpsNumber-amtypeKey1-1);
					$("#golist"+sessionStorage.electMeas+"s"+(mpsNumber-amtypeKey1-1)).fadeIn();
					$(".amType"+(mpsNumber-amtypeKey1-1)).addClass("changeCssAmmeter");
					sessionStorage.ammeterJ=mpsNumber-amtypeKey1-1;
					amtypeKey1++;
				}else if(mpsNumber-amtypeKey1==0){
					$("#containid"+sessionStorage.electMeas).addClass("changeCssAmmeter");
					sessionStorage.ammeterJ=0;
					sessionStorage.newChgDesc=undefined;
					amtypeKey=0;
					amtypeKey1=0;
				}
			}
		}
	}
}
var amtypeKey1=0;
function clearClassKey(){
	$(".golist").hide();
	$(".aGolist").hide();
	$(".typeClass").removeClass("changeCssAmmeter");
	$("#containid"+sessionStorage.electMeas).removeClass("changeCssAmmeter");
	sessionStorage.newChgDesc=undefined;
}