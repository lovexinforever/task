﻿var connectSql = function() {
	this.sqlVar = "";
	this.appNo = "";
	this.mpSchemeArray = new Array();
	this.mtSchemeArray = new Array();
	this.deviceArray = new Array();
}
connectSql.prototype = {
	selectElecAllData : function(appNo) {
		var taxis = "";
		// if(false){
		// taxis=" order by cons_no asc ";
		// }
		if(sessionStorage.taxis == 0) {
			taxis = ""
		} else if(sessionStorage.taxis == 1) {
			taxis = " order by cons_no asc ";
		} else if(sessionStorage.taxis == 2) {
			taxis = " order by cons_name asc ";
		} else if(sessionStorage.taxis == 3) {
			taxis = " order by mp_addr asc ";
		}
		this.sqlVar = "select distinct mps.[floor] as [floor] ,mps.mp_name as mp_name,mps.mp_addr as mp_addr,mps.longitude as longitude,mps.latitude as latitude, (case when a.name is null then mps.meas_mode else a.name end) as meas_mode, (case when b.name is null then '计量箱' else b.name end) as container_flag,mps.ps_org_no as ps_org_no,mps.cons_name as cons_name,mps.mp_scheme_id as mp_scheme_id,mps.cons_no as cons_no,mps.already_do as already_do,mtb.container_asset_no as container_asset_no,mtb.mp_no as mp_no from yx_mp_scheme mps,yx_mt_box mtb  left join yx_mt_scheme mts on mts.mp_scheme_id=mps.mp_scheme_id left join yx_it_scheme its on its.mp_scheme_id=mps.mp_scheme_id left join (select code_sort_id,value,name from p_code) a on a.code_sort_id='19004'  and a.value=mps.meas_mode left join (select code_sort_id,value,name from p_code) b on b.code_sort_id='18001'  and b.value=mtb.container_flag where  mps.mp_scheme_id=mtb.mp_scheme_id and mps.app_no=? " + taxis;
		this.appNo = appNo;
		db_execut_oneSQL("dbzj.db", this.sqlVar, [appNo], es.sqlCallBack, null);
	},
	sqlCallBack : function(a, b) {
		this.len = b.rows.length;
		if(this.len == 0) {
			if(sessionStorage.stopRef == 1) {
				es.updateNoUserList(sessionStorage.mpAppNo);
				o.openWait("用户已终止", 0);
				changepage("Businesslist/html/business_list.html");
				sessionStorage.stopRef = 0;
			} else {
				sessionStorage.stopRef = 0;
				eo.elecClickDown(sessionStorage.user_name, sessionStorage.mpAppNo, sessionStorage.instanceIdDb);
			}
			return;
		}
		this.e = b.rows.item;
		this.mpSchemeArray = new Array();
		for(var i = 0; i < this.len; i++) {
			this.mpSchemeArray[i] = e(i);
		}
		this.sqlVar = "select mtp.mp_scheme_id,yme.id as MTid,yme.mp_name as MTmp_name,yme.cons_name,yme.cons_no,(case when b.name is null then yme.chg_desc else b.name end) as MTchg_desc,(case when c.name is null then yme.sort_code else c.name end) as MTsort_code,(case when d.name is null then yme.accuracy_code else d.name end) as MTaccuracy_code,(case when e.name is null then yme.volt_code else e.name end) as MTvolt_code,(case when f.name is null then yme.current_code else f.name end) as MTcurrent_code,(case when g.name is null then yme.wiring_mode else g.name end) as MTwiring_mode,yme.asset_no as asset_no,yie.scheme_id as scheme_id,yie.mp_name as ITmp_name,(case when h.name is null then yie.chg_desc else h.name end) as ITchg_desc,(case when i.name is null then yie.sort_code else i.name end) as ITsort_code,(case when j.name is null then yie.accuracy_code else j.name end) as ITaccuracy_code,(case when k.name is null then yie.current_ratio_code else k.name end) as ITcurrent_ratio_code,(case when l.name is null then yie.phase_code else l.name end) as ITphase_code,(case when o.name is null then yie.volt_ratio_code else o.name end) as ITvolt_ratio_code,yie.asset_no as ITasset_no from (select distinct mps.floor as floor ,mps.mp_name as mp_name,mps.mp_addr as mp_addr,mps.longitude as longitude,mps.latitude as latitude,(case when m.name is null then mps.meas_mode else m.name end) as meas_mode, (case when n.name is null then '计量箱' else n.name end) as container_flag,mps.ps_org_no as ps_org_no,mps.cons_name as cons_name,mps.mp_scheme_id as mp_scheme_id,mps.cons_no as cons_no,mps.already_do as already_do,mtb.container_asset_no as container_asset_no,mtb.mp_no as mp_no from yx_mp_scheme mps,yx_mt_box mtb left join yx_mt_scheme mts on mts.mp_scheme_id=mps.mp_scheme_id left join yx_it_scheme its on its.mp_scheme_id=mps.mp_scheme_id left join (select code_sort_id,value,name from p_code) m on m.code_sort_id='19004'  and m.value=mps.meas_mode left join (select code_sort_id,value,name from p_code) n on n.code_sort_id='18001'  and n.value=mtb.container_flag where  mps.mp_scheme_id=mtb.mp_scheme_id and mps.app_no=?) mtp left join yx_mt_scheme yme on yme.mp_scheme_id=mtp.mp_scheme_id left join yx_it_scheme yie on yie.mp_scheme_id= mtp.mp_scheme_id left join (select code_sort_id,value,name from p_code) b on b. code_sort_id='11009'  and b.value=yme.chg_desc left join (select code_sort_id,value,name from p_code) c on c. code_sort_id='18012'  and c.value=yme.sort_code left join (select code_sort_id,value,name from p_code) d on d. code_sort_id='18009'  and d.value=yme.accuracy_code left join (select code_sort_id,value,name from p_code) e on e. code_sort_id='18063'  and e.value=yme.volt_code left join (select code_sort_id,value,name from p_code) f on f. code_sort_id='18064'  and f.value=yme.current_code  left join (select code_sort_id,value,name from p_code) g on g. code_sort_id='19005'  and g.value=yme.wiring_mode left join (select code_sort_id,value,name from p_code) h on h.code_sort_id='11009'  and h.value=yie.chg_desc left join (select code_sort_id,value,name from p_code) i on i.code_sort_id='18001'  and i.value=yie.sort_code left join (select code_sort_id,value,name from p_code) j on j.code_sort_id='18011'  and j.value=yie.accuracy_code left join (select code_sort_id,value,name from p_code) k on k.code_sort_id='18002'  and k.value=yie.current_ratio_code left join (select code_sort_id,value,name from p_code) l on l.code_sort_id='19009'  and l.value=yie.phase_code left join (select code_sort_id,value,name from p_code) o on o.code_sort_id='18003'  and o.value=yie.volt_ratio_code";
		db_execut_oneSQL("dbzj.db", this.sqlVar, [sessionStorage.mpAppNo], es.selecAllBack, null);
	},
	selecAllBack : function(a, b) {
		this.len = b.rows.length;
		this.e = b.rows.item;
		this.mtSchemeArray = new Array();
		for(var i = 0; i < this.len; i++) {
			this.mtSchemeArray[i] = e(i);
		}
		eh.getResult(mpSchemeArray, mtSchemeArray);
	},
	updateLoc : function(assetNo, floor, appNo, mpScheme, oldAsset) {
		var taxis = "";
		var sql="";
		// if(false){
		// taxis=" order by cons_no asc ";
		// }
		if(sessionStorage.taxis == 0) {
			taxis = ""
		} else if(sessionStorage.taxis == 1) {
			taxis = " order by cons_no asc ";
		} else if(sessionStorage.taxis == 2) {
			taxis = " order by cons_name asc ";
		} else if(sessionStorage.taxis == 3) {
			taxis = " order by mp_addr asc ";
		}
		this.sqlVal = "update yx_mp_scheme set floor='" + floor + "',already_do='1' where mp_scheme_id in( select mp_scheme_id from yx_mt_box t where container_asset_no ='" + oldAsset + "' and mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no='" + appNo + "') " + taxis + " limit " + sessionStorage.electMeas + "," + mpschemeArray.length + ")";
		db_execut_oneSQL("dbzj.db", this.sqlVal, [], null, null);
		
		if(oldAsset == "") {
			sql = "update yx_mt_box set container_asset_no='" + assetNo + "',old_asset_no='' where mp_scheme_id='" + mpScheme + "'";
			db_execut_oneSQL("dbzj.db", sql, [], null, null);
		}else{
			sql = "select old_asset_no from yx_mt_box where mp_scheme_id='" + mpScheme + "'";
			db_execut_oneSQL("dbzj.db", sql, [], function(a, b) {
				var len = b.rows.length;
				if(len > 0) {
					var result = b.rows.item(0).OLD_ASSET_NO;
					if(result == undefined) {
						sql = "update yx_mt_box set container_asset_no='" + assetNo + "', old_asset_no='" + oldAsset + "' where mp_scheme_id=" + mpScheme;
					} else {
						sql = "update yx_mt_box set container_asset_no='" + assetNo + "' where mp_scheme_id=" + mpScheme;
					}
				} else {
					sql = "update yx_mt_scheme set container_asset_no='" + assetNo + "', old_asset_no='" + oldAsset + "'  where id=" + mpScheme;
				}
				db_execut_oneSQL("dbzj.db", sql, [], null, null);
			}, null);
		}
		//var sql = "update yx_mt_box set container_asset_no='" + assetNo + "' where  container_asset_no='" + oldAsset + "' and mp_scheme_id='" + mpScheme + "'";
		//db_execut_oneSQL("dbzj.db", sql, [], null, null);
		if(assetNo != oldAsset) {
			var sql2 = "update yx_mp_scheme set longitude='',latitude='' where mp_scheme_id='" + mpScheme + "'";
			db_execut_oneSQL("dbzj.db", sql2, [], null, null);
		}
	},
	updateUnionAsset : function(schemeid, oldAsset, newAsset) {
		var sql = "";
		if(oldAsset == "") {
			sql = "update yx_mt_box set container_asset_no='" + newAsset + "',old_asset_no='' where mp_scheme_id='" + schemeid + "'";
			db_execut_oneSQL("dbzj.db", sql, [], null, null);
		} else {
			//sql = "update yx_mt_box set container_asset_no='" + newAsset + "' where  mp_scheme_id='" + schemeid + "'";
			sql = "select old_asset_no from yx_mt_box where mp_scheme_id='" + schemeid + "' and container_asset_no='" + oldAsset + "'";
			db_execut_oneSQL("dbzj.db", sql, [], function(a, b) {
				var len = b.rows.length;
				// alert('len: ' + len);
				if(len > 0) {
					var result = b.rows.item(0).OLD_ASSET_NO;
					// alert('b.rows.item(0): ' + JSON.stringify(b.rows.item(0)));
					// alert('result: ' + result);
					if(result == undefined) {
						sql = "update yx_mt_box set container_asset_no='" + newAsset + "', old_asset_no='" + oldAsset + "' where mp_scheme_id=" + schemeid;
					} else {
						sql = "update yx_mt_box set container_asset_no='" + newAsset + "' where mp_scheme_id=" + schemeid;
					}
				} else {
					sql = "update yx_mt_scheme set container_asset_no='" + val + "' where id=" + schemeid;
				}
				db_execut_oneSQL("dbzj.db", sql, [], null, null);
			}, null);
		}
		//db_execut_oneSQL("dbzj.db", sql, [], null, null);
		var sql2 = "update yx_mp_scheme set longitude='',latitude='' where mp_scheme_id='" + schemeid + "'";
		db_execut_oneSQL("dbzj.db", sql2, [], null, null);
	},
	updateDownType : function(appNo) {
		this.sqlVal = "update yx_task_list set downloading_type=1 where app_no=?";
		db_execut_oneSQL("dbzj.db", this.sqlVal, [appNo], null, null);
	},
	//处理当前用户
	dealMpschem : function(mpSchemeId) {
		sessionStorage.scrollxy = 0;
		this.sqlVal = "update yx_mp_scheme set already_do=1 where mp_scheme_id='" + mpSchemeId + "'";
		db_execut_oneSQL("dbzj.db", this.sqlVal, [], null, null);
	},
	selectCause : function(appNo) {
		this.sqlVal = "select cause as cause from yx_app_info where app_no='" + appNo + "'";
		db_execut_oneSQL("dbzj.db", this.sqlVal, [], eh.getCause, null);
	},
	//查询示数
	selectIrreadList : function(meterID) {
		this.sqlVal = "select * from (select meter_scheme_id as meter_scheme_id,id as id, (case when a.name is null then yx_irread.read_type_code else a.name end) as read_type_code, last_read as last_read, this_read as this_read,excp_handle_code as excp_handle_code ,mr_digit as mr_digit, a.value,a.content2,a.content4,a.content3,a.content1  from yx_irread left join (select code_sort_id,value,name,content2,content3,content4,content1 from p_code where code_sort_id='18010') a on a.value=yx_irread.read_type_code where meter_scheme_id='" + meterID + "'   and a.value  >=121  order by    a.value   ) union all  select * from ( select meter_scheme_id as meter_scheme_id,id as id, (case when a.name is null then yx_irread.read_type_code else a.name end) as read_type_code, last_read as last_read, this_read as this_read,excp_handle_code as excp_handle_code ,mr_digit as mr_digit,a.value,a.content2,a.content4,a.content3,a.content1 from yx_irread  left join (select code_sort_id,value,name,content1,content2,content3,content4 from p_code where code_sort_id='18010') a on a.value=yx_irread.read_type_code where meter_scheme_id='" + meterID + "'   and a.value  <121      order by    a.value   );"
		db_execut_oneSQL("dbzj.db", this.sqlVal, [], eo.getIrread, null);
	},
	operIrread : function(type1, type2, type3) {
		var type = [];
		for(var i = 0; i < type2.length; i++) {
			type.push("update yx_irread set this_read='" + type3[i] + "'  where METER_SCHEME_ID='" + type1[i] + "' and READ_TYPE_CODE=(select value from p_code where name='" + type2[i] + "') ");
		}
		db_batch_data("dbzj.db", type, [], null, null);
		o.openWait("保存成功", 0, 1);
	},
	typeCode01 : function(data) {
		var sql = [];
		for(var i = 0; i < data.length; i++) {
			sql.push("update yx_irread set EXCP_HANDLE_CODE='01'  where METER_SCHEME_ID='" + eo.irread_id[i] + "' and READ_TYPE_CODE=(select value from p_code where name='" + eo.read_type_code_all[i] + "') ");
		}
		db_batch_data("dbzj.db", sql, [], null, null);
	},
	updateExplor : function(i) {
		var utype = "update yx_irread set EXCP_HANDLE_CODE='01'  where METER_SCHEME_ID='" + eo.irread_id[i] + "' and READ_TYPE_CODE=(select value from p_code where name='" + eo.read_type_code_all[i] + "') ";
		db_execut_oneSQL("dbzj.db", utype, [], null, null);
	},
	updateOverReturn : function(type1, type2, type4) {
		var utype = [];
		for(var i = 0; i < type4.length; i++) {
			utype.push("update yx_irread set EXCP_HANDLE_CODE='08'  where METER_SCHEME_ID='" + eo.irread_id[type4[i]] + "' and READ_TYPE_CODE=(select value from p_code where name='" + type2[i] + "') ");
		}
		db_batch_data("dbzj.db", utype, [], null, null);
	},
	updateModifyNew : function(val, scheme, old_asset_no) {
		// alert('scheme: ' + scheme);
		var sql_get = "select count(1) as a from yx_mt_scheme where  asset_no='" + val + "' and id <>'" + scheme + "'";
		db_execut_oneSQL("dbzj.db", sql_get, [], function(a, b) {
			var e = b.rows.item;
			if(e(0).a == 0) {
				var sql = '';
				var checkSql = '';
				// alert('old_asset_no: ' + old_asset_no);
				if(old_asset_no == '') {
					sql = "update yx_mt_scheme set asset_no='" + val + "', old_asset_no='" + old_asset_no + "' where id=" + scheme;
					db_execut_oneSQL("dbzj.db", sql, [], newassetFun, null);
				} else {
					checkSql = "select old_asset_no from yx_mt_scheme where id='" + scheme + "' and asset_no='" + old_asset_no + "'";
					db_execut_oneSQL("dbzj.db", checkSql, [], function(a, b) {
						var len = b.rows.length;
						// alert('len: ' + len);
						if(len > 0) {
							var result = b.rows.item(0).OLD_ASSET_NO;
							// alert('b.rows.item(0): ' + JSON.stringify(b.rows.item(0)));
							// alert('result: ' + result);
							if(result == undefined) {
								sql = "update yx_mt_scheme set asset_no='" + val + "', old_asset_no='" + old_asset_no + "' where id=" + scheme;
							} else {
								sql = "update yx_mt_scheme set asset_no='" + val + "' where id=" + scheme;
							}
						} else {
							sql = "update yx_mt_scheme set asset_no='" + val + "' where id=" + scheme;
						}
						db_execut_oneSQL("dbzj.db", sql, [], newassetFun, null);
					});
				}
				// var sql = "update yx_mt_scheme set asset_no='" + val + "', old_asset_no='" + old_asset_no + "' where id=" + scheme;
				// db_execut_oneSQL("dbzj.db", sql, [], newassetFun, null);
			} else {
				o.openWait("资产编号不能重复", 0);
			}
		}, null);
	},
	//终止用户
	deleteUser : function(mpschemeid) {
		//删除示数
		var sql_irread = "delete from yx_irread where meter_scheme_id in (select id from yx_mt_scheme where mp_scheme_id='" + mpschemeid + "')";
		db_execut_oneSQL("dbzj.db", sql_irread, [], null, null);
		var sql_it = "delete from yx_it_scheme where mp_scheme_id ='" + mpschemeid + "'";
		db_execut_oneSQL("dbzj.db", sql_it, [], null, null);
		//删除电能表
		var sql_mt = "delete from yx_mt_scheme where mp_scheme_id='" + mpschemeid + "'";
		db_execut_oneSQL("dbzj.db", sql_mt, [], null, null);
		//删除计量箱柜信息
		var sql_tbox = "delete from yx_mt_box where mp_scheme_id='" + mpschemeid + "'";
		db_execut_oneSQL("dbzj.db", sql_tbox, [], null, null);
		//删除用户
		var sqlVar = "delete from yx_mp_scheme where mp_scheme_id='" + mpschemeid + "'";
		db_execut_oneSQL("dbzj.db", sqlVar, [], reLoadElect, null);
	},
	//存储拍照信息
	updataImgInsert : function(data) {
		this.deviceArray = new Array();
		this.deviceArray = data;
		var sql = "select * from device_picture_files where asset_no='" + data[4] + "'";
		db_execut_oneSQL("dbzj.db", sql, [], es.insertImgIfos, null);
	},
	insertImgIfos : function(a, b) {
		var len = b.rows.length;
		var sql = "";
		if(len == 0) {
			sql = "insert into  device_picture_files(app_no, mp_scheme_id, cons_no,device_type, asset_no, file_format, file_size, file_create_time, file_path, file_name, file_root_path)  values(?,?,?,?,?,?,?,?,?,?,?)";
		} else {
			var s = b.rows.item;
			sql = "update  device_picture_files set app_no=?, mp_scheme_id=?, cons_no=?,device_type=?, asset_no=?, file_format=?, file_size=?, file_create_time=?, file_path=?, file_name=?, file_root_path=? where asset_no='" + s(0).ASSET_NO + "'";
		}
		db_execut_oneSQL("dbzj.db", sql, es.deviceArray, saveImgInfosUccess, null);
	},
	selectIrreadPrint : function(i) {
		this.sqlVar = "select ir_date as ir_date from yx_app_info where app_no=?"
		db_execut_oneSQL("dbzj.db", this.sqlVar, [i], eo.printSet1, null);
	},
	selectIrreadPrint2 : function(mpsid) {
		var sql = "select distinct g.chg_desc as chg_desc,ird.read_type_code as read_type_code,g.current_code as current_code,g.volt_code as volt_code,g.sort_code as sort_code,g.asset_no as asset_no,g.id as id,g.mp_scheme_id as mp_scheme_id,read_type_code as read_type_code, this_read as this_read,last_read as last_read from (select  mps.mp_scheme_id,mps.cons_name as cons_name,mps.cons_no as cons_no,mps.mp_addr as mp_addr,apps.ir_date as ir_date,mts.asset_no as asset_no, mts.id as id,(case when b.name is null then mts.chg_desc else b.name end) as chg_desc,(case when a.name is null then mps.meas_mode else a.name end) as meas_mode, (case when e.name is null then mts.volt_code else e.name end) as  volt_code, (case when c.name is null then mts.sort_code else c.name end) as  sort_code,(case when f.name is null then mts.current_code else f.name end) as current_code from yx_mp_scheme mps,yx_mt_scheme mts,yx_app_info apps left join (select code_sort_id,value,name from p_code) b on b. code_sort_id='11009'  and b.value=mts.chg_desc left join (select code_sort_id,value,name from p_code) e on e. code_sort_id='18063'  and e.value=mts.volt_code left join (select code_sort_id,value,name from p_code) f on f. code_sort_id='18064'  and f.value=mts.current_code left join (select code_sort_id,value,name from p_code) c on c. code_sort_id='18012'  and c.value=mts.sort_code left join (select code_sort_id,value,name from p_code) a on a.code_sort_id='19004'  and a.value=mps.meas_mode where mps.mp_scheme_id=mts.mp_scheme_id  and mps.app_no=apps.app_no) g left join  (select meter_scheme_id,this_read,last_read, (case when a.name is null then yx_irread.read_type_code else a.name end) as read_type_code from yx_irread left join (select code_sort_id,value,name from p_code) a on a.code_sort_id='18010'  and a.value=yx_irread.read_type_code   ) ird on g.id=ird.meter_scheme_id where g.mp_scheme_id=?";
		db_execut_oneSQL("dbzj.db", sql, [mpsid], eo.getIrreadDate, null);
	},
	updateAppInfos : function(data) {
		this.sqlVar = "update yx_app_info set ir_date=?,memo=? where app_no=? ";
		db_execut_oneSQL("dbzj.db", this.sqlVar, data, eo.returnAppInfos, null);
	},
	//查询准备上装计量点id
	tempReadyUploadId : function(appNo, mplist, count) {
		var cctn = "";
		var taxis = "";
		// if(false){
		// taxis=" order by cons_no asc ";
		// }
		if(sessionStorage.taxis == 0) {
			taxis = ""
		} else if(sessionStorage.taxis == 1) {
			taxis = " order by cons_no asc ";
		} else if(sessionStorage.taxis == 2) {
			taxis = " order by cons_name asc ";
		} else if(sessionStorage.taxis == 3) {
			taxis = " order by mp_addr asc ";
		}
		if($("#dropUl2").css("display") == "none") {
			cctn = " limit " + count;
		} else {
			cctn = "";
		}
		var lists = "update yx_mp_scheme set already_do=2 where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where already_do=1 and app_no=? " + taxis + cctn + ") and mp_scheme_id in (" + mplist + ")";
		db_execut_oneSQL("dbzj.db", lists, [appNo], function() {
			eo.changeImgToUpDone();
		}, null);
	},
	//查询用户上装信息
	selectAppInfos : function(appNo) {
		var an = "select app_no,emp_no,emp_name,ir_date,memo,dept_no,org_no from yx_app_info where app_no=?";
		db_execut_oneSQL("dbzj.db", an, [appNo], eo.appendAppinfoPage, null);
	},
	//上装信息查询
	getUpLoadinfos : function(appNo, mplist, count) {
		var appinfo = "select app_no,emp_no,emp_name,ir_date,memo,dept_no,org_no from yx_app_info where app_no=?";
		db_execut_oneSQL("dbzj.db", appinfo, [appNo], function(a, b) {
			var len = b.rows.length;
			var e = b.rows.item;
			getUpAppInfo = [];
			for(var i = 0; i < len; i++) {
				getUpAppInfo[i] = e(i);
			}
			es.UpLoadMt(appNo, mplist, count);
		}, null);
	},
	UpLoadMt : function(appNo, mplist, count) {
		var s = mplist == "" ? "" : "and t2.mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where mp_scheme_id in (" + mplist + "))";
		var cctn = "";
		var taxis = "";
		// if(false){
		// taxis=" order by cons_no asc ";
		// }
		if(sessionStorage.taxis == 0) {
			taxis = ""
		} else if(sessionStorage.taxis == 1) {
			taxis = " order by cons_no asc ";
		} else if(sessionStorage.taxis == 2) {
			taxis = " order by cons_name asc ";
		} else if(sessionStorage.taxis == 3) {
			taxis = " order by mp_addr asc ";
		}
		if($("#dropUl2").css("display") == "none") {
			cctn = " limit " + count;
		} else {
			cctn = "";
		}
		//var mtsql1 = "select id,mp_scheme_id,asset_no,cons_no,chg_desc from yx_mt_scheme where mp_scheme_id in(select mp_scheme_id from yx_mp_scheme where already_do=1 and app_no=? " + taxis + cctn + ") " + s ;
		var mtsql = "select t1.id as ID,t1.mp_scheme_id as MP_SCHEME_ID,t1.asset_no as ASSET_NO,t1.cons_no as CONS_NO,t1.chg_desc as CHG_DESC,t1.old_asset_no as OLD_ASSET_NO from yx_mt_scheme t1,(select mp_scheme_id from yx_mp_scheme where already_do=1 and app_no=?  " + taxis + cctn + ") t2 where t1.mp_scheme_id=t2.mp_scheme_id " + s;
		db_execut_oneSQL("dbzj.db", mtsql, [appNo], function(a, b) {
			var len = b.rows.length;
			var e = b.rows.item;
			getUpMtScheme = [];
			for(var i = 0; i < len; i++) {
				getUpMtScheme[i] = e(i);
				// alert('getUpMtScheme[i]: ' + JSON.stringify(getUpMtScheme[i]));
			}
			es.UpLoadIt(appNo, mplist, count);
		}, null);
	},
	UpLoadIt : function(appNo, mplist, count) {
		var s = mplist == "" ? "" : "and t.mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where mp_scheme_id in (" + mplist + "))";
		var cctn = "";
		var taxis = "";
		// if(false){
		// taxis=" order by cons_no asc ";
		// }
		if(sessionStorage.taxis == 0) {
			taxis = ""
		} else if(sessionStorage.taxis == 1) {
			taxis = " order by cons_no asc ";
		} else if(sessionStorage.taxis == 2) {
			taxis = " order by cons_name asc ";
		} else if(sessionStorage.taxis == 3) {
			taxis = " order by mp_addr asc ";
		}
		if($("#dropUl2").css("display") == "none") {
			cctn = " limit " + count;
		} else {
			cctn = "";
		}
		//var itsql1 = "select mp_scheme_id,asset_no,sort_code,scheme_id as ID from yx_it_scheme where mp_scheme_id in( select mp_scheme_id from yx_mp_scheme where already_do=1 and app_no=? " + taxis + cctn + ") " + s ;
		var itsql = "select t1.mp_scheme_id as MP_SCHEME_ID,t1.asset_no as ASSET_NO,t1.sort_code as SORT_CODE,t1.scheme_id as ID,t1.old_asset_no as OLD_ASSET_NO from yx_it_scheme t1,(select mp_scheme_id from yx_mp_scheme where already_do=1 and app_no=?" + taxis + cctn + ") t where t.mp_scheme_id=t1.mp_scheme_id  and t1.chg_desc='01' " + s;
		db_execut_oneSQL("dbzj.db", itsql, [appNo], function(a, b) {
			var len = b.rows.length;
			var e = b.rows.item;
			getUpItScheme = [];
			for(var i = 0; i < len; i++) {
				getUpItScheme[i] = e(i);
			}
			es.UpLoadBox(appNo, mplist, count);
		}, null);
	},
	UpLoadBox : function(appNo, mplist, count) {
		var s = mplist == "" ? "" : "and t.mp_scheme_id in (" + mplist + ")";
		var cctn = "";
		var taxis = "";
		// if(false){
		// taxis=" order by cons_no asc ";
		// }
		if(sessionStorage.taxis == 0) {
			taxis = ""
		} else if(sessionStorage.taxis == 1) {
			taxis = " order by cons_no asc ";
		} else if(sessionStorage.taxis == 2) {
			taxis = " order by cons_name asc ";
		} else if(sessionStorage.taxis == 3) {
			taxis = " order by mp_addr asc ";
		}
		if($("#dropUl2").css("display") == "none") {
			cctn = " limit " + count;
		} else {
			cctn = "";
		}
		var boxsql = "select b.old_asset_no,b.id,b.container_asset_no,b.container_flag,b.mp_scheme_id,t.longitude,t.latitude from yx_mt_box b,yx_mp_scheme t where b.mp_scheme_id=t.mp_scheme_id and t.mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where  already_do=1  and app_no=? " + taxis + cctn + ") " + s;
		db_execut_oneSQL("dbzj.db", boxsql, [appNo], function(a, b) {
			var len = b.rows.length;
			var e = b.rows.item;
			getUpBoxScheme = [];
			for(var i = 0; i < len; i++) {
				getUpBoxScheme[i] = e(i);
			}
			es.UpLoadIrread(appNo, mplist, count);
		}, null);
	},
	UpLoadIrread : function(appNo, mplist, count) {
		var cctn = "";
		var taxis = "";
		// if(false){
		// taxis=" order by cons_no asc ";
		// }
		if(sessionStorage.taxis == 0) {
			taxis = ""
		} else if(sessionStorage.taxis == 1) {
			taxis = " order by mps.cons_no asc ";
		} else if(sessionStorage.taxis == 2) {
			taxis = " order by mps.cons_name asc ";
		} else if(sessionStorage.taxis == 3) {
			taxis = " order by mps.mp_addr asc ";
		}
		if($("#dropUl2").css("display") == "none") {
			cctn = " limit " + count;
		} else {
			cctn = "";
		}
		var irrsql = "select  meter_scheme_id,meter_id,read_type_code,this_read,excp_handle_code  from yx_irread where meter_scheme_id in ( select id from yx_mt_scheme mts,yx_mp_scheme mps where mts.mp_scheme_id=mps.mp_scheme_id and mps.mp_scheme_id in (select distinct mps.mp_scheme_id from yx_mt_scheme mts,yx_mp_scheme mps where mts.mp_scheme_id=mps.mp_scheme_id and  mps.already_do=1 and app_no=? and mts.mp_scheme_id in (" + mplist + ") " + taxis + cctn + "))"
		db_execut_oneSQL("dbzj.db", irrsql, [appNo], function(a, b) {
			var len = b.rows.length;
			var e = b.rows.item;
			getUpIrread = [];
			for(var i = 0; i < len; i++) {
				getUpIrread[i] = e(i);
			}
			es.UpLoadGps(appNo, mplist, count);
		}, null);
	},
	UpLoadGps : function(appNo, mplist, count) {
		var s = mplist == "" ? "" : "and m.mp_scheme_id in (" + mplist + ")";
		var cctn = "";
		var taxis = "";
		// if(false){
		// taxis=" order by cons_no asc ";
		// }
		if(sessionStorage.taxis == 0) {
			taxis = ""
		} else if(sessionStorage.taxis == 1) {
			taxis = " order by m.cons_no asc ";
		} else if(sessionStorage.taxis == 2) {
			taxis = " order by m.cons_name asc ";
		} else if(sessionStorage.taxis == 3) {
			taxis = " order by m.mp_addr asc ";
		}
		if($("#dropUl2").css("display") == "none") {
			cctn = " limit " + count;
		} else {
			cctn = "";
		}
		var gpssql = "select b.id, m.longitude, m.latitude, m.mp_id,floor from yx_mp_scheme m,yx_mt_box b where m.mp_scheme_id=b.mp_scheme_id and already_do=1 and app_no=? " + s + taxis + cctn;
		db_execut_oneSQL("dbzj.db", gpssql, [appNo], function(a, b) {
			var gpsMapIDNum = 0;
			var len = b.rows.length;
			var e = b.rows.item;
			getUpGpsInfos = [];
			for(var i = 0; i < len; i++) {
				if(e(i).LONGITUDE != "" || e(i).LATITUDE != "") {
					if(!e(i).FLOOR) {
						e(i).FLOOR = "";
					}
					getUpGpsInfos[gpsMapIDNum] = e(i);
					gpsMapIDNum++;
				}
			}
			es.UpLoadDev(appNo, mplist, count);

		}, null);
	},
	UpLoadDev : function(appNo, mplist, count) {
		var cctn = "";
		var taxis = "";
		// if(false){
		// taxis=" order by cons_no asc ";
		// }
		if(sessionStorage.taxis == 0) {
			taxis = ""
		} else if(sessionStorage.taxis == 1) {
			taxis = " order by cons_no asc ";
		} else if(sessionStorage.taxis == 2) {
			taxis = " order by cons_name asc ";
		} else if(sessionStorage.taxis == 3) {
			taxis = " order by mp_addr asc ";
		}
		if($("#dropUl2").css("display") == "none") {
			cctn = " limit " + count;
		} else {
			cctn = "";
		}
		var s = mplist == "" ? "" : "and mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where mp_scheme_id in (" + mplist + ") " + taxis + cctn + ")";
		var devsql = "select APP_NO,MP_SCHEME_ID,CONS_NO,DEVICE_TYPE,ASSET_NO,FILE_FORMAT,FILE_SIZE,FILE_CREATE_TIME,FILE_PATH,FILE_NAME,FILE_ROOT_PATH from device_picture_files where asset_no in (select asset_no from yx_mt_scheme where mp_scheme_id in ( select mp_scheme_id from yx_mp_scheme where already_do=1 and app_no=?) " + s + ")";
		db_execut_oneSQL("dbzj.db", devsql, [appNo], function(a, b) {
			var len = b.rows.length;
			var e = b.rows.item;
			getUpDevinfos = [];
			for(var i = 0; i < len; i++) {
				getUpDevinfos[i] = e(i);
			}
			eo.upLoadDateImgInfos();
		}, null);
	},
	devicePicture : function(appNo, mplist, count) {
		var cctn = "";
		var taxis = "";
		var s = mplist == "" ? "" : "and mp_scheme_id in (" + mplist + ")";
		// if(false){
		// taxis=" order by cons_no asc ";
		// }
		if(sessionStorage.taxis == 0) {
			taxis = ""
		} else if(sessionStorage.taxis == 1) {
			taxis = " order by cons_no asc ";
		} else if(sessionStorage.taxis == 2) {
			taxis = " order by cons_name asc ";
		} else if(sessionStorage.taxis == 3) {
			taxis = " order by mp_addr asc ";
		}
		if($("#dropUl2").css("display") == "none") {
			cctn = " limit " + count;
		} else {
			cctn = "";
		}
		//var sql = "select asset_no as asset_no from yx_mt_scheme where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where  already_do=1 and app_no =?  and mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where mp_scheme_id in (" + mplist + ")) " + taxis + cctn + ")";
		var sql = "select asset_no as asset_no from yx_mt_scheme where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where  already_do=1 and app_no ='" + appNo + "'  and mp_scheme_id in(select t.mp_scheme_id from yx_mp_scheme t,(select mp_scheme_id from yx_mp_scheme where already_do=1 and  app_no='" + appNo + "' " + taxis + cctn + ")  b where t.mp_scheme_id=b.mp_scheme_id  ) " + s + " ) ";
		db_execut_oneSQL("dbzj.db", sql, [], eo.gotoOpGetAsset, null);
	},
	deletePicture : function(asset) {
		var s = "delete from DEVICE_PICTURE_FILES where  ASSET_NO=?";
		db_execut_oneSQL("dbzj.db", s, [asset], function() {
			es.updataImgInsert(device_picture);
		}, null);
	},
	selectInfoStat : function(appNo) {
		var sql = "select count(1) as allcount,sum(case when already_do<>0 then 1 else 0 end) as docount from yx_mp_scheme where app_no=?";
		db_execut_oneSQL("dbzj.db", sql, [appNo], eo.StatSuccess, null);
	},
	selectImageInfos : function(ast) {
		var sql = "select file_create_time as file_create_time from DEVICE_PICTURE_FILES where asset_no=?";
		db_execut_oneSQL("dbzj.db", sql, [ast], eo.selectImgTimeSuccess, null);
	},
	selectUpType : function(appNo) {
		this.sqlVar = "select UPLOAD_TYPE from yx_task_list where app_no=?";
		db_execut_oneSQL("dbzj.db", this.sqlVar, [appNo], eo.getTypeofType, null);
	},
	updateTypeUpload : function(appNo, type) {
		this.sqlVar = "update yx_task_list set upload_type='" + type + "' where app_no=?";
		db_execut_oneSQL("dbzj.db", this.sqlVar, [appNo], null, null);
	},
	updateNoUserList : function(appNo) {
		this.sqlVar = "update yx_task_list set upload_type='0',downloading_type='0' where app_no=?";
		db_execut_oneSQL("dbzj.db", this.sqlVar, [appNo], null, null);
	},
	deleteDoneUserList : function(appNo) {
		var sql1 = "delete from yx_app_info where app_no in(select app_no from yx_mp_scheme where already_do=1 and app_no=?)";
		db_execut_oneSQL("dbzj.db", sql1, [appNo], null, null);
		var sql2 = "delete from yx_mp_scheme  where already_do=1 and app_no=?";
		db_execut_oneSQL("dbzj.db", sql2, [appNo], null, null);
		var sql3 = "delete from yx_mt_scheme  where mp_scheme_id in(select mp_scheme_id from yx_mp_scheme where already_do=1 and app_no=?)";
		db_execut_oneSQL("dbzj.db", sql3, [appNo], null, null);
		var sql4 = "delete from yx_it_scheme where mp_scheme_id in( select mp_scheme_id from yx_mp_scheme where already_do=1 and app_no=? )";
		db_execut_oneSQL("dbzj.db", sql4, [appNo], null, null);
		var sql5 = "delete from yx_mt_box where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where already_do=1 and app_no=?)";
		db_execut_oneSQL("dbzj.db", sql5, [appNo], null, null);
		var sql6 = "delete from yx_irread where meter_scheme_id in ( select id from yx_mt_scheme mts,yx_mp_scheme mps where mts.mp_scheme_id=mps.mp_scheme_id and  mps.already_do=1 and app_no=?)";
		db_execut_oneSQL("dbzj.db", sql6, [appNo], null, null);
		var sql7 = "delete from device_picture_files where asset_no in (select asset_no from yx_mt_scheme where mp_scheme_id in ( select mp_scheme_id from yx_mp_scheme where already_do=1 and app_no=? ))";
		db_execut_oneSQL("dbzj.db", sql7, [appNo], null, null);
		var sql8 = "delete from yx_task_list where app_no=?";
		db_execut_oneSQL("dbzj.db", sql8, [appNo], null, null);
	},
	selectMpgpsType : function(mpschemeid) {
		var sql = " select up_gps_type,LONGITUDE,LATITUDE,floor from yx_mp_scheme  where mp_scheme_id=?";
		db_execut_oneSQL("dbzj.db", sql, [mpschemeid], eo.installMpgpsType, null);
	},
	updateItAsset : function(schemeID, asset, old_asset_no) {
		// alert('schemeID: '+ schemeID);
		// alert('asset: ' + asset);
		// alert('old_asset_no: ' + old_asset_no);
		var sdsql = '';
		if(old_asset_no == '') {
			sdsql = "update yx_it_scheme set asset_no='" + asset + "', old_asset_no='" + old_asset_no + "' where scheme_id='" + schemeID + "'";
			db_execut_oneSQL("dbzj.db", sdsql, [], null, null);
			return;
		}
		var sql = "select old_asset_no from yx_it_scheme where scheme_id='" + schemeID + "' and asset_no='" + old_asset_no + "'";
		db_execut_oneSQL("dbzj.db", sql, [], function(a, b) {
			var len = b.rows.length;
			// alert('len: ' + len);
			if(len > 0) {
				var result = b.rows.item(0).OLD_ASSET_NO;
				if(result == undefined) {
					sdsql = "update yx_it_scheme set asset_no='" + asset + "', old_asset_no='" + old_asset_no + "' where scheme_id='" + schemeID + "'";
				} else {
					sdsql = "update yx_it_scheme set asset_no='" + asset + "' where scheme_id='" + schemeID + "'";
				}
			} else {
				sdsql = "update yx_it_scheme set asset_no='" + asset + "', old_asset_no='" + old_asset_no + "' where scheme_id='" + schemeID + "'";
			}
			// alert('sql: ' + sdsql);
			db_execut_oneSQL("dbzj.db", sdsql, [], null, null);
		}, null);
		// var sdsql = "update yx_it_scheme set asset_no='" + asset + "', is_update='" + old_asset_no + "' where scheme_id='" + schemeID + "'";
		// db_execut_oneSQL("dbzj.db", sdsql, [], null, null);
	},
	upDateUpload : function(appNo, type) {
		var sql = "update yx_task_list set upload_type='" + type + "' where app_no='" + appNo + "'";
		db_execut_oneSQL("dbzj.db", sql, [], null, null);
	},
	//工作流提交前查询上装用户信息
	selectBeforeAppInfos : function(data, appNo) {
		var sql1 = "update yx_app_info set ir_date='" + data[0] + "',memo='" + data[1] + "' where app_no='" + data[2] + "'";
		db_execut_oneSQL("dbzj.db", sql1, [], function() {
			var an = "select app_no,emp_no,emp_name,ir_date,memo,dept_no,org_no from yx_app_info where app_no='" + appNo + "'";
			db_execut_oneSQL("dbzj.db", an, [], eo.TODOreferInfos, null);
		}, null);
	},
	//关联计量箱修改
	saveMpgpsInfos : function(lng, lat, appNo, i, assetNo) {
		var taxis = "";
		// if(false){
		// taxis=" order by cons_no asc ";
		// }
		if(sessionStorage.taxis == 0) {
			taxis = ""
		} else if(sessionStorage.taxis == 1) {
			taxis = " order by cons_no asc ";
		} else if(sessionStorage.taxis == 2) {
			taxis = " order by cons_name asc ";
		} else if(sessionStorage.taxis == 3) {
			taxis = " order by mp_addr asc ";
		}
		var sql = "update yx_mp_scheme set longitude='" + lng + "',latitude='" + lat + "' where mp_scheme_id in(select mp_scheme_id from yx_mt_box where mp_scheme_id in(select mp_scheme_id from yx_mp_scheme where app_no='" + appNo + "' " + taxis + " ) and container_asset_no='" + assetNo + "'  limit " + i + "," + mpschemeArray.length + ")";
		db_execut_oneSQL("dbzj.db", sql, [], null, null);
	}
}