var UtilCss="../../Util/css/",
	ElecCss="electricenergyoutside/css/",
	BusCss="Businesslist/css/",
	UtilJs="../../Util/js/",
	PlatJs="../../Platform/Worklist/js/",
	PlatToolJs="../../Platform/Tools/js/",
	PlatDateJs="../../Platform/Date/js/",
	PlatUnfindJs="../../Platform/UnifiedView/js/",
	PlatFileJs="../../Platform/File/js/",
	PlatBtJs="../../Platform/BTPrinter/js/",
	PlatContactJs="../../Platform/Contact/js/",
	PlatScanJs="../../Platform/BTScanner/js/",
	PlatDownJs="../../Platform/Download/js/",
	PlatSetJs="../../Front/setting/js/",
	ElecJs="electricenergyoutside/js/",
	PlatComJs="../../Platform/Plat/common/js/";
/*****************加载css样式***************/
loadjscssfile(UtilCss+"dbubase.css","css");
loadjscssfile(UtilCss+"dbuload.css","css");
loadjscssfile(UtilCss+"dbPop-up-box.css","css");
loadjscssfile(UtilCss+"dbpublic.css","css");
loadjscssfile(ElecCss+"electric_energy.css","css");
loadjscssfile(BusCss+"business.css","css");

/*****************加载js***************/
loadjscssfile(PlatComJs+"adaptive.js","js");
loadjscssfile(PlatComJs+"common.js","js");
loadjscssfile(UtilJs+"iscroll.js","js");
loadjscssfile(PlatJs+"send_data.js","js");
loadjscssfile(PlatJs+"down_zip.js","js");
loadjscssfile(UtilJs+"zepto.min.js","js");
loadjscssfile(PlatToolJs+"camera_photo.js","js");
loadjscssfile(PlatToolJs+"gallery.js","js");
loadjscssfile(UtilJs+"SQLitePlugin.js","js");
loadjscssfile(UtilJs+"dbUtil.js","js");
loadjscssfile(PlatDateJs+"getdate.js","js");
loadjscssfile(UtilJs+"audiowarn.js","js");
loadjscssfile(PlatUnfindJs+"unifiedview.js","js");
loadjscssfile(UtilJs+"readammeter.js","js");
loadjscssfile(UtilJs+"useusbdevice.js","js");
loadjscssfile(PlatToolJs+"map.js","js");
loadjscssfile(PlatToolJs+"nmap.js","js");
loadjscssfile(PlatToolJs+"map_mode.js","js");
loadjscssfile(PlatToolJs+"arcgis.js","js");
loadjscssfile(UtilJs+"gps.js","js");
loadjscssfile(PlatFileJs+"file.js","js");
loadjscssfile(UtilJs+"uploaddata.js","js");
loadjscssfile(PlatJs+"upload_file.js","js");
loadjscssfile(PlatBtJs+"BTPrinter.js","js");
loadjscssfile(PlatContactJs+"Contact_Plugin.js","js");
loadjscssfile(PlatScanJs+"BTScanner.js","js");
loadjscssfile(UtilJs+"scanAssetNo.js","js");
loadjscssfile(PlatDownJs+"download.js","js");
loadjscssfile(PlatToolJs+"toast.js","js");
loadjscssfile(PlatSetJs+"config.js","js");
loadjscssfile(ElecJs+"electric_keycode.js","js");
loadjscssfile(ElecJs+"irread_touch.js","js");

function loadjscssfile(filename,filetype){
	var fileref="";
	if(filetype=="js"){
		fileref=document.createElement("script");
		fileref.setAttribute("type","text/javascript");
		fileref.setAttribute("src",filename);
	}else if(filetype=="css"){
		fileref=document.createElement("link");
		fileref.setAttribute("rel","stylesheet");
		fileref.setAttribute("type","text/css");
		fileref.setAttribute("href",filename);
	}
	var oHead = document.getElementsByTagName('HEAD').item(0);
	if(typeof fileref!=""){
		oHead.appendChild(fileref);
	}
}
