var busiUrl="Businesslist/html/business_list.html",
	chonUrl="../../Util/Images/checkboxon.png",
	choffUrl="../../Util/Images/checkboxoff.png",
	dbsyUrl="../../Util/Images/arrangements.png",
	tool2Url="../../Util/Images/tool2.png",
	toolUrl="../../Util/Images/tool.png",
	printdyUrl="../../Util/Images/dy.png",
	printdy2Url="../../Util/Images/dy2.png",
	scanSmsUrl="../../Util/Images/sms.png",
	indexUrl="../../Platform/Plat/html/index.html",
	scanSms1Url="../../Util/Images/sms1.png";
$(document).ready(function(){
	$("#update").val(sessionStorage.TIM_0605.split(" ")[0]);
	$("#newUpdate").val(sessionStorage.TIM_0605.split(" ")[0]);
	$("#contentPageOne").load(busiUrl);
	$("#back_to_module_choose_installs").click(function(){
		$("#uploadInfoType1").attr("src",chonUrl);
		$("#uploadInfoType2").attr("src",choffUrl);
		$("#uploadInfoType3").attr("src",choffUrl);
		sessionStorage.refreshTrue=0;
		sessionStorage.stopRef=undefined;
		sessionStorage.findCode=undefined;
		sessionStorage.lookAssetID=undefined;
		sessionStorage.newChgDesc=undefined;
		$("#dbsy_sqyy").attr("src","../../Util/Images/plxz.png");
		window.location.replace(indexUrl);
	})
	
	document.body.addEventListener("touchstart",function(){
		if(sessionStorage.touchClew==1){
			 $("#waitcontent").hide();
		}
		touchEnd();
	},false);
	//document.getElementById("loseFocus").addEventListener("touchstart",touchEnd,false);
})
function changepage(loadinglink){
	var parendID=$("div[id*='getparentID_']").parent().attr("id");
	var parendidf;
   	if(parendID=="contentPageOne"){
	   	parendidf ="contentPageTwo";
   	}else{
   		parendidf ="contentPageOne";
   	}
  	$("#"+parendidf).load(loadinglink);
  	var parendidf1 = document.getElementById(parendidf);
  	var parendID2 = document.getElementById(parendID);
  	parendidf1.style.display="block";
  	parendidf1.className="contentPageTwo";
  	parendID2.className="contentPageOne";
  	
  	parendidf1.style.zIndex="3";
  	parendID2.style.zIndex="2";
  	parendID2.style.display="none";
  	var t1=setTimeout(function(){$("#"+parendID+" *").remove();},80);
}

var mdFalse=0;
//判断是否为测试环境
if(sessionStorage.ISPRO=="0"){
	//测试环境
	$("#dbzj_tool").attr("src",tool2Url);
}else{
	//正式环境
	$("#dbzj_tool").attr("src",toolUrl);
}
if(sessionStorage.printer==1){
	$("#print_connecte_db").attr("src",printdyUrl);
}else{
	$("#print_connecte_db").attr("src",printdy2Url);
}
if(sessionStorage.scan == 1){
	$("#scan_connecte_db").attr("src",scanSmsUrl);
}else{
	$("#scan_connecte_db").attr("src",scanSms1Url);
}
//解决日历卡、页面重绘问题
function cleardata(){
	 $(".testnofocus").focus(); 
	 setTimeout(function(){
	 $(".testnofocus").blur();
	 },2000) 
	}
function open_veiw(){
	if(sessionStorage.consNoUnify&&sessionStorage.consNoUnify!="undefined"){
		unify(sessionStorage.consNoUnify);
	}else{
		unify("");
	}
}
//导航
function getgpsse(){
	if($("#dbsy_sqyy").attr("src")!="../../Util/Images/plxz.png"){
		var value=JSON.parse(sessionStorage.sessGpsXy);
		//sessionStorage.sessGpsXy='{"ends_x":[],"ends_y":[]}'
		if(JSON.stringify(value).length==25){
			openMap();
		}else{
			multipointNavi(function(data){
				//data.code==100成功
				if(data.code=="101"){
					o.openWait("定位失败,正在打开地图...",0);
					setTimeout(function(){
						//showMap();
						openMap();
					},2000);
				}else if(data.code=="102"){
					o.openWait("传递地图参数错误",0);
					setTimeout(function(){
						//showMap();
						openMap();
					},2000);
				}
			},value);
		}
	}else{
		//showMap();
		openMap();
	}
}
function sys_tool(type){
	//弹出工具箱
	if(type==1){
		//弹出对话框
	   // $(".Pop-up-layer2").toggle()
		if(document.getElementById("Pop-up-layer2_mc").style.display=="none"){
			$("#Pop-up-layer2_mc").show();
			document.ontouchmove = function(e){ e.preventDefault(); }// 禁止滚动
		}else{
			$("#Pop-up-layer2_mc").hide();
			document.ontouchmove = function(e){ }// 启动滚动
		}
	}
	//点击工具箱任何工具关闭，工具箱。
	else if(type==2){
 		 closedailog("Pop-up-layer2_mc");
	 	 document.ontouchmove = function(e){ }
	}
	if(type==3){
		read_Barcode(log,log);
		closedailog("Pop-up-layer2_mc");
		document.ontouchmove = function(e){ }
		function log(e){
			
		}
	}
	if(type==4){
		swtich_Light(log,log);
		function log(){};
	}
	
}

////////////////////////////今天 16-22添加///////////////////////////
/*隐藏页面底部*/
// function hide_foot(){	
	// $(".commen_foot").hide();
	// //获得焦点
	// if($(".shadow textarea,.shadow input").is(":focus")){
	    // $(".shadow").show();
		// $(".shadow textarea").height(200)
	// }else{
	// $(".shadow").hide();
	// }
// }
// function show_foot(){
	    // $(".shadow textarea").height(100)	
		// $(".commen_foot").show();
		// $(".shadow").show();
// }

// document.getElementById("loseFocus").addEventListener("touchstart",touchbg,false);
// function touchbg(){
		// if(document.activeElement.tagName==="INPUT"||document.activeElement.tagName==="TEXTAREA"){
// 			
			 // if(typeof hideSoftInputFromWindow=="function"){
				 // hideSoftInputFromMainActivity()
			  // }else{
			  // }
// 
			// $(".testnofocus").focus(); 
			 // setTimeout(function(){
				 // $(".testnofocus").blur(); 
				 // },300)
// 
			// }
// }
///////////////////////////////////////////////////////

//关闭对话框
function closedailog(id){
	 var s = 100
	 var hidediloag=setInterval(function(){
	     s=s-10;
		 var docustyle = document.getElementById(id).style;
		 docustyle.height=s+"%";
		 docustyle.overflow="hidden"
		 if(s==-10){
			 docustyle.display="none"
	         clearInterval(hidediloag);
			 }
	 },1)
	  setTimeout(function(){
      		 $(".testnofocus").focus(); 
	     setTimeout(function(){
		 $(".testnofocus").blur(); 
		 },2000)  
	  },0)
}
var get_num_gps=0;
function display_elect_id_info(){
	settimeout();
	if(get_num_gps==1){
		getarcgis(0);
		get_num_gps=0;
	}
	$("#dbzj_loading_view").hide();
	$("#Pop-up-layer_elect_id_info").hide();
	document.ontouchmove = function(e){  }
}
//打开对话框
function opendailog(id){
	 var s=0;
	 var hidediloag=setInterval(function(){
	     s=s+10;
		 var docustyle = document.getElementById(id).style;
		 docustyle.display="block";
		 docustyle.height=s+"%";
		 docustyle.overflow="auto";
		 if(s==100){
			 docustyle.height="103%";
			 docustyle.width="102%";
	         clearInterval(hidediloag);
		 }
	 },100)
} 
//document.getElementById("loseFocus").addEventListener("touchstart",touchEnd,false);
function touchEnd(){
	if(document.activeElement.tagName==="INPUT"||document.activeElement.tagName==="TEXTAREA"){
		$(".commen_foot").show();
	}
}
//查看申请原因
function dbsy_link(){
	if($("#dbsy_sqyy").attr("src")=="../../Util/Images/arrangements2.png"){
		es.selectCause(sessionStorage.mpAppNo);
	}
}
function getNumberToGoPlxz(tx,res){
	var len=res.rows.length,e=res.rows.item;
	if(len>0){
		if(e(0).number==e(0).allnumber){
			changepage("FastNewAdd/html/lotnew.html");
			$("#dbsy_sqyy").attr("src","../../Util/Images/arrangements.png");
			//s.selectNewAdd(localStorage.user_name);
		}else{
			o.openWait("工单全部下装完成才能批量新装!",0);
		}
	}
}
