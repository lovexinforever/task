//iscroll滑动
var o=new Operation(),sa=new handle(),bar=new barCode(),s=new sqlConnect(),h=new htmlAppend(),appNoList=new Array(),appAllList=new Array(),tempLocAppNo=new Array(),refreshTrue=false,allDownType=0,downTrue=false,userCount=0,stopDown=0,objId="";
//插件加载完成
document.addEventListener("deviceready",initVazil,false);
function initVazil(){
	//蓝牙连接功能
	o.blueTool("scan_connecte_db");
	//o.getScroll("scrollDivID");
	//加载表头
	$("#dbzj_loginuser_info").html(sessionStorage.area + "-" + sessionStorage.user_name_str + "-" + sessionStorage.user_name);
	//打开蒙版
	o.openWait("数据正在加载中...",1);
	//请求数据
	refreshTrue=false;
	s.getDateInit("dbzj.db",sessionStorage.user_name,getSuccess,getFail);
}
//获取数据回调
function getSuccess(tx,res){
	var count = res.rows.item(0).bs;
	if(count>0){
		if(sessionStorage.statusFilter==1){
			$("#dbzjBusinessListFilter").attr("src",o.returnString("filter2.png"));
			jsonDbzjFilter = {"app_no":sessionStorage.dbzjFilterAppNo,"ins_name":sessionStorage.dbzjFilterInsName,"act_name":sessionStorage.dbzjFilterActName,"rcv_time1":sessionStorage.dbzjFilterRcvTime1,"rcv_time2":sessionStorage.dbzjFilterRcvTime2,"due_time1":sessionStorage.dbzjFilterDueTime1,"due_time2":sessionStorage.dbzjFilterDueTime2,"notes":sessionStorage.dbzjFilterNotes,"upload_type1":sessionStorage.displayUploadApp1,"upload_type2":sessionStorage.displayUploadApp2,"downloading_type1":sessionStorage.displayDownload1,"downloading_type2":sessionStorage.displayDownload2};
			o.choiseInstallElec(jsonDbzjFilter,sessionStorage.user_name,FilterCallBack);
			return;
		}
		//如果在本地查询到数据,则查询出来并提示可手动刷新最新数据
		s.initDate("dbzj.db",sessionStorage.user_name,getInitPage,getFail);
	}else{
		//请求服务器数据
		o.sendTask(sessionStorage.user_name,sessionStorage.ORG_NO,getSendDate,getFail);
	}
}
//获取本地数据库数据,填充页面数据
function getInitPage(e,b,c){
	var len = b.rows.length;
	userCount=len;
	var e = b.rows.item;
	//先清空列表数据再填充
	var ahtml=$("#dbzj_business_list_data"),ahtmlAppend="";
	ahtml.html("");
	//关闭蒙版
	//友情提示需要手动刷新
	for(var i=0;i<len;i++){
		//$("#dbzj_business_list_data").append(h.loadInitPage(e,i,0));
		ahtmlAppend+=h.loadInitPage(e(i),i,0);
	}
	//$("#dbzj_business_list_data").append("<div style='height:150px'></div>");
	ahtml.append(ahtmlAppend+"<div style='height:150px'></div>");
	if(sessionStorage.scrollxy){
		ahtml.scrollTop(sessionStorage.scrollxy);
	}
	//如果是筛选或者从用户列表返回，则不进行提示
	if(sessionStorage.refreshTrue==1){
		sessionStorage.refreshTrue=0;
		o.openWait("",2);
		return;
	}
	if(!c){
		if(allDownType==0){
			if(!refreshTrue){
				//如果是第一次进入待办事宜
				o.openWait("如有工单不一致，请手动刷新",0);
			}else{
				//如果是点击刷新
				o.openWait("刷新工单完成",0);
			}
		}else{
			//下载完成刷新
			allDownType=0;
			o.openWait("下载工单完成",0);
		}
	}else{
		o.openWait("数据加载完成",0,1);
	}
}
//单个下载工单显示到界面
function dataProc(data){
	var html=h.loadInitPage(data(0),sessionStorage.appNoi,2);
	$("#main_list_business"+sessionStorage.appNoi).html(html);
}
//请求数据返回结果
function getSendDate(data,type){
	var gets="";
	if(!type){
		gets=o.getData(data);
	}else{
		gets=data;
	}
	// var gets=o.getData(data);
	if(typeof gets=="object"){
		if(gets==""){
			userCount=gets.length;
			s.deleteLastDate("dbzj.db",sessionStorage.user_name);
			o.openWait("暂无工单信息",0);
		}else{
			userCount=gets.length;
			//插入数据库操作
			s.insertList("dbzj.db",gets,sessionStorage.user_name);
			//先清空列表数据再填充
			var businessID=$("#dbzj_business_list_data"),businessHtml="";
			businessID.html("");
			//关闭蒙版
			//请求数据之后先展示到界面，然后后台操作插入数据库
			for(var i=0;i<gets.length;i++){
				businessHtml+=h.loadInitPage(gets[i],i,1);
			}
			businessID.append(businessHtml+"<div style='height:150px'></div>");
			o.openWait("数据加载完毕",0);
		}
	}else if(typeof gets=="string"){
		var sgets=gets.substring(gets.lastIndexOf("/")+1,gets.length).replace(".zip",".txt");
		sessionStorage.downfilename=sgets;
		donwloadAndZip(sessionStorage.DOWN_URL+"/"+gets,"",o.dataUrlCallBack);
	}else{
		o.openWait(gets,0);
	}
}
//失败回调
function getFail(){
	o.openWait("无网络服务",0);
	if(downTrue){
		s.urlFail();
	}
}
//工单下载
function dbzjBusinessListDowmload(that,type){
	downTrue=true;
	if(type!=2){
		var thisID=that.id,alt=that.alt,i=alt.split("_")[0],id=alt.split("_")[1],appNo=thisID.split("_")[1],insId=thisID.split("_")[2],src=($("#"+thisID).attr("src")).substring(($("#"+thisID).attr("src")).lastIndexOf("/")+1,($("#"+thisID).attr("src")).length);
		sessionStorage.binitAppNo=appNo;
		sessionStorage.appNoi=i;
		sessionStorage.thisID=thisID;
		sessionStorage.reinsId=insId;
		sessionStorage.imageUp=src;
		if(src=="chulizhong.png" || src == "chuliwancheng.png"){
			//是否重新下载数据
			$("#confirmDailogImg").show();
			return ;
		}
	//如果下载，则更改图标状态
		o.openWait("数据下装中...",1);
		$("#"+thisID).attr("src",o.returnString("dowanload_ing.gif"));
		s.dbzjBusinessDownLoad(appNo,insId,sessionStorage.user_name,i,DownSingle,getFail);
	}else{
		o.openWait("数据下装中...",1);
		$("#"+sessionStorage.thisID).attr("src",o.returnString("dowanload_ing.gif"));
		s.dbzjBusinessDownLoad(sessionStorage.binitAppNo,sessionStorage.reinsId,sessionStorage.user_name,i,DownSingle,getFail);
	}
}
function DownSingle(data){
	downTrue=false;
	o.getDownSingle(data,sessionStorage.binitAppNo,1);
}
//重新下载工单
function upload_img(){
	$("#confirmDailogImg").hide();
	// s.updateDownType(sessionStorage.binitAppNo);
	dbzjBusinessListDowmload(sessionStorage.thisID,2);
}
function upload_img_concle(){
	$("#confirmDailogImg").hide();
}
//页面跳转至计量点信息页面
//点击待办事宜,获取点击记录申请编号
function dbzjBusinessListClick(appNo,insId,i) {
	if($("#typeDownID"+i).html()=="暂无工单计量信息"){
		o.openWait("该工单没有计量信息",0);
		return ;
	}
	sessionStorage.mpAppNo = appNo.split("_")[0];
	//记录计量信息头部
	sessionStorage.insIdDbzj = appNo.split("_")[1];
	sessionStorage.instanceIdDb=insId;
	//存储当前位置
	sessionStorage.appNoi=i;
	sessionStorage.scrollxy=$("#dbzj_business_list_data").scrollTop();
	o.openWait("数据加载中...",1);
	$("#dbsy_sqyy").attr("src","../../Util/Images/arrangements2.png");
	changepage("electricenergyoutside/html/electricenergyoutside.html");
}
/*--------------------全部工单下载--------------------*/
function AllDownload(){
	if($("#dbzj_business_list_data").html()==""){
		o.openWait("暂无数据，无法下装",0);
	}else{
		$("#confirm_dailog_download").show();
	}
}
//确定下载
function downloadAllOk(){
	stopDown=0;
	$("#qxXiazai").html('<img src="../../Util/Images/qxxz.png" class="img_qxxz" onclick="imgQxxz()" />');
	//关闭确定界面
	$("#confirm_dailog_download").hide();
	//打开下载界面
	$("#dbzjLoadingViewScroll").show();
	//显示总工单数
	factorial(0,userCount);
	
	$("#countofall").html(userCount);
}

function factorial(num,userCount){
	//全部下载中单个进度
	if(num<userCount){
		//alert($("#main_list_business"+num).find("img:eq(1)").attr("src"));
		var thisID=$("#main_list_business"+num).find("img:eq(1)").attr("id"),
			alt=$("#main_list_business"+num).find("img:eq(1)").attr("alt"),
			i=alt.split("_")[0],
			id=alt.split("_")[1],
			appNo=thisID.split("_")[1],
			insId=thisID.split("_")[2],
			src=($("#"+thisID).attr("src")).substring(($("#"+thisID).attr("src")).lastIndexOf("/")+1,($("#"+thisID).attr("src")).length);
		$("#alreadydownload").html(num+1);
		sessionStorage.imageUp=src;
		if(src=="chulizhong.png" || src == "chuliwancheng.png"|| src == "downloadover.png"){
			factorial(num+1,userCount);
			return;
		}
		$("#main_list_business"+num).find("img:eq(1)").attr("src",o.returnString("dowanload_ing.gif"));
		s.dbzjBusinessDownLoad(appNo,insId,sessionStorage.user_name,i,function(data){
			o.getDownSingle(data,appNo,2,num,userCount);
		},function(){
			$("#dbzjLoadingViewScroll").hide();
			o.openWait("网络连接失败!",0);
			$("#main_list_business"+num).find("img:eq(1)").attr("src",o.returnString("download3.png"));
		});
	}else{
		//提示信息提示参数
		allDownType=1;
		$("#dbzjLoadingViewScroll").hide();
		o.openWait("数据已下装",0);
	}
}
//取消下载
function confirmCancel(){
	$("#confirm_dailog_download").hide();
}
//中断下载
function imgQxxz(){
	stopDown=1;
	$("#qxXiazai").html("正在取消下载.......");
}
/*--------------------全部工单下载结束--------------------*/
//工单刷新
function businessRefresh(){
	allDownType=0;
	downTrue=false;
	var time="";
	if(sessionStorage.Rtime){
		time="<br />最近刷新时间:"+	sessionStorage.Rtime;
	}else{
		time="";
	}
	sessionStorage.statusFilter=0;
	$("#dbzjBusinessListFilter").attr("src",o.returnString("filter.png"));
	o.openWait("正在刷新请稍等..."+time,1);
	o.sendTask(sessionStorage.user_name,sessionStorage.ORG_NO,RefreshBack,getFail);
	var d=new Date(),s=d.toTimeString(),m=d.getMonth()+1,data=d.getDate(),y=d.getFullYear();
	sessionStorage.Rtime=y+"/"+m+"/"+data+" "+s.split(" ")[0];
}
//刷新数据处理
function RefreshBack(data,type){
	var gets="";
	if(!type){
		gets=o.getData(data);
	}else{
		gets=data;
	}
	if(typeof gets=="object"){
		if(gets==""){
			$("#dbzj_business_list_data").html("");
			s.deleteLastDate("dbzj.db",sessionStorage.user_name);
			o.openWait("暂无工单信息",0);
		}else{
			appNoList=new Array();
			appAllList=new Array();
			for(var i=0;i<gets.length;i++){
				appNoList.push(gets[i].app_no);
				appAllList=gets;
			}
			//删除数据库
			s.deleteSqlDbzj("dbzj.db",appNoList,"not","",1);
			//更新数据库
			s.updateAppUser(sessionStorage.user_name);
		}
	}else if(typeof gets=="string"){
		var sgets=gets.substring(gets.lastIndexOf("/")+1,gets.length).replace(".zip",".txt");
		sessionStorage.downfilename=sgets;
		donwloadAndZip(sessionStorage.DOWN_URL+"/"+gets,"",o.dataUrlCallBack);
	}else{
		o.openWait(gets,0);
	}
}
/*-------------------------------筛选开始--------------------------*/
function dbzjBusinessFilter(){
	$("#dbzjShaixuanDiv").show();
}
//关闭筛选界面
function dbzjFilterClose(){
	$("#dbzjShaixuanDiv").hide();
}
//确定筛选条件
var displayUploadApp1="",displayUploadApp2="",displayDownload1="",displayDownload2="",loadTime1="",loadTime2="",jsonDbzjFilter="";
function dbzjFilterOk(){
  	var reg = new RegExp("\\"+"%","g");
  	var reg2 = new RegExp("\\"+"_","g");
	//条件：申请编号
	var dbzjFilterAppNo = $("#dbzjFilterAppNo").val();
	dbzjFilterAppNo = dbzjFilterAppNo.replace(/^\s+|\s+$/g, "");
	dbzjFilterAppNo = dbzjFilterAppNo.replace(reg,"[%]");
	dbzjFilterAppNo = dbzjFilterAppNo.replace(reg2,"[_]");
	//流程名称
	sessionStorage.dbzjFilterAppNo=dbzjFilterAppNo;
	var dbzjFilterInsName = $("#dbzjFilterInsName").val();
	dbzjFilterInsName = dbzjFilterInsName.replace(/^\s+|\s+$/g, "");
	dbzjFilterInsName = dbzjFilterInsName.replace(reg,"[%]");
	dbzjFilterInsName = dbzjFilterInsName.replace(reg2,"[_]");
	//活动名称
	sessionStorage.dbzjFilterInsName=dbzjFilterInsName;
	var dbzjFilterActName = $("#dbzjFilterActName").val();
	dbzjFilterActName = dbzjFilterActName.replace(/^\s+|\s+$/g, "");
	dbzjFilterActName = dbzjFilterActName.replace(reg,"[%]");
	dbzjFilterActName = dbzjFilterActName.replace(reg2,"[_]");
	sessionStorage.dbzjFilterActName=dbzjFilterActName;
	//接收时间 起始
	var dbzjFilterRcvTime1 = $("#dbzjFilterRcvTime1").val();
	sessionStorage.dbzjFilterRcvTime1=dbzjFilterRcvTime1;
	//接收时间结束
	var dbzjFilterRcvTime2 = $("#dbzjFilterRcvTime2").val();
	sessionStorage.dbzjFilterRcvTime2=dbzjFilterRcvTime2;
	//到期时间起始
	var dbzjFilterDueTime1 = $("#dbzjFilterDueTime1").val();
	sessionStorage.dbzjFilterDueTime1=dbzjFilterDueTime1;
	//到期时间结束
		
	var dbzjFilterDueTime2 = $("#dbzjFilterDueTime2").val();
	sessionStorage.dbzjFilterDueTime2=dbzjFilterDueTime2;
	//说明
	var dbzjFilterNotes = $("#dbzjFilterNotes").val();
	dbzjFilterNotes = dbzjFilterNotes.replace(/^\s+|\s+$/g, "");
	dbzjFilterNotes = dbzjFilterNotes.replace(reg,"[%]");
	dbzjFilterNotes = dbzjFilterNotes.replace(reg2,"[_]");
	sessionStorage.dbzjFilterNotes=dbzjFilterNotes;
	var upload_type=0;
	displayUploadApp1=$("#filterUploadType1").attr("src")==o.returnString("checkboxon.png")?"1":"";
	sessionStorage.displayUploadApp1=displayUploadApp1;
	displayUploadApp2=$("#filterUploadType2").attr("src")==o.returnString("checkboxon.png")?"0":"";
	sessionStorage.displayUploadApp2=displayUploadApp2;
	displayDownload1=$("#filterUploadType3").attr("src")==o.returnString("checkboxon.png")?"1":"";
	sessionStorage.displayDownload1=displayDownload1;
	displayDownload2=$("#filterUploadType4").attr("src")==o.returnString("checkboxon.png")?"0":"";
	sessionStorage.displayDownload2=displayDownload2;
	//初始化筛选条件
	jsonDbzjFilter = {"app_no":dbzjFilterAppNo,"ins_name":dbzjFilterInsName,"act_name":dbzjFilterActName,"rcv_time1":dbzjFilterRcvTime1,"rcv_time2":dbzjFilterRcvTime2,"due_time1":dbzjFilterDueTime1,"due_time2":dbzjFilterDueTime2,"notes":dbzjFilterNotes,"upload_type1":displayUploadApp1,"upload_type2":displayUploadApp2,"downloading_type1":displayDownload1,"downloading_type2":displayDownload2};
	//sessionStorage.ofshaixuan=1;
	//调用筛选接口
	o.choiseInstallElec(jsonDbzjFilter,sessionStorage.user_name,FilterCallBack);
	//筛选状态
	sessionStorage.statusFilter=1;
	$("#dbzjBusinessListFilter").attr("src",o.returnString("filter2.png"));
	dbzjFilterClose();
}
//3:筛选；2：下载
function FilterCallBack(e,res){
	var count = res.rows.length;
		//数据已存在数据库
		if(count > 0) {
			//查询数据库
			getInitPage(e, res,3);
		}else{
			o.openWait("筛选结果为空",0);
		}
}
//清空当前筛选输入框
function dbzjFilterClear(){
	$("#dbzjFilterAppNo").val("");
	$("#dbzjFilterInsName").val("");
	$("#dbzjFilterActName").val("");
	$("#dbzjFilterRcvTime1").val("");
	$("#dbzjFilterRcvTime2").val("");
	$("#dbzjFilterDueTime1").val("");
	$("#dbzjFilterDueTime2").val("");
	$("#dbzjFilterLoadTime1").val("");
	$("#dbzjFilterLoadTime2").val("");
	$("#dbzjFilterNotes").val("");
	$("#filterUploadType1").attr("src",o.returnString("checkboxoff.png"));
	$("#filterUploadType2").attr("src",o.returnString("checkboxoff.png"));
	$("#filterUploadType3").attr("src",o.returnString("checkboxoff.png"));
	$("#filterUploadType4").attr("src",o.returnString("checkboxoff.png"));
}
//时间选择
function dbzjFilterClick(num) {
	switch(num) {
		case 1:
			objId = "dbzjFilterRcvTime1";
			break;
		case 2:
			objId = "dbzjFilterRcvTime2";
			break;
		case 3:
			objId = "dbzjFilterDueTime1";
			break;
		case 4:
			objId = "dbzjFilterDueTime2";
			break;
	}
	get_sx_date(electSuccess, electSuccess);
}
function electSuccess(e){
	//点击清除按钮
	//$("#dbzj_loginuser_nav").click();
	if(e==0){
		$("#" + objId).val("");
	} else {
		if(objId == "dbzjFilterRcvTime2" && $("#dbzjFilterRcvTime1").val() > e) {
			o.openWait("结束日期不能小于开始日期",0);
		} else if(objId == "dbzjFilterDueTime2" && $("#dbzjFilterDueTime1").val() > e) {
			o.openWait("结束日期不能小于开始日期",0);
		}else if(objId == "dbzjFilterRcvTime1" && $("#dbzjFilterRcvTime2").val() < e && $("#dbzjFilterRcvTime2").val()!=""){
			o.openWait("开始日期不能大于结束日期",0);
		}else if(objId == "dbzjFilterDueTime1" && $("#dbzjFilterDueTime2").val() < e && $("#dbzjFilterDueTime2").val()!=""){
			o.openWait("开始日期不能大于结束日期",0);
		}else {
			$("#" + objId).val(e);
		}
	}
}
function filterUploadType(type){
	//上装，未上装，下装，未下装
	if($("#filterUploadType"+type).attr("src")==o.returnString("checkboxon.png")){
		$("#filterUploadType"+type).attr("src",o.returnString("checkboxoff.png"));
	}else{
		$("#filterUploadType"+type).attr("src",o.returnString("checkboxon.png"));
	}
}
/*-------------------------------筛选结束--------------------------*/
//视频播放功能
function seeVideo(){
	showFuncIntroVideoList();
}
//打开统一视图
//后退到平台首页
function dbzjLoginuserBack(){
	//取消是否刷新变量
	sessionStorage.refreshTrue=0;
	sessionStorage.scrollxy=undefined;
	window.location.replace("../../Platform/Plat/html/index.html");
}
