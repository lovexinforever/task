/** 显示功能介绍视屏列表的构造函数 */
var FuncIntroVideoList = function() {
}

/**
 * 显示系统功能介绍列表
 * （1）如果在SdCard上不存在目录"/mnt/sdcard/movies"目录则显示SdCard根目录
 */
FuncIntroVideoList.prototype.showFuncIntroVideoList = function(action) {
	return PhoneGap.exec(null, null, 'FunIntroPlugin', action, ['']);
}

cordova.addConstructor(function() {
	cordova.addPlugin("funcIntroVideoList", new FuncIntroVideoList()); 
});

/** 显示视频列表 */
function showFuncIntroVideoList(){
	window.plugins.funcIntroVideoList.showFuncIntroVideoList("action_show_func_intro_video_list");
}