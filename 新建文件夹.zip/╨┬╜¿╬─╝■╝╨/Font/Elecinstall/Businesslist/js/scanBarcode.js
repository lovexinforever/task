function get_barcode(code){

	if($('#waitlogin').css('display')=="block"){
		return;
	}
	var barcode=sa.handleAssetNo(sessionStorage.ORG_NO,code),mtBoxBarcode="";
	o.openWait("扫描资产号为："+barcode,0,1);
	//获取电表资产号后,从数据库获取当前申请工单
	//if(sessionStorage.findCode!=1){
	sessionStorage.barCodeInti=barcode;
	var measureBox=(code.toString()).substring(0,2);
	if(measureBox=="23"){
		mtBoxBarcode="G"+code.substring(2,code.length);
	}else{
		mtBoxBarcode=code;
	}
	sessionStorage.mtBoxBarcode=mtBoxBarcode;
	//if($("#dbsy_sqyy").attr("src")=="../../Util/Images/plxz.png"){
	if($("#dbsy_sqyy").attr("src")=="../../Util/Images/arrangements.png"){
		s.selectAppNoFromBarcode(barcode,bar.getAppNoFromBarcode);
	}else if($("#dbsy_sqyy").attr("src")=="../../Util/Images/arrangements2.png"){
		//如果是新增电表直接触发扫描填充功能:sessionStorage.chgDesc=1为新增,=2为拆除
		
		//在工单里面扫描到条码之后
		if(sessionStorage.newChgDesc==1){
			//新增
			$("#modify_mtscheme").val(barcode);
		}else if(sessionStorage.newChgDesc==3){
			//填充计量箱
			o.openWait("扫描资产号为："+mtBoxBarcode,0,1);
			$("#getAssetno").val(mtBoxBarcode);
		}else if(sessionStorage.newChgDesc==4){
			$("#sort_itmt").val(barcode);
				//新增互感器
		}else{
			//拆除
			s.selectAppNoFromBarcode(barcode,bar.getAppNoFromBarcode2);
		}
	}else{
		//批量新装功能
		//查找电能表或者计量箱
		//计量箱数组storageMtBox
		//mtBoxBarcode="0201630344";
		//封装查找计量箱代码
		scanFalse=1;
		var str=$("#Pop_up_tops").find(".headtext").html();
		if($("#Pop_up_tops").css("display")=="block"){
			if(str=="修改电表"){
				$("#newModifyInputID").val(barcode);
			}else if(str=="新增电表"){
				$("#newAddInputID").val(barcode);
			}else if(str="新增表箱"){
				$("#newBoxInputID").val(barcode);
			}
		}else{
			//	sessionStorage.NewMt = i;
			//sessionStorage.plMeater=0;
			if(sessionStorage.plMeater==1){
				$("#wantmodify"+sessionStorage.NewMt).val(mtBoxBarcode);
			}else{
				nop.findBox(mtBoxBarcode,barcode);
			}
		}
	}
}
function changeState(){
	showToast("设备已关闭"); 
	$("#electricener_laoding_view").hide();
	$("#span_miniElect").html("电量：--");
	$("#power_connecte_db").attr("src","../../Util/Images/dl.png");
	$("#scan_connecte_db").attr("src","../../Util/Images/sms1.png");
}
barCode=function(){
	//this.powerWarnt=0;
}
barCode.prototype={
	getAppNoFromBarcode:function(a,b){
		if(b.rows.length>0){
			var an=b.rows.item;
			playaudio("/electricenergyoutside/video/moonbeam.ogg");
			//找到对应的申请编号,触发点击事件
			sessionStorage.findCode=1;
			dbzjBusinessListClick(an(0).app_no+"_"+an(0).ins_name,an(0).instance_id);
		}else{
			o.openWait("没有找到对应电能表",0);
		}	
	},
	getAppNoFromBarcode2:function(a,b){
		if(b.rows.length>0){
			playaudio("/electricenergyoutside/video/moonbeam.ogg");
			eh.scanFromBrd(sessionStorage.barCodeInti);
		}else{
			for(var i=0;i<eh.newEmpty.length;i++){
				var s1=eh.newEmpty[i].split("-")[0],s2=eh.newEmpty[i].split("-")[1],s3=eh.newEmpty[i].split("-")[2],s4=eh.newEmpty[i].split("-")[3];
				if(s2=="新增"&&$("#ammeterInput"+s3+"s"+s4).val()==""){
					var old_asset_no = sessionStorage.amIput == undefined ? '' : sessionStorage.amIput;
					es.updateModifyNew(sessionStorage.barCodeInti,s1,old_asset_no);
					es.dealMpschem(mpschemeArray[s3].mp_scheme_id);
					$("#readyDo"+s3).attr("src","electricenergyoutside/images/already.png");
					mpschemeArray[s3].mt[s4].asset_no=sessionStorage.barCodeInti;
					electricClick(s3,"electricAll"+s3,s4,2);
					$("#golist"+s3+"s"+s4).fadeIn();
					$(".amType"+s4).addClass("changeCssAmmeter");
					sessionStorage.electMeas=s3;
					sessionStorage.ammeterI=s3;
					sessionStorage.ammeterJ=s4;
					return;
				}
			}
			//如果没找到电能表，就找第一个为空的新增电能表
			o.openWait("没有找到对应电能表",0);
		}	
	},
	//工具栏蓝牙连接
	BTConn_dbzj:function(type){
		if(type == "10"){
			// 连接打印机时不允许同时连接扫描设备
			if(sessionStorage.printer == 1){
				$("#print_connecte").attr("src","../../Util/Images/sms1.png");
				bar.disconnect_printer();
			} else {
				// 连接扫描设备
				if(sessionStorage.scan == 1){
					bar.powerWarnt=0;
					$("#scan_connecte_db").attr("src","../../Util/Images/sms1.png");
					$("#span_miniElect").html("电量：--");
					$("#power_connecte_db").attr("src","../../Util/Images/dl.png");
					bar.disconnect_scan();
				}else{
					bluetooth_conn(function (e){
						$("#scan_connecte_db").attr("src","../../Util/Images/sms.png");
						bar.getPowerValue();
						if(e.msg == 3) {
							o.openWait("请先设置需要连接的扫描设备",0);
							sessionStorage.scan = 0 ;
							$("#scan_connecte_db").attr("src","../../Util/Images/sms1.png");
							$("#span_miniElect").html("电量：--");
							$("#power_connecte_db").attr("src","../../Util/Images/dl.png");
						} else if(e.msg!=1){
							o.openWait("扫描连接失败",0);
							sessionStorage.scan = 0 ;
							$("#scan_connecte_db").attr("src","../../Util/Images/sms1.png");
							$("#span_miniElect").html("电量：--");
							$("#power_connecte_db").attr("src","../../Util/Images/dl.png");
						} else if (e.msg == 1){
							$("#scan_connecte_db").attr("src","../../Util/Images/sms.png");
							sessionStorage.scan = 1 ;
							bar.getPowerValue();
						}
					})
				}
			}
		} else{
			if(sessionStorage.scan == 1){
				$("#print_connecte_db").attr("src","../../Util/Images/dy2.png");
				bar.disconnect_scan();
			}else{
				// 连接打印设备
				if(sessionStorage.printer == 0){
					$("#print_connecte_db").attr("src","../../Util/Images/dy.png");
					bluetooth_print_conn(function (e){
						if(e.msg == 3) {
							$("#print_connecte_db").attr("src","../../Util/Images/dy2.png");
							o.openWait("请先设置需要连接的打印设备",0);
							sessionStorage.printer = 0;
						} else if(e.msg!=1){
							$("#print_connecte_db").attr("src","../../Util/Images/dy2.png");
							o.openWait("打印连接失败",0);
							sessionStorage.printer = 0;
						} else if (e.msg == 1){
							$("#print_connecte_db").attr("src","../../Util/Images/dy.png");
							sessionStorage.printer = 1;
						}
					})
				}else if(sessionStorage.printer == 1){
					bar.disconnect_printer();
				}else{
					showToast("设备未连接");
				}
			}
		}
		setTimeout(function(){
			$("#Pop-up-layer2_mc").hide();
			document.ontouchmove = function(e) {
			}// 启动滚动
		}, 1000) ;
	},
	//断开蓝牙
	disconnect_scan:function(){
		// 断开与扫描设备的连接
		bluetooth_disconnect(function(e){
			if (e.msg == 1) {
				$("#span_miniElect").html("电量：--");
				$("#power_connecte_db").attr("src","../../Util/Images/dl.png");
				$("#scan_connecte_db").attr("src","../../Util/Images/sms1.png");
				showToast("设备连接断开");
				sessionStorage.scan = 0 ;
			};
		})
	},
	//断开打印机
	disconnect_printer:function(){
		// 断开与扫描设备的连接
		bluetooth_disconnect(function(e){
			if (e.msg == 1) {
				showToast("设备连接断开");
				$("#print_connecte_db").attr("src","../../Util/Images/dy.png");
				sessionStorage.printer = 0;
			};
		})
	},
	getPowerValue:function(){
		get_BT_Power(function(a){
			$("#span_miniElect").html("电量："+a);
			setInterval(function(){
				get_BT_Power(function(a){
					$("#power_connecte_db").attr("src","../../Util/Images/dl1.png");
					$("#span_miniElect").html("电量："+a);
					if(a < "10%" && a!="--"){
						if(bar.powerWarnt==0){
							bar.powerWarnt=1;
							o.openWait("蓝牙终端电量低于10%,请及时充电",0);
						}
					}
				},function(){
					$("#power_connecte_db").attr("src","../../Util/Images/dl.png");
					$("#span_miniElect").html("电量：--");
				})
			},30000)
		},null);
	}
}