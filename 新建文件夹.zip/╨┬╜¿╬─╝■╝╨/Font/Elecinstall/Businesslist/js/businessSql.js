var sqlConnect=function(){
	this.sqlVar="";
	this.tableLimit="";
	this.tableUnion="";
	this.tb="";
}
sqlConnect.prototype={
	initCount:function(uid){
	},
	initDate:function(dbzj,tx,callBack1,callBack2){
		this.sqlVar="select ta.instance_id,ta.app_no,ta.ins_name,ta.act_name, ta.notes,ta.rcv_time,ta.due_time, downloading_type,upload_type, ta.load_time,sum(count_mp_scheme) as count_mp_scheme, sum(proc_mp_scheme) as proc_mp_scheme ,sum(orderType1) as orderType1   ,sum(orderType2) as orderType2 ,sum(orderType3) as orderType3,sum(orderType4) as orderType4 ,sum(orderType5) as orderType5 from (select * from(select t.instance_id as instance_id,t.app_no as app_no,t.load_time as load_time,ins_name as ins_name,act_name as act_name, notes as notes,rcv_time as rcv_time,due_time as due_time,downloading_type as downloading_type,upload_type as upload_type,'0' count_mp_scheme, '0' proc_mp_scheme, 1   as orderType1 ,0   as orderType2,0  as orderType3,0  as orderType4,0 as orderType5 from yx_task_list t where  upload_type = 1 and user_id='"+tx+"' order by rcv_time desc ) union all select * from (select t.instance_id as instance_id,t.app_no as app_no,t.load_time as load_time,ins_name as ins_name,act_name as act_name,notes as notes,rcv_time as rcv_time,due_time as due_time,downloading_type as downloading_type,upload_type as upload_type,count_mp_scheme,proc_mp_scheme , 0  as orderType1 ,2   as orderType2,0  as orderType3,0 as orderType4,0  as orderType5 from yx_task_list t left join (select app_no,count(mp_scheme_id) as count_mp_scheme, sum(case when already_do<>0 then 1 else 0 end) as proc_mp_scheme from yx_mp_scheme group by app_no) mp  on  t.app_no=mp.app_no where count_mp_scheme=proc_mp_scheme  and t.user_id='"+tx+"'  order by rcv_time desc ) union all select * from ( select t.instance_id as instance_id,t.app_no as app_no,t.load_time as load_time,ins_name as ins_name,act_name as act_name, notes as notes,rcv_time as rcv_time,due_time as due_time,downloading_type as downloading_type, upload_type as upload_type,count_mp_scheme,proc_mp_scheme , 0  as orderType1 ,0   as orderType2,3 as orderType3,0  as orderType4,0  as orderType5 from yx_task_list t left join (select app_no,count(mp_scheme_id) as count_mp_scheme, sum(case when already_do<>0 then 1 else 0 end) as proc_mp_scheme from yx_mp_scheme group by app_no) mp  on  t.app_no=mp.app_no where proc_mp_scheme  < count_mp_scheme  and t.user_id='"+tx+"'  order by rcv_time desc ) union all  select * from ( select t.instance_id as instance_id,t.app_no as app_no,t.load_time as load_time,ins_name as ins_name,act_name as act_name, notes as notes,rcv_time as rcv_time,due_time as due_time,downloading_type as downloading_type, upload_type as upload_type,'0' count_mp_scheme, '0' proc_mp_scheme    ,  '0'   as orderType1 ,'0'   as orderType2,'0'  as orderType3,'4'  as orderType4,'0'  as orderType5 from yx_task_list t where  downloading_type = 1  and user_id='"+tx+"' order by rcv_time desc ) union all select * from (select t.instance_id as instance_id,t.app_no as app_no,t.load_time as load_time,ins_name as ins_name,act_name as act_name, notes as notes,rcv_time as rcv_time,due_time as due_time,downloading_type as downloading_type, upload_type as upload_type,'0' count_mp_scheme, '0' proc_mp_scheme    , 0   as orderType1 ,0   as orderType2,0 as orderType3,0  as orderType4,5 as orderType5 from yx_task_list t   where  downloading_type = 0  and user_id='"+tx+"'  order by rcv_time desc )) ta group by  ta.instance_id,ta.app_no,ta.ins_name,ta.act_name,ta.notes,ta.rcv_time,ta.due_time order by orderType1 desc, orderType2 desc ,orderType4 desc,  orderType3 desc, orderType5 desc  , proc_mp_scheme desc, rcv_time desc";
		db_execut_oneSQL("dbzj.db",this.sqlVar,[],callBack1,callBack2);
	},
	getDateInit:function(dbzj,id,callBack1,callBack2){
		this.sqlVar="select count(1) as bs from YX_TASK_LIST where user_id=?";
		db_execut_oneSQL(dbzj, this.sqlVar, [id], callBack1, callBack2);
	},
	insertList:function(dbzj,data,userid){
		//批量插入数据库
		// this.tableLimit="insert into YX_TASK_LIST(USER_ID,APP_NO,INS_NAME,ACT_NAME,NOTES,RCV_TIME,DUE_TIME,STATUS_CODE,INSTANCE_ID) ";
		// if(data.length>0){
			// this.tableUnion=this.tableLimit+this.unionAll(data,userid);
			// db_execut_oneSQL(dbzj, this.tableUnion, [], null, null);
		// }
		var sqls=[];
		for(var i=0;i<data.length;i++){
			sqls.push("insert into YX_TASK_LIST(USER_ID,APP_NO,INS_NAME,ACT_NAME,NOTES,RCV_TIME,DUE_TIME,STATUS_CODE,INSTANCE_ID) values('"+userid+"','"+data[i].app_no+"','"+data[i].ins_name+"','"+data[i].act_name+"','"+data[i].notes+"','"+data[i].rcv_time+"','"+data[i].due_time+"','"+data[i].status_code+"','"+data[i].instance_id+"')");
		}
		db_batch_data("dbzj.db",sqls,[],null,null);
	},
	//批组合批量sql语句
	unionAll:function(data,userid){
		//data:PKG.PKG.TASK
		this.tb=" select '"+userid+"','"+data[0].app_no+"','"+data[0].ins_name+"','"+data[0].act_name+"','"+data[0].notes+"','"+data[0].rcv_time+"','"+data[0].due_time+"','"+data[0].status_code+"','"+data[0].instance_id+"' ";
		if(data.length>1){
			for(var i=1;i<data.length;i++){
				this.tb+=" union all select '"+userid+"','"+data[i].app_no+"','"+data[i].ins_name+"','"+data[i].act_name+"','"+data[i].notes+"','"+data[i].rcv_time+"','"+data[i].due_time+"','"+data[i].status_code+"','"+data[i].instance_id+"' ";
			}
		}
		return this.tb;
	},
	//单个工单下载
	dbzjBusinessDownLoad:function(appNo,insId,userName,i,callBack1,callBack2){
		var pkg = '{"MOD":"02","FUN":"01","ORG_NO":"' + sessionStorage.ORG_NO + '","PKG_TYPE":"0","PKG":{"USR":"' + userName + '","APP_NO":"' + appNo + '","INSTANCE_ID":"' + insId + '","APP_INFO":"1","MP_SCHEME":"1","MT_SCHEME":"1","IT_SCHEME":"1","MT_BOX":"1","IRREAD":"1","DEVICE_PICTURE_FILES":"1"}}';
		send_data("0000", "2002", pkg, callBack1, callBack2);
	},
	//删除相关工单
	deleteSqlDbzj:function(dbzj,appList,noBool,insertAll,type,num,userCount){
		 //删除示数
		 var sql_irread="delete from yx_irread where meter_scheme_id in (select id from yx_mt_scheme where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no "+noBool+" in ("+appList+") and app_no in (select app_no from yx_task_list where user_id='"+sessionStorage.user_name+"')))";
		 db_execut_oneSQL(dbzj,sql_irread,[],null,null);
		 //删除互感器信息
		 var sql_it="delete from yx_it_scheme where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in ("+appList+") and app_no "+noBool+"  in (select app_no from yx_task_list where user_id='"+sessionStorage.user_name+"'))";
		 db_execut_oneSQL(dbzj,sql_it,[],null,null);
		 //删除电能表
		 var sql_mt="delete from yx_mt_scheme where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in ("+appList+") and app_no "+noBool+"  in (select app_no from yx_task_list where user_id='"+sessionStorage.user_name+"'))";
		 db_execut_oneSQL(dbzj,sql_mt,[],null,null);
		 //删除计量箱柜信息
		 var sql_tbox="delete from yx_mt_box where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in ("+appList+") and app_no "+noBool+"  in (select app_no from yx_task_list where user_id='"+sessionStorage.user_name+"'))";
		 db_execut_oneSQL(dbzj,sql_tbox,[],null,null);
		 //删除上装人员信息
		 var sql_app="delete from yx_app_info where app_no "+noBool+"  in ("+appList+") and app_no in (select app_no from yx_task_list where user_id='"+sessionStorage.user_name+"')";
		 db_execut_oneSQL(dbzj,sql_app,[],null,null);
		 //删除计量信息
		 var sql_mp=" delete from yx_mp_scheme  where app_no "+noBool+"  in ("+appList+") and app_no in (select app_no from yx_task_list where user_id='"+sessionStorage.user_name+"')";
		 db_execut_oneSQL(dbzj,sql_mp,[],null,null);
		 if(noBool=="not"){
 			//删除待办事宜
			var sql="delete from yx_task_list where app_no not in ("+appList+")   and user_id='"+sessionStorage.user_name+"'";
			db_execut_oneSQL(dbzj,sql,[],null,null);
		 }else{
		 	this.insertMpscheme(dbzj,insertAll,appList,type,num,userCount);
		 }
	},
	deleteLastDate:function(dbzj,userID){
		 //删除示数
		 var sql_irread="delete from yx_irread where meter_scheme_id in (select id from yx_mt_scheme where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in (select app_no from yx_task_list where user_id='"+userID+"')))";
		 db_execut_oneSQL(dbzj,sql_irread,[],null,null);
		 //删除互感器信息
		 var sql_it="delete from yx_it_scheme where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in (select app_no from yx_task_list where user_id='"+userID+"'))";
		 db_execut_oneSQL(dbzj,sql_it,[],null,null);
		 //删除电能表
		 var sql_mt="delete from yx_mt_scheme where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in (select app_no from yx_task_list where user_id='"+userID+"'))";
		 db_execut_oneSQL(dbzj,sql_mt,[],null,null);
		 //删除计量箱柜信息
		 var sql_tbox="delete from yx_mt_box where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in (select app_no from yx_task_list where user_id='"+userID+"'))";
		 db_execut_oneSQL(dbzj,sql_tbox,[],null,null);
		 //删除上装人员信息
		 var sql_app="delete from yx_app_info where app_no in (select app_no from yx_task_list where user_id='"+userID+"')";
		 db_execut_oneSQL(dbzj,sql_app,[],null,null);
		 //删除计量信息
		 var sql_mp=" delete from yx_mp_scheme  where app_no in (select app_no from yx_task_list where user_id='"+userID+"')";
		 db_execut_oneSQL(dbzj,sql_mp,[],null,null);
		 var sql="delete from yx_task_list where user_id='"+userID+"'";
		 db_execut_oneSQL(dbzj,sql,[],null,null);
	},
	insertMpscheme:function(dbzj,sql,appNo,type,num,userCount){
		var dbzj = window.sqlitePlugin.openDatabase(dbzj, "1.0", "dbzj.db", 10 * 1024 * 1024);
		dbzj.transaction(function(tx) {
			this.i=0;
			for(var i=0;i<sql.length;i++){
				tx.executeSql(sql[i], [], function(tx, res) {
					if(i==sql.length){
						if(this.i==0){
							$("#"+sessionStorage.thisID).attr("src","../../Util/Images/downloadover.png");
							this.sqlVar="update YX_TASK_LIST set downloading_type=1,upload_type=0 where app_no='"+appNo+"'";
							db_execut_oneSQL("dbzj.db",this.sqlVar,[],function(){
								if(type==2){
									if(num+1<userCount){
										if(stopDown==1){
											allDownType=1;
											o.openWait("已取消下装",0);
											$("#dbzjLoadingViewScroll").hide();
											s.initDate("dbzj.db",sessionStorage.user_name,getInitPage,getFail);
										}else{
											$("#main_list_business"+num).find("img:eq(1)").attr("src",o.returnString("downloadover.png"));
											factorial(num+1,userCount);
										}
									}else{
										//提示信息提示参数
										allDownType=1;
										$("#dbzjLoadingViewScroll").hide();
										o.openWait("全部数据下装完成",0);
										s.initDate("dbzj.db",sessionStorage.user_name,getInitPage,getFail);
									}
								}else{
									o.openWait("数据下装完成",0);
									s.downLoadType();
								}	
							},s.urlFail);
							this.i++;
						}
					}
				})
			}
		},s.urlFail);
	},
	urlFail:function(){
		o.openWait("网络连接失败",0);
		$("#"+sessionStorage.thisID).attr("src",o.returnString(sessionStorage.imageUp)?o.returnString(sessionStorage.imageUp):o.returnString(download3.png));
	},
	downLoadType:function(data){
		var dsql="select t.instance_id as instance_id ,t.app_no as app_no,ins_name as ins_name,act_name as act_name,t.load_time as load_time,notes as notes,rcv_time as rcv_time,due_time as due_time,downloading_type as downloading_type,upload_type upload_type,count_mp_scheme,proc_mp_scheme from yx_task_list t left join (select app_no,count(mp_scheme_id) as count_mp_scheme,sum(case when already_do<>0 then 1 else 0 end) as proc_mp_scheme from yx_mp_scheme group by app_no) mp  on  t.app_no=mp.app_no where t.user_id='"+sessionStorage.user_name+"' and t.app_no='"+sessionStorage.binitAppNo+"' order by t.app_no desc";
		db_execut_oneSQL("dbzj.db",dsql,[],function(tx,res){
			dataProc(res.rows.item);
		},null);
	},
	updateAppUser:function(userid){
		//查询数据库,如果数据库中没有请求中app_no,则进行插入操作,如果有,则进行更新操作
		var rausql="select act_name as act_name,app_no as app_no, due_time as due_time, instance_id as instance_id,ins_name as ins_name,notes as notes,rcv_time as rcv_time,status_code as status_code, user_id as user_id from YX_TASK_LIST where user_id='"+userid+"'";
		db_execut_oneSQL("dbzj.db",rausql,[],s.compareAppNo,null);
	},
	compareAppNo:function(len,e){
		len=e.rows.length;
		e=e.rows.item;
		tempLocAppNo=new Array();
		for(var i=0;i<len;i++){
			tempLocAppNo.push(e(i).app_no);
		}
		s.insertAndUpdate(appAllList,tempLocAppNo);
	},
	insertAndUpdate:function(refData,locAppNo){
		var insert = "INSERT INTO YX_TASK_LIST(USER_ID,APP_NO,INS_NAME,ACT_NAME,NOTES,RCV_TIME,DUE_TIME,STATUS_CODE,INSTANCE_ID)VALUES(?,?,?,?,?,?,?,?,?)";
		var update = "UPDATE YX_TASK_LIST SET INS_NAME=?,ACT_NAME=?,NOTES=?,RCV_TIME=?,DUE_TIME=?,STATUS_CODE=?,INSTANCE_ID=? WHERE APP_NO=? AND USER_ID=?";
		var dbzj = window.sqlitePlugin.openDatabase("dbzj.db", "1.0", "dbzj.db", 10 * 1024 * 1024);
		//打开事务操作数据库
		dbzj.transaction(queryDB);
		function queryDB(tx){
			for(var i = 0; i < refData.length; i++) {
				var item = refData[i];
				if(JSON.stringify(locAppNo) != "") {
					var index = locAppNo.indexOf(item.app_no);
					//插入数据
					if(index == -1) {
						tx.executeSql(insert, [sessionStorage.user_name, item.app_no, item.ins_name, item.act_name, item.notes, item.rcv_time, item.due_time, item.status_code, item.instance_id], sucessCB, null);
						continue;
					}
				}
				//没有插入的都做update操作
				tx.executeSql(update, [item.ins_name, item.act_name, item.notes, item.rcv_time, item.due_time, item.status_code, item.instance_id, item.app_no, sessionStorage.user_name], sucessCB, null);
			}
			var exec_num = 1;
			function sucessCB(tx, res) {
				//执行完毕
				if(exec_num == refData.length) {
					refreshTrue=true;
					//下载成功之后,改变下载状态类型
					s.initDate("dbzj.db",sessionStorage.user_name,getInitPage,getFail);
					exec_num=0;
				}
				exec_num++;
			}
		}
	},
	// 筛选
	ChoiseFilter:function(userid,whereArg,or_str,callBack1){
		var cfsql="select * from (select ta.instance_id,ta.app_no,ta.ins_name,ta.act_name,ta.notes,ta.rcv_time,ta.due_time,ta.load_time,downloading_type,upload_type,sum(count_mp_scheme) as count_mp_scheme, sum(proc_mp_scheme) as proc_mp_scheme,sum(orderType1) as orderType1,sum(orderType2) as orderType2 ,sum(orderType3) as orderType3,sum(orderType4) as orderType4 ,sum(orderType5) as orderType5 from (select * from(select t.instance_id as instance_id,t.app_no as app_no,t.load_time as load_time,ins_name as ins_name,act_name as act_name,notes as notes,rcv_time as rcv_time,due_time as due_time,downloading_type as downloading_type,upload_type as upload_type,'0' count_mp_scheme, '0' proc_mp_scheme,1 as orderType1,0 as orderType2,0  as orderType3,0  as orderType4,0 as orderType5 from yx_task_list t where  upload_type = 1 and user_id='"+userid+"' order by rcv_time desc ) union all select * from (select t.instance_id as instance_id,t.app_no as app_no,t.load_time as load_time,ins_name as ins_name,act_name as act_name,notes as notes,rcv_time as rcv_time,due_time as due_time,downloading_type as downloading_type,upload_type as upload_type,count_mp_scheme,proc_mp_scheme,0  as orderType1 ,2   as orderType2,0  as orderType3,0 as orderType4,0  as orderType5 from yx_task_list t left join (select app_no,count(mp_scheme_id) as count_mp_scheme,sum(case when already_do<>0 then 1 else 0 end) as proc_mp_scheme from yx_mp_scheme group by app_no) mp  on  t.app_no=mp.app_no where count_mp_scheme=proc_mp_scheme  and t.user_id='"+userid+"'  order by rcv_time desc ) union all select * from (select t.instance_id as instance_id,t.app_no as app_no,t.load_time as load_time,ins_name as ins_name,act_name as act_name,notes as notes,rcv_time as rcv_time,due_time as due_time,downloading_type as downloading_type,upload_type as upload_type,count_mp_scheme,proc_mp_scheme,0  as orderType1 ,0   as orderType2,3 as orderType3,0  as orderType4,0  as orderType5 from yx_task_list t left join (select app_no,count(mp_scheme_id) as count_mp_scheme,sum(case when already_do<>0 then 1 else 0 end) as proc_mp_scheme from yx_mp_scheme group by app_no) mp on t.app_no=mp.app_no where proc_mp_scheme  < count_mp_scheme and t.user_id='"+userid+"' order by rcv_time desc ) union all select * from (select t.instance_id as instance_id,t.app_no as app_no,t.load_time as load_time,ins_name as ins_name,act_name as act_name,notes as notes,rcv_time as rcv_time,due_time as due_time,downloading_type as downloading_type,upload_type as upload_type,'0' count_mp_scheme, '0' proc_mp_scheme,'0' as orderType1,'0' as orderType2,'0' as orderType3,'4' as orderType4,'0' as orderType5 from yx_task_list t where  downloading_type = 1 and user_id='"+userid+"' order by rcv_time desc ) union all select * from (select t.instance_id as instance_id,t.app_no as app_no,t.load_time as load_time,ins_name as ins_name,act_name as act_name,notes as notes,rcv_time as rcv_time,due_time as due_time,downloading_type as downloading_type,upload_type as upload_type,'0' count_mp_scheme, '0' proc_mp_scheme,0 as orderType1 ,0 as orderType2,0 as orderType3,0  as orderType4,5 as orderType5 from yx_task_list t where downloading_type = 0 and user_id='"+userid+"' order by rcv_time desc)) ta group by  ta.instance_id,ta.app_no,ta.ins_name,ta.act_name,ta.notes,ta.rcv_time,ta.due_time order by orderType1 desc,orderType2 desc,orderType4 desc,orderType3 desc, orderType5 desc,proc_mp_scheme desc, rcv_time desc ) a where 1=1 "+whereArg + or_str;
		db_execut_oneSQL("dbzj.db",cfsql,[],callBack1,null);
	},
	//查询扫描到得条码是否存在
	selectAppNoFromBarcode:function(barcode,callBack1){
		var sql="select app_no as app_no,instance_id as instance_id,ins_name as ins_name from yx_task_list where app_no=(select app_no from yx_mp_scheme where mp_scheme_id =(select mp_scheme_id from yx_mt_scheme where asset_no='"+barcode+"'))";
		db_execut_oneSQL("dbzj.db",sql,[],callBack1,null);
	},
	selectDownLoadNumber:function(number){
		//判断是否有批量新装工单
		var sqluser="select count(1) as c from yx_task_list where ins_name like '%新装%' and user_id='"+sessionStorage.user_name+"' ";
		db_execut_oneSQL("dbzj.db",sqluser,[],function(tx,res){
			var len=res.rows.item.length,e=res.rows.item;
			if(e(0).c>0){
				var sql="select count(1) as number,(select count(1) from yx_task_list where  user_id='"+sessionStorage.user_name+"') as allnumber from yx_task_list where DOWNLOADING_TYPE=1 and user_id='"+sessionStorage.user_name+"'";
				db_execut_oneSQL("dbzj.db",sql,[],getNumberToGoPlxz,null);
			}else{
				o.openWait("暂无批量新装工单!",0);
			}
		},null);
		
	}
}
