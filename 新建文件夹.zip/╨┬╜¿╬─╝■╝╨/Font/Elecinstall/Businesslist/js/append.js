var htmlAppend=function(){
	this.html="";
	this.statues={};
	this.time=new Date();
}
htmlAppend.prototype={
	loadInitPage:function(e,i,type){
		if(type==2){
			return "<table cellpadding='0' cellspacing='0' width='100%' border='0'><tr valign='top'><td width='55px'><img src='../../Util/Images/link.png' class='imglin_link'/></td><td width='10px'></td><td><span class='green'>" + e.ins_name + "(" + e.app_no + ")</span><br /><span class='red fontsize2' id='typeDownID"+i+"'>"+h.getType(e.downloading_type,h.getBusinessCount(e.count_mp_scheme),e.proc_mp_scheme,type,e.app_no,e.upload_type)+"</span></td><td width='50px'><img onclick='dbzjBusinessListDowmload(this)' alt='"+i+"_"+e.app_no+"' id='dowanload_" + e.app_no + "_" + e.instance_id + "' class='download_status wmimg_dx' style='cursor:pointer' name='dontclick" + i + "' src='" + h.dbzjBusinessListDowmloadStatue(e.downloading_type,h.getBusinessCount(e.count_mp_scheme),h.getBusinessCount(e.proc_mp_scheme), i,0) + "'/></td></tr></table><div class='dialog_box " + h.bgTime(1, e.due_time) + "' onclick='dbzjBusinessListClick(this.id," + e.instance_id + ","+i+")' id='" + e.app_no + "_" + e.ins_name +"'><div class='trianglea'><img src='../../Util/Images/" + h.bgTime(2, e.due_time) + "' class='wmimg_trianglea' /></div>活动名称：" + e.act_name + "<br/>说&nbsp;&nbsp;明&nbsp;&nbsp;栏：" + e.notes + "<br />接收时间：" + h.preTime(e.rcv_time) + "<br />到期时间：" + h.preTime(e.due_time) +"</div>";
		}else{
			return "<li id='scrollLiID"+i+"'><div class='main_list' id='main_list_business"+i+"'><table cellpadding='0' cellspacing='0' width='100%' border='0'><tr valign='top'><td width='55px'><img src='../../Util/Images/link.png' class='imglin_link'/></td><td width='10px'></td><td><span class='green' width='300px;'>" + e.ins_name + "(" + e.app_no + ")</span><br /><span class='red fontsize2' id='typeDownID"+i+"'>"+h.getType(e.downloading_type,h.getBusinessCount(e.count_mp_scheme),e.proc_mp_scheme,type,e.app_no,e.upload_type)+"</span></td><td width='50px'><img onclick='dbzjBusinessListDowmload(this)' alt='"+i+"_"+e.app_no+"' id='dowanload_" + e.app_no + "_" + e.instance_id + "' class='download_status wmimg_dx' name='dontclick" + i + "' src='" + h.dbzjBusinessListDowmloadStatue(e.downloading_type,h.getBusinessCount(e.count_mp_scheme),h.getBusinessCount(e.proc_mp_scheme), i,type) + "'/></td></tr></table><div class='dialog_box " + h.bgTime(1, e.due_time) + "' onclick='dbzjBusinessListClick(this.id," + e.instance_id+","+i + ")' id='" + e.app_no + "_" + e.ins_name + "'><div class='trianglea'><img src='../../Util/Images/" + h.bgTime(2, e.due_time) + "' class='wmimg_trianglea' /></div>活动名称：" + e.act_name + "<br/>说&nbsp;&nbsp;明&nbsp;&nbsp;栏：" + e.notes + "<br />接收时间：" + h.preTime(e.rcv_time) + "<br />到期时间：" + h.preTime(e.due_time) +"</div></div></li>";
		}
	},
	getType:function(e,count,b,type,appno,uptype){
		if(e==0||!e){
			return "数据未下装";
		}else{
			if(count==0){
				return "暂无工单计量信息";
			}else{
				return "<span class='red fontsize2'>共<span class='green' id='business_list_count+" + appno + "'>" + count + "</span>,已处理<span class='green' id='business_list_did'>" + b + "</span><span class='red fontsize2' style='margin-left:100px;'>" + this.upload_type_return(uptype) + "</span></span>";
			}
		}
	},
	dbzjBusinessListDowmloadStatue:function(statue,count, cprot,i,type){
		//type==0从本地数据请求数据 type==1 从服务器请求数据
		if(type==0){
			if(statue==0){
				return o.returnString("download3.png");
			}else{
				if(count==0){
					return o.returnString("downloadover.png");
				}else{
					if(cprot==0){
						return  o.returnString("downloadover.png");
					}else{
						if(count==cprot){
							return o.returnString("chuliwancheng.png");
						}else{
							return o.returnString("chulizhong.png");
						}
					}
				}
			}
		}else{
			return o.returnString("download3.png");
		}
	},
	upload_type_return:function(e){
		if(e == 0) {
			return "未上装";
		} else if(e == 1) {
			return "已上装 未提交工作流";
		} else if(e == 2) {
			return "上装失败";
		} else if(e == 3 ){
			return "已上装 提交工作流失败";
		} else{
			return "未上装";
		}
	},
	bgTime:function(number, e){
		var m_ = this.time.getMonth() + 1;
		if(m_ < 10) {
			m_ = "0" + m_;
		}
		var d_ = this.time.getDate();
		if(d_ < 10) {
			d_ = "0" + d_;
		}
		var str = this.time.getFullYear() + "-" + m_ + "-" + d_;
		if(Date.parse(e) - Date.parse(str) < 0) {
			if(number == 1) {
				return "dianji_wxa";
			} else if(number == 2) {
				return "triangleb_wx.png";
			}
		}
		if(Date.parse(e) - Date.parse(str) > 0 || e == "" || e == null) {
			if(number == 1) {
				return "";
			} else if(number == 2) {
				return "lengjiao3.png";
			}
		}
	},
	getBusinessCount:function(e){
		if(!e) {
			return 0;
		} else {
			return e;
		}
	},
	preTime:function(e){
		var b="";
		if(e){
			b = e.substring(0, e.lastIndexOf("."));
		}
		return b;
	}
}
