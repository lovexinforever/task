var Operation=function(){
	this.myScroll="";
	this.operSql="";
	this.pkg="";
	this.scanAsset=new handle();
	this.s=new sqlConnect();
	this.h=new htmlAppend();
	this.tempArry=new Array();
	this.stimeout="";
	
	this._130127_cons_no = 0; 
	this.gettype_gongzuoliu=0;
	this.dbzj_story_all_array ={};
	this.len=0;
	this.item={};
	this.rueslt="";
	this.display_upload_app1="";
	this.display_upload_app2="";
	this.display_download1="";
	this.display_download2="";
	this.load_time1="";
	this.load_time2="";
	this.chuli_xiazai="";
	this.intance_id_db="";
	this.single_number="";
	this.single_number_i="";
	this.json_dbzj_shaixuan="";
	this.obj_id="";
	this.story_ico = "";
	this.stop_download = 0;
	this.alreadydownload = 1;
	
	this.insertAll="";
	
	this.INSERTAPP=""; 
	
	this.INSERTMP=""; 
	
	this.INSERTMT=""; 
	
	this.INSERTIT=""; 
	
	this.INSERTBOX=""; 
	
	this.INSERTIRREAD=""; 
	
	this.INSERTFILES=""; 	
}

Operation.prototype={
	getScroll:function(id){
		this.myScroll = new iScroll(id, {
			hScrollbar : true,
			vScrollbar : true,
			hideScrollbar : false
		});
	},
	blueTool:function(id){
		bluetooth_conn(function(e){
			if(e.msg == 1){
				sessionStorage.scan=1;
				document.getElementById(id).src="../../Util/Images/sms.png";
				o.getPowerValue();
			}else if(e.msg==3){
				//连接设备提示
				$("#span_miniElect").html("电量：--");
				//pop_top_display();
			}else{
				showToast("与扫描设备连接失败");
			}
		});
	},
	getPowerValue:function(){
		get_BT_Power(function(a){
			$("#span_miniElect").html("电量："+a);
			setInterval(function(){
				get_BT_Power(function(a){
					$("#power_connecte_db").attr("src","../../Util/Images/dl1.png");
					$("#span_miniElect").html("电量："+a);
					if(a < "10%" && a!="--"){
						if(powerWarnt==0){
							powerWarnt=1;
							o.openWait("蓝牙终端电量低于10%,请及时充电",0);
						}
					}
				},function(){
					$("#power_connecte_db").attr("src","../../Util/Images/dl.png");
					$("#span_miniElect").html("电量：--");
				})
			},30000)
		},null);
	},
	openWait:function(msg,type,number){
		//this.timeOut(id,msgid,msg,type,time);
		//type:1等待框,type:0 单纯弹出框3秒自动关闭,type:2 立刻关闭提示框
		var t=0,time="";
		if(number){
			type=0;
			t=number*1000;
		}else{
			t=2000;
		}
		plat_common.loadDialog(msg,type);
		if(type==0){
			time=setTimeout(function(){
				plat_common.closeDialog();
			},t);
		}else if(type==2){
			clearInterval(time);
			plat_common.closeDialog();
		}
	},
	timeOut:function(id,msgid,msg,type,time){
		sessionStorage.touchClew=0;
		document.getElementById(id).style.display="block";
		document.getElementById(msgid).innerHTML=msg;
		switch(type){
			case 0:
				clearTimeout(o.stimeout);
				var t=3000;
				if(time&&time!="undefined"){
					sessionStorage.touchClew=1;
					t=time;
				}
				o.stimeout=setTimeout(function(){
					document.getElementById(id).style.display="none";
				},t);
			break;
			case 1:
				document.getElementById(id).style.display="block";
			break;
			case 2:
				document.getElementById(id).style.display="none";
			break;
		}
	},
	sendTask:function(uid,orgno,callBack1,callBack2){
		this.pkg = '{"MOD":"01","FUN":"01","PKG_TYPE":"0","ORG_NO":"' + orgno + '","PKG":{"USR":"' + uid + '","TYPECODE":"2002","TASK":[]}}';
		send_data("0000", "2001", this.pkg, callBack1, callBack2);
	},
	getData:function(d){
		d=JSON.parse(d);
		if(d.RET=="00"){
			if(d.PKG.RET=="01"){
				//大数据量
				if(d.PKG.PKG.URL){
					return ""+d.PKG.PKG.URL;
				}else{
					//小数据量
					d.PKG.PKG.TASK=JSON.parse(JSON.stringify(d.PKG.PKG.TASK).toLowerCase());
					d.PKG.PKG.TASK.sort(this.tranSact);
					return d.PKG.PKG.TASK;
				}
			}else{
				return this.scanAsset.getMsgCode(d.PKG.RET);
			}
		}else{
			if(d.RET=="01"){
				//重新登录
				setTimeout(function(){
					window.location.replace("../../Platform/Login/html/welcome.html");
				},3000);
				return "会话失效,需重新登录...";
			}else{
				return this.scanAsset.getErrorCode(d.RET);
			}
		}
	},
		/*
		 * 1 表示成功
		 * 2 表示下载数据包失败
		 * 3 解压数据包失败
		 * 4 删除压缩包失败
		 * 0 表示其他错误
	 */
	dataUrlCallBack:function(zipmsg){
		 if(zipmsg.msg==1){
			//包含的文件名
			 read(sessionStorage.downfilename,function(data){
			 	if(data.msg==1){
			 		var TASK=JSON.parse(JSON.stringify(JSON.parse(data.context).TASK).toLowerCase());
					TASK.sort(this.tranSact);
	 				RefreshBack(TASK,1);
			 	}else{
			 		o.openWait("读取数据失败",0);
			 	}
			 })
		  }else{
		  	switch(zipmsg.msg){
		 		case 2:
		 			o.openWait("表示下载数据包失败",0);
		 		break;
		 		case 3:
		 			o.openWait("解压数据包失败",0);
		 		break;
		 		case 4:
		 			o.openWait("删除压缩包失败",0);
		 		break;
		 		case 0:
		 			o.openWait("其他错误",0);
		 		break;
		 		case 5:
		 			o.openWait("服务器文件不存在",0);
		 		break;
		 		
		 	}
		  }
	},
	//排序
	tranSact:function(a,b){
		//按时间降序排序
		if(a.rcv_time>b.rcv_time){
			return -1;
		}else if(a.rcv_time<=b.rcv_time){
			return 1;
		}
	},
	//下载单个数据回调
	getDownSingle:function(data,appNo,type,num,userCount){
		data=JSON.parse(data);
		if(data.RET=="00"){
			if(data.PKG.RET=="01"){
				if(data.PKG.PKG.URL){
					var sgets=data.PKG.PKG.URL.substring(data.PKG.PKG.URL.lastIndexOf("/")+1,data.PKG.PKG.URL.length).replace(".zip",".txt");
					sessionStorage.downfilename=sgets;
					donwloadAndZip(sessionStorage.DOWN_URL+"/"+data.PKG.PKG.URL,"",o.dataDownMpBack);
				}else{
					this.doneDownData(appNo,data,type,num,userCount);
				}
			}else{
				$("#main_list_business"+sessionStorage.appNoi).find("img:eq(1)").attr("src",o.returnString(sessionStorage.imageUp));
				this.openWait(this.scanAsset.getMsgCode(data.PKG.RET),0);
				$("#dbzjLoadingViewScroll").hide();
			}
		}else{
			if(data.RET=="01"){
				//重新登录
				o.openWait("会话失效,需重新登录...",0);
				setTimeout(function(){
					window.open("../../Platform/Login/html/welcome.html");
				},3000);
			}else{
				$("#main_list_business"+sessionStorage.appNoi).find("img:eq(1)").attr("src",o.returnString(sessionStorage.imageUp));
				this.openWait(this.scanAsset.getErrorCode(data.RET),0);
				$("#dbzjLoadingViewScroll").hide();
			}
		}
	},//将服务器返回数据插入到数据库
	getInsertSQL:function(tablename, str) {
		if(str == "" || str == null || str.length == 0) {
			return "";
		}
		var i = 1;
		var insert_sql = "INSERT INTO " + tablename + "(";
		if(str.length > 0) {
			var str_length = 0;
			for(var x in str[0]) {
				str_length++;
			}
			for(var c in str[0]) {
				insert_sql += c + (i == str_length ? ")" : ",");
				i++;
			}
			i = 1;
			insert_sql = insert_sql.substring(0, insert_sql.length - 1) + ")";
			insert_sql += "VALUES(";
		}
		var insert_list = "";
		for(var p in str) {
			var insert_value = insert_sql;
			for(var f in str[p]) {
				insert_value += "'" + str[p][f] + (i == str[p].length ? "')" : "',");
				i++;
			}
			insert_value = insert_value.substring(0, insert_value.length - 1) + ")";
			this.tempArry.push(insert_value);
		}
		//alert("插入数据库计量数据："+insert_list);
		//insert_list=insert_list.substring(0,insert_list.length-1);
		return this.tempArry;
	},
	//下装数据处理
	doneDownData:function(appNo,data,type,num,userCount){
		this.tempArry=new Array();
		//数据请求成功
		this.pkg = data.PKG.PKG;
		//后插入数据库
		this.INSERTAPP=this.getInsertSQL("YX_APP_INFO",this.pkg.APP_INFO);

		this.INSERTMP=this.getInsertSQL("YX_MP_SCHEME",this.pkg.MP_SCHEME);

		this.INSERTMT=this.getInsertSQL("YX_MT_SCHEME",this.pkg.MT_SCHEME);

		this.INSERTIT=this.getInsertSQL("YX_IT_SCHEME",this.pkg.IT_SCHEME);

		this.INSERTBOX=this.getInsertSQL("YX_MT_BOX",this.pkg.MT_BOX);

		this.INSERTIRREAD=this.getInsertSQL("YX_IRREAD",this.pkg.IRREAD);

		this.INSERTFILES=this.getInsertSQL("DEVICE_PICTURE_FILES",this.pkg.DEVICE_PICTURE_FILES);	
		//先删除数据
		s.deleteSqlDbzj("dbzj.db",appNo,"",this.tempArry,type,num,userCount);
	},
	dataDownMpBack:function(zipmsg){
		if(zipmsg.msg==1){
			//包含的文件名
			 read(sessionStorage.downfilename,function(data){
			 	switch(data.msg){
			 		case 1:
						//var TASK=JSON.parse(JSON.stringify(JSON.parse(data.context).TASK).toLowerCase());
						//TASK.sort(this.tranSact);
		 				//RefreshBack(TASK,1);
		 				this.doneDownData(sessionStorage.binitAppNo,JSON.parse(data.context),1,num,userCount);
			 		break;
			 		case 2:
			 			o.openWait("表示下载数据包失败",0);
			 		break;
			 		case 3:
			 			o.openWait("解压数据包失败",0);
			 		break;
			 		case 4:
			 			o.openWait("删除压缩包失败",0);
			 		break;
			 		case 0:
			 			o.openWait("其他错误",0);
			 		break;
			 		
			 	}
			 })
		  }
	},
	//筛选
	choiseInstallElec:function(jsonObject,userid,callBack1) {
		var whereArg = "", flag = false,num = 0,or_str="",down_type="";
		for(var i in jsonObject) {
			var value = jsonObject[i];
			flag = jsonObject[i] != "" && jsonObject[i] != null;
			// 该字段不是时间字段
			if(i.indexOf("time") == -1 && i.indexOf("upload")==-1 && i.indexOf("down")==-1 ) {
				if(flag) {
					whereArg += i + " like " + "\'\%" + value + "\%\'" + " and ";
				}
			}else if(i.indexOf("upload_type1")>-1){
				if(flag){
					or_str += " or upload_type='"+value+"'";
				}
			}else if(i.indexOf("upload_type2")>-1){
				if(flag){
					or_str += " or upload_type='"+value+"'";
				}
			}else if(i.indexOf("downloading_type1")>-1){
				if(flag){
					or_str += " or downloading_type='"+value+"'";
				}
			}else if(i.indexOf("downloading_type2")>-1){
				if(flag){
					or_str += " or downloading_type='"+value+"'";
				}
			}else{
				var key = i.substring(0, i.length - 1);
				// num 是偶数， 时间字段的条件是大于该值
				if(flag && (num % 2 == 0)) {
					whereArg += key + " >= " + "\'" + value + "\'" + " and ";
				}
				// num 是奇数 ， 时间字段的条件是小于该值
				else if(flag && (num % 2 == 1)) {
					whereArg += key + " <= " + "\'" + value + " 24:00:00\'" + " and ";
				}
				num++;
			}
		}
		if(whereArg == "") {
			whereArg = " ";
		} else {
			whereArg = " and " + whereArg.substring(0, whereArg.lastIndexOf(" and "));
		}
		if(or_str !="" ){
			or_str = "  and (1>3  "+or_str+")";
		}
		s.ChoiseFilter(userid,whereArg,or_str,callBack1);	
	},
	returnString:function(e){
		return "../../Util/Images/"+e;
	}
}
