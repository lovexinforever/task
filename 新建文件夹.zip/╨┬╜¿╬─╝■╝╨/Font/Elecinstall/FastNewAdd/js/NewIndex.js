var ns = new NewSql(), nop = new NewOperAtion(), scanFalse = 0, tempBoxNotDone = [], tempTime = 0;
//存储上装信息
// 上装人员信息
// 电能表信息
// 互感器信息
// 计量箱信息
// GPS信息
var strlen = [];
var newAddMeasFlag=true;
var tempAppInfo = [], tempMtScheme = [], tempItScheme = [], tempBox = [], tempGps = [];
//存储计量箱到数组中
var storageMtBox = [];
sessionStorage.plMeater=0;
ns.selectNewAdd(sessionStorage.user_name);
$("#newLoginuser_info").html(sessionStorage.area + "-" + sessionStorage.user_name_str + "-" + sessionStorage.user_name);
function newAddSuccess(res, b) {
	o.openWait("", 2);
	var e = b.rows.item, len = b.rows.length;
	if(b.rows.length > 0) {
		//查询出所有新装计量箱信息并填充页面
		var getNewData = "";
		storageMtBox = [];
		for(var i = 0; i < len; i++) {
			storageMtBox[i] = e(i);
			getNewData += "<li><div class='float listLi'><div>" + (i + 1) + "</div><div>表箱号：</div><div><input id='wantmodify" + i + "' onchange='updateContain(this)' value='" + e(i).container_asset_no + "' tel='" + i + "' /></div><div>(&nbsp;电表<span id='mtassetNumber" + i + "'>" + e(i).assetnumber + "</span>个&nbsp;) <span id='getReturnLongID" + i + "'>" + returnGpsDone(e(i).longitude) + "</span></div></div><div class='hideContent'><div class='float hideButton'><div class='flex active_mt'>电能表(<span id='flexMtNumber" + i + "'>0</span>)</div><div class='flex' style='display:none'>互感器</div></div><div class='hideMiddleContent'><ul id='hideLiID" + i + "'></ul></div><div class='float BtnParent'><div class='bottomButton flex'>新增电表</div><div class='bottomButton flex'>GPS定位</div></div></div></li>";
		}
		$("#newAddBoxID").html(getNewData + "<div style='height:200px; float:none; both:clear;'></div>");
	}
}

function returnGpsDone(e) {
	if(e != "" && e) {
		return "<span style='color:green'>已定位</span>"
	} else {
		return "<span style='color:red'>未定位</span>";
	}
}

//查询电能表
function showMtScheme(tx, res) {
	var len = res.rows.length;
	var e = res.rows.item;
	if(len > 0) {
		$("#flexMtNumber" + sessionStorage.NewMt).html(len);
		var html = "";
		for(var i = 0; i < len; i++) {
			html += "<li><div class='float hideLi mtmodifyclass' mtid='" + e(i).id + "'><div><img class='fastclass' src='FastNewAdd/image/sign.png'/></div><div>资产编号</div><div><input id='zcbh" + e(i).id + "' value='" + e(i).asset_no + "' readonly='readonly'></div><div>户号：" + e(i).cons_no + "</div></div><div class='hideAddress'>" + e(i).mp_addr + "</div></li>";
		}
		$("#hideLiID" + sessionStorage.NewMt).html(html);
		var heightval = $("#hideLiID" + sessionStorage.NewMt).parent().parent();
		setTimeout(function() {
			if(len > 3) {
				heightval.height(500);
			} else {
				heightval.height(len * 107 + 180);
			}
		}, 100)
	}
	setTimeout(function() {
		var hdiv = $("#newAddBoxID >li:eq(" + sessionStorage.NewMt + ") div:eq(0)");
		var scrolldiv = hdiv.position().top;
		$("#middleListID").scrollTop($("#middleListID").scrollTop() + scrolldiv - 185);
	}, 250);
}

function newAddmt(conAssetNo, i, conNo) {
	sessionStorage.NewMt = i;
	$("#Pop_up_tops").slideDown();
	$("#Pop_up_tops").html("<div class='round_up_top'><div class='outpadding'><div class='bar_code_tm outshadow'><div class='top_headlinemge headtext'>新增电表</div><div class='newinput'><span>资产编号：</span><input id='newAddInputID'  maxlength='10'  value='' /></div><div class='bottombtn float'><div class='flex' id='nsBottomOk'>确　定</div><div class='flex' id='nsBottomCancel'>关　闭</div></div></div></div></div>");
	//如果conAssetNo为空，则表示为新增计量箱，
	if(conNo == "") {
		conAssetNo = sessionStorage.mtNewConsNo;
		$("#nsBottomOk").click(function() {
			if($("#newAddInputID").val().length < 10) {
				o.openWait("请输入正确的资产号!", 0);
			} else {
				ns.selectNullBox($("#newAddInputID").val(), conAssetNo);
			}
		})
	} else {
		sessionStorage.mtNewConsNo = conAssetNo;
		$("#nsBottomOk").click(function() {
			ns.selectAssetBox($("#newAddInputID").val());
		})
	}
	$("#nsBottomCancel").click(function() {
		$("#Pop_up_tops").slideUp();
	})
}

function selectMtSuccess(tx, res) {
	var len = res.rows.length;
	var e = res.rows.item;
	if(len > 0) {
		if($("#newAddBoxID").html().indexOf(e(0).asset_no) != -1) {
			o.openWait("该电能表已经存在，不能重复添加", 0);
			return;
		}
		//查询出值之后改变电能表所对应的计量点处理状态
		ns.updateMpSchemeType(e(0).asset_no);
		$("#Pop_up_tops").slideUp();
		var html = "<li><div class='float hideLi mtmodifyclass' mtid='" + e(0).id + "'><div><img class='fastclass' src='FastNewAdd/image/sign.png'/></div><div>资产编号</div><div><input id='zcbh" + e(0).id + "' value='" + e(0).asset_no + "' readonly='readonly'></div><div>户号：" + e(0).cons_no + "</div></div><div class='hideAddress'>" + e(0).mp_addr + "</div></li>";
		$("#hideLiID" + sessionStorage.NewMt).append(html);
		var heightval = $("#hideLiID" + sessionStorage.NewMt).parent().parent();
		var ulnumber = $("#hideLiID" + sessionStorage.NewMt).find("li").length;
		if(ulnumber <= 2) {
			heightval.height(heightval.height() + 103);
		} else {
			heightval.height(500);
		}
		var number = $("#flexMtNumber" + sessionStorage.NewMt).html();
		number++;
		$("#flexMtNumber" + sessionStorage.NewMt).html(number);
		//delete sessionStorage.NewMt;
		//滚动到最底部
		var p = $("#hideLiID" + sessionStorage.NewMt).parent();
		p.scrollTop($("#hideLiID" + sessionStorage.NewMt).height());
		//更改电能表标记
		ns.UpdateMtFlag(e(0).asset_no);
	} else {
		//电能表不存在的情况下，再查找是否有为空的电能表能对应上该计量箱
		//当前计量箱用户号：storageMtBox[sessionStorage.NewMt].cons_no
		//用用户号查找为空的电能表
		ns.selectNullAmmt();

		//storageMtBox[sessionStorage.NewMt].cons_no
	}
}

//新增表箱
function newAddBoxClick() {
	$("#Pop_up_tops").slideDown();
	$("#Pop_up_tops").html("<div class='round_up_top'><div class='outpadding'><div class='bar_code_tm outshadow'><div class='top_headlinemge headtext'>新增表箱</div><div class='newinput'><span>资产编号：</span><input id='newBoxInputID' value='' /></div><div class='bottombtn float'><div class='flex' id='nsBoxBottomOk'>确　定</div><div class='flex' id='nsBoxBottomCancel'>关　闭</div></div></div></div></div>");
	$("#nsBoxBottomOk").click(function() {
		sessionStorage.mtNewConsNo = $("#newBoxInputID").val();
		nop.AddBoxBarcode($("#newBoxInputID").val());
	})
	$("#nsBoxBottomCancel").click(function() {
		$("#Pop_up_tops").slideUp();
	})
}

//修改计量箱
function updateContain(obj) {
	var i = $(obj).attr("tel");
	var v = $("#newAddBoxID li:eq(" + i + ") .listLi input").val();
	sessionStorage.plMeater = 0;
	if(v.replace(/\s+/g, "") == "") {
		o.openWait("计量箱不能为空！", 0);
		$("#newAddBoxID li:eq(" + i + ") .listLi input").val(storageMtBox[i].container_asset_no);
	} else {
		ns.updateContainer(storageMtBox[i].container_asset_no, $("#newAddBoxID li:eq(" + i + ") .listLi input").val(), sessionStorage.user_name, i);
	}
}

//工单信息
function billInfomation() {
	ns.statInfomation(sessionStorage.user_name)
}

//上裝
function uploadPl() {
	//循环上装全部工单
	//首先判断是否所有工单都处理过了

	ns.judgeAppNo(sessionStorage.user_name);

	// var li = $("#newAddBoxID .listLi")
	// var parent = li.parent();
	// var flag = li.hasClass('active');
	// var hasShow;
	// //如果有展开的计量箱
	// if(flag) {
	// var j = $(".active input").attr("tel");
	// sessionStorage.NewMt = j;
	// //数据库查询当前提交工作流工单是否存在其他未处理信息
	// //ns.selectReferInfos(storageMtBox[j].mp_scheme_id);
	// upLoadFunction(j);
	// } else {
	// o.openWait("打开计量箱才能上装！", 0);
	// }
}

function gotoReferSuccess(tx, res) {
	var len = res.rows.length, e = res.rows.item;
	if(len > 0) {
		var lenRow = [];
		for(var i = 0; i < len; i++) {
			lenRow.push(e(i).CONS_NAME);
		}
		o.openWait("该计量箱对应工单下用户：[" + JSON.stringify(lenRow) + "]未处理,请处理完之后再上装！", 0);
	} else {
		o.openWait(data.PKG.PKG.MSG + ",正在提交工作流....", 1);
		//nop.submission();
		//查询对应工单的活动id
		ns.selectInstance(sessionStorage.newAppNo);
	}
}

//上装方法提取
function upLoadFunction(j) {
	var str = $("#getReturnLongID" + j).html();
	if(str.indexOf("已定位") == -1) {
		navigator.notification.confirm("GPS未定位,是否继续上装？", function(index) {
			if(index == 1) {
				if(storageMtBox[j].mp_scheme_id) {
					ns.selectUpLoadCheck(storageMtBox[j].mp_scheme_id, sessionStorage.user_name);
				} else {
					o.openWait("计量箱未配置电能表,不能上装！", 0);
				}
			}
		}, "温馨提示", "是,否");
		//o.openWait("计量箱没定位，不能上装！", 0);
	} else {
		//查询该计量箱是否处理完成
		ns.selectUpLoadCheck(storageMtBox[j].mp_scheme_id, sessionStorage.user_name);
	}
}

function doneLoad(tx, res) {
	var len = res.rows.length, e = res.rows.item;
	if(len > 0) {
		//如果电表数和统计电表数相等，则可以上装
		if($("#mtassetNumber" + sessionStorage.NewMt).html() == e(0).assetnumber) {
			$("#newUpLoadID").slideDown();
			ns.selectAppInfo(storageMtBox[sessionStorage.NewMt].mp_scheme_id);
		} else {
			o.openWait("该计量箱没处理完！", 0);
		}
	}
}

//选择上装时间
function newUploadAppData() {
	get_sx_date(newSuccess, newSuccess);
}

function newSuccess(e) {
	if(e == 0) {
		$("#update").val("请输入上装日期");
	} else {
		var data = new Date(), t1 = e;
		var t2 = data.getFullYear() + "-" + ((data.getMonth() + 1) < 10 ? "0" + (data.getMonth() + 1) : (data.getMonth() + 1)) + "-" + (data.getDate() < 10 ? "0" + data.getDate() : data.getDate());
		t1 = t1.replace(/\-/g, "");
		t2 = t2.replace(/\-/g, "");
		var t3 = Number(t1) - Number(t2);
		if(t3 > 0) {
			o.openWait("上装时间不能大于当前日期！", 0);
		} else {
			$("#newUpdate").val(e);
		}
	}
}

//确定上装，先保存上装人员信息
function newLockCheckForm() {
	o.openWait("数据正在上装....", 1);
	$("#newUpLoadID").hide();
	ns.updateAppInfos([$("#newUpdate").val(), $("#textareaInput").val(), storageMtBox[sessionStorage.NewMt].mp_scheme_id]);
}

//关闭上状框
function newLockCheckCancle() {
	$("#newUpLoadID").slideUp();
}

function BackToDbsy() {
	changepage("Businesslist/html/business_list.html");
	$("#dbsy_sqyy").attr("src", "../../Util/Images/plxz.png");
}

/**************************************触发事件************************************************/
//新增电能表
$(document).on("click", "#newAddBoxID .bottomButton", function() {
	var str = $(this).html();
	var j = $(this).parents("li").find("input").attr("tel");
	if(clFlag) {
		if(str == "新增电表") {
			clFlag = false;
			//当前为新增电表
			//$("#wantmodify"+sessionStorage.NewMt).val()
			//传递计量箱编号
			newAddmt($("#wantmodify" + j).val(), j, storageMtBox[j].cons_no);
			//先查询电能表所对应的计量箱
			//selectNullBox();
			setTimeout(function() {
				clFlag = true;
			}, 300)
		} else {
			//GPS定位功能
			if($("#mtassetNumber" + j).html() != 0) {
				nop.newGetGpsArcgis(storageMtBox[j].mp_scheme_id, storageMtBox[j].longitude, storageMtBox[j].latitude);
			} else {
				o.openWait("计量箱暂未添加电表！", 0);
			}

		}
	}
});
$(document).on("click", ".hideButton div", function() {
	$(this).parent().find('.active').removeClass('active');
	$(this).addClass('active');
});
var clFlag = true;
$(document).on("click", "#newAddBoxID .listLi", function() {
	if(clFlag) {
		clFlag = false;
		var parent = $(this).parent();
		var flag = $(this).hasClass('active');
		var hasShow;
		if(!flag) {
			hasShow = $('.middleList .listLi.active');
			$(this).addClass('active');
			var hideContent = parent.find('.hideContent');
			hideContent.slideDown();
			//查询电能表flag为1的电能表并显示出来
			var j = $(this).parents("li").find("input").attr("tel");
			sessionStorage.NewMt = j;
			if(storageMtBox[j].cons_no != "") {
				ns.selectMtFlag(storageMtBox[j].container_asset_no);
			}
		} else {
			hasShow = $(this);
		}
		if(hasShow.length > 0) {
			hasShow.removeClass('active');
			var showContent = hasShow.parent().find('.hideContent');
			showContent.slideUp();
		}
		setTimeout(function() {
			clFlag = true;
		}, 300)
	}
});
//$(document).off("click","#newAddBoxID .listLi", listLiClick);

//删除电能表
$(document).on("click", ".fastclass", function(e) {
	e.stopPropagation();
	if(clFlag) {
		clFlag = false;
		var heightval = $("#hideLiID" + sessionStorage.NewMt).parent().parent();
		var ulnumber = $("#hideLiID" + sessionStorage.NewMt).find("li").length;
		var that = this;
		navigator.notification.confirm("是否删除该电表？", function(index) {
			if(index == 1) {
				clFlag = true;
				var lens = $("#flexMtNumber" + sessionStorage.NewMt).html() - 1;
				$("#flexMtNumber" + sessionStorage.NewMt).html(lens);
				if(ulnumber <= 3) {
					heightval.height(heightval.height() - 103);
				}
				$(that).parent().parent().parent().remove();
				ns.deleteMt($(that).parent().parent().find("input").val());
			} else {
				clFlag = true;
			}
		}, "温馨提示", "是,否");
	}
})
//修改电能表资产号
$(document).on("click", ".mtmodifyclass", function() {
	var that = this;
	var id = $(that).attr("mtid");
	//记录资产号
	var vals = $(that).find("input").val();
	nop.modifyMt(vals, id);
})
$(document).on("touchstart", "#middleListID .hideMiddleContent", function() {
	//$('.hideMiddleContent').on('touchstart',function(e){
	console.log('touchstart');
	$('#middleListID').css('overflow', 'hidden');
	$(this).css('overflow', 'scroll');
});
$(document).on("touchend", "#middleListID .hideMiddleContent", function() {
	//$('.hideMiddleContent').on('touchend',function(e){
	console.log('touchend');
	$(this).css('overflow', 'hidden');
	$('#middleListID').css('overflow', 'scroll');
});
//编辑计量箱资产编号
$(document).on("click", ".listLi input", function(e) {
	var i = $(this).attr("tel");
	sessionStorage.NewMt = i;
	sessionStorage.plMeater = 1;
	e.stopPropagation();
})