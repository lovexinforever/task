var NewOperAtion = function() {

}
NewOperAtion.prototype = {
	findBox : function(mtBoxBarcode, barcode) {
		o.openWait("扫描资产号为：" + mtBoxBarcode, 0, 1);
		for(var i = 0; i < storageMtBox.length; i++) {
			if(mtBoxBarcode == storageMtBox[i].container_asset_no) {
				var hdiv = $("#newAddBoxID >li:eq(" + i + ") div:eq(0)");
				var flag = hdiv.hasClass('active');
				//如果找到计量箱,则焦点定位到计量箱位置
				//展开计量箱
				//如果当前点击的没有被打开则打开它
				if(!flag) {
					//先将以前被打开的关闭
					var preli = $("#newAddBoxID li .active");
					if(preli.length > 0) {
						preli.removeClass('active');
						var showContent = preli.parent().find('.hideContent');
						showContent.slideUp();
					}
					//扫描滑动到当前位置
					setTimeout(function() {
						var hdiv = $("#newAddBoxID >li:eq(" + i + ") div:eq(0)");
						var scrolldiv = hdiv.position().top;
						$("#middleListID").scrollTop($("#middleListID").scrollTop() + scrolldiv - 185);

						hdiv.addClass('active');
						var content = hdiv.parent().find('.hideContent');
						content.slideDown();
						//查询电能表flag为1的电能表并显示出来
						sessionStorage.NewMt = i;
						ns.selectMtFlag(storageMtBox[i].cons_no);
					}, 200)
				} else {
					//否则扫描电能表添加到计量箱
					//newAddmt(storageMtBox[i].consNo, i);
					//ns.selectAssetBox(barcode, storageMtBox[i].consNo);
				}
				return;
			}

		}
		//当前为没有找到计量箱情况,则进行电表添加业务
		var flags = $(".middleList .listLi").hasClass('active');
		var consno = $('.middleList .listLi.active');
		var t = consno.parents("li").find("input").attr("tel");
		//如果计量箱为打开状态，则添加电能表，否则进行新增计量箱
		if(flags) {
			ns.selectAssetBox(barcode);
		} else {
			if(newAddMeasFlag){
				newAddMeasFlag=false;
				navigator.notification.confirm("是否对资产号为'" + mtBoxBarcode + "'的计量箱进行新增？", function(index) {
					if(index == 1) {
						newAddMeasFlag=true;
						nop.AddBoxBarcode(mtBoxBarcode);
					}else{
						newAddMeasFlag=true;
					}
				}, "温馨提示", "是,否");
			}
		}
	},
	modifyMt : function(val, id) {
		sessionStorage.mtModifyId = id;
		$("#Pop_up_tops").slideDown();
		$("#Pop_up_tops").html("<div class='round_up_top'><div class='outpadding'><div class='bar_code_tm outshadow'><div class='top_headlinemge headtext'>修改电表</div><div class='newinput'><span>资产编号：</span><input id='newModifyInputID' maxlength='10' value='" + val + "' /></div><div class='bottombtn float'><div class='flex' id='noBottomOk'>确　定</div><div class='flex' id='noBottomCancel'>关　闭</div></div></div></div></div>");
		$("#noBottomOk").click(function() {
			ns.modify($("#newModifyInputID").val(), id);
		})
		$("#noBottomCancel").click(function() {
			$("#Pop_up_tops").slideUp();
		})
	},
	newModify : function() {
		$("#zcbh" + sessionStorage.mtModifyId).val($("#newModifyInputID").val());
		$("#Pop_up_tops").slideUp();
	},
	//新增一个空表箱
	AddBoxBarcode : function(asset) {
		asset = asset.replace(/\s+/g, "");
		if(asset == "") {
			o.openWait("新增计量箱不能为空!", 0);
			return;
		}
		sessionStorage.NewMt=storageMtBox.length;
		var html = "<li><div class='float listLi'><div>" + (storageMtBox.length + 1) + "</div><div>表箱号：</div><div><input value='" + asset + "' tel='" + storageMtBox.length + "' /></div><div>(&nbsp;电表<span id='mtassetNumber" + storageMtBox.length + "'>0</span>个)<span id='getReturnLongID"+storageMtBox.length +"'><span style='color:red'>未定位</span></span></div></div><div class='hideContent'><div class='float hideButton'><div class='flex active_mt'>电能表(<span id='flexMtNumber" + storageMtBox.length  + "'>0</span>)</div><div class='flex' style='display:none'>互感器</div></div><div class='hideMiddleContent'><ul id='hideLiID" + storageMtBox.length + "'></ul></div><div class='float BtnParent'><div class='bottomButton flex'>新增电表</div><div class='bottomButton flex'>GPS定位</div></div></div></li>";
		var arrPush = {
			"mp_scheme_id" : "",
			"id" : "",
			"cons_name" : "",
			"assetnumber" : "0",
			"mp_addr" : "",
			"cons_no" : "",
			"number" : "0",
			"container_flag" : "05",
			"container_asset_no" : asset
		};
		storageMtBox.push(arrPush);
		if($("#newAddBoxID div:last").before()){
			$("#newAddBoxID div:last").before(html);
		}else{
			$("#newAddBoxID").append(html+"<div></div>");
		}
		//滑到底部
		//window.scrollTo(0, $("#newAddBoxID li:last").position().top);
		$("#Pop_up_tops").slideUp();
		$("#newAddBoxID >li:last .listLi").click();
		setTimeout(function() {
			var hdiv = $("#newAddBoxID >li:eq(" + sessionStorage.NewMt + ") div:eq(0)");
			var scrolldiv =0;
			try{
				scrolldiv = hdiv.position().top;
			}catch(ex){
				
			}
			$("#middleListID").scrollTop($("#middleListID").scrollTop() + scrolldiv - 185);
		}, 300)
	},
	StatInfo : function(tx, res) {
		var len = res.rows.length, e = res.rows.item;
		if(len > 0) {
			//查询出多少工单个数
			$("#Pop_up_tops").slideDown();
			$("#Pop_up_tops").html("<div class='round_up_top'><div class='bar_code_tm'><div class='top_headlinemge'><span class='span_headlinemge'>&nbsp;&nbsp;工单信息统计</span><span style='float:right; padding-right:10px;margin-top:1px'><img src='../../Util/Images/cancel_1.png' class='img_cancel_1'/></span></div><div class='bottom_message'><table cellpadding='0' cellspacing='0' border='0' width='80%' style='margin-left:50px; text-align:left'><tr><td height='10px'></td></tr><tr><td>共有工单:<span id='usercountid' style='margin-left:30px'>" + nop.returnUserNumber(e(0).sumapp_no) + "</span>   个</td></tr><tr><td>完成工单:<span id='doid' style='margin-left:30px'>" + nop.returnUserNumber(e(0).docount) + "</span>   个</td></tr><tr><td>剩余工单:<span id='uprealid' style='margin-left:30px'>" + nop.returnUserNumber(e(0).nocount) + "</span>   个</td></tr><tr style='text-algin:left;'><td height='10px'></td></tr></table></div><img src='../../Util/Images/enter.png' class='img_enter_el' onclick='nop.nextOK()' /></div></div></div>");
			$(".img_cancel_1").click(function() {
				$("#Pop_up_tops").slideUp();
			})
		}else{
			o.openWait("暂无工单信息！", 0);
		}
	},
	returnUserNumber : function(e) {
		if(e) {
			return e;
		} else {
			return 0;
		}
	},
	nextOK : function() {
		$("#Pop_up_tops").slideUp();
	},
	newGetGpsArcgis : function(e, x, y) {
		o.openWait("GPS定位中...", 1);
		get_GPS_info(60, function(data) {
			tempTime=0;
			var arr = new Array();
			arr = data.split(",");
			s1 = arr[0];
			s2 = arr[1];
			if(x == "" || y == "") {
				nop.newGisMeas(s1, s2);
			} else {
				var warp = nop.computeDistanceAndBearing(s2, s1, y, x);
				if(warp < 10) {
					//小于10米则直接保存
					nop.newGisMeas(s1, s2);
				} else {
					navigator.notification.confirm("GPS坐标偏移大于10米，是否打开地图校验？", function(index) {
						if(index == 1) {
							//传入两个点查看地图
							nop.compareGisMeas(s1, s2, x, y);
							navigator.notification.confirm("是否覆盖当前坐标？", function(index) {
								if(index == 1) {
									nop.newGisMeas(s1, s2);
								} else {
									o.openWait("取消覆盖", 0, 2);
								}
							}, "温馨提示", "是,否");
						} else {
							navigator.notification.confirm("GPS坐标偏移大于10米，是否覆盖当前坐标？", function(index) {
								if(index == 1) {
									nop.newGisMeas(s1, s2);
								} else {
									o.openWait("取消保存", 0, 2);
								}
							}, "温馨提示", "是,否");
						}
					}, "温馨提示", "是,否");
				}
			}
		}, function(e) {
			var goingTime=setTimeout(function(){
				tempTime++;
				if(tempTime<=10){
					//调用获取GPS坐标方法
					nop.newGetGpsArcgis();
				}else{
					tempTime=0;
					o.openWait(e,0);
				}
			},2000);
		});
	},
	compareGisMeas : function(s1, s2, x, y) {
		var value = {
			"content" : [{
				"name" : "旧点",
				"x" : x,
				"y" : y
			}, {
				"name" : "新点",
				"x" : s1,
				"y" : s2
			}],
			"disableLocated" : true
		};
		drawPoints(function(data) {
			//data.code , data.desc
		}, value);
	},
	newGisMeas : function(lon, lat) {
		o.openWait("GPS已定位", 0);
		//列表中更改定位信息,临时存储数据更改GPS值
		$("#getReturnLongID" + sessionStorage.NewMt).html("<span style='color:green'>已定位</span>");
		storageMtBox[sessionStorage.NewMt].longitude = lon;
		storageMtBox[sessionStorage.NewMt].latitude = lat;
		//保存GPS坐标
		ns.updataMpLonLat(lon, lat, storageMtBox[sessionStorage.NewMt].mp_scheme_id);
	},
	computeDistanceAndBearing : function(lat1, lon1, lat2, lon2) {
		var MAXITERS = 20;
		// Convert lat/long to radians
		lat1 = lat1 * Math.PI / 180.0;
		lat2 = lat2 * Math.PI / 180.0;
		lon1 = lon1 * Math.PI / 180.0;
		lon2 = lon2 * Math.PI / 180.0;
		var results = [];
		var a = 6378137.0;
		// WGS84 major axis
		var b = 6356752.3142;
		// WGS84 semi-major axis
		var f = (a - b) / a;
		var aSqMinusBSqOverBSq = (a * a - b * b) / (b * b);

		var L = lon2 - lon1;
		var A = 0.0;
		var U1 = Math.atan((1.0 - f) * Math.tan(lat1));
		var U2 = Math.atan((1.0 - f) * Math.tan(lat2));

		var cosU1 = Math.cos(U1);
		var cosU2 = Math.cos(U2);
		var sinU1 = Math.sin(U1);
		var sinU2 = Math.sin(U2);
		var cosU1cosU2 = cosU1 * cosU2;
		var sinU1sinU2 = sinU1 * sinU2;

		var sigma = 0.0;
		var deltaSigma = 0.0;
		var cosSqAlpha = 0.0;
		var cos2SM = 0.0;
		var cosSigma = 0.0;
		var sinSigma = 0.0;
		var cosLambda = 0.0;
		var sinLambda = 0.0;

		var lambda = L;
		for(var iter = 0; iter < MAXITERS; iter++) {
			var lambdaOrig = lambda;
			cosLambda = Math.cos(lambda);
			sinLambda = Math.sin(lambda);
			var t1 = cosU2 * sinLambda;
			var t2 = cosU1 * sinU2 - sinU1 * cosU2 * cosLambda;
			var sinSqSigma = t1 * t1 + t2 * t2;
			sinSigma = Math.sqrt(sinSqSigma);
			cosSigma = sinU1sinU2 + cosU1cosU2 * cosLambda;
			sigma = Math.atan2(sinSigma, cosSigma);
			var sinAlpha = (sinSigma == 0) ? 0.0 : cosU1cosU2 * sinLambda / sinSigma;
			cosSqAlpha = 1.0 - sinAlpha * sinAlpha;
			cos2SM = (cosSqAlpha == 0) ? 0.0 : cosSigma - 2.0 * sinU1sinU2 / cosSqAlpha;

			var uSquared = cosSqAlpha * aSqMinusBSqOverBSq;
			A = 1 + (uSquared / 16384.0) * (4096.0 + uSquared * (-768 + uSquared * (320.0 - 175.0 * uSquared)));
			var B = (uSquared / 1024.0) * (256.0 + uSquared * (-128.0 + uSquared * (74.0 - 47.0 * uSquared)));
			var C = (f / 16.0) * cosSqAlpha * (4.0 + f * (4.0 - 3.0 * cosSqAlpha));
			var cos2SMSq = cos2SM * cos2SM;
			deltaSigma = B * sinSigma * (cos2SM + (B / 4.0) * (cosSigma * (-1.0 + 2.0 * cos2SMSq) - (B / 6.0) * cos2SM * (-3.0 + 4.0 * sinSigma * sinSigma) * (-3.0 + 4.0 * cos2SMSq)));
			lambda = L + (1.0 - C) * f * sinAlpha * (sigma + C * sinSigma * (cos2SM + C * cosSigma * (-1.0 + 2.0 * cos2SM * cos2SM)));
			var delta = (lambda - lambdaOrig) / lambda;
			if(Math.abs(delta) < 1.0e-12) {
				break;
			}
		}
		var distance = (b * A * (sigma - deltaSigma));
		results[0] = distance;
		if(results.length > 1) {
			var initialBearing = Math.atan2(cosU2 * sinLambda, cosU1 * sinU2 - sinU1 * cosU2 * cosLambda);
			initialBearing *= 180.0 / Math.PI;
			results[1] = initialBearing;
			if(results.length > 2) {
				var finalBearing = Math.atan2(cosU1 * sinLambda, -sinU1 * cosU2 + cosU1 * sinU2 * cosLambda);
				finalBearing *= 180.0 / Math.PI;
				results[2] = finalBearing;
			}
		}
		return results;
	},
	newAppinfoPage:function(tx,res){
		var len=res.rows.length,e=res.rows.item;
		if(len>0){
			$("#emp_nameId").html(e(0).EMP_NAME);
			$("#textareaInput").val(e(0).MEMO);
		}
	},
	returnAppInfos:function(){
		//更新上装人员信息之后,再次查询需要上装的数据,组织上装
		//ns.getAllUploadInfos(storageMtBox[sessionStorage.NewMt].mp_scheme_id);
		ns.judgeAppNo(sessionStorage.user_name);
	},
	//工单上装
	getAllinfomation:function(tempAppInfo,tempMtScheme,tempBox,tempGps){
		//var tempAppInfo=[],tempMtScheme=[],tempBox=[],tempGps=[];
		var str1="",str2="",str3="",str4="";
		//是否为空
		if(tempGps==""){
			str4='';
		}else{
			str4=','+'"MPGPS_INFOS":' + JSON.stringify(tempGps);
		}
		if(tempBox==""){
			str3='';
		}else{
			str3=','+'"MT_BOX":' + JSON.stringify(tempBox);
		}
		if(tempMtScheme==""){
			str2="";	
		}else{
			str2=','+'"MT_SCHEME":' + JSON.stringify(tempMtScheme);
		}
		if(tempAppInfo==""){
			str1='';
		}else{
			str1=','+'"APP_NO":' + JSON.stringify(tempAppInfo);
		}
		var pkg = '{"MOD":"02","FUN":"02","ORG_NO":"' + sessionStorage.ORG_NO + '","PKG_TYPE":"0","PKG":{"USR":"' + sessionStorage.user_name + '","APP_NO":"' + sessionStorage.newAppNo +'","INFLAT":"0"' + str1 + str2 + str3 + str4 +'}}';
		send_data("0000","2002",pkg,nop.newUpLoadCallBack,function(){
			o.openWait("上装失败，网络连接失败",0);
		});
	},
	newUpLoadCallBack:function(data){
		data=JSON.parse(data);
		if(data.RET!="00"){
			o.openWait(o.scanAsset.getErrorCode(data.RET),0);
		}else{
			if(data.PKG.RET!="01"){
				o.openWait(data.PKG.PKG.MSG,0);
			}else{
				o.openWait(data.PKG.PKG.MSG + ",正在提交工作流....", 1);
				//查询对应工单的活动id
				ns.selectInstance(sessionStorage.newAppNo);
				//ns.selectReferInfos(storageMtBox[sessionStorage.NewMt].mp_scheme_id);
			}
		}
	},
	submission:function(tx,res){
		var len=res.rows.length;b=res.rows.item;
		if(len>0){
			var instance='{"MOD":"01","FUN":"03","PKG_TYPE":"0","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"USR":"' + sessionStorage.user_name + '","APP_NO":"' + sessionStorage.newAppNo + '","ORG_NO":"'+sessionStorage.ORG_NO+'","INSTANCE_ID":"'+b(0).INSTANCE_ID+'"}}';
			send_data("0000", "2002", instance, function(e){
				var str_gzl = JSON.parse(e);
				if(str_gzl.RET!="00"){
					o.openWait(o.scanAsset.getErrorCode(str_gzl.RET),0);
				}else{
					if(str_gzl.PKG.RET!="01"){
						o.openWait(str_gzl.PKG.PKG.MSG,0);
					}else{
						o.openWait(str_gzl.PKG.PKG.MSG+",列表正在刷新...",1);
						//工作流提交成功之后删除相关数据
						setTimeout(function(){
							ns.deleteNewUpUserList(sessionStorage.newAppNo);
							ns.selectNewAdd(sessionStorage.user_name,1);
							$("#newUpLoadID").hide();
						},2000)
					}
				}
			},function(){
				o.openWait("网络连接失败",0);
			});
		}else{
			o.openWait("查询流程编号失败！",0);
		}
	},
	//获取对应计量箱所对应的空电能表
	getTheNullMt:function(tx,res){
		var len=res.rows.length;b=res.rows.item;
		if(len>0){
			//如果存在，则修改填充电能表的第一个值，并标记为已处理
			//将扫描到得资产号或者手动输入的电表资产号填充并显示
			//需要增加进入数据库的电表资产号：$("#newAddBoxID").html();
			//扫描获取的资产号：sessionStorage.barCodeInti
			if($("#Pop_up_tops").css("display")=="block"){
				var lents=$("#newAddInputID").val().length;
				if(lents<10){
					o.openWait("请输入正确的资产号!", 0);
				}else{
					ns.updateNewAddMt(b(0).ID,$("#newAddInputID").val(),$("#wantmodify"+sessionStorage.NewMt).val());
				}
			}else{
				ns.updateNewAddMt(b(0).ID,sessionStorage.barCodeInti,$("#wantmodify"+sessionStorage.NewMt).val());
			}
		}else{
		  	//否则查找计量箱编号
		  	//电表不存在就重新查找计量箱
			if(scanFalse == 1) {
				nop.findBox(sessionStorage.mtBoxBarcode);
				scanFalse = 0;
			} else {
				o.openWait("电能表不存在", 0);
			}
		}
	},
	updateNewMtSuccess:function(consNo,assetNo){
		//update成功之后，将电能表展示到页面中
		//查询出值之后改变电能表所对应的计量点处理状态
		ns.updateMpSchemeType(e(0).asset_no);
		$("#Pop_up_tops").slideUp();
		var html = "<li><div class='float hideLi mtmodifyclass' mtid='" + e(0).id + "'><div><img class='fastclass' src='FastNewAdd/image/sign.png'/></div><div>资产编号</div><div><input id='zcbh" + e(0).id + "' value='" + e(0).asset_no + "' readonly='readonly'></div><div>户号：" + e(0).cons_no + "</div></div><div class='hideAddress'>" + e(0).mp_addr + "</div></li>";
		$("#hideLiID" + sessionStorage.NewMt).append(html);
		var heightval = $("#hideLiID" + sessionStorage.NewMt).parent().parent();
		var ulnumber = $("#hideLiID" + sessionStorage.NewMt).find("li").length;
		if(ulnumber <= 2) {
			heightval.height(heightval.height() + 103);
		} else {
			heightval.height(500);
		}
		var number = $("#flexMtNumber" + sessionStorage.NewMt).html();
		number++;
		$("#flexMtNumber" + sessionStorage.NewMt).html(number);
		//delete sessionStorage.NewMt;
		//滚动到最底部
		var p = $("#hideLiID" + sessionStorage.NewMt).parent();
		p.scrollTop($("#hideLiID" + sessionStorage.NewMt).height());
		//更改电能表标记
		ns.UpdateMtFlag(e(0).asset_no);
	},
	//查询出所有批量新装工单编号
	getAppNoList:function(tx,res){
		var len=res.rows.length,e=res.rows.item;
		strlen=[];
		if(len>0){
			for(var i=0;i<len;i++){
				strlen.push(e(i).app_no+"-"+e(i).sumer+"-"+e(i).counter);
			}
		}
		//拿到所有需要上装的工单：strlen
		nop.appNoListUpload(strlen);
	},
	appNoListUpload:function(strlen){
		var str1=strlen[0].split("-")[0],str2=strlen[0].split("-")[1],str3=strlen[0].split("-")[2];
		if(strlen.length>0){
			if(str2!=str3){
				o.openWait("工单["+str1+"]还没有处理完,请处理完成再上装！", 0);
			}else{
				ns.selectUpList(str1);
				strlen.splice(0,1);
			}
		}else{
			o.openWait("批量上装完成", 0);
		}
	}
}




