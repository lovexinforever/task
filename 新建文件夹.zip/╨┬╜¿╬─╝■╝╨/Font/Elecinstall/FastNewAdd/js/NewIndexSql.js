var NewSql = function() {
}
NewSql.prototype = {
	selectNewAdd : function(userid,type) {
		if(type==1){
			o.openWait("数据正在上装...",1);
			nop.appNoListUpload(strlen);
		}else{
			var sql = "select a.number,count(1) as assetnumber,mtb.mp_addr as mp_addr,mtb.mp_scheme_id as mp_scheme_id,mtb.cons_no as cons_no,mtb.cons_name as cons_name,mtb.container_asset_no as container_asset_no  from yx_mt_scheme mt,yx_mt_box mtb left join (select count(1) as number from yx_task_list where  ins_name like '%新装%' and  user_id='"+userid+"' ) a where mt.mp_scheme_id=mtb.mp_scheme_id and mtb.container_asset_no<>'' and mt.mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in (select app_no from yx_task_list where ins_name like '%新装%' and  user_id='"+userid+"'  )) group by container_asset_no";
			db_execut_oneSQL("dbzj.db", sql, [], newAddSuccess, null);
		}
	},
	selectAssetBox : function(asset) {
		var sql = "select id as id,asset_no as asset_no,cons_no as cons_no,cons_name as cons_name,mp_addr as mp_addr,mp_scheme_id as mp_scheme_id from yx_mt_scheme where asset_no='" + asset + "'";
		db_execut_oneSQL("dbzj.db", sql, [], selectMtSuccess, null);
	},
	UpdateMtFlag : function(mtAsset) {
		var sql = "update yx_mt_scheme set flag=1 where asset_no='" + mtAsset + "'";
		db_execut_oneSQL("dbzj.db", sql, [], null, null);
	},
	selectMtFlag : function(conAsset) {
		var sql = "select t.id as id,t.asset_no as asset_no,t.cons_no as cons_no,t.mp_addr as mp_addr from yx_mt_scheme t where t.flag=1 and t.mp_scheme_id in (select mp_scheme_id from yx_mt_box where container_asset_no='"+conAsset+"') and t.mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in ( select app_no from yx_task_list where ins_name like '%新装%' and  user_id='"+sessionStorage.user_name+"'))";
		db_execut_oneSQL("dbzj.db", sql, [], showMtScheme, null);
	},
	deleteMt : function(asset) {
		var sql = "update yx_mt_scheme set flag=0 where asset_no='" + asset + "'";
		db_execut_oneSQL("dbzj.db", sql, [], null, null);
	},
	modify : function(value, id) {
		var sql_get = "select count(1) as a from yx_mt_scheme where  asset_no='" + value + "' and id <>'" + id + "'";
		db_execut_oneSQL("dbzj.db", sql_get, [], function(a, b) {
			var e = b.rows.item;
			if(e(0).a == 0) {
				var sql = "update yx_mt_scheme set asset_no='" + value + "' where id='" + id + "'";
				db_execut_oneSQL("dbzj.db", sql, [], nop.newModify, null);
			} else {
				o.openWait("资产编号不能重复", 0);
			}
		}, null);
	},
	selectNullBox : function(asset, conAsset) {
		//计量箱为空的时候进入的执行语句，所以只查询为空的电能表，如果为空，则执行电表资产号的修改
		var sql = "select * from yx_mt_scheme where asset_no= '"+asset+"'";
		db_execut_oneSQL("dbzj.db", sql, [], function(tx, res) {
			var e = res.rows.item, len = res.rows.length;
			if(len > 0) {
				//处理过的计量箱更改为已处理状态
				//var updatedo="update yx_mp_scheme set already_do=1 where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in (select app_no from yx_task_list where ins_name like '%新装%' and  user_id='" + sessionStorage.user_name + "') and app_no in ( select app_no from yx_mp_scheme where mp_scheme_id in (select mp_scheme_id from yx_mt_box where container_asset_no=''  and mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in (select app_no from yx_task_list where ins_name like '%新装%' and  user_id='" + sessionStorage.user_name + "' limit 1)))))";
				var updatedo="update yx_mp_scheme set already_do=1 where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in (select app_no from yx_mp_scheme where mp_scheme_id='"+e(0).MP_SCHEME_ID+"'))";
				db_execut_oneSQL("dbzj.db", updatedo, [], function(){
					//asset:新增电能表资产号,conAsset：新增计量箱资产号
					var up_date = "update yx_mt_box set container_asset_no='"+conAsset+"' where container_asset_no='' and mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in (select app_no from yx_mp_scheme where mp_scheme_id='"+e(0).MP_SCHEME_ID+"')) ";
					db_execut_oneSQL("dbzj.db", up_date, [], function(){
						//修改空计量箱之后，再执行电能表的插入
						//查询所在计量箱电能表个数
						ns.AddBoxMtAsset(conAsset);
						ns.selectAssetBox(asset);
					},null);
				},null);
			} else {
				//o.openWait("电能表不存在", 0);
				//电能表不存在之后,查找是否存在空的电能表
				ns.selectNullAmmt();
			}
		}, null);
		
		
	},
	AddBoxMtAsset : function(conAsset) {
		//查询户号对应电表个数和GPS信息
		var sql = "select count(1) as assetnumber,mps.longitude as longitude from yx_mt_scheme mt,yx_mt_box mtb,yx_mp_scheme mps left join (select count(1) as number from yx_task_list where ins_name like '%新装%' and  user_id='"+sessionStorage.user_name+"' ) a where mt.mp_scheme_id=mtb.mp_scheme_id  and mps.mp_scheme_id=mtb.mp_scheme_id  and mt.mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in (select app_no from yx_task_list where ins_name like '%新装%' and user_id='"+sessionStorage.user_name+"'  )) and  mtb.container_asset_no='"+conAsset+"' group by container_asset_no";
		db_execut_oneSQL("dbzj.db", sql, [], function(tx, res) {
			var e = res.rows.item, len = res.rows.length;
			if(len > 0) {
				$("#mtassetNumber" + sessionStorage.NewMt).html(e(0).assetnumber);
				if(e(0).longitude!=""){
					$("#getReturnLongID"+sessionStorage.NewMt).html("<span style='color:green'>已定位</span>")
				}else{
					$("#getReturnLongID"+sessionStorage.NewMt).html("<span style='color:red'>未定位</span>")
				}
			}
		}, null);
	},
	updateContainer : function(oldasset, newasset, userid, i) {
		//var sql = "update yx_mt_box set CONTAINER_ASSET_NO='" + newasset + "' where CONTAINER_ASSET_NO='" + oldasset + "' and mp_scheme_id in(select mp_scheme_id from yx_mp_scheme where app_no in(select app_no from yx_task_list where user_id='" + userid + "') and app_no in ( select app_no from yx_mp_scheme where mp_scheme_id in (select mp_scheme_id from yx_mt_box where container_asset_no='"+oldasset+"' and mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in (select app_no from yx_task_list where ins_name like '%新装%' and  user_id='" + sessionStorage.user_name + "' limit 1)))))";
		var sql="update yx_mt_box set container_asset_no='"+newasset+"' where container_asset_no='"+oldasset+"' and mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in(select app_no from yx_task_list where  ins_name like '%新装%' and user_id='"+userid+"' ))";
		db_execut_oneSQL("dbzj.db", sql, [], null, null);
	},
	statInfomation:function(userid){
		var sql="select count(1) as sumapp_no,sum(case when already_do<>0 then 1 else 0 end) as docount,sum(case when already_do=0 then 1 else 0 end) as nocount from yx_task_list where  ins_name like '%新装%' and  user_id='"+userid+"'";
		db_execut_oneSQL("dbzj.db", sql, [], nop.StatInfo, null);
	},
	updataMpLonLat:function(lon,lat,mpschemeid){
		var sql="update yx_mp_scheme set longitude='"+lon+"', latitude='"+lat+"' where mp_scheme_id in(select mp_scheme_id from yx_mp_scheme where app_no=(select app_no from yx_mp_scheme where mp_scheme_id='"+mpschemeid+"'))";
		db_execut_oneSQL("dbzj.db", sql, [], null, null);
	},
	selectAppInfo:function(mpschemeid){
		var sql="select app_no,emp_no,emp_name,ir_date,memo,dept_no,org_no from yx_app_info where app_no=(select app_no from yx_mp_scheme where mp_scheme_id='"+mpschemeid+"')";
		db_execut_oneSQL("dbzj.db",sql,[],nop.newAppinfoPage,null);
	},
	//查询电表数和计量箱统计数是否相等
	selectUpLoadCheck:function(mpschemeid,userid){
		var sql="select count(1) as assetnumber from yx_mt_scheme mt,yx_mt_box mtb left join (select count(1) as number from yx_task_list where  ins_name like '%新装%' and  user_id='"+userid+"' ) a where mt.mp_scheme_id=mtb.mp_scheme_id  and mt.mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in (select app_no from yx_task_list where ins_name like '%新装%' and  user_id='"+userid+"'  )) and mtb.mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in (select app_no from yx_mp_scheme where mp_scheme_id='"+mpschemeid+"'))group by container_asset_no";
		db_execut_oneSQL("dbzj.db",sql,[],doneLoad,null);
	},
	//更新人员上装信息
	updateAppInfos:function(data){
		var sql="update yx_app_info set ir_date=?,memo=? where app_no=(select app_no from yx_mp_scheme where mp_scheme_id=?) ";
		db_execut_oneSQL("dbzj.db",sql,data,nop.returnAppInfos,null);
	},
	getAllUploadInfos:function(mpSchemeId){
		//var tempAppInfo=[],tempMtScheme=[],tempItScheme=[],tempBox=[],tempGps=[];
		//查询上装人员信息
		var sql="select app_no,emp_no,emp_name,ir_date,memo,dept_no,org_no from yx_app_info where app_no=(select app_no from yx_mp_scheme where mp_scheme_id='"+mpSchemeId+"')";
		db_execut_oneSQL("dbzj.db",sql,[],function(tx,res){
			var len=res.rows.length,e=res.rows.item;
			if(len>0){
				sessionStorage.newAppNo=e(0).APP_NO;
				for(var i=0;i<len;i++){
					tempAppInfo[i]=e(i);
				}
			}
			ns.getTempScheme(mpSchemeId);
		},null);
		
	},
	getTempScheme:function(mpSchemeId){
		//var tempAppInfo=[],tempMtScheme=[],tempItScheme=[],tempBox=[],tempGps=[];
		//查询电能表信息
		var sql="select id,mp_scheme_id,asset_no,chg_desc from yx_mt_scheme  where mp_scheme_id in (select mp_scheme_id from yx_task_list where app_no = (select app_no from yx_task_list where mp_scheme_id='"+mpSchemeId+"'))";
		db_execut_oneSQL("dbzj.db",sql,[],function(tx,res){
			var len=res.rows.length,e=res.rows.item;
			if(len>0){
				for(var i=0;i<len;i++){
					tempMtScheme[i]=e(i);
				}
			}
			ns.getTempBox(mpSchemeId);
		},null);
	},
	getTempBox:function(mpSchemeId){
		//查询计量箱信息
		var sql="select b.id,b.container_asset_no,b.container_flag,b.mp_scheme_id,t.longitude,t.latitude from yx_mt_box b,yx_mp_scheme t where b.mp_scheme_id=t.mp_scheme_id and b.mp_scheme_id='"+mpSchemeId+"'";
		db_execut_oneSQL("dbzj.db",sql,[],function(tx,res){
			var len=res.rows.length,e=res.rows.item;
			if(len>0){
				for(var i=0;i<len;i++){
					tempBox[i]=e(i);
				}
			}
			ns.getTempGps(mpSchemeId);
		},null);
	},
	getTempGps:function(mpSchemeId){
		//查询GPS信息
		var sql="select b.id, m.longitude, m.latitude, m.mp_id,floor from yx_mp_scheme m,yx_mt_box b where m.mp_scheme_id=b.mp_scheme_id and b.mp_scheme_id='"+mpSchemeId+"'";
		db_execut_oneSQL("dbzj.db",sql,[],function(tx,res){
			var len=res.rows.length,e=res.rows.item;
			if(len>0){
				tempGps=[];
				for(var i = 0; i <len; i++){
					if(e(i).LONGITUDE!=""||e(i).LATITUDE!=""){
						if(!e(i).FLOOR){
							e(i).FLOOR="";
						}
						tempGps.push(e(i));
					}
				}
			}
			nop.getAllinfomation();
		},null);
	},
	//查询流程编号
	selectInstance:function(appNo){
		var sql="select INSTANCE_ID from yx_task_list where app_no='"+appNo+"'";
		db_execut_oneSQL("dbzj.db",sql,[],nop.submission,null);
	},
	//删除已提交工作流的工单所对应的信息
	deleteNewUpUserList:function(appNo){
		var sql1="delete from yx_app_info where app_no in(select app_no from yx_mp_scheme where already_do=1 and app_no=?)";
		db_execut_oneSQL("dbzj.db",sql1,[appNo],null,null);
		var sql2="delete from yx_mp_scheme  where already_do=1 and app_no=?";
		db_execut_oneSQL("dbzj.db",sql2,[appNo],null,null);
		var sql3="delete from yx_mt_scheme  where mp_scheme_id in(select mp_scheme_id from yx_mp_scheme where already_do=1 and app_no=?)";
		db_execut_oneSQL("dbzj.db",sql3,[appNo],null,null);
		var sql4="delete from yx_it_scheme where mp_scheme_id in( select mp_scheme_id from yx_mp_scheme where already_do=1 and app_no=? )";
		db_execut_oneSQL("dbzj.db",sql4,[appNo],null,null);
		var sql5="delete from yx_mt_box where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where already_do=1 and app_no=?)";
		db_execut_oneSQL("dbzj.db",sql5,[appNo],null,null);
		var sql6="delete from yx_irread where meter_scheme_id in ( select id from yx_mt_scheme mts,yx_mp_scheme mps where mts.mp_scheme_id=mps.mp_scheme_id and  mps.already_do=1 and app_no=?)";
		db_execut_oneSQL("dbzj.db",sql6,[appNo],null,null);
		var sql7="delete from device_picture_files where asset_no in (select asset_no from yx_mt_scheme where mp_scheme_id in ( select mp_scheme_id from yx_mp_scheme where already_do=1 and app_no=? ))";
		db_execut_oneSQL("dbzj.db",sql7,[appNo],null,null);
		var sql8="delete from yx_task_list where app_no=?";
		db_execut_oneSQL("dbzj.db",sql8,[appNo],null,null);
	},
	//更改计量点处理状态
	updateMpSchemeType:function(assetNo){
		var sql="update yx_mp_scheme set already_do=1 where mp_scheme_id=(select mp_scheme_id from yx_mt_scheme where asset_no='"+assetNo+"')";
		db_execut_oneSQL("dbzj.db",sql,[],null,null);
	},
	//先装后配功能
	selectNullAmmt:function(){
		//查找为空的电能表
		var sql="select * from yx_mt_scheme where asset_no='' and mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in(select app_no from yx_task_list where  ins_name like '%新装%' and  user_id='"+sessionStorage.user_name+"'))";
		db_execut_oneSQL("dbzj.db",sql,[],nop.getTheNullMt,null);
	},
	updateNewAddMt:function(ID,assetNo,conAssetNo){
		var sql="update yx_mt_scheme set asset_no='"+assetNo+"' where id='"+ID+"'";
		db_execut_oneSQL("dbzj.db",sql,[],function(){
			if(conAssetNo){
				//处理计量箱对应的工单
				var updatedo="update yx_mp_scheme set already_do=1 where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no in (select app_no from yx_task_list where ins_name like '%新装%' and  user_id='" + sessionStorage.user_name + "') and app_no in ( select app_no from yx_mp_scheme where mp_scheme_id in (select mp_scheme_id from yx_mt_box where container_asset_no='"+conAssetNo+"'  limit 1 )))";
				db_execut_oneSQL("dbzj.db", updatedo, [], null,null);
				ns.AddBoxMtAsset(conAssetNo);
			}
			//查询出值之后改变电能表所对应的计量点处理状态
			ns.updateMpSchemeType(assetNo);
			//标记为电表已处理
			ns.UpdateMtFlag(assetNo);
			//将元素添加到页面中
			ns.selectAssetBox(assetNo);
		},null);
	},
	//查询该计量箱所对应的工单下是否所有计量点都处理过
	selectReferInfos:function(mpschemeid){
		//循环查询工单中工单是否全部处理
		var sql="select cons_name from yx_mp_scheme where already_do<>2 and app_no = (select app_no from yx_mp_scheme where mp_scheme_id='"+mpschemeid+"' )"
		db_execut_oneSQL("dbzj.db",sql,[],gotoReferSuccess,null);
	},
	judgeAppNo:function(userid){
		//查询用户当前为批量新装的所有工单app_no
		var sql="  select sum(case when m.already_do=1 then 1 else 0 end) as sumer,count(m.already_do) as counter,t.app_no as app_no from yx_task_list t, yx_mp_scheme m  where t.app_no=m.app_no and t.ins_name like '%新装%' and user_id='"+userid+"' group by t.app_no ";
		db_execut_oneSQL("dbzj.db",sql,[],nop.getAppNoList,null);
	},
	selectUpList:function(appNo){
		sessionStorage.newAppNo=appNo;
		var s1=[],s2=[],s3=[],s4=[],s5=[],s6=[];
		var sql1="select app_no,emp_no,emp_name,ir_date,memo,dept_no,org_no from yx_app_info where app_no = '"+appNo+"'";
		var sql2="select id,mp_scheme_id,asset_no,chg_desc from yx_mt_scheme  where mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no = '"+appNo+"') and mp_scheme_id in(select mp_scheme_id from yx_mp_scheme where already_do=1)";
		var sql3="select b.id,b.container_asset_no,b.container_flag,b.mp_scheme_id,t.longitude,t.latitude from yx_mt_box b ,yx_mp_scheme t where b.mp_scheme_id=t.mp_scheme_id and b.mp_scheme_id in (select mp_scheme_id from yx_mp_scheme where app_no='"+appNo+"') and b.mp_scheme_id in(select mp_scheme_id from yx_mp_scheme where already_do=1)";
		var sql4="select b.id, m.longitude, m.latitude, m.mp_id,floor from yx_mp_scheme m,yx_mt_box b  where m.mp_scheme_id=b.mp_scheme_id and m.already_do=1 and m.mp_scheme_id in(select mp_scheme_id from yx_mp_scheme where app_no='"+appNo+"')";
		db_execut_oneSQL("dbzj.db",sql1,[],function(tx,res){
			var len=res.rows.length,e=res.rows.item;
			if(len>0){
				for(var i=0;i<len;i++){
					s1.push(e(i));
				}
			}
			db_execut_oneSQL("dbzj.db",sql2,[],function(tx,res){
				var len=res.rows.length,e=res.rows.item;
				if(len>0){
					
					for(var i=0;i<len;i++){
						s2.push(e(i));
					}
					
				}
				db_execut_oneSQL("dbzj.db",sql3,[],function(tx,res){
					var len=res.rows.length,e=res.rows.item;
					if(len>0){
						for(var i=0;i<len;i++){
							s3.push(e(i));
						}
						
					}
					db_execut_oneSQL("dbzj.db",sql4,[],function(tx,res){
						var len=res.rows.length,e=res.rows.item;
						if(len>0){
							for(var i=0;i<len;i++){
								s4.push(e(i));
							}
						}
						nop.getAllinfomation(s1,s2,s3,s4);
					},null);
				},null);
			},null);
		},null);
	}
}