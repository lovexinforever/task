/**
主页面index.html业务

 Modified by duanjia 2014/10/22	
*/
//加载平台工具箱
business_com.loadToolKit();
//列表页面滚动
var collectListHeight = plat_common.getHeight()-292+'px';
$('#collect_List').height(collectListHeight);
var collectListScroll = plat_common.iScrollInit('collect_List');
//是否请求过施工单位数据的标示
var querySg_flag = false;
//新建终端档案时需要判断终端资产号还是电表资产号
var focus_index_tc = 0;

//终端资产号获取焦点时
$("#_termial_assetNo_").focus(function(){
	focus_index_tc = 0;
	$("#_deter_assetNo_").parent().removeClass('inputLabss');
	$(this).parent().removeClass('inputLabss').addClass('inputLabss');
});

//电表资产号获取焦点时
$("#_deter_assetNo_").focus(function(){
	focus_index_tc = 1;
	$("#_termial_assetNo_").parent().removeClass('inputLabss');
	$(this).parent().removeClass('inputLabss').addClass('inputLabss');
});

   /**
   *小终端下按钮 
   */
  function ft_key_down(){
  	if($("#addSelectPop").css('display')=='block'){
  		focus_index_tc = 1;
  		$("#_termial_assetNo_").parent().removeClass('inputLabss');
  		$("#_deter_assetNo_").parent().removeClass('inputLabss').addClass('inputLabss');
  	}
  }
  /**
   *小终端上按钮 
   */
  function ft_key_up(){
  	if($("#addSelectPop").css('display')=='block'){
  		focus_index_tc = 0;
  		$("#_deter_assetNo_").parent().removeClass('inputLabss')
  		$("#_termial_assetNo_").parent().removeClass('inputLabss').addClass('inputLabss');
  	}
  }
  /**
   *小终端左按钮 
   */
  function ft_key_left(){
  	if($("#addSelectPop").css('display')=='block'){
  		focus_index_tc = 0;
  		$("#_deter_assetNo_").parent().removeClass('inputLabss')
  		$("#_termial_assetNo_").parent().removeClass('inputLabss').addClass('inputLabss');
  	}
  }
  /**
   *小终端右按钮 
   */
  function ft_key_right(){
  	if($("#addSelectPop").css('display')=='block'){
  		focus_index_tc = 1;
  		$("#_termial_assetNo_").parent().removeClass('inputLabss');
  		$("#_deter_assetNo_").parent().removeClass('inputLabss').addClass('inputLabss');
  	}
  }

//单选
$('#collect_List ul li').live('click', function(){
	if(menuFlag){
		menuFlag = false;
		setTimeout(function(){
			menuFlag = true;
		},300);
		$(this).find(".chk").toggleClass("active");
	}
});

//新建按钮
$('#collectnewBuilt').on('click', function(){
	//每次点开时清空原有值
	var obj = $("#addSelectPop").find('input');
	obj.each(function(){
		$(this).val('');
	});
	$("#builder").next('span').text('');
	$("#addSelectPop").show();
	//每次点开时将焦点置为默认值
	focus_index_tc = 0;
	$("#_deter_assetNo_").parent().removeClass('inputLabss');
	$("#_termial_assetNo_").parent().removeClass('inputLabss').addClass('inputLabss');
	//如果还未获取过施工单位,则获取
	if(!querySg_flag){
		//发送请求获取施工单位
		//getConstructUnitList();
	}
});

//解析施工单位数据
function parseConstructUnitData(dataList){
	querySg_flag = true;
	//"32401":{orgNo:32401,SPECIAL_ORG_NAME:南京供电公司,PARENT_SPECIAL_ORG_ID:32101,work_company_list:[{WORK_COMPANY_ID:111,WORK_COMPANY_NAME:华博}]}
	var len=dataList.length,orgNo_arr = {};
	//对orgNo按照5位,7位分组
	for(var i=0;i<len;i++){
		var temp = dataList[i];
	    if(!orgNo_arr[temp.ORG_NO]){
	    	orgNo_arr[temp.ORG_NO] = {"ORG_NO":temp.ORG_NO,"SPECIAL_ORG_NAME":temp.SPECIAL_ORG_NAME,"PARENT_SPECIAL_ORG_ID":temp.PARENT_SPECIAL_ORG_ID,"work_company_list":[{"WORK_COMPANY_ID":temp.WORK_COMPANY_ID,"WORK_COMPANY_NAME":temp.WORK_COMPANY_NAME}]};
	    }else{
	    	orgNo_arr[temp.ORG_NO].work_company_list.push({"WORK_COMPANY_ID":temp.WORK_COMPANY_ID,"WORK_COMPANY_NAME":temp.WORK_COMPANY_NAME});
	    }
	}
	//orgNo按5位和7位存放
	var orgNo_5=[],orgNo_7=[];
	for(var data in orgNo_arr){
		if(data.length==5){
			orgNo_5.push(orgNo_arr[data]);
		}else{
			orgNo_7.push(orgNo_arr[data]);
		}
	}
	
	var str = '';
	str += '<li>江苏省电力公司</li>';
	str += '<ul>';
	for(var j=0,j_len=orgNo_5.length;j<j_len;j++){
		var temp_j = orgNo_5[j];
		str += '<li>'+temp_j.SPECIAL_ORG_NAME+'</li>';
		str += '<ul>';
		for(var k=0,k_len=orgNo_7.length;k<k_len;k++){
			var temp_k = orgNo_7[k];
			if(temp_k.PARENT_SPECIAL_ORG_ID == temp_j.ORG_NO){
				str += '<li>'+temp_k.SPECIAL_ORG_NAME+'</li>';
				str += '<ul>';
				for(var m=0,m_len=temp_k.work_company_list.length;m<m_len;m++){
					str += '<li class="lastetc" title="'+temp_k.work_company_list[m].WORK_COMPANY_ID+'">'+temp_k.work_company_list[m].WORK_COMPANY_NAME+'</li>';
				}
				str += '</ul>';
			}
		}
		for(var l=0,l_len=temp_j.work_company_list.length;l<l_len;l++){
			str += '<li class="lastetc" title="'+temp_j.work_company_list[l].WORK_COMPANY_ID+'">'+temp_j.work_company_list[l].WORK_COMPANY_NAME+'</li>';
		}
		str += '</ul>';
	}
	str += '</ul>';
	$("#builderPop>ul").html(str);
	setTimeout(function(){
		posilistScroll.refresh();
	},200);
}

//获取施工单位数据
function getConstructUnitList(){
	plat_common.loadDialog("施工单位获取中,请稍后...");
	var s_url = business_com.requestUrl;
	var tid = business_com.tid;
	var org_no = localStorage.ORG_NO;
	var innerPkg = {"ORG_NO":org_no};
	var outerPkg = {"FUN":"09","MOD":"04","PKG_TYPE":"0","USR":localStorage.user_name,"ORG_NO":org_no,"PKG":innerPkg};
	var jsonData = {"FUN":"0000","LEN":plat_common.getLenOfChinese(outerPkg),"MOD":"2029","PKG":outerPkg,"REQ":"0","SSN":localStorage.SSN,"USR":localStorage.user_name,"TID":tid};
	plat_common.ajax_req(s_url,"data",jsonData,function(success){
		try{
			console.log("数据返回为: "+JSON.stringify(success));
			//服务端返回码
			var ret = success.PKG.RET;
			if(ret == '01'){
				//解析数据填充变量
				var dataList= success.PKG.PKG.CONSTRUCT_UNIT_LIST;
				if(null==dataList||dataList.length==0){
					plat_common.loadDialog('查询结果为空!',0);
				}else{
					plat_common.loadDialog('成功获取到施工单位数据!',0);
					parseConstructUnitData(dataList);
				}
			}else if(ret=='14'){
				plat_common.loadDialog(success.PKG.PKG.MSG,0);
			}else{
				console.log("获取施工单位数据,返回码为: "+ret);
				plat_common.loadDialog("获取数据失败,服务端返回数据错误!",0);
			}
		}
		catch(e){
			console.log("获取施工单位数据返回解析出现异常!");
			plat_common.loadDialog("获取施工单位数据失败,服务端返回数据错误!",0);
		}
		setTimeout(function(){
			 plat_common.closeDialog();
		},2000);
	},function(e){
		console.log("获取施工单位数据失败,网络连接错误!");
		plat_common.loadDialog("获取施工单位数据失败,网络连接错误!",0);
		setTimeout(function(){
			 plat_common.closeDialog();
		},2000);
	});
}

//取消按钮
$('#collectAddCancle').on('click', function(){
	$("#addSelectPop").hide();
});

//确定按钮
$('#colectAddOK').on('click', function(){
	var obj = $("#addSelectPop");
	//获取终端资产号
	var terminal_assetNo = obj.find('input:eq(0)').val().trim();
	//获取电表资产号
	var demter_assetNo = obj.find('input:eq(1)').val().trim();
	//获取施工单位
	var sgUnit = $('#builder').next('span').text();
	console.log('sgUnit: '+sgUnit);

	if(terminal_assetNo==''){
		showToast('终端资产号不能为空!');
		return;
	}
	if(!/^(05|11)/.test(terminal_assetNo)){
		showToast('终端资产号必须是05开头或11开头!');
		return;
	}
	if(!/[0-9]{10}/.test(terminal_assetNo)){
		showToast('终端资产号必须是10位数字!');
		return;
	}
	if(sgUnit==''){
		showToast('施工单位不能为空!');
		return;
	}
	//如果是11开头的,3个参数都不能为空
	if(/^(11)/.test(terminal_assetNo)){
		if(demter_assetNo==''){
			showToast('电表资产号不能为空!');
		    return;
		}
		var result = business_com.checkAssetSection(demter_assetNo,demter_assetNo);
		if(result!='success'){
			showToast(result);
			return;
		}
	}else{
		//可以不填,但是填了就得填对
		if(demter_assetNo!=''){
			var result = business_com.checkAssetSection(demter_assetNo,demter_assetNo);
			if(result!='success'){
				showToast(result);
				return;
			}
		}
	}
	$("#addSelectPop").hide();
	//发送请求建档
	buildNewTerminal(terminal_assetNo,demter_assetNo,sgUnit);
});

//终端建档(terminal_assetNo:终端资产号,demter_assetNo:电表资产号,sgUnit:施工单位)
function buildNewTerminal(terminal_assetNo,demter_assetNo,sgUnit){
	plat_common.loadDialog("终端建档中,请稍后...");
	var s_url = business_com.requestUrl;
	var tid = business_com.tid;
	//建档测试写死，完成时需换成实际数据("WORK_COMPANY_ID":'1000000000001825',"SYS_LOGIN_NAME":'NJAdmin')
	var innerPkg = {"TERMINAL_ASSET_NO":terminal_assetNo,"METER_ASSET_NO":demter_assetNo,"WORK_COMPANY_ID":sgUnit,"SYS_LOGIN_NAME":localStorage.user_name,"MACHINE_NO":tid};
	var outerPkg = {"FUN":"02","MOD":"04","PKG_TYPE":"0","USR":localStorage.user_name,"ORG_NO":localStorage.ORG_NO,"PKG":innerPkg};
	var jsonData = {"FUN":"0000","LEN":plat_common.getLenOfChinese(outerPkg),"MOD":"2029","PKG":outerPkg,"REQ":"0","SSN":localStorage.SSN,"USR":localStorage.user_name,"TID":tid};
	plat_common.ajax_req(s_url,"data",jsonData,function(success){
		try{
			console.log("数据返回为: "+JSON.stringify(success));
			//服务端返回码
			var ret = success.PKG.RET;
			if(ret=='01'){
				//获取内层返回码
				var rlt_flag = success.PKG.PKG.RLT_FLAG;
				if(rlt_flag=='1'){
					plat_common.loadDialog(success.PKG.PKG.MSG,0);
					//解析数据填充页面
				    var dataList= success.PKG.PKG.TERMINALINFO;
				    collectMeterObj.terminalInfo = dataList;
				    parsingCollectDataToListHtml(dataList);
				    // $("#collectListTotal").text($("#collect_List li").length);
				}else{
					plat_common.loadDialog(success.PKG.PKG.MSG,0);
					$("#collect_List ul:eq(0)").html('');
					// $("#collectListTotal").text(0);
				}
			}else if(ret=='13'||ret=='14'){
				plat_common.loadDialog(success.PKG.PKG.MSG,0);
			}
			else{
				console.log("终端建档,返回码为: "+ret);
				plat_common.loadDialog("终端建档失败,服务端返回数据错误!",0);
				$("#collect_List ul:eq(0)").html('');
				// $("#collectListTotal").text(0);
			}
		}
		catch(e){
			console.log("终端建档数据返回解析出现异常!");
			plat_common.loadDialog("终端建档失败,服务端返回数据错误!",0);
			$("#collect_List ul:eq(0)").html('');
			// $("#collectListTotal").text(0);
		}
		// $("#collectListNum").text(0);
		setTimeout(function(){
			 plat_common.closeDialog();
			 collectListScroll.refresh();
		},2000);
	},function(e){
		console.log("终端建档失败,网络连接错误!");
		plat_common.loadDialog("终端建档失败,网络连接错误!",0);
		$("#collect_List ul:eq(0)").html('');
		// $("#collectListTotal").text(0);
		// $("#collectListNum").text(0);
		setTimeout(function(){
			 plat_common.closeDialog();
			 collectListScroll.refresh();
		},2000);
	},120*1000);
}

//施工单位弹窗
$('#builder').on('click', function(){
	$("#builderSelectPop").show();
});
//施工单位内容滚动
var posilistScroll = new iScroll('builderPop', {
  onBeforeScrollStart: function(e) {
    var target = e.target;
    while (target.nodeType != 1)
      target = target.parentNode;
    if (target.tagName != 'SELECT' && target.tagName != 'INPUT' && target.tagName != 'TEXTAREA')
      e.preventDefault();
  },
  hideScrollbar: true
});

//施工单位层级点击事件
var note3Flag = true;
$("#builderPop ul li").live('click',function() {
  if (note3Flag) {
    note3Flag = false;
    if (!$(this).hasClass('lastetc')) {
      $(this).toggleClass("shell");
      posilistScroll.refresh();
    }
    $("#builderPop ul li").removeClass("trgleclass");
    $(this).addClass("trgleclass");
    setTimeout(function() {
      note3Flag = true;
    }, 500);
  }
});

//取消按钮
$('#builderCancle').on('click', function(){
	$("#builderSelectPop").hide();
});
//确定按钮
$('#builderOK').on('click', function(){
	//获取选中的施工单位
	var obj = $("#builderPop").find('.trgleclass');
	if(obj.hasClass('lastetc')){
		$('#builder').val(obj.html());
		$('#builder').next('span').text(obj.attr('title'));
		$("#builderSelectPop").hide();
	}else{
		showToast('请选择一个施工单位');
	}
});

//查询弹窗
$('#collectSelect').on('click', function(){
	$("#collectSelectPop").show();
	//每次点开时清空原有查询值
	$("#input_collectNoId").val('');
});
//取消按钮
$('#collectCancle').on('click', function(){
	$("#collectSelectPop").hide();
});
//确定按钮
$('#colectOK').on('click', function(){
	var asset_no = $("#input_collectNoId").val().trim();
	if(asset_no==''){
		showToast("请输入或扫描终端资产号进行查询！");
    	return;
	}
	if(!/^(05|11)/.test(asset_no)){
		showToast('终端资产号必须是05开头或11开头!');
		return;
	}
	if(!/[0-9]{10}/.test(asset_no)){
		showToast('终端资产号必须是10位数字!');
		return;
	}
	$("#collectSelectPop").hide();
	queryCollectAssetNo(asset_no);
});

//查看按钮
$('#collectCheck').on('click', function(){
	var len = $("#collect_List li").find(".chk.active").length;
	if(len==0){
		plat_common.loadDialog("请勾选要查看的终端！","0");
    	setTimeout(function(){plat_common.closeDialog();},2000);
    	return false;
	}
	if(len>1){
		plat_common.loadDialog("一次只能选择一个终端查看！","0");
    	setTimeout(function(){plat_common.closeDialog();},2000);
    	return false;
	}
	var url = './collectCheck.html';
	var pageName = '采集点终端档案'
	goToModel(this, url, pageName, 1);
	touchable = true;
});

//删除按钮
// $('#collectDel').on('click', function(){
// 	//获取页面记录
// 	var objs = $("#collect_List li");
// 	if(objs.length==0){
// 		showToast('当前没有可以删除的记录!');
// 		return;
// 	}
	
// 	//获取页面勾选记录
// 	var objs_checked = objs.find(".chk.active");
// 	if(objs_checked.length==0){
// 		showToast('请勾选需要删除的记录!');
// 		return;
// 	}
	
// 	objs_checked.parent().remove();
// 	//更新记录总数和已选择数
// 	$("#collectListTotal").text($("#collect_List li").length);
	// $("#collectListNum").text($("#collect_List .chk.active").length);
// 	setTimeout(function(){
// 		collectListScroll.refresh();
// 	},200);
// });

//快速下发按钮
$('#quickdown').on('click', function(){
	//获取页面中的记录条数
	var li_len = $("#collect_List li").length;
	if(li_len==0){
		showToast("当前没有可用的终端记录,请先新建或查询!");
		return;
	}
	//获取被勾选的记录条数
	var check_obj_len = $("#collect_List .chk.active").length;
	if(check_obj_len==0){
		showToast("请勾选一条终端记录进行快速下发!");
		return;
	}else if(check_obj_len>1){
		showToast("只能对一条终端记录进行快速下发操作!!");
		return;
	}
	
	var url = '../quickdown/html/quickdown.html';
	var pageName = '快速下发';
	goToModel(this, url, pageName, 1);
});
//快速召测按钮
$('#quickcallmearsure').on('click', function(){
	//获取页面中的记录条数
	var li_len = $("#collect_List li").length;
	if(li_len==0){
		showToast("当前没有可选的终端,请先新建或查询!");
		return;
	}
	//获取被勾选的记录条数
	var check_obj_len = $("#collect_List .chk.active").length;
	if(check_obj_len==0){
		showToast("请勾选一条终端记录进行快速召测!");
		return;
	}else if(check_obj_len>1){
		showToast("只能对一条终端记录进行快速召测操作!!");
		return;
	}
	
	var url = '../quickcallmearsure/html/quickcallmearsure.html';
	var pageName = '快速召测';
	goToModel(this, url, pageName, 1);
});

/***********************************************************************jingyuhai*********************************************/
/**
 *定义采集运维首页页面用到的变量 
 */
document.addEventListener("deviceready",function(){
	$("header").find("p:eq(1)").html(localStorage.area+"-"+localStorage.user_name_str+"-"+localStorage.user_name);
	//进行蓝牙连接
	bluetooth_conn(function(e){
		if(e.msg == 1){
			showToast("设备已连接");
		}else if(e.msg==3){
			showToast("扫描设备未设置");
		}else{
			showToast("连接失败");
		}
	});
},false);
/**
 *蓝牙扫描的回调方法 
 * @param {Object} barcode 扫描的资产编号
 */
function get_barcode(barcode){
	//新建终端档案时扫描条码
	if($("#addSelectPop").css('display')=='block'){
		switch(focus_index_tc){
			case 0:
				//处理终端资产号
				barcode = business_com.handleTerminalNo(barcode);
				$("#_termial_assetNo_").val(barcode);
				break;
			case 1:
				barcode = business_com.dealWithAssetNO(barcode);
				$("#_deter_assetNo_").val(barcode);
				break;
		}
	}else if($("#collectSelectPop").css('display')=='block'){
		//查询终端弹窗
		//处理终端资产号
		barcode = business_com.handleTerminalNo(barcode);
		$("#input_collectNoId").val(barcode);
		$("#collectSelectPop").hide();
	    queryCollectAssetNo(barcode);
	} else if ($('#addQueryBox').css('display') == 'block') {
		//添加挂接电表中的查询电表
		barcode = business_com.dealWithAssetNO(barcode);
		$('#addQueryBox input').val(barcode);
		$('#addQueryBoxOK').click();
	} else if ($('#mearMoveBox').css('display') == 'block') {
		barcode = business_com.handleTerminalNo(barcode);
		$("#toTermialNo").val(barcode);
	}
}
/**
 *通过终端资产编号查询终端列表数据 
 * assetNo:输入或扫描的电表资产号(单个)
 */
function queryCollectAssetNo(assetNo){
	var pkg = {"MOD":"04","FUN":"01","PKG_TYPE":"0","USR":localStorage.user_name,"ORG_NO":localStorage.ORG_NO,"PKG":{"TERMINAL_ASSET_NO":assetNo}};
	var data = jointAjaxData(pkg);
	plat_common.loadDialog("终端信息查询中...");
	plat_common.ajax_req(business_com.requestUrl,"data",data,function(result){
		try{
			console.log("数据返回为: "+JSON.stringify(result));
			//后台返回码
			var ret = result.PKG.RET;
			if(ret == "01"){
				//返回的数据集(虽然是数组,但是里面只有一条记录)
				var dataList = result.PKG.PKG.TERMINAL_INFO_LIST;
				collectMeterObj.terminalInfo = dataList;
				if(null==dataList || dataList.length==0){
					plat_common.loadDialog("查询结果为空！","0");
					$("#collect_List ul:eq(0)").html('');
					// $("#collectListTotal").text(0);
				}else{
					parsingCollectDataToListHtml(dataList);
					$("#collectListTotal").text($("#collect_List li").length);
				}
			}else if(ret == "14"){
				var result_msg = '';
				if(result.PKG.PKG.MSG){
					result_msg = result.PKG.PKG.MSG;
				}else{
					result_msg = '查询终端信息失败!';
				}
				plat_common.loadDialog(result_msg,"0");
				$("#collect_List ul:eq(0)").html('');
				// $("#collectListTotal").text(0);
			}else{
				plat_common.loadDialog("查询失败,服务器返回数据错误！","0");
				$("#collect_List ul:eq(0)").html('');
				// $("#collectListTotal").text(0);
			}
		}catch(e){
			plat_common.loadDialog("查询失败,服务器返回数据异常！","0");
			$("#collect_List ul:eq(0)").html('');
			// $("#collectListTotal").text(0);
		}
		// $("#collectListNum").text(0);
		setTimeout(function(){plat_common.closeDialog();},2000);
		setTimeout(function(){
			collectListScroll.refresh();
		},200);
	},function(e){
		console.log('数据请求失败,返回为：'+JSON.stringify(e));
		plat_common.loadDialog("查询失败,网络连接错误！","0");
    	setTimeout(function(){plat_common.closeDialog();},2000);
    	$("#collect_List ul:eq(0)").html('');
    	// $("#collectListTotal").text(0);
    	// $("#collectListNum").text(0);
    	setTimeout(function(){
			collectListScroll.refresh();
		},200);
	},120*1000);
}

/**
 * 拼接查询的终端列表信息到页面中
 */
function parsingCollectDataToListHtml(dataList){
	var len = dataList.length;
	var htmlStr = '';
	for(var i=0;i<len;i++){
		var temp = dataList[i];
		htmlStr +='<li class="float">'+
                '<div class="chk flex"></div>'+
                '<div class="flex info">'+
                  '<div class="float">'+
                    '<p class="flex float"><span>终端资产号：</span><span class="cls_TerminalAssetNo">'+temp.TERMINAL_ASSET_NO+'</span></p>'+
                    '<p class="flex float"><span>在线状态：</span><span>'+temp.ONLINE_STATUS+'</span></p>'+
                    //SIM卡的号码
                    '<p style="display:none"><span class="GPRS_CODE">'+temp.GPRS_CODE+'</span>'+
                      //终端地址
                      '<span class="TERMINAL_ADDR">'+temp.TERMINAL_ADDR+'</span>'+
                      //采集点编号
                      '<span class="cls_CpNo">'+temp.CP_NO+'</span>'+
                      //终端类型
                      '<span class="TERMINAL_TYPE_CODE">'+temp.TERMINAL_TYPE_CODE+'</span>'+
                    '</p>'+
                  '</div>'+
                  '<div class="float">'+
                    '<p class="flex float"><span>运行状态：</span><span class="cls_TerminalRunState">'+temp.RUN_STATUS_CODE+'</span></p>'+
                    '<p class="flex float"><span>终端型号：</span><span class="ID">'+temp.ID+'</span></p>'+
                  '</div>'+
                  '<div class="float">'+
                    '<div class="flex float"><span>安装位置：</span><span class="TERMINAL_LOC">'+temp.TERMINAL_LOC+'</span></div>'+
                  '</div>'+
                '</div>'+
              '</li>';
	}
	$("#collect_List ul:eq(0)").html(htmlStr);
}
/**
*拼接请求服务器的参数
*@param pkg  业务数据
*/
function jointAjaxData(pkg){
  	var len = plat_common.getLenOfChinese(JSON.stringify(pkg));
  	return {"FUN":"0000","LEN":""+len+"","MOD":"2029","PKG":pkg,"REQ":"0","SSN":localStorage.SSN,"USR":localStorage.user_name,"TID":localStorage.TID};
}

//屏幕大小变化（华为底部）
window.onresize = function(){
	ReSize();
}
function ReSize(){
	var name = CurrFileName.get(collectPage);
	switch(name){
		//采集点终端档案
		case 'collectCheck':
			$("#collect_Detail").height(plat_common.getHeight() - 164);
			collectCheckScroll.refresh;
			$("#collectsubmenu").height(plat_common.getHeight());
			leftMenuScroll.refresh;
		break;
		//快速下发
		case 'quickdown':
			$("#down_List").height(plat_common.getHeight()-203);
			downObj.downList.refresh;
		break;
		//快速召测
		case 'quickcallmearsure':
			$("#call_List").height(plat_common.getHeight()-203);
			downObj.downList.refresh;
		break;
		//添加电表
		case 'mearsureadd':
			$("#add_List").height(plat_common.getHeight() - 203);
			addObj.addList.refresh;
		break;
		//电表测量点
		case 'mearsurepoint':
			$("#mear_List").height(plat_common.getHeight() - 202);
			mearObj.mearList.refresh;
			$("#collectsubmenu").height(plat_common.getHeight());
			leftMenuScroll.refresh;
		break;
		//电表档案信息页面
		case 'ammeter':
			$("#ammeter_Detail").height(plat_common.getHeight() - 164);
			ammeterScroll.refresh;
			$("#collectsubmenu").height(plat_common.getHeight());
			leftMenuScroll.refresh;
		break;
		default :
			var homeBack = $('#homeBack').css('display');
			if(homeBack!='none'){//index
				$('#collect_List').height(plat_common.getHeight()-292);
				collectListScroll.refresh;
			}
		break;
	}
}

//时钟召测
$("#clockTest").click(function(){
	//获取页面中的记录条数
	var li_len = $("#collect_List li").length;
	if(li_len==0){
		showToast("当前没有可选的终端,请先新建或查询!");
		return;
	}
	//获取被勾选的记录条数
	var check_objs = $("#collect_List .chk.active"),check_obj_len=check_objs.length;
	if(check_obj_len==0){
		showToast("请勾选一条终端记录进行时钟召测!");
		return;
	}else if(check_obj_len>1){
		showToast("只能对一条终端记录进行时钟召测!");
		return;
	}
	
	plat_common.loadDialog("时钟召测中,请稍后...");
	var s_url = business_com.requestUrl;
	var tid = business_com.tid;
	var org_no = localStorage.ORG_NO;
	var innerPkg = {"TERMINAL_ASSET_NO":check_objs.parents('li').find('.cls_TerminalAssetNo').text(),"SYS_LOGIN_NAME":localStorage.user_name,"MACHINE_NO":tid};
	var outerPkg = {"FUN":"13","MOD":"04","PKG_TYPE":"0","USR":localStorage.user_name,"ORG_NO":localStorage.ORG_NO,"PKG":innerPkg};
	var jsonData = {"FUN":"0000","LEN":plat_common.getLenOfChinese(outerPkg),"MOD":"2029","PKG":outerPkg,"REQ":"0","SSN":localStorage.SSN,"USR":localStorage.user_name,"TID":tid};
	plat_common.ajax_req(s_url,"data",jsonData,function(success){
		try{
			console.log("数据返回为: "+JSON.stringify(success));
			//服务端返回码
			var ret = success.PKG.RET;
			if(ret == '01'){
				var rlt_flag = success.PKG.PKG.RLT_FLAG;
				//成功
				if(rlt_flag=='1'){
					//召测成功,将时间展示一下给用户
					plat_common.loadDialog(success.PKG.PKG.TMNL_TIME,0);
				}else{
				   //失败
				   plat_common.loadDialog(success.PKG.PKG.MSG,0);
				}
			}else if(ret=='14'){
				plat_common.loadDialog(success.PKG.PKG.MSG,0);
			}else{
				console.log("时钟召测,返回码为: "+ret);
				plat_common.loadDialog("时钟召测失败,服务端返回数据错误!",0);
			}
		}
		catch(e){
			console.log("时钟召测数据返回解析出现异常!");
			plat_common.loadDialog("时钟召测失败,服务端返回数据错误!",0);
		}
		setTimeout(function(){
			 plat_common.closeDialog();
		},3000);
	},function(e){
		console.log("时钟召测失败,网络连接错误!");
		plat_common.loadDialog("时钟召测失败,网络连接错误!",0);
		setTimeout(function(){
			 plat_common.closeDialog();
		},2000);
	});
});


//终端检测
$("#terminalCheck").click(function(){
	//获取页面中的记录条数
	var li_len = $("#collect_List li").length;
	if(li_len==0){
		showToast("当前没有可选的终端,请先新建或查询!");
		return;
	}
	//获取被勾选的记录条数
	var check_objs = $("#collect_List .chk.active"),check_obj_len=check_objs.length;
	if(check_obj_len==0){
		showToast("请勾选一条终端记录进行终端检测!");
		return;
	}else if(check_obj_len>1){
		showToast("只能对一条终端记录进行终端检测!");
		return;
	}
	
	plat_common.loadDialog("终端检测中,请稍后...");
	var s_url = business_com.requestUrl;
	var tid = business_com.tid;
	var org_no = localStorage.ORG_NO;
	var innerPkg = {"TERMINAL_ASSET_NO":check_objs.parents('li').find('.cls_TerminalAssetNo').text(),"SYS_LOGIN_NAME":localStorage.user_name,"MACHINE_NO":tid};
	var outerPkg = {"FUN":"14","MOD":"04","PKG_TYPE":"0","USR":localStorage.user_name,"ORG_NO":localStorage.ORG_NO,"PKG":innerPkg};
	var jsonData = {"FUN":"0000","LEN":plat_common.getLenOfChinese(outerPkg),"MOD":"2029","PKG":outerPkg,"REQ":"0","SSN":localStorage.SSN,"USR":localStorage.user_name,"TID":tid};
	plat_common.ajax_req(s_url,"data",jsonData,function(success){
		try{
			console.log("数据返回为: "+JSON.stringify(success));
			//服务端返回码
			var ret = success.PKG.RET;
			if(ret == '01'){
				var rlt_flag = success.PKG.PKG.RLT_FLAG;
				//成功
				if(rlt_flag=='1'){
					plat_common.loadDialog("检测成功,结果为:<br/>"+"生产厂家："+success.PKG.PKG.FACTORY+"<br/>主程序版本号："+success.PKG.PKG.MAINVERSION+"<br/>硬件版本号："+success.PKG.PKG.HARDVERSON+"<br/>信号值："+success.PKG.PKG.SIGNAL+"<br/>信号强度："+success.PKG.PKG.PASERDBM,0);
				}else{
				   //失败
				   plat_common.loadDialog(success.PKG.PKG.MSG,0);
				}
			}else if(ret=='14'){
				plat_common.loadDialog(success.PKG.PKG.MSG,0);
			}else{
				console.log("终端检测,返回码为: "+ret);
				plat_common.loadDialog("终端检测失败,服务端返回数据错误!",0);
			}
		}
		catch(e){
			console.log("终端检测数据返回解析出现异常!");
			plat_common.loadDialog("终端检测失败,服务端返回数据错误!",0);
		}
		setTimeout(function(){
			 plat_common.closeDialog();
		},3000);
	},function(e){
		console.log("终端检测失败,网络连接错误!");
		plat_common.loadDialog("终端检测失败,网络连接错误!",0);
		setTimeout(function(){
			 plat_common.closeDialog();
		},2000);
	});
});


//终端对时
$("#checkTime").click(function(){
	//获取页面中的记录条数
	var li_len = $("#collect_List li").length;
	if(li_len==0){
		showToast("当前没有可选的终端,请先新建或查询!");
		return;
	}
	//获取被勾选的记录条数
	var check_objs = $("#collect_List .chk.active"),check_obj_len=check_objs.length;
	if(check_obj_len==0){
		showToast("请勾选一条终端记录进行终端对时!");
		return;
	}else if(check_obj_len>1){
		showToast("只能对一条终端记录进行终端对时!");
		return;
	}
	
	plat_common.loadDialog("终端对时中,请稍后...");
	var s_url = business_com.requestUrl;
	var tid = business_com.tid;
	var org_no = localStorage.ORG_NO;
	var innerPkg = {"TERMINAL_ASSET_NO":check_objs.parents('li').find('.cls_TerminalAssetNo').text(),"SYS_LOGIN_NAME":localStorage.user_name,"MACHINE_NO":tid};
	var outerPkg = {"FUN":"15","MOD":"04","PKG_TYPE":"0","USR":localStorage.user_name,"ORG_NO":localStorage.ORG_NO,"PKG":innerPkg};
	var jsonData = {"FUN":"0000","LEN":plat_common.getLenOfChinese(outerPkg),"MOD":"2029","PKG":outerPkg,"REQ":"0","SSN":localStorage.SSN,"USR":localStorage.user_name,"TID":tid};
	plat_common.ajax_req(s_url,"data",jsonData,function(success){
		try{
			console.log("数据返回为: "+JSON.stringify(success));
			//服务端返回码
			var ret = success.PKG.RET;
			if(ret == '01'){
				var rlt_flag = success.PKG.PKG.RLT_FLAG;
				//成功
				if(rlt_flag=='1'){
					plat_common.loadDialog(success.PKG.PKG.MSG,0);
				}else{
				   //失败
				   plat_common.loadDialog(success.PKG.PKG.MSG,0);
				}
			}else if(ret=='14'){
				plat_common.loadDialog(success.PKG.PKG.MSG,0);
			}else{
				console.log("终端对时,返回码为: "+ret);
				plat_common.loadDialog("终端对时失败,服务端返回数据错误!",0);
			}
		}
		catch(e){
			console.log("终端对时数据返回解析出现异常!");
			plat_common.loadDialog("终端对时失败,服务端返回数据错误!",0);
		}
		setTimeout(function(){
			 plat_common.closeDialog();
		},2000);
	},function(e){
		console.log("终端对时失败,网络连接错误!");
		plat_common.loadDialog("终端对时失败,网络连接错误!",0);
		setTimeout(function(){
			 plat_common.closeDialog();
		},2000);
	});
});
