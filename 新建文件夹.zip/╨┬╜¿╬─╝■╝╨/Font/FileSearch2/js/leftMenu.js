/**
控制左侧菜单业务
*/
//注册滑动事件
leftTouch(document.getElementById('maincontent'));
//控制是否可被滑动
var touchable = false;
//菜单是否打开true表示打开
var menuOpen = false;
//标记从添加电表页面返回
var backRefresh = false;
//纵向滑动
var leftMenuHeight = plat_common.getHeight() + 'px';
$("#collectsubmenu").height(leftMenuHeight).css('position', 'relative');
leftMenuScroll = plat_common.iScrollInit('collectsubmenu', {
  hScrollbar: false
});

//菜单图表点击事件
$("#leftMenu").on('click', function() {
  leftMenuOpen();
});

//打开或关闭菜单
function leftMenuOpen() {
  if (menuOpen) {
    $("#collectleftmenu").css('width', 0);
    menuOpen = false;
  } else {
    $("#collectleftmenu").css('width', '360px');
    $('#shadow').css('left', '-14px');
    menuOpen = true;
  }
}
//点击一级菜单+号展开了关闭效果
$('#collectsubmenu .leftmenuliImg').on('click', function(e) {
  e.stopPropagation();
  if (menuFlag) {
    bubble();
    var li = $(this).parent('li');
    var div = li.next();
    var ul = div.next();
    var state = div.css('display');
    var ulH = ul.height();
    if (ulH == 0) {
      return;
    }
    if (state == 'block') {
      $(this).css('background', 'url(../../images/menu_li.png) no-repeat 23px 0px');
      ul.prev('li').css('border-bottom', '0px solid #36404e');
      ul.css('-webkit-transition', 'all ease 0ms').height(ulH);
      setTimeout(function() {
        ul.css('-webkit-transition', 'all ease 500ms').height(0);
      });
      setTimeout(function() {
        ul.css('display', 'none');
        div.css('display', 'none');
        ul.height('');
      }, 500);
    } else {
      $(this).css('background', 'url(../../images/menu_li2.png) no-repeat 23px 0px');
      div.css('display', 'block');
      ul.height(0);
      ul.css('display', 'block');
      setTimeout(function() {
        ul.height(ulH);
      });
      setTimeout(function() {
        ul.prev('li').css('border-bottom', '1px solid #36404e');
      }, 500);
    }
  }
});

/*
左侧菜单触摸事件
 */
function leftTouch(touchObj) {
  var moveStartX = 0,
    moveStartY = 0,
    moveEndX = 0,
    moveEndY = 0,
    moveDistance = 0,
    shadowDistance = 0;
  var currentWidth = 0;
  touchObj.addEventListener('touchstart', function(e) {
    e.stopPropagation();
    preventTouch();
    if (!touchable) return;
    currentWidth = $('#collectleftmenu').width();
    moveStartX = e.touches[0].pageX;
    moveStartY = e.touches[0].pageY;
  }, false);
  touchObj.addEventListener('touchmove', function(e) {
    e.stopPropagation();
    preventTouch();
    if (!touchable) return;
    moveEndX = e.touches[0].pageX;
    moveEndY = e.touches[0].pageY;
    //横向滑动
    if (Math.abs(moveEndX - moveStartX) > Math.abs(moveEndY - moveStartY)) {
      moveDistance = moveEndX - moveStartX + currentWidth;
      moveDistance < 0 ? 0 : moveDistance;
      $('#collectleftmenu').css({
        '-webkit-transition': 'all ease 0ms',
        'width': moveDistance + 'px'
      });
      shadowDistance = 375 - moveDistance;
      if (shadowDistance <= 0) {
        shadowDistance = Math.abs(shadowDistance);
        $('#shadow').css({
          '-webkit-transition': 'all ease 0ms',
          'left': shadowDistance + 'px'
        });
      } else {
        $('#shadow').css({
          '-webkit-transition': 'all ease 0ms',
          'left': -shadowDistance + 'px'
        });
      }
    }
  }, false);
  touchObj.addEventListener('touchend', function(e) {
    e.stopPropagation();
    preventTouch();
    if (!touchable) return;
    if (moveDistance < 180) {
      $('#collectleftmenu').css({
        '-webkit-transition': 'all ease 500ms',
        'width': '0px'
      });
      menuOpen = false;
    } else {
      $('#collectleftmenu').css({
        '-webkit-transition': 'all ease 500ms',
        'width': '360px'
      });
      $('#shadow').css({
        '-webkit-transition': 'all ease 500ms',
        'left': '-14px'
      });
      menuOpen = true;
    }
    setTimeout(function() {
      $('#collectleftmenu').css({
        '-webkit-transition': 'all ease 500ms'
      });
      $('#shadow').css({
        '-webkit-transition': 'all ease 500ms'
      });
    }, 1000);
    moveStartX = 0;
    moveStartY = 0;
    moveEndX = 0;
    moveEndY = 0;
    moveDistance = 0;
    shadowDistance = 0;
  }, false);
};

function preventTouch() {
  window.addEventListener('touchstart', clearTouch, false);
  window.addEventListener('touchmove', clearTouch, false);
  window.addEventListener('touchend', clearTouch, false);
};
function clearTouch() {}
/*
菜单地址按钮
 */
$('#collectsubmenu .trangle1').on('click', function(e) {
  e.stopPropagation();
  var collect_Detail_Page = $('#collect_Detail').parents('.moveContent');
  var mear_List_Page = $('#mear_List').parents('.moveContent');
  var ammeter_Detail_Page = $('#ammeter_Detail').parents('.moveContent');
  leftMenuOpen();
  $('#collectsubmenu ul ul >li').removeClass('activeli');
  setTimeout(function() {
    if (collect_Detail_Page.css('display') == 'none') {
      collect_Detail_Page.css('display', 'block');
      setTimeout(function() {
        mear_List_Page.addClass('stayOnRight');
        ammeter_Detail_Page.addClass('stayOnRight');
        collect_Detail_Page.removeClass('moveToleft')
        setTimeout(function() {
          mear_List_Page.remove();
          ammeter_Detail_Page.remove();
        }, 500);
      }, 500);
    }
  }, 500);
});
/*
  电表测量点
 */
$('#collectsubmenu .activeimg').on('click', function(e) {
  e.stopPropagation();
  var currentPage = $('.moveContent:last');
  var url = '../mearsurepoint/html/mearsurepoint.html';
  var pageName = '电表测量点';
  $("#collectleftmenu").css('width', 0);
  $('#collectsubmenu ul ul >li').removeClass('activeli');
  menuOpen = false;
  setTimeout(function() {
    $('#ammeter_Detail').parents('.moveContent').addClass('moveToleft');
    if ($('#mear_List').length == 0) {
      currentPage.after('<div class="moveContent stayOnRight"></div>');
      currentPage.next().load(url, function() {
				delete CurrFileName[collectPage];
				CurrFileName.add(collectPage,url.slice(url.lastIndexOf('/')+1,url.lastIndexOf('.')));
        $("header").find("p:first").html(pageName);
        currentPage.addClass('moveToleft');
        currentPage.next().removeClass('stayOnRight');
        setTimeout(function() {
          $('.moveContent:last').prev().css('display', 'none');
        }, 500);
				ReSize();
      });
    } else {
      $('.moveContent:last').prev().css('display', 'none');
    }
    setTimeout(function() {
      $('#ammeter_Detail').parents('.moveContent').remove();
    }, 500);
  }, 500)
});
/*
电表详细页
 */
$('#collectsubmenu ul ul >li').live('click', function(e) {
  e.stopPropagation();
  $(this).siblings().removeClass('activeli').end().addClass('activeli');
  var curr_asset_no = $(this).find('span').html();
  var index = checkIndex(collectMeterObj.MearsurePointInfo, 'ASSET_NO', curr_asset_no);
  var currentPage = $('.moveContent:last');
  var url = '../mearsurepoint/html/ammeter.html';
  var pageName = '电表档案信息';
  leftMenuOpen();
  setTimeout(function() {
    $('#mear_List').parents('.moveContent').addClass('moveToleft');
    if ($('#ammeter_Detail').length == 0) {
      currentPage.after('<div class="moveContent stayOnRight"></div>');
      currentPage.next().load(url, function() {
				delete CurrFileName[collectPage];
				CurrFileName.add(collectPage,url.slice(url.lastIndexOf('/')+1,url.lastIndexOf('.')));
        $("header").find("p:first").html(pageName);
        currentPage.addClass('moveToleft');
        currentPage.next().removeClass('stayOnRight');
        fillMeterInfo(collectMeterObj.MearsurePointInfo[index]);
        setTimeout(function() {
          $('.moveContent:last').prev().css('display', 'none');
        }, 500);
				ReSize();
      });
    } else {
      fillMeterInfo(collectMeterObj.MearsurePointInfo[index]);
    }
    setTimeout(function() {
      $('#mear_List').parents('.moveContent').remove();
    }, 500);
  }, 500);
});
/*
右侧返回按钮
 */
$('#headBackRight').on('click', function(e) {
  e.stopPropagation();
  var lastMoveContent = $('.moveContent:last');
  lastMoveContent.prev().css('display', 'block');
  setTimeout(function() {
    lastMoveContent.addClass('stayOnRight');
    lastMoveContent.prev().removeClass('moveToleft');
    $('#collectsubmenu ul ul >li').removeClass('activeli');
    setTimeout(function() {
      lastMoveContent.remove();
      if ($('.moveContent').length == 1) {
        $("header").find("p:first").html('采集运维');
        $('#headBackRight').css('display', 'none');
        $('#leftMenu').css('display', 'none');
        $('#homeBack').css('display', 'inline-block');
        touchable = false;
				collectPage = 0;
				delete CurrFileName[collectPage+1];
      } else {
        $("header").find("p:first").html('采集点终端档案');
				delete CurrFileName[collectPage];
				CurrFileName.add(collectPage,'collectCheck');
      }
			ReSize();
    }, 500);
  }, 100);
	
});
