/*
  采集点终端档案页面
 */

//电表信息对象
var collectMeterObj = {
  METER_INFO_LIST_TOTAL: [], //添加挂接中查询的电表集合
  MearsurePointInfo: [] //根据终端资产号查询到挂接在此终端下的电表集合
};

/*
将终端档案查询结果填充
 */
function htmlCollectMeterFilesDetail(terminalInfo) {
  var tude = terminalInfo.TUDE == '' ? ['', ''] : terminalInfo.TUDE.split(', '),
    newHtml = '采集点编号：' + terminalInfo.CP_NO + '<br />' +
    '终端资产号：' + terminalInfo.TERMINAL_ASSET_NO + '<br />' +
    '终端地址：' + terminalInfo.TERMINAL_ADDR + '<br />' +
    '所属部门：' + terminalInfo.DEPT_NO + '<br />' +
    '终端型号：' + terminalInfo.ID + '<br />' +
    '终端厂家：' + terminalInfo.FACTORY_CODE + '<br />' +
    'SIM卡号：' + terminalInfo.GPRS_CODE + '<br />' +
    '运行状态：' + terminalInfo.RUN_STATUS_CODE + '<br />' +
    '通讯规约：' + terminalInfo.PROTOCOLTYPECODE + '<br />' +
    '施工单位：' + terminalInfo.CHK_REMARK + '<br />' +
    '信道名称：' + terminalInfo.CHANNELNAME + '<br />' +
    '终端安装位置：' + terminalInfo.TERMINAL_LOC + '<br />' +
    '创建日期：' + terminalInfo.CHK_DATE + '<br />' +
    'GPS经度：' + tude[0] + '<br />' +
    'GPS纬度：' + tude[1] + '<br />' +
    '备注信息：' + terminalInfo.REMARK_DET;
  $('#collectsubmenu').find('.trangle1').html(terminalInfo.TERMINAL_LOC);
  $('#collect_Detail .collect_DetailInfo').html(newHtml);
  collectCheckScroll.refresh();
};

/*
电表测量点-查询-终端资产编号
 */
function queryMearsurePoint(TERMINAL_ASSET_NO) {
  pkgPkg = {
    'TERMINAL_ASSET_NO': TERMINAL_ASSET_NO
  };
  paramPkg = {
    "MOD": "04",
    "FUN": '03',
    "PKG_TYPE": "0",
    "USR": localStorage.user_name,
    "ORG_NO": localStorage.ORG_NO,
    "PKG": pkgPkg
  };
  param = {
    "FUN": "0000",
    "LEN": plat_common.getLenOfChinese(paramPkg),
    "MOD": "2029",
    "REQ": "0",
    "SSN": localStorage.SSN,
    "USR": localStorage.user_name,
    "TID": business_com.tid,
    "PKG": paramPkg
  };

  if (backRefresh) {
    plat_common.loadDialog("页面刷新中...", 1);
    collectMeterObj.MearsurePointInfo = [];
  } else {
    plat_common.loadDialog("查询挂接电表数据中...", 1);
  }
  plat_common.ajax_req(business_com.requestUrl, "data", param, function(result) {
    try {
      console.log("电表测量点 服务器返回:" + JSON.stringify(result));
      plat_common.closeDialog();
      var result_list = result.PKG.PKG.METER_INFO_LIST;
      collectMeterObj.MearsurePointInfo = result_list;
      if (result.PKG.RET == "01") {
        if (null == result_list || result_list.length == 0) {
          plat_common.loadDialog("当前终端下未挂接电表！", 0);
          setTimeout(function() {
            plat_common.closeDialog();
          }, 2000);
        }
        if (backRefresh) {
          fillMenuMearsurePoint(collectMeterObj.MearsurePointInfo);
        }
        backRefresh = false;
        $('#mearsurepoint').siblings('ul').html('');
        htmlLeftMenuMearsurePoint(collectMeterObj.MearsurePointInfo);
      } else {
        backRefresh = false;
        plat_common.loadDialog("获取数据失败!", 0);
        setTimeout(function() {
          plat_common.closeDialog();
        }, 2000);
      }
    } catch (e) {
      backRefresh = false;
      plat_common.loadDialog("获取数据失败!", 0);
      setTimeout(function() {
        plat_common.closeDialog();
      }, 2000);
    }
  }, function(err) {
    backRefresh = false;
    plat_common.loadDialog("网络异常，获取数据失败！", 0);
    setTimeout(function() {
      plat_common.closeDialog();
    }, 2000);
  }, 30 * 1000);
};
/*
左侧菜单填充电能表
 */
function htmlLeftMenuMearsurePoint(meterList) {
  var newHtml = '';
  var l = meterList.length;
  if (l == 0) {
    $('.leftmenuDiv').css('display', 'none');
    $('#leftmenuliImg').css('background', 'url(../../images/menu_li.png) no-repeat 23px 0px');
  } else {
    $('.leftmenuDiv').css('display', 'block');
    $('#leftmenuliImg').css('background', 'url(../../images/menu_li2.png) no-repeat 23px 0px');
    for (var i = 0; i < l; i++) {
      newHtml += '<li>电能表  ' + meterList[i].ASSET_NO + '<span style="display:none;">' + meterList[i].ASSET_NO + '</span></li>'
    }
  }
  $('#mearsurepoint').siblings('ul').html(newHtml);
  $('#leftmenuliImg').next().html('电表测量点（挂接：' + l + '块电表）')
  leftMenuScroll.refresh();
};
/*
右侧填充电能表测量点信息
 */
function fillMenuMearsurePoint(mearList) {
  var newHtml = '';
  var l = mearList.length;
  for (var i = 0; i < l; i++) {
    newHtml += '<li class="float" index=' + mearList[i].METER_INDEX + '>' +
      '<div class="chk flex"></div>' +
      '<div class="flex info">' +
      '<div class="float">' +
      '<p class="flex float"><span>电表局编号：</span><span>' + mearList[i].ASSET_NO + '</span></p>' +
      '<p class="flex float"><span>所属台区：</span><span>' + mearList[i].TG_NO + '</span></p>' +
      '</div>' +
      '<div class="float">' +
      '<p class="flex float"><span>抄表状态：</span><span>' + mearList[i].LAST_STATUS + '</span></p>' +
      '<p class="flex float"><span>电表类别：</span><span>' + mearList[i].SORT_CODE + '</span></p>' +
      '</div>' +
      '</div>' +
      '</li>';
  };
  $('#mear_List ul').html(newHtml);
  mearObj.mearList.refresh();
};
/*
右侧填充电能表测量点信息--点击显示更多
 */
function fillMoreMenuMearsurePoint(meter) {
  var newHtml = '终端资产号：' + meter.TERMINAL_ASSET_NO + '<br />' +
    '点号：' + meter.MP_INDEX + '<br />' +
    '电能表序号：' + meter.METER_INDEX + '<br />' +
    '采集点编号：' + meter.CP_NO + '<br />' +
    '采集点对象ID：' + meter.COLL_OBJ_ID + '<br />' +
    '电表局编号：' + meter.ASSET_NO + '<br />' +
    '抄表状态：' + meter.LAST_STATUS + '<br />' +
    '电表类别：' + meter.SORT_CODE + '<br />' +
    '所属台区：' + meter.TG_NO + '<br />' +
    '抄表段编号：' + meter.MR_SECT_NO + '<br />' +
    '用电地址：' + meter.ELEC_ADDR + '<br />' +
    '用户编号：' + meter.CONS_NO + '<br />' +
    '用户名称：' + meter.CONS_NAME + '<br />' +
    '安装日期：' + meter.INST_DATE + '<br />' +
    '电表厂商：' + meter.MANUFACTURER + '<br />' +
    '电表标识：' + meter.METER_ID + '<br />' +
    '电表状态：' + get_Send_Status_Value(meter.SEND_STATUS) + '<br />' +
    '通信规约类型：' + meter.PROTOCOL_TYPE + '<br />' +
    '通信速率：' + meter.COMM_RATE + '<br />' +
    '端口号：' + meter.COMM_PORT + '<br />' +
    '通信地址：' + meter.COMM_ADDR + '<br />' +
    '有功电能示值的整数位个数：' + meter.INTEGER_NUM + '<br />' +
    '有功电能示值的小数位个数：' + meter.DECIMAL_NUM + '<br />' +
    '大类号：' + BIG_TYPE_NO_OBJ[meter.BIG_TYPE_NO] + '<br />' +
    '小类号：' + SMALL_TYPE_NO_OBJ['' + meter.BIG_TYPE_NO + meter.SMALL_TYPE_NO] + '<br />' +
    '电能费率个数：' + meter.TARIFF_NUM + '<br />';
  $('#mearLookPop .LookDetail').html(newHtml);
}
/*
添加按钮-里面的查询
 */
function queryMeterFromAddPage(METER_ASSET_NO) {
  pkgPkg = {
    'METER_ASSET_NO': METER_ASSET_NO
  };
  paramPkg = {
    "MOD": "04",
    "FUN": '12',
    "PKG_TYPE": "0",
    "USR": localStorage.user_name,
    "ORG_NO": localStorage.ORG_NO,
    "PKG": pkgPkg
  };
  param = {
    "FUN": "0000",
    "LEN": plat_common.getLenOfChinese(paramPkg),
    "MOD": "2029",
    "PKG": paramPkg,
    "REQ": "0",
    "SSN": localStorage.SSN,
    "USR": localStorage.user_name,
    "TID": business_com.tid
  };

  plat_common.loadDialog("请求数据中...", 1);
  plat_common.ajax_req(business_com.requestUrl, "data", param, function(result) {
    try {
      console.log("添加按钮-里面的查询 服务器返回:" + JSON.stringify(result));
      plat_common.closeDialog();
      var result_list = result.PKG.PKG.METER_INFO_LIST;
      if (result.PKG.RET == "01") {
        if (null == result_list || result_list.length == 0) {
          plat_common.loadDialog("查询结果为空！", 0);
          setTimeout(function() {
            plat_common.closeDialog();
          }, 2000);
        } else {
          collectMeterObj.METER_INFO_LIST = result_list;
          fillMeterFromAddPage(collectMeterObj.METER_INFO_LIST);
          collectMeterObj.METER_INFO_LIST_TOTAL.push(collectMeterObj.METER_INFO_LIST[0]);
        }
      } else {
        plat_common.loadDialog("获取数据失败!", 0);
        setTimeout(function() {
          plat_common.closeDialog();
        }, 2000);
      }
    } catch (e) {
      plat_common.loadDialog("获取数据失败!", 0);
      setTimeout(function() {
        plat_common.closeDialog();
      }, 2000);
    }
  }, function(err) {
    plat_common.loadDialog("网络异常，获取数据失败！", 0);
    setTimeout(function() {
      plat_common.closeDialog();
    }, 2000);
  }, 30 * 1000);
};
/*
填充查询的电表列表
 */
function fillMeterFromAddPage(mearList) {
  var newHtml = '';
  var l = mearList.length;
  for (var i = 0; i < l; i++) {
    var gjMeters = $('#mear_List li').find('span:eq(1)');
    mearList[i].METER_STATUS = getGJStatus(mearList[i].METER_STATUS);
    for (var j = 0; j < gjMeters.length; j++) {
      if (gjMeters[j].childNodes[0].nodeValue == mearList[i].METER_ASSET_NO) {
        mearList[i].METER_STATUS = '已挂接当前终端';
      }
    }
    newHtml += '<li class="float">' +
      '<div class="chk flex"></div>' +
      '<div class="flex info">' +
      '<div class="float">' +
      '<p class="flex float">' +
      '<span>电表局编号：</span>' +
      '<span>' + mearList[i].METER_ASSET_NO + '</span>' +
      '</p>' +
      '<p class="flex float">' +
      '<span>抄表段编号：</span>' +
      '<span>' + mearList[i].MR_SECT_NO + '</span>' +
      '</p>' +
      '</div>' +
      '<div class="float">' +
      '<p class="flex float">' +
      '<span>用户编号：</span>' +
      '<span>' + mearList[i].CONS_NO + '</span>' +
      '</p>' +
      '<p class="flex float">' +
      '<span>挂接状态：</span>' + changeColor(mearList[i].METER_STATUS) +
      '</p>' +
      '</div>' +
      '</div>' +
      '</li>';
  };
  $('#add_List ul').append(newHtml);
};
/*
改变挂接状态颜色
 */
function changeColor(meter_status) {
  if (meter_status == '未挂接') {
    return '<span class="addRed">' + meter_status + '</span>';
  } else {
    return '<span class="addGreen">' + meter_status + '</span>';
  }
}
/*
填充查询的电表列表更多信息
 */
function fillMoreMeterFromAddPage(meter) {
  var newHtml = '点号：' + meter.MP_INDEX + '<br />' +
    '电表局编号：' + meter.METER_ASSET_NO + '<br />' +
    '抄表段编号：' + meter.MR_SECT_NO + '<br />' +
    '用户ID：' + meter.CONS_ID + '<br />' +
    '用户编号：' + meter.CONS_NO + '<br />' +
    '用户名称：' + meter.CONS_NAME + '<br />' +
    '电表标识：' + meter.METER_ID + '<br />' +
    '用电地址：' + meter.ELEC_ADDR + '<br />' +
    '挂接状态：' + meter.METER_STATUS + '<br />' +
    '台区编号：' + meter.TG_NO + '<br />';
  $('#addLookPop .LookDetail').html(newHtml);
};

/*
填充电表页面
 */
function fillMeterInfo(meter) {
  var newHtml = '<div class="ammeterTitle">电表信息</div>' +
    '<div class="ammterCon">' +
    '终端资产号：' + meter.TERMINAL_ASSET_NO + '<br />' +
    '点号：' + meter.MP_INDEX + '<br />' +
    '电能表序号：' + meter.METER_INDEX + '<br />' +
    '采集点编号：' + meter.CP_NO + '<br />' +
    '采集点对象ID：' + meter.COLL_OBJ_ID + '<br />' +
    '电表局编号：' + meter.ASSET_NO + '<br />' +
    '抄表状态：' + meter.LAST_STATUS + '<br />' +
    '电表类别：' + meter.SORT_CODE + '<br />' +
    '所属台区：' + meter.TG_NO + '<br />' +
    '抄表段编号：' + meter.MR_SECT_NO + '<br />' +
    '用电地址：' + meter.ELEC_ADDR + '<br />' +
    '用户编号：' + meter.CONS_NO + '<br />' +
    '用户名称：' + meter.CONS_NAME + '<br />' +
    '安装日期：' + meter.INST_DATE + '<br />' +
    '电表厂商：' + meter.MANUFACTURER + '<br />' +
    '电表标识：' + meter.METER_ID + '<br />' +
    '电表状态：' + get_Send_Status_Value(meter.SEND_STATUS) + '<br />' +
    '通信规约类型：' + meter.PROTOCOL_TYPE + '<br />' +
    '通信速率：' + meter.COMM_RATE + '<br />' +
    '端口号：' + meter.COMM_PORT + '<br />' +
    '通信地址：' + meter.COMM_ADDR + '<br />' +
    '有功电能示值的整数位个数：' + meter.INTEGER_NUM + '<br />' +
    '有功电能示值的小数位个数：' + meter.DECIMAL_NUM + '<br />' +
    '大类号：' + BIG_TYPE_NO_OBJ[meter.BIG_TYPE_NO] + '<br />' +
    '小类号：' + SMALL_TYPE_NO_OBJ['' + meter.BIG_TYPE_NO + meter.SMALL_TYPE_NO] + '<br />' +
    '电能费率个数：' + meter.TARIFF_NUM + '</div>';
  $('#ammeter_Detail .collect_DetailInfo').html(newHtml);
  ammeterScroll.scrollToElement($('#ammeter_Detail .collect_DetailInfo')[0], 100);
  ammeterScroll.refresh();
}

/*
返回点击对象的下标
 */
function checkIndex(list, str, currStr) {
  var l = list.length;
  for (var i = 0; i < l; i++) {
    if (list[i][str] == currStr) {
      return i;
    }
  }
};
/*
获取挂接状态
 */
function getGJStatus(METER_STATUS) {
  return METER_STATUS == '' ? '未挂接' : '已挂接';
}
/*
清除电表挂接状态
 */
function clearGuaJie(paramObj) {
  pkgPkg = {
    'METER_ASSET_NO': paramObj.METER_ASSET_NO,
    'ORG_NO': paramObj.ORG_NO
  };
  paramPkg = {
    "MOD": "01",
    "FUN": '03',
    "PKG_TYPE": "0",
    "USR": localStorage.user_name,
    "ORG_NO": localStorage.ORG_NO,
    "PKG": pkgPkg
  };
  param = {
    "FUN": "0000",
    "LEN": plat_common.getLenOfChinese(paramPkg),
    "MOD": "2029",
    "PKG": paramPkg,
    "REQ": "0",
    "SSN": localStorage.SSN,
    "USR": localStorage.user_name,
    "TID": business_com.tid
  };

  plat_common.loadDialog("请求数据中...", 1);
  plat_common.ajax_req(business_com.requestUrl, "data", param, function(result) {
    try {
      console.log("清除电表挂接状态 服务器返回:" + JSON.stringify(result));
      plat_common.closeDialog();
      if (result.PKG.RET == "01") {
        var returnInfo = result.PKG.PKG;
        plat_common.loadDialog(returnInfo.MSG, 0);
        if (returnInfo.RLT_FLAG == 1) {
          var curr_asset_no = returnInfo.METER_ASSET_NO;
          collectMeterObj.updateMeter.removeClass('addGreen').addClass('addRed');
          collectMeterObj.updateMeter[0].childNodes[0].nodeValue = '未挂接';
          var index = checkIndex(collectMeterObj.METER_INFO_LIST_TOTAL, 'METER_ASSET_NO', curr_asset_no);
          collectMeterObj.METER_INFO_LIST_TOTAL[index].METER_STATUS = '未挂接';
        }
        setTimeout(function() {
          plat_common.closeDialog();
        }, 3000);
      } else {
        plat_common.loadDialog("获取数据失败!", 0);
        setTimeout(function() {
          plat_common.closeDialog();
        }, 2000);
      }
    } catch (e) {
      plat_common.loadDialog("获取数据失败!", 0);
      setTimeout(function() {
        plat_common.closeDialog();
      }, 2000);
    }
  }, function(err) {
    var METER_ASSET_NO = collectMeterObj.updateMeter.end().find('span:eq(1)').html();
    queryMeterFromAddPageForClear(METER_ASSET_NO);
    // plat_common.loadDialog("网络异常，获取数据失败！", 0);
    // setTimeout(function() {
    //   plat_common.closeDialog();
    // }, 2000);
  }, 120 * 1000);
};
/*
清除挂接后的查询，校验清除是否成功
 */
function queryMeterFromAddPageForClear(METER_ASSET_NO) {
  pkgPkg = {
    'METER_ASSET_NO': METER_ASSET_NO
  };
  paramPkg = {
    "MOD": "04",
    "FUN": '12',
    "PKG_TYPE": "0",
    "USR": localStorage.user_name,
    "ORG_NO": localStorage.ORG_NO,
    "PKG": pkgPkg
  };
  param = {
    "FUN": "0000",
    "LEN": plat_common.getLenOfChinese(paramPkg),
    "MOD": "2029",
    "PKG": paramPkg,
    "REQ": "0",
    "SSN": localStorage.SSN,
    "USR": localStorage.user_name,
    "TID": business_com.tid
  };

  plat_common.ajax_req(business_com.requestUrl, "data", param, function(result) {
    try {
      console.log("添加按钮-里面的查询 服务器返回111:" + JSON.stringify(result));
      plat_common.closeDialog();
      var result_list = result.PKG.PKG.METER_INFO_LIST;
      if (result.PKG.RET == "01") {
        if (null == result_list || result_list.length == 0) {
          plat_common.loadDialog("获取数据失败!", 0);
          setTimeout(function() {
            plat_common.closeDialog();
          }, 2000);
        } else {
          if (result_list[0].METER_STATUS == '') {
            plat_common.loadDialog("清除挂接成功！", 0);
            var curr_asset_no = result_list[0].METER_ASSET_NO;
            collectMeterObj.updateMeter.removeClass('addGreen').addClass('addRed');
            collectMeterObj.updateMeter[0].childNodes[0].nodeValue = '未挂接';
            var index = checkIndex(collectMeterObj.METER_INFO_LIST_TOTAL, 'METER_ASSET_NO', curr_asset_no);
            collectMeterObj.METER_INFO_LIST_TOTAL[index].METER_STATUS = '未挂接';
          } else {
            plat_common.loadDialog("清除挂接失败！", 0);
          }
          setTimeout(function() {
            plat_common.closeDialog();
          }, 3000);
        }
      } else {
        plat_common.loadDialog("获取数据失败!", 0);
        setTimeout(function() {
          plat_common.closeDialog();
        }, 2000);
      }
    } catch (e) {
      plat_common.loadDialog("获取数据失败!", 0);
      setTimeout(function() {
        plat_common.closeDialog();
      }, 2000);
    }
  }, function(err) {
    plat_common.loadDialog("网络异常，获取数据失败！", 0);
    setTimeout(function() {
      plat_common.closeDialog();
    }, 2000);
  }, 30 * 1000);
};
/*
电表挂接-添加电能表
 */
function addMeterFromAddPage(paramObj) {
  pkgPkg = {
    'TERMINAL_ASSET_NO': paramObj.TERMINAL_ASSET_NO,
    'REF_METER_ASSET_NO': paramObj.REF_METER_ASSET_NO,
    'METER_ASSET_NO': paramObj.METER_ASSET_NO,
    'ORG_NO': paramObj.ORG_NO
  };
  paramPkg = {
    "MOD": "01",
    "FUN": "01",
    "PKG_TYPE": "0",
    "USR": localStorage.user_name,
    "ORG_NO": localStorage.ORG_NO,
    "PKG": pkgPkg
  };
  param = {
    "FUN": "0000",
    "LEN": plat_common.getLenOfChinese(paramPkg),
    "MOD": "2029",
    "PKG": paramPkg,
    "REQ": "0",
    "SSN": localStorage.SSN,
    "USR": localStorage.user_name,
    "TID": business_com.tid
  };

  plat_common.loadDialog("请求数据中...", 1);
  plat_common.ajax_req(business_com.requestUrl, "data", param, function(result) {
    try {
      console.log("添加电能表 服务器返回:" + JSON.stringify(result));
      plat_common.closeDialog();
      if (result.PKG.RET == "01") {
        var returnInfo = result.PKG.PKG;
        plat_common.loadDialog(returnInfo.MSG, 0);
        if (returnInfo.RLT_FLAG == 1) {
          //返回电表表号
          var curr_asset_no = returnInfo.METER_ASSET_NO;
          collectMeterObj.updateMeter.removeClass('addRed').addClass('addGreen');
          collectMeterObj.updateMeter[0].childNodes[0].nodeValue = '已挂接当前终端';
          var index = checkIndex(collectMeterObj.METER_INFO_LIST_TOTAL, 'METER_ASSET_NO', curr_asset_no);
          collectMeterObj.METER_INFO_LIST_TOTAL[index].METER_STATUS = '已挂接当前终端';
        }
        setTimeout(function() {
          plat_common.closeDialog();
        }, 3000);
      } else {
        plat_common.loadDialog("获取数据失败!", 0);
        setTimeout(function() {
          plat_common.closeDialog();
        }, 2000);
      }
    } catch (e) {
      plat_common.loadDialog("获取数据失败!", 0);
      setTimeout(function() {
        plat_common.closeDialog();
      }, 2000);
    }
  }, function(err) {
    var METER_ASSET_NO = collectMeterObj.updateMeter.end().find('span:eq(1)').html();
    queryMeterFromAddPageForAdd(METER_ASSET_NO);
    // plat_common.loadDialog("网络异常，获取数据失败！", 0);
    // setTimeout(function() {
    //   plat_common.closeDialog();
    // }, 2000);
  }, 120 * 1000);
};
//
function queryMeterFromAddPageForAdd(METER_ASSET_NO) {
  pkgPkg = {
    'METER_ASSET_NO': METER_ASSET_NO
  };
  paramPkg = {
    "MOD": "04",
    "FUN": '12',
    "PKG_TYPE": "0",
    "USR": localStorage.user_name,
    "ORG_NO": localStorage.ORG_NO,
    "PKG": pkgPkg
  };
  param = {
    "FUN": "0000",
    "LEN": plat_common.getLenOfChinese(paramPkg),
    "MOD": "2029",
    "PKG": paramPkg,
    "REQ": "0",
    "SSN": localStorage.SSN,
    "USR": localStorage.user_name,
    "TID": business_com.tid
  };

  plat_common.ajax_req(business_com.requestUrl, "data", param, function(result) {
    try {
      console.log("添加按钮-里面的查询 服务器返回111:" + JSON.stringify(result));
      plat_common.closeDialog();
      var result_list = result.PKG.PKG.METER_INFO_LIST;
      if (result.PKG.RET == "01") {
        if (null == result_list || result_list.length == 0) {
          plat_common.loadDialog("获取数据失败!", 0);
          setTimeout(function() {
            plat_common.closeDialog();
          }, 2000);
        } else {
          if (result_list[0].METER_STATUS == '') {
            plat_common.loadDialog("添加电表失败！", 0);
          } else {
            plat_common.loadDialog("已挂接当前终端！", 0);
            var curr_asset_no = result_list[0].METER_ASSET_NO;
            collectMeterObj.updateMeter.removeClass('addRed').addClass('addGreen');
            collectMeterObj.updateMeter[0].childNodes[0].nodeValue = '已挂接当前终端';
            var index = checkIndex(collectMeterObj.METER_INFO_LIST_TOTAL, 'METER_ASSET_NO', curr_asset_no);
            collectMeterObj.METER_INFO_LIST_TOTAL[index].METER_STATUS = '已挂接当前终端';
          }
          setTimeout(function() {
            plat_common.closeDialog();
          }, 3000);
        }
      } else {
        plat_common.loadDialog("获取数据失败!", 0);
        setTimeout(function() {
          plat_common.closeDialog();
        }, 2000);
      }
    } catch (e) {
      plat_common.loadDialog("获取数据失败!", 0);
      setTimeout(function() {
        plat_common.closeDialog();
      }, 2000);
    }
  }, function(err) {
    plat_common.loadDialog("网络异常，获取数据失败！", 0);
    setTimeout(function() {
      plat_common.closeDialog();
    }, 2000);
  }, 30 * 1000);
};

//电表状态
function get_Send_Status_Value(sendStatus) {
  return sendStatus == 0 ? '未下发' : '已下发';
};
// 大类号小类号
var BIG_TYPE_NO_OBJ = {
    '3': '三相商业',
    '4': '单相商业',
    '5': '低压居民',
    '6': '关口'
  },
  SMALL_TYPE_NO_OBJ = {
    '31': '智能电表(三相)',
    '35': '分时表(三相)',
    '39': '单费率表(三相)',
    '38': '卡表(三相)',
    '310': '简易多功能表(三相)',
    '311': '多功能表(三相)',
    '41': '智能电表(单相)',
    '45': '分时表(单相)',
    '511': '智能电表(单相)',
    '515': '分时表(单相)',
    '51': '智能电表(三相)',
    '55': '分时表(三相)',
    '59': '单费率表(三相)',
    '58': '卡表(三相)',
    '65': '配变考核关口',
    '614': '光伏发电关口'
  };

//电表迁移-迁移电能表
function meter_moveTo_Other(paramObj) {
  pkgPkg = {
    'NEW_TERMINAL_ASSET_NO': paramObj.NEW_TERMINAL_ASSET_NO,
    'OLD_TERMINAL_ASSET_NO': paramObj.OLD_TERMINAL_ASSET_NO,
    'METER_ASSET_NO': paramObj.METER_ASSET_NO,
    'COLL_PORT': paramObj.COLL_PORT,
    'SYS_LOGIN_NAME': localStorage.user_name,
    'MACHINE_NO': business_com.tid
  };
  paramPkg = {
    "MOD": "04",
    "FUN": '16',
    "PKG_TYPE": "0",
    "USR": localStorage.user_name,
    "ORG_NO": localStorage.ORG_NO,
    "PKG": pkgPkg
  };
  param = {
    "FUN": "0000",
    "LEN": plat_common.getLenOfChinese(paramPkg),
    "MOD": "2029",
    "PKG": paramPkg,
    "REQ": "0",
    "SSN": localStorage.SSN,
    "USR": localStorage.user_name,
    "TID": business_com.tid
  };
  plat_common.loadDialog("电表迁移中...", 0);
  plat_common.ajax_req(business_com.requestUrl, "data", param, function(success) {
    try {
      console.log("电表迁移:" + JSON.stringify(success));
      plat_common.closeDialog();
      if (success.PKG.RET == "01") {
        var result = success.PKG.PKG;
        if (result.RLT_FLAG == '0') {
          plat_common.loadDialog(result.MSG, 0); //失败
        } else {
          plat_common.loadDialog(result.MSG, 0); //成功
          //删除缓存的电表
          var meter_asset_no_list = paramObj.METER_ASSET_NO.split(','),
            i = 0,
            l = meter_asset_no_list.length;
          for (; i < l; i++) {
            var index = checkIndex(collectMeterObj.MearsurePointInfo, 'ASSET_NO', meter_asset_no_list[i]);
            collectMeterObj.MearsurePointInfo.splice(index, 1);
            var leftMeterList = $('#mearsurepoint').siblings('ul').find('li span'),
              k = 0;
            for (; k < leftMeterList.length; k++) {
              var curr_leftMeter = leftMeterList[k].innerHTML;
              if (curr_leftMeter == meter_asset_no_list[i]) {
                $('#mearsurepoint').siblings('ul').find('li:eq(' + k + ')').remove();
              };
            };
          };
          //删除页面选择迁移的电表
          $('#mear_List li .active').parent().remove();
          var num = $('#mear_List li').length - $('#mear_List li .active').length;
          $('#leftmenuliImg').next().html('电表测量点（挂接：' + num + '块电表）')
        };
      } else {
        plat_common.loadDialog("获取数据失败!", 0);
      };
    } catch (e) {
      plat_common.loadDialog("获取数据失败!", 0);
    }
    setTimeout(function() {
      plat_common.closeDialog();
    }, 3000);
  }, function(err) {
    plat_common.loadDialog("网络异常，获取数据失败！", 0);
    setTimeout(function() {
      plat_common.closeDialog();
    }, 2000);
  }, 30 * 1000);
};