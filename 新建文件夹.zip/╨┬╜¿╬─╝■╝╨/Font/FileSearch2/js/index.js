// JavaScript Document
/*
 * author: qiuzhujun
 * date: 2014/09/25
 */
//页面返回跳转
//0表示首页，1表示二级页面，2表示3级页面…
var collectPage = 0;

//防治click事件短时间内被触发多次
var menuFlag=true;

//还原冒泡
function bubble(){
	menuFlag=false;
	var stopbulle=setTimeout(function(){
	  menuFlag=true;
	  //清除setTimeout
	  clearTimeout(stopbulle)
	},500)
}

//头部返回按钮事件
$('#headBack').click(function(){
	var content = $("header").find("p:first");
	if(menuOpen) {leftMenuOpen();}
	switch(collectPage){
		case 0:
			closeTools();
			break;
		case 1:
			$(document.body).off();
			content.html('采集运维');
			$('header img').css('display','none');
			$("#homeBack").css('display','inline-block');
			$('.moveContent:first-child').removeClass('moveToleft');
			delete CurrFileName[collectPage+1];
			collectPage = 0;
			//remove model
			setTimeout(function() {
				$(".moveContent:last-child").remove();
			}, 500);
			delete window.onresize;
			break;
		case 2:
			if(content.text() == '添加电表'){
				content.html('电表测量点');
			}else if(content.text() == '采集点终端档案修改'){
				content.html('采集点终端档案');
			}else if(content.text() == '电表档案信息修改'){
				content.html('电表档案信息');
			}
			$('header img').css('display','none');
			$("#leftMenu").css('display','inline-block');
			$('.moveContent:eq(1)').removeClass('moveToleft');
			delete CurrFileName[collectPage+1];
			collectPage = 1;
			//remove model
			setTimeout(function() {
				$(".moveContent:last-child").remove();
			}, 500);
			delete window.onresize;
			break;
		case 5:
			content.html('电表测量点');
			$('#add_List').parents('.moveContent').prev().removeClass('moveToleft');
			$('#add_List').parents('.moveContent').addClass('stayOnRight');
			$('#headBack').css('display','none');
			$('#leftMenu').css('display','inline-block');
			$('#headBackRight').css('display','inline-block');
			collectPage = 1;
			setTimeout(function() {
				$('#add_List').parents('.moveContent').remove();
			}, 500);
			delete window.onresize;
			touchable = true;
			backRefresh = true;
			//清空页面数据
			$('#mearsurepoint').siblings('ul').html('');
			$('#mear_List ul').html('');
			//刷新页面重新请求
			collectMeterObj.METER_INFO_LIST_TOTAL = [];
			queryMearsurePoint(collectMeterObj.terminalInfo[0].TERMINAL_ASSET_NO);
		break;
	}
	ReSize();
});

//当前文件名
var CurrFileName = new Object();
	CurrFileName.add = function(key, value){
		this[key] = value;
	};
	CurrFileName.get = function(key){
		return this[key];
	};
//页面跳转方法
function goToModel(obj, url, pageName, num){
	CurrFileName.add(num,url.slice(url.lastIndexOf('/')+1,url.lastIndexOf('.')));
	collectPage = num;
	var target = $(obj).closest('.moveContent');
	target.after('<div class="moveContent stayOnRight"></div>');
	target.next().load(url, function(){
		//修改header
		$("header").find("p:first").html(pageName)
		//加载动画
		target.addClass('moveToleft');
		target.next().removeClass('stayOnRight');
	});
}

//点击home按钮，返回平台首页
$("#homeBack").click(function(){
	closeTools();
});