﻿/**
 * 设备出入箱相关js
 * createby:wangyuxing
 * date:2014/05/22
 **/
//从ydjc数据库的p_code表获取设备的状态和类型,arr_equip存放设备类别(01电能表,02电压互感器...)
var arr_stat = [],arr_type = [], arr_equip = [];
business_com.getStatTypeFormDb(arr_stat,arr_type,arr_equip);
//加载平台工具箱
business_com.loadToolKit();

//设置用户姓名及供电公司
$(function(){
	$("header p:eq(1)").html(localStorage.area+"-"+localStorage.user_name_str+"-"+localStorage.user_name);
})

var touchMechod = {
	listtouch:function(){
		$(this).addClass("touch");
		},
	listend:function(){
		$(this).removeClass("touch");
		}
	}
var timeout = 10,
		len = $("[id^=list]").length;
for(var i = 1;i<=len;i++){
	(function($,i){
		$(".list"+i).on({
			"touchstart": touchMechod.listtouch,
			"touchend": touchMechod.listend
			})
 		setTimeout(function(){
		var temp_obj = $('.list'+i);
		temp_obj.addClass('list'+i+'f');
		setTimeout(function(){
			$(".list"+i+">div").removeClass("listfontf");
			i++;
			},1000)
		},timeout);
		timeout+=500;
 	})(jQuery,i);
}

//页面返回跳转
/**
 *pagejumpno=0;从list返回到模块选择界面
 *pagejumpno=1;从1级页面返回到模块list界面
 *pagejumpno=2;从2级页面返回到模块list界面
 */
var pagejumpno = 0;
$("header .flex:eq(0)").click(function() {
	var dom = $("header").find(".btn");
	switch (pagejumpno) {
		case 0:
			//window.location.href = "../../../../Platform/Plat/html/index.html";
			//setTimeout(function() {
			//	$(".moveContent:last-child").remove();
	    	//}, 500);
	    	closeTools();
			break;
		case 1:
			var content = $('header .content >p:first-child').html().trim();
			if(content == "设备出入箱"){
				if(MyApp && MyApp.house_info_array.length!=0){
					navigator.notification.confirm("确认退出设备出入箱吗?", goto_main, "提示", "确认,取消");
				}else{
					goto_main(1);
				}
			}else if(content=="设备分拣"){
			    if(assetsArray.length !=0){
			        navigator.notification.confirm("确认退出设备分拣吗?", goto_main, "提示", "确认,取消");
			    }else{
			       goto_main(1);
			    }
			}else{
				goto_main(1);
			}

		    function goto_main(index_btn){
		    	if(index_btn == 1){
		    		$(document.body).off("click.device","**");
					dom.hide().unbind("click");
					$("header").find("img").attr("src", "../../images/home.png");
					$('header .content >p:first-child').html('资产管理');
					$(".moveContent:first-child").removeClass("moveToleft");
					delete CurrFileName[pagejumpno+1];
					pagejumpno = 0;
					setTimeout(function() {
						$(".moveContent:last-child").remove();
					}, 500);
		    	}
		    }
			delete window.onresize;
			break;
		case 2:
		    var content = $('header .content >p:first-child').html().trim();
			$("footer").css({
				position: "static"
			});
			if(content=="报废申请详细"){
				$('header .content >p:first-child').html('报废申请');
				setTimeout(function(){
				 $("#scrapScanlisthtml").css("display","block")
				},800)
			}
			dom.attr('style', 'display:none;');
			$(".moveContent:eq(1)").removeClass("moveToleft");
			delete CurrFileName[pagejumpno+1];
			pagejumpno = 1;
			setTimeout(function() {
				$(".moveContent:last-child").remove();
	    	}, 500);
			delete window.onresize;
			break;
		case 3:
			dom.attr('style','display:none;');
			$(".moveContent:eq(2)").removeClass("moveToleft");
			$('header .content >p:first-child').html('盘点作业');
			delete CurrFileName[pagejumpno+1];
			pagejumpno = 2;
			setTimeout(function(){
				$(".moveContent:last-child").remove();
				}, 500);
			delete window.onresize;
	}
	ReSize();
});

//当前文件名
var CurrFileName = new Object();
	CurrFileName.add = function(key, value){
		this[key] = value;
	};
	CurrFileName.get = function(key){
		return this[key];
	};

function goToModel(obj, url, value, num) {
	CurrFileName.add(num,url.slice(url.lastIndexOf('/')+1,url.lastIndexOf('.')));
	pagejumpno = num;
	var target = $(obj).closest('.moveContent');
	target.after('<div class="moveContent stayOnRight"></div>');
	target.next().load(url, function() {
		//修改header
		$('header .content >p:first-child').html(value);
		$('header img:first-child').attr("src", "../../images/back.png");
		//加载动画
		target.addClass("moveToleft");
		target.next().removeClass('stayOnRight');
	});
}


  //检查资产编号扫描是否合法
  function testAssetNO(assetNo){
  	 var regExp1 = /^\d+$/;
	 var regExp2 = /^[A-Z|a-z]+[0-9]+$/;
	 if(assetNo.length!=10){
	 	return false;
	 }
	 if(!regExp1.test(assetNo) && !regExp2.test(assetNo)){
	 	return false;
	 }
	 return true;
  }


document.addEventListener("deviceready",function(){
	//进行蓝牙连接
	bluetooth_conn(function(e){
		if(e.msg == 1){
			showToast("设备已连接");
		}else if(e.msg==3){
			showToast("扫描设备未设置");
		}else{
			showToast("连接失败");
		}
	});
},false);

//模块控制
$(".maincont").on("click","div[id^=list]",function() {
	var index = $("div[id^=list]").index(this);
	switch (index) {
		//设备出入箱
		case 0:
			goToModel(this, '../devicein/html/devicein.html', '设备出入箱', 1);
			break;
		//设备分拣
		case 1:
			goToModel(this,'../sorting/html/sorting.html','设备分拣',1);
			break;
		//报废申请
		case 2:
			/*plat_common.loadDialog("功能开发中,敬请期待!",0);
			setTimeout(function(){
				plat_common.closeDialog();
			},1500);*/
			goToModel(this, '../Scrapping/html/scrapping.html', '报废申请', 1);
			break;
		//盘点作业
		case 3:
			 /*plat_common.loadDialog("功能开发中,敬请期待!",0);
			 setTimeout(function(){
				plat_common.closeDialog();
			 },1500);*/
			goToModel(this, '../checktask/html/checktaskList.html', '盘点作业', 1);
			break;
		case 4:
			goToModel(this, '../reclaimedMeter/html/reclaimedMeter.html', '拆回表查询', 1);
			break;
		case 5:
			goToModel(this, '../fanchang/html/fanchang.html', '返厂更换申请', 1);
			break;
		case 6:
			goToModel(this,'../tuihuo/html/tuihuo.html','返厂维修',1);
			break;
		break;
	}
});

//页面大小改变
window.onresize = function(){ReSize();}
function ReSize(){
	var name = CurrFileName.get(pagejumpno);
	switch(name){
		//设备出入箱
		case 'devicein':
			$('#inboxwrap').height(plat_common.getHeight()-411);
			inboxwrap.refresh;
			$("#outboxwrap").height(plat_common.getHeight()-486);
			outboxwrap.refresh();
			$("#slidebar").height(plat_common.getHeight()-190);
			slidebar.refresh();
		break;
		//设备分拣
		case 'sorting':
			$('#listocntent3').height(plat_common.getHeight()-363);
			sortingScroll.refresh();
		break;
		//报废申请
		case 'scrapping':
			$('#scrappedcntent').height(plat_common.getHeight()-358);
			scrolltask.refresh();
		break;
		//盘点作业
		case 'checktaskList':
			$('#listocntentList').height(plat_common.getHeight()-102);
			scrollList.refresh();
		break;
		case 'checktask':
			$('#stack_detail_list').height(plat_common.getHeight()-263);
			scrolltask.refresh();
		break;
		case 'hasChecktask':
			$('#hasCheck_list').height(plat_common.getHeight()-263);
			hasCheck_listScroll.refresh();
		break;
		//拆回表查询
		case 'reclaimedMeter':
			$('#outboxwrap').height(plat_common.getHeight()-273);
			my_scroll.refresh();
		break;
		case 'reclaimedMeterDetail':
			recaimDetail_obj.dom.height(plat_common.getHeight()-164);
			detail_info.refresh();
		break;
		//返厂更换申请
		case 'fanchang':
			$('#fanchangScroll').height(plat_common.getHeight()-370);
		break;
		//返厂维修
		case 'tuihuo':
			$('#tuihuoScroll').height(plat_common.getHeight()-444);
		break;
	}
}