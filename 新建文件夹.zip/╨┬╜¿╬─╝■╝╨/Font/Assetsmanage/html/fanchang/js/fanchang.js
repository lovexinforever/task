/**
 *返厂更换业务功能模块
 *景钰海
 *2014/11/3
 */
var fc_zcydzyDataList = [];
var fc_zcydzyAssetNos = [];
var fc_zcydzyReqNum = 0;
//从P_CODE表查出18063:电压,18017:型号,18081:厂家,18009:准确度等级,18012:电能表类别,19005:接线方式,18064:电流
var tuihuo_flag = true,arr_volt = [],model_code=[],MANUFACTURER_arr=[],AP_PRE_LEVEL_CODE_arr=[],SORT_CODE_arr=[],WIRING_MODE_arr=[],RATED_CURRENT_arr=[];
   
/**
 * 返厂更换-设备查询-周转箱条形码
 * @equipType 设备类别
 * @bar_code 周转箱条形码
 */
function fc_requestEquip_barCode(equipType,bar_cade){
	var pkg = {"MOD":"21","FUN":"01","PKG_TYPE":"0","USR":localStorage.user_name,"ORG_NO":localStorage.ORG_NO,"PKG":{"BAR_CODE":bar_cade,"ORG_NO":localStorage.ORG_NO,"EQUIP_CATEG":equipType}}
	plat_common.loadDialog("设备正在查询中...","1");
	fc_zcydzyReqNum++;
	fc_baseRequestFun(pkg,null,function(result){
		if(result !="error"){
			var dataList = result.METER_LIST;
			var len = dataList.length;
			if(len>0){
				fc_queryPcode(dataList,5);
			}else{
				plat_common.loadDialog("未查询到设备！","0");
			}
			fc_closeLoadDialog();
		}
	});
}
/**
 * 返厂更换-设备查询-资产编号段
 * @equipType 设备类别
 * @assetNo_bng 资产编号开始
 * @assetNo_end 资产编号结束
 */
function fc_requestEquip_assetNo(equipType,assetNo_bng,obj){
	var pkg = {"MOD":"21","FUN":"02","PKG_TYPE":"0","USR":localStorage.user_name,"ORG_NO":localStorage.ORG_NO,"PKG":{"ASSET_NO_BNG":assetNo_bng,"ASSET_NO_END":assetNo_bng,"ORG_NO":localStorage.ORG_NO,"EQUIP_CATEG":equipType}}
	//plat_common.loadDialog("设备正在查询中...","1");
	fc_zcydzyReqNum++;
	fc_baseRequestFun(pkg,obj,function(result,obj_){
		if(result !="error"){
			var dataList = result.METER_LIST;
			var len = dataList.length;
			if(len>0){
				fc_queryPcode(dataList,1);
			}else{
				if(obj_){
					obj_.text("查询结果为空");
					obj_.parents("li").find(".checkbox").removeClass('checked').addClass("checkbox3");
					changeFcSelectedNum();
				}
			}
			fc_closeLoadDialog();
		}
	});
}
/**
 * 返厂更换申请
 * @assetNoList 返厂更换申请的资产编号List
 */
function fc_saveReturnBackApp(return_type, assetNoList){
	var pkg = {"MOD":"21","FUN":"03","PKG_TYPE":"0","USR":localStorage.user_name,"ORG_NO":localStorage.ORG_NO,"PKG":{"ORG_NO":localStorage.ORG_NO,"EMP_NO":localStorage.user_name,"RETURN_TYPE":return_type,"ASSET_NO_LIST":assetNoList}}
	plat_common.loadDialog("设备返厂更换正在申请中...","1");
	fc_zcydzyReqNum++;
	fc_baseRequestFun(pkg,null,function(result){
		if(result !="error"){
			var msg = result.MSG;
			plat_common.loadDialog(msg,0);
			var obj = $("#fanchangScroll li").find(".checked");
			obj.each(function(index,element){
				var i = $("#fanchangScroll li").index($(this).parents("li"));
				fc_zcydzyDataList.splice(i,1);
				fc_zcydzyAssetNos.splice(i,1);
				$(this).parents("li").remove();
			});
			$(".scrappedTotalNum").text(fc_zcydzyDataList.length);
			changeFcSelectedNum();
    		fc_closeLoadDialog();
		}
	});
}
/**
 * 把查询得到的设备信息解析填充到页面中
 * @len 设备信息条数
 * @dataList 设备信息数据
 */
function fc_jointDataToHtml(dataList,flag){
	var htmlStr = '';
	var len = dataList.length;
	for(var i=0;i<len;i++){
		var index = fc_zcydzyAssetNos.indexOf(dataList[i].ASSET_NO);
		var msg = "正在查询中...";
		if(flag==3)msg = "资产未确认";
		if(index==-1){
			fc_zcydzyAssetNos.push(dataList[i].ASSET_NO);
			fc_zcydzyDataList.push(dataList[i]);
			if(flag==5){
				htmlStr+='<li class="float">'+fc_baseLiHtml(dataList[i])+'</li>';
			}else{
				htmlStr+='<li class="float"> <span class="checkbox checkbox2 flex"></span>'+
						'<div class="flex info">'+
						  '<div class="float">'+
							'<div class="flex float"> <span>资产编号：</span> <span id="fc_assetNoID" class="scontent">'+dataList[i].ASSET_NO+'</span> </div>'+
							'<div class="flex float"> <span class="svalue" id="fc_msgID">'+msg+'</span></div>'+
						  '</div>'+
						'</div>'+
					  '</li>';
			}
		}else{
			if(dataList[i].TYPE_CODE.length !=0){
				if(fc_zcydzyDataList[index].TYPE_CODE.length ==0){
					fc_zcydzyDataList[index] = dataList[i];
					console.log(fc_baseLiHtml(dataList[i]));
					$("#fanchangScroll li").eq(index).html(fc_baseLiHtml(dataList[i]));
					changeFcSelectedNum();
				}
			}else{
				if(fc_zcydzyDataList[index].TYPE_CODE.length ==0){
					$("#fanchangScroll li").eq(index).find("#fc_msgID").text("资产未确认");
				}
			}
		}
	}
	if(flag==5 || flag==3 ||flag==2){
		$("#fanchangScroll >ul").append(htmlStr);
		var wrapperHeight = $('#fanchangScroll').height();
	 	var ulHeight = $('#fanchangScroll ul').height();
	  	if (wrapperHeight < ulHeight) {
	    	$('#fanchangScroll').scrollTop(ulHeight);
	  	};
		$(".scrappedTotalNum").text(fc_zcydzyDataList.length);
	}
}

function fc_baseLiHtml(data){
	var htmlStr ='<span class="checkbox checkbox2 flex"></span>'+
	                '<div class="flex info">'+
	                    '<div class="float">'+
	                        '<div class="flex float">'+
	                            '<span>设备类别：</span>'+
	                            '<span id="fc_equipTypeID">'+getNameByValue("equip",data.EQUIP_CATEG)+'</span>'+
	                        '</div>'+
	                        '<div class="flex float">'+
	                            '<span>资产编号：</span>'+
	                            '<span id="fc_assetNoID">'+data.ASSET_NO+'</span>'+
	                        '</div>'+
	                    '</div>'+
	                    '<div class="float">'+
	                        '<div class="flex float">'+
	                            '<span>当前状态：</span>'+
	                            '<span id="fc_statesID">'+getNameByValue("status",data.CUR_STATUS_CODE)+'</span>'+
	                        '</div>'+
	                        '<div class="flex float">'+
	                            '<span>类型：</span>'+
	                            '<span id="fc_typeID">'+getNameByValue("type",data.TYPE_CODE)+'</span>'+
	                        '</div>'+
	                    '</div>'+
	                '</div>';
	return htmlStr;	
}
/**
 * 请求服务器的基础方法
 * pkg 请求的参数
 * sucFun 请求回调方法
 */
function fc_baseRequestFun(pkg,obj,successFun){
	var data = jointAjaxData(pkg);
	var proDetailProList = "error";
    plat_common.ajax_req(business_com.requestUrl,"data",data,function(result){
    	console.log(JSON.stringify(result));
    	try{
    		if(result.PKG.RET == "01"){
    			proDetailProList = result.PKG.PKG;
    		}else if(result.PKG.RET == "14"){
				if(obj)obj.text("资产未确认");
    			plat_common.loadDialog(result.PKG.PKG.MSG,0);
    			fc_closeLoadDialog();
    		}else{
				if(obj)obj.text("资产未确认");
    			plat_common.loadDialog("服务器返回数据异常!",0);
    			fc_closeLoadDialog();
    		}
    	}catch(e){
			if(obj)obj.text("资产未确认");
    		plat_common.loadDialog("服务器返回数据异常!",0);
    		fc_closeLoadDialog();
    	}
    	if(obj){
			successFun(proDetailProList,obj);
    	}else{
			successFun(proDetailProList);
    	}
    },function(e){
    	if(obj){
		    obj.text("资产未确认");
			successFun(proDetailProList,obj);
    	}else{
			successFun(proDetailProList);
    	}
    	plat_common.loadDialog("网络连接错误","0");
        fc_closeLoadDialog();
    },30000);
}
function fc_closeLoadDialog(){
	setTimeout(function(){
		fc_zcydzyReqNum--;
		if(fc_zcydzyReqNum==0){
			plat_common.closeDialog();
		}
	},3000);
}
/**
 *拼接请求服务器的参数
 *@param pkg  业务数据 
*/
function jointAjaxData(pkg){
	var len = plat_common.getLenOfChinese(JSON.stringify(pkg));
  	return {"FUN":"0000","LEN":""+len+"","MOD":"2022","PKG":pkg,"REQ":"0","SSN":localStorage.SSN,"USR":localStorage.user_name,"TID":localStorage.TID};
}

//在P_CODE表通过value值获取name属性值,type:设备类型,volt:电压,model_code:型号,MANUFACTURER:厂家,AP_PRE_LEVEL_CODE:准度度等级,SORT_CODE:电能表类别,WIRING_MODE:接线方式,RATED_CURRENT:电流,status:设备状态,设备类别：equip
function getNameByValue(type, value) {
	var arr = [];
	switch(type) {
		case "type"://设备类型
			arr = arr_type;
			break;
		case "volt"://电压
			arr = arr_volt;
			break;
		case "model_code"://型号
			arr = model_code;
			break;
		case "MANUFACTURER"://厂家
			arr = MANUFACTURER_arr;
			break;
		case "AP_PRE_LEVEL_CODE"://准度度等级
			arr = AP_PRE_LEVEL_CODE_arr;
			break;
		case "SORT_CODE"://电能表类别
			arr = SORT_CODE_arr;
			break;
		case "WIRING_MODE"://接线方式
			arr = WIRING_MODE_arr;
			break;
		case "RATED_CURRENT"://电流
			arr = RATED_CURRENT_arr;
			break;
		case "status"://设备状态
			arr = arr_stat;
			break;
		case "equip"://设备类别
			arr = arr_equip;
			break;
	}

	for(var i = 0, len = arr.length; i < len; i++) {
		var temp = arr[i];
		if(temp.value == value) {
			return temp.name;
		}
	}
	return '';
}

/**
 *通过设备类型码查询出对应的设备类型名称
 *@param num 设备类型码
 */
function numberQueryEquipName(num) {
	var len = arr_equip.length;
	var name;
	for(var i = 0; i < len; i++) {
		if(num == arr_equip[i].value) {
			name = arr_equip[i].name;
			break;
		}
	}
	return name;
}

function fc_queryPcode(dataList,flag){
	//18063:电压,18017:型号,18081:厂家,18009:准确度等级,18012:电能表类别,19005:接线方式,18064:电流
	var sql = "select code_sort_id,name,value from p_code where code_sort_id = '18063' or code_sort_id='18017' or code_sort_id='18081' or code_sort_id='18009' or code_sort_id='18012' or code_sort_id='19005' or code_sort_id='18064';";
	if(arr_volt.length==0){
		document.addEventListener("deviceready",function(){
	       //数据库查询
		   db_execut_oneSQL("dbzj.db",sql,[],function(tx,res){
		   	  var obj = res.rows;
		   	  for(var k=0,len=obj.length;k<len;k++){
		   	  	 var tempObj = obj.item(k);
		   	  	 var code_sort_id = tempObj.CODE_SORT_ID;
		   	  	 var name = tempObj.NAME;
		   	  	 var value = tempObj.VALUE;
		   	  	 
		   	  	 var json = {"code_sort_id":code_sort_id,'name':name,"value":value};
		   	  	 switch(code_sort_id){
		   	  	 	case '18063':
		   	  	 	 	arr_volt.push(json);
		   	  	 		break;
		   	  	 	case '18017':
		   	  	 		model_code.push(json);
		   	  	 		break;
		   	  	 	case '18081':
		   	  	 		MANUFACTURER_arr.push(json);
		   	  	 		break;
		   	  	 	case '18009':
		   	  	 		AP_PRE_LEVEL_CODE_arr.push(json);
		   	  	 		break;
		   	  	 	case '18012':
		   	  	 		SORT_CODE_arr.push(json);
		   	  	 		break;
		   	  	 	case '19005':
		   	  	 		WIRING_MODE_arr.push(json);
		   	  	 		break;
		   	  	 	case '18064':
		   	  	 		RATED_CURRENT_arr.push(json);
		   	  	 		break;
		   	  	 }
		   	  }
		   	  fc_jointDataToHtml(dataList,flag);	
		   },function(e){
		   	  console.log("拆回表查询P_CODE表失败!");
		   	  fc_jointDataToHtml(dataList,flag);	
		   });
	  },false);
 }else{
 	fc_jointDataToHtml(dataList,flag);	
 }
}
