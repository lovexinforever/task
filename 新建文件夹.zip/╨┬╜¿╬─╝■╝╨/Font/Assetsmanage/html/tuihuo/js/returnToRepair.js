var tuihuoObj = {
  queryMeterList_total: [],
  currMeterAssetNoList: $('#tuihuoScroll li').find('span:eq(2)')
};
//从P_CODE表查出18063:电压,18017:型号,18081:厂家,18009:准确度等级,18012:电能表类别,19005:接线方式,18064:电流
var arr_volt = [],
  model_code = [],
  MANUFACTURER_arr = [],
  AP_PRE_LEVEL_CODE_arr = [],
  SORT_CODE_arr = [],
  WIRING_MODE_arr = [],
  RATED_CURRENT_arr = [],
  tuihuo_flag = true;
/*------------------设置list高度----------------------*/
var height = plat_common.getHeight();
$('#tuihuoScroll').height(height - 444);
/*------------------复选框勾选----------------------*/
$('#tuihuoScroll .checkbox').live('click', function(e) {
  if (tuihuo_flag) {
    tuihuo_flag = false;
    setTimeout(function() {
      tuihuo_flag = true;
    }, 100);
    e.stopPropagation();
    $(this).toggleClass('checked');
    getSelectedMeterLength();
    $('#tuihuo_asset_bng').val('');
    $('#tuihuo_asset_end').val('');
    $('#tuihuo_asset').val('');
  }
});
//设备类型
$('#select_equip_categ').on('click', function() {
  plat_common.invokePopup('设备类型', ['电能表'], ['取消', '确定'], ['select_equip_cancel', 'select_equip_OK'], 0);
});

function select_equip_cancel(selIndex, selContent, popup) {
  popup.remove();
};

function select_equip_OK(selIndex, selContent, popup) {
  popup.remove();
};
//移除
$('#deleteSelected').on('click', function(e) {
  deleteExecuteSuccessMeter();
});
//删除事件
function deleteExecuteSuccessMeter() {
  var checkedMeter = $('#tuihuoScroll li .checked'),
    len = checkedMeter.length,
    totalNum = Number($('#tuihuoTotalNum').html());
  if (len == 0) {
    showDialogOfSecend('请勾选要移除的电表！');
    return;
  };
  for (var i = 0, j = 0; i < checkedMeter.length; i++) {
    var curr_meter_asset_no = $('#tuihuoScroll li .checked:eq(' + j + ')').next().find('span:eq(1)').html(),
      index = checkIndex(tuihuoObj.queryMeterList_total, 'ASSET_NO', curr_meter_asset_no);
    j++;
    if (index !== undefined) {
      tuihuoObj.queryMeterList_total.splice(index, 1);
      i--;
    }
  };
  $('#tuihuoTotalNum').html(totalNum - len);
  checkedMeter.parents('li').remove();
  $('#selectAll').html('全选');
  getSelectedMeterLength();
};
//删除事件(部分执行失败)
function deleteExecuteForFail(asset_no_list) {
  var i = 0,
    len = asset_no_list.length,
    totalNum = Number($('#tuihuoTotalNum').html());
  for (; i < asset_no_list.length; i++) {
    var curr_asset_no = asset_no_list[i],
      index1 = checkIndex(tuihuoObj.queryMeterList_total, 'ASSET_NO', curr_asset_no),
      index2 = checkAssetNoRepeat(curr_asset_no);
    if (index1 !== undefined) {
      tuihuoObj.queryMeterList_total.splice(index1, 1);
      i--;
    };
    if (index2 !== undefined) {
      $('#tuihuoScroll li:eq(' + index2 + ')').remove();
    }
  }
  $('#tuihuoTotalNum').html(totalNum - len);
  getSelectedMeterLength();
};
//全选
$('#selectAll').on('click', function(e) {
  var val = $(this).html(),
    visibleNum = $('#tuihuoScroll li').find('span:eq(0)').not('.existHidden').length,
    liCheckedBox = $('#tuihuoScroll li').find('span:eq(0)').not($('.existHidden'));
  if (visibleNum == 0) {
    return;
  };
  val == '全选' ? ($(this).html('取消全选'), liCheckedBox.addClass('checked'), $('#tuihuo_asset').val(''), $('#tuihuo_asset_bng').val(''), $('#tuihuo_asset_end').val('')) : ($(this).html('全选'), liCheckedBox.removeClass('checked'));
  getSelectedMeterLength();
});
//资产编号和资产编号段填充
$('#tuihuo_asset').on('input', function(e) {
  $('#tuihuo_asset_bng').val('');
  $('#tuihuo_asset_end').val('');
  changeScanBorder(this);
});
$('#tuihuo_asset_sencond input').on('input', function(e) {
  $('#tuihuo_asset').val('');
  changeScanBorder(this);
});

function changeScanBorder(obj) {
  $('.scanBorder').removeClass('scanBorder');
  $(obj).addClass('scanBorder');
};
//详细信息的弹窗
$('#tuihuoScroll li').live('click', function() {
  if (tuihuo_flag) {
    tuihuo_flag = false;
    setTimeout(function() {
      tuihuo_flag = true;
    }, 100);
    if ($(this).find('span:eq(0)').hasClass('existHidden')) {
      showDialogOfSecend('该电表查询结果为空！');
      return false;
    }
    var curr_asset_no = $(this).find('div span:eq(1)').html();
    var index = checkIndex(tuihuoObj.queryMeterList_total, 'ASSET_NO', curr_asset_no);
    if (index === undefined) {
      showDialogOfSecend('该电表资产未确认！');
      return false;
    }
    $('#tuihuoDetailBox').show();
    document.ontouchmove = function(e) {
      e.preventDefault();
    };
    fillHtmlToTuiHuoDetailPage(tuihuoObj.queryMeterList_total[index]);
  }
});
//详细信息弹窗-取消
$('#tuihuoDetailOK').on('click', function() {
  $('#tuihuoDetailBox').hide();
  document.ontouchmove = function(e) {};
});
//执行的弹窗
$('#tuihuoExecute').on('click', function() {
  var checkedMeter = $('#tuihuoScroll li .checked');
  if (checkedMeter.length == 0) {
    showDialogOfSecend('请选择要执行返厂的设备！');
    return;
  };
  $('#tuihuoExecuteBox').show();
  document.ontouchmove = function(e) {
    e.preventDefault();
  };
});
//执行的弹窗-取消
$('#tuihuoExecuteCancle').on('click', function() {
  $('#tuihuoExecuteBox').hide();
  $('#tuihuoExecutePop textarea').val('');
  document.ontouchmove = function(e) {};
});
//执行的弹窗-确定
$('#tuihuoExecuteOK').on('click', function() {
  var paramObj = {
      ASSET_NO_LIST: [],
      REMARK: $('#tuihuoExecutePop textarea').val()
    },
    checkedMeter = $('#tuihuoScroll li .checked'),
    i = 0,
    l = checkedMeter.length;
  for (i; i < l; i++) {
    var curr_meter_asset_no = $('#tuihuoScroll li .checked:eq(' + i + ')').next().find('span:eq(1)').html(),
      index = checkIndex(tuihuoObj.queryMeterList_total, 'ASSET_NO', curr_meter_asset_no);
    curr_obj = {
      'ASSET_NO': curr_meter_asset_no,
      'EQUIP_ID': tuihuoObj.queryMeterList_total[index] == undefined ? '' : tuihuoObj.queryMeterList_total[index].EQUIP_ID,
      'EQUIP_CATEG': '01'
    };
    paramObj.ASSET_NO_LIST.push(curr_obj);
  };
  if (paramObj.REMARK == '') {
    showDialogOfSecend('请输入返厂维修备注信息！');
  } else {
    $('#tuihuoExecuteBox').hide();
    $('#tuihuoExecutePop textarea').val('');
    document.ontouchmove = function(e) {};
    executeTuiHuo(paramObj);
  };
});
//返厂维修-设备查询-资产编号段
function tuihuoQuery(paramObj) {
  var tid = business_com.tid,
    url = business_com.requestUrl,
    innerPKG = {
      'ASSET_NO_BNG': paramObj.ASSET_NO_BNG,
      'ASSET_NO_END': paramObj.ASSET_NO_END,
      'ORG_NO': localStorage.ORG_NO,
      'EQUIP_CATEG': paramObj.EQUIP_CATEG
    },
    outerPKG = {
      'MOD': '22',
      'FUN': '01',
      'PKG_TYPE': 0,
      'USR': localStorage.user_name,
      'ORG_NO': localStorage.ORG_NO,
      'PKG': innerPKG
    },
    param = {
      'FUN': '0000',
      'LEN': plat_common.getLenOfChinese(outerPKG),
      'MOD': '2022',
      'REQ': '0',
      'USR': localStorage.user_name,
      'TID': tid,
      'SSN': localStorage.SSN,
      'PKG': outerPKG
    };
  plat_common.loadDialog('数据加载中...', 1);
  plat_common.ajax_req(url, "data", param, function(success) {
    try {
      console.log("数据返回为: " + JSON.stringify(success));
      success = JSON.parse(JSON.stringify(success));
      if (success.PKG.RET == '01') {
        $('#tuihuo_asset_bng').val('');
        $('#tuihuo_asset_end').val('');
        $('#tuihuo_asset').val('');
        var meterList = success.PKG.PKG.METER_LIST;
        if (null == meterList || meterList.length == 0) {
          plat_common.loadDialog("数据为空!");
        } else {
          tuihuoObj.queryMeterList = success.PKG.PKG.METER_LIST;
          for (var i = 0, l = tuihuoObj.queryMeterList.length; i < l; i++) {
            var meter = tuihuoObj.queryMeterList[i];
            meter.TYPE_CODE = getNameByValue('type', meter.TYPE_CODE);
            meter.CUR_STATUS_CODE = getNameByValue('status', meter.CUR_STATUS_CODE);
            meter.VOLT_CODE = getNameByValue('volt', meter.VOLT_CODE);
            meter.RATED_CURRENT = getNameByValue('RATED_CURRENT', meter.RATED_CURRENT);
            meter.MANUFACTURER = getNameByValue('MANUFACTURER', meter.MANUFACTURER);
            meter.SORT_CODE = getNameByValue('SORT_CODE', meter.SORT_CODE);
            meter.AP_PRE_LEVEL_CODE = getNameByValue('AP_PRE_LEVEL_CODE', meter.AP_PRE_LEVEL_CODE);
            meter.WIRING_MODE = getNameByValue('WIRING_MODE', meter.WIRING_MODE);
            var index = checkIndex(tuihuoObj.queryMeterList_total, 'ASSET_NO', meter.ASSET_NO);
            if (index === undefined) {
              tuihuoObj.queryMeterList_total.push(meter);
            } else {
              tuihuoObj.queryMeterList.splice(i, 1);
              i--;
              l--;
            }
          }
          if (tuihuoObj.queryMeterList.length > 0) {
            fillHtmlToTuiHuoPageForOffline(tuihuoObj.queryMeterList);
          } else {
            showDialogOfSecend('查询的结果已在列表中！');
          }
        }
        getSelectedMeterLength();
      } else {
        console.log("设备查询失败,返回码: " + success.PKG.RET);
        plat_common.loadDialog(success.PKG.MSG, 0);
      }
    } catch (e) {
      console.log("设备查询异常,原因: " + JSON.stringify(e));
      plat_common.loadDialog("设备查询失败!服务端返回数据错误!", 0);
    }
    setTimeout(function() {
      plat_common.closeDialog();
    }, 2000);
  }, function(e) {
    console.log("设备查询失败,原因: " + JSON.stringify(e));
    plat_common.loadDialog("设备查询失败!网络连接错误!", 0);
    setTimeout(function() {
      plat_common.closeDialog();
    }, 2000);
  });
};
//返厂维修-执行
function executeTuiHuo(paramObj) {
  var tid = business_com.tid,
    url = business_com.requestUrl,
    innerPKG = {
      'ORG_NO': localStorage.ORG_NO,
      'EMP_NO': localStorage.user_name,
      'RETURN_REMARK': paramObj.REMARK,
      'ASSET_NO_LIST': paramObj.ASSET_NO_LIST
    },
    outerPKG = {
      'MOD': '22',
      'FUN': '04',
      'PKG_TYPE': '0',
      'USR': localStorage.user_name,
      'ORG_NO': localStorage.ORG_NO,
      'PKG': innerPKG
    },
    param = {
      'FUN': '0000',
      'LEN': plat_common.getLenOfChinese(outerPKG),
      'MOD': '2022',
      'REQ': '0',
      'SSN': localStorage.SSN,
      'USR': localStorage.user_name,
      'TID': tid,
      'PKG': outerPKG
    };
  plat_common.loadDialog('执行中...', 1);
  plat_common.ajax_req(url, 'data', param, function(success) {
    console.log('执行返回结果： ' + JSON.stringify(success));
    try {
      var result = JSON.parse(JSON.stringify(success)),
        executeResult = result.PKG.PKG;
      if (result.PKG.RET == '01') {
        if (executeResult.FAIL_ASSET_NO === '') {
          plat_common.loadDialog('全部执行成功！', 0);
          deleteExecuteSuccessMeter();
        } else {
          plat_common.loadDialog(executeResult.FAIL_ASSET_NO + '执行失败！', 0);
          var fail_asset_no_list = executeResult.FAIL_ASSET_NO.split(','),
            success_asset_no_list = [];
          $.each(fail_asset_no_list, function(index) {
            var fail_index = checkIndex(paramObj.ASSET_NO_LIST, 'ASSET_NO', fail_asset_no_list[index]);
            paramObj.ASSET_NO_LIST.splice(fail_index, 1);
          });
          $.each(paramObj.ASSET_NO_LIST, function(val) {
            success_asset_no_list.push(val.ASSET_NO);
          });
          deleteExecuteForFail(success_asset_no_list);
        }
      } else {
        plat_common.loadDialog('执行失败，服务器返回异常！', 0);
      }
    } catch (e) {
      console.log('执行失败，原因：' + JSON.stringify(e));
      plat_common.loadDialog('执行失败，服务端返回异常！', 0);
    };
    setTimeout(function() {
      plat_common.closeDialog();
    }, 2000);
  }, function(e) {
    plat_common.loadDialog('执行失败！网络连接错误！', 0);
    setTimeout(function() {
      plat_common.closeDialog();
    }, 2000);
  });
};
//填充查询结果到页面
function fillHtmlToTuiHuoPage(meterList) {
  var newHtml = '',
    i = 0,
    l = meterList.length,
    curr_totalNum = $('#tuihuoTotalNum').html(),
    totalNum = Number(curr_totalNum) + Number(l);
  for (; i < l; i++) {
    newHtml += '<li class="float">' +
      '<span class="checkbox flex"></span>' +
      '<div class="flex info">' +
      '<div class="float">' +
      '<div class="flex">' +
      '<span>资产编号：</span>' +
      '<span>' + meterList[i].ASSET_NO + '</span>' +
      '</div>' +
      '<div class="flex">' +
      '<span>类别：</span>' +
      '<span>' + meterList[i].SORT_CODE + '</span>' +
      '</div>' +
      '</div>' +
      '<div class="float">' +
      '<div class="flex">' +
      '<span>类　　型：</span>' +
      '<span>' + meterList[i].TYPE_CODE + '</span>' +
      '</div>' +
      '</div>' +
      '<div class="float">' +
      '<div class="flex">' +
      '<span>生产厂家：</span>' +
      '<span>' + meterList[i].MANUFACTURER + '</span>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '</li>';
  };
  $('#tuihuoTotalNum').html(totalNum);
  $('#tuihuoScroll ul').append(newHtml);
};
//填充查询结果到详细弹窗
function fillHtmlToTuiHuoDetailPage(meter) {
  var newHtml = '<div class="scrappingArea lineH50">' +
    '资产编号：' + meter.ASSET_NO + '<br/>' +
    '生产厂家：' + meter.MANUFACTURER + '<br/>' +
    '类别：' + meter.SORT_CODE + '<br/>' +
    '类型：' + meter.TYPE_CODE + '<br/>' +
    '电压：' + meter.VOLT_CODE + '<br/>' +
    '电流：' + meter.RATED_CURRENT + '<br/>' +
    '接线方式：' + meter.WIRING_MODE + '<br/>' +
    '准确度等级：' + meter.AP_PRE_LEVEL_CODE + '<br/>' +
    '状态：' + meter.CUR_STATUS_CODE + '<br/>' +
    '</div>';
  $('#tuihuoDetailPop').html(newHtml);
};
//2秒提示框
function showDialogOfSecend(str) {
  plat_common.loadDialog(str, 0);
  setTimeout(function() {
    plat_common.closeDialog();
  }, 2000);
};
//返回点击的目标
function checkIndex(list, str, currStr) {
  var l = list.length;
  for (var i = 0; i < l; i++) {
    if (list[i][str] == currStr) {
      return i;
    }
  }
};
//获取选中的个数
function getSelectedMeterLength() {
  var selectedLength = $('#tuihuoScroll li .checked').length;
  $('#tuihuoSelectNum').html(selectedLength);
};
//蓝牙扫描
function get_barcode(barcode) {
  var barcode = business_com.dealWithAssetNO(barcode),
    regExp1 = /^\d{10}/,
    regExp2 = /^[A-Z|a-z]+[0-9]+$/,
    asset_no = $('#tuihuo_asset'),
    asset_no_bng = $('#tuihuo_asset_bng'),
    asset_no_end = $('#tuihuo_asset_end');
  if (barcode.length == 10 && regExp1.test(barcode) || regExp2.test(barcode)) {
    if (asset_no.hasClass('scanBorder')) {
      asset_no_bng.val('');
      asset_no_end.val('');
      asset_no.val('');
      //扫描即追加该资产号到列表中
      var index = checkAssetNoRepeat(barcode);
      if (index !== undefined) {
        showDialogOfSecend('此电表已在列表中！');
      } else {
        fillAssetNoToPage(barcode);
      }
    } else if (asset_no_bng.hasClass('scanBorder')) {
      asset_no.val('');
      asset_no_bng.val(barcode);
    } else if (asset_no_end.hasClass('scanBorder')) {
      asset_no.val('');
      asset_no_end.val(barcode);
    }
  } else {
    showDialogOfSecend('资产编号必须是10位！')
  }
};
//蓝牙上下左右事件
function key_press(num) {
  var inputArr = [$('#tuihuo_asset'), $('#tuihuo_asset_bng'), $('#tuihuo_asset_end')];
  for (var i = 0, l = inputArr.length; i < l; i++) {
    if (inputArr[i].hasClass('scanBorder')) {
      inputArr[i].removeClass('scanBorder');
      num == true ?
        i == 0 ? inputArr[l - 1].addClass('scanBorder') : inputArr[i - 1].addClass('scanBorder') :
        i == l - 1 ? inputArr[0].addClass('scanBorder') : inputArr[i + 1].addClass('scanBorder');
      return;
    }
  }
};
//蓝牙上
function ft_key_up() {
  key_press(true);
};
//蓝牙下
function ft_key_down() {
  key_press(false);
};
//蓝牙左
function ft_key_left() {
  key_press(true);
};
//蓝牙右
function ft_key_right() {
  key_press(false);
};
//蓝牙OK
function ft_key_ok() {
  $('#queryWithAssetNO').click();
};
//检查蓝牙连接
function blue_connectss() {
  bluetooth_conn(function(e) {
    if (e.msg == 1) {
      showToast("设备已连接!");
    } else if (e.msg == 3) {
      showToast("扫描设备未设置!");
    } else {
      showToast("连接失败!");
      showmsg("扫描设备连接失败,请重新连接扫描设备!", 1500);
    }
  });
};
//更改蓝牙连接状态
function changeState(status) {
  if (status == 0) {
    showToast("扫描设备连接已断开!");
    showmsg('扫描设备连接已断开,请重新连接扫描设备!', 1500);
  }
};
//在P_CODE表通过value值获取name属性值,type:设备类型,volt:电压,model_code:型号,MANUFACTURER:厂家,AP_PRE_LEVEL_CODE:准度度等级,SORT_CODE:电能表类别,WIRING_MODE:接线方式,RATED_CURRENT:电流,status:设备状态,设备类别：equip
function getNameByValue(type, value) {
  var arr = [];
  switch (type) {
    case "type": //设备类型
      arr = arr_type;
      break;
    case "volt": //电压
      arr = arr_volt;
      break;
    case "model_code": //型号
      arr = model_code;
      break;
    case "MANUFACTURER": //厂家
      arr = MANUFACTURER_arr;
      break;
    case "AP_PRE_LEVEL_CODE": //准度度等级
      arr = AP_PRE_LEVEL_CODE_arr;
      break;
    case "SORT_CODE": //电能表类别
      arr = SORT_CODE_arr;
      break;
    case "WIRING_MODE": //接线方式
      arr = WIRING_MODE_arr;
      break;
    case "RATED_CURRENT": //电流
      arr = RATED_CURRENT_arr;
      break;
    case "status": //设备状态
      arr = arr_stat;
      break;
    case "equip": //设备类别
      arr = arr_equip;
      break;
  }

  for (var i = 0, len = arr.length; i < len; i++) {
    var temp = arr[i];
    if (temp.value == value) {
      return temp.name;
    }
  }
  return '';
};
//18063:电压,18017:型号,18081:厂家,18009:准确度等级,18012:电能表类别,19005:接线方式,18064:电流
document.addEventListener('deviceready', function() {
  var sql = 'select code_sort_id, name, value from p_code where code_sort_id = "18063" or code_sort_id = "18017" or code_sort_id = "18081" or code_sort_id = "18009" or code_sort_id = "18012" or code_sort_id = "19005" or code_sort_id = "18064";';
  db_execut_oneSQL('dbzj.db', sql, [], function(tx, res) {
    var obj = res.rows;
    for (var i = 0, len = obj.length; i < len; i++) {
      var tempObj = obj.item(i),
        code_sort_id = tempObj.CODE_SORT_ID,
        name = tempObj.NAME,
        value = tempObj.VALUE,
        json = {
          'code_sort_id': code_sort_id,
          'name': name,
          'value': value
        };
      switch (code_sort_id) {
        case '18063':
          arr_volt.push(json);
          break;
        case '18017':
          model_code.push(json);
          break;
        case '18081':
          MANUFACTURER_arr.push(json);
          break;
        case '18009':
          AP_PRE_LEVEL_CODE_arr.push(json);
          break;
        case '18012':
          SORT_CODE_arr.push(json);
          break;
        case '19005':
          WIRING_MODE_arr.push(json);
          break;
        case '18064':
          RATED_CURRENT_arr.push(json);
          break;
      };
    };
  });
}, false);

//点击“查询资产编号”
$('#queryWithAssetNO').on('click', function() {
  if (tuihuo_flag) {
    tuihuo_flag = false;
    setTimeout(function() {
      tuihuo_flag = true;
    }, 100);
    var asset_no_bng = $('#tuihuo_asset_bng').val(),
      asset_no_end = $('#tuihuo_asset_end').val(),
      asset_no = $('#tuihuo_asset').val(),
      checkedLi = $('#tuihuoScroll li .checked'),
      asset_no_list = '',
      regExp1 = /^\d[0-9]+$/, //   /^\d{10}/
      regExp2 = /^[A-Z|a-z]+[0-9]+$/;
    if (asset_no !== '') {
      if (asset_no.length !== 10) {
        showDialogOfSecend('资产编号必须是10位！');
        return false;
      } else if (!(regExp1.test(asset_no) || regExp2.test(asset_no))) {
        showDialogOfSecend('资产编号为全数字或字母+数字！');
        return false;
      };
      var index = checkAssetNoRepeat(asset_no); //校验是否重复
      if (index === undefined) {
        $('#tuihuo_asset').val('');
        $('#selectAll').html('全选');
        fillAssetNoToPage(asset_no);
        // queryWithAssetNO(asset_no);//需要先调用updateStatusOnPage(asset_no, '正在查询……');
      } else {
        var curr_li_status = $('#tuihuoScroll li:eq(' + index + ')').find('span:last').html();
        if (curr_li_status === '资产未确认') {
          updateStatusOnPage(asset_no, '正在查询……'); //更新显示为“正在查询……”
          $('#tuihuo_asset').val('');
          $('#selectAll').html('全选');
          queryWithAssetNO(asset_no);
        } else if (curr_li_status === '正在查询……') {
          showDialogOfSecend('该电表正在查询……');
        } else {
          showDialogOfSecend('该电表已在列表中且已查询！');
        }
      }
    } else if (asset_no == '' && 　asset_no_bng == '' && asset_no_end == '') {
      if (checkedLi.length > 0) {
        var asset_no_htmlList = checkedLi.parent().find('span:eq(2)'); //.find('span:last').parents('li')
        for (var i = 0, l = asset_no_htmlList.length; i < l; i++) {
          var curr_asset_no = asset_no_htmlList[i].innerHTML,
            index = checkAssetNoRepeat(curr_asset_no);
          if (index !== undefined) {
            var curr_li_status = $('#tuihuoScroll li:eq(' + index + ')').find('span:last').html();
            if (curr_li_status === '资产未确认') {
              updateStatusOnPage(curr_asset_no, '正在查询……'); //更新显示为“正在查询……”
              asset_no_list += i == l - 1 ? curr_asset_no : (curr_asset_no + ',');
            } else if (curr_li_status === '正在查询……') {
              showDialogOfSecend('该电表正在查询……');
              return false;
            }
          }
        }
        if (asset_no_list === '') {
          showDialogOfSecend('已选择项中没有资产未确认的电表的，请选择资产未确认的电表！');
          return false;
        }
        queryWithAssetNO(asset_no_list);
        $('#tuihuo_asset').val('');
        $('#selectAll').html('全选');
      } else {
        showDialogOfSecend('请选择或输入/扫描需要查询的电表！');
        return false;
      };
    } else {
      queryWithAssetNOBngAndEnd();
      $('#selectAll').html('全选');
      $('#tuihuo_asset_bng').val('');
      $('#tuihuo_asset_end').val('');
    };
  }
});
/*
  填充资产编号到页面
 */
function fillAssetNoToPage(asset_no) {
  var newHtml = '<li class="float">' +
    '<span class="checkbox flex"></span>' +
    '<div class="flex info" style="line-height: 73px;">' +
    '<div class="float">' +
    '<div class="flex">' +
    '<span>资产编号：</span>' +
    '<span>' + asset_no + '</span>' +
    '</div>' +
    '<div class="flex" style="color: red;">' +
    '<span>资产未确认</span>' +
    '</div>' +
    '</div>' +
    '</div>' +
    '</li>',
    totalNum = Number($('#tuihuoTotalNum').html()) + 1,
    wrapperHeight = $('#tuihuoScroll').height(),
    ulHeight = $('#tuihuoScroll ul').height();
  $('#tuihuoTotalNum').html(totalNum);
  $('#tuihuoScroll ul').append(newHtml);
  if (wrapperHeight < ulHeight) {
    $('#tuihuoScroll').scrollTop(ulHeight);
  };
};
/*
  填充查询结果到页面(离线查询)
 */
function fillHtmlToTuiHuoPageForOffline(meterList) {
  var newHtml = '',
    i = 0,
    l = meterList.length;
  for (; i < l; i++) {
    var index = checkAssetNoRepeat(meterList[i].ASSET_NO);
    if (index !== undefined) {
      var liHtml = $('#tuihuoScroll li:eq(' + index + ')');
      newHtml = '<span class="checkbox flex"></span>' +
        '<div class="flex info">' +
        '<div class="float">' +
        '<div class="flex">' +
        '<span>资产编号：</span>' +
        '<span>' + meterList[i].ASSET_NO + '</span>' +
        '</div>' +
        '<div class="flex">' +
        '<span>类别：</span>' +
        '<span>' + meterList[i].SORT_CODE + '</span>' +
        '</div>' +
        '</div>' +
        '<div class="float">' +
        '<div class="flex">' +
        '<span>类　　型：</span>' +
        '<span>' + meterList[i].TYPE_CODE + '</span>' +
        '</div>' +
        '</div>' +
        '<div class="float">' +
        '<div class="flex">' +
        '<span>生产厂家：</span>' +
        '<span>' + meterList[i].MANUFACTURER + '</span>' +
        '</div>' +
        '</div>' +
        '</div>';
      liHtml.html(newHtml);
    } else {
      fillHtmlToTuiHuoPage(meterList);
    }
  };
};
/*
  校验资产编号是否存在
 */
function checkAssetNoRepeat(assetno) {
  var htmlAssetNoList = $('#tuihuoScroll li').find('span:eq(2)'),
    i = 0,
    l = htmlAssetNoList.length;
  for (; i < l; i++) {
    if (htmlAssetNoList[i].innerHTML == assetno) {
      return i;
    }
  };
};
/*
  查询事件(资产编号段)
 */
function queryWithAssetNOBngAndEnd() {
  var paramObj = {
      EQUIP_CATEG: '01'
    },
    asset_no_bng = $('#tuihuo_asset_bng').val(),
    asset_no_end = $('#tuihuo_asset_end').val(),
    regExp1 = /^\d[0-9]+$/, //   /^\d{10}/
    regExp2 = /^[A-Z|a-z]+[0-9]+$/;
  var curr_status = (asset_no_bng == '' || asset_no_end == '') ? showDialogOfSecend('资产编号段不能为空！') :
    (asset_no_bng.length == 10 && asset_no_end.length == 10) ?
    (regExp1.test(asset_no_bng) || regExp2.test(asset_no_bng)) && (regExp1.test(asset_no_end) || regExp2.test(asset_no_end)) ?
    getParamObj(asset_no_bng, asset_no_end) : showDialogOfSecend('资产编号为全数字或字母+数字！') : showDialogOfSecend('资产编号必须是10位！');

  function getParamObj(str1, str2) {
    paramObj.ASSET_NO_BNG = str1;
    paramObj.ASSET_NO_END = str2;
    return true;
  };
  if (!curr_status) {
    return;
  };
  tuihuoQuery(paramObj);
};
/*
  查询事件(资产编号)
 */
function queryWithAssetNO(asset_no) {
  var tid = business_com.tid,
    url = business_com.requestUrl,
    innerPKG = {
      'ASSET_NO': asset_no,
      'ORG_NO': localStorage.ORG_NO,
      'EQUIP_CATEG': '01'
    },
    outerPKG = {
      'MOD': '22',
      'FUN': '03',
      'PKG_TYPE': 0,
      'USR': localStorage.user_name,
      'ORG_NO': localStorage.ORG_NO,
      'PKG': innerPKG
    },
    param = {
      'FUN': '0000',
      'LEN': plat_common.getLenOfChinese(outerPKG),
      'MOD': '2022',
      'REQ': '0',
      'USR': localStorage.user_name,
      'TID': tid,
      'SSN': localStorage.SSN,
      'PKG': outerPKG
    };
  plat_common.ajax_req(url, "data", param, function(success) {
    try {
      console.log("数据返回为: " + JSON.stringify(success));
      success = JSON.parse(JSON.stringify(success));
      if (success.PKG.RET == '01') {
        $('#tuihuo_asset_bng').val('');
        $('#tuihuo_asset_end').val('');
        $('#tuihuo_asset').val('');
        var meterList = success.PKG.PKG.METER_LIST;
        var null_asset_no = success.PKG.PKG.NULL_ASSET_NO;
        if (null_asset_no !== '') {
          updateStatusOnPage(null_asset_no, '查询结果为空');
        }
        if (null_asset_no === '' && meterList.length == 0) {
          showDialogOfSecend("数据为空!");
        } else if (meterList.length !== 0) {
          tuihuoObj.queryMeterList = success.PKG.PKG.METER_LIST;
          for (var i = 0, l = tuihuoObj.queryMeterList.length; i < l; i++) {
            var meter = tuihuoObj.queryMeterList[i];
            meter.TYPE_CODE = getNameByValue('type', meter.TYPE_CODE);
            meter.CUR_STATUS_CODE = getNameByValue('status', meter.CUR_STATUS_CODE);
            meter.VOLT_CODE = getNameByValue('volt', meter.VOLT_CODE);
            meter.RATED_CURRENT = getNameByValue('RATED_CURRENT', meter.RATED_CURRENT);
            meter.MANUFACTURER = getNameByValue('MANUFACTURER', meter.MANUFACTURER);
            meter.SORT_CODE = getNameByValue('SORT_CODE', meter.SORT_CODE);
            meter.AP_PRE_LEVEL_CODE = getNameByValue('AP_PRE_LEVEL_CODE', meter.AP_PRE_LEVEL_CODE);
            meter.WIRING_MODE = getNameByValue('WIRING_MODE', meter.WIRING_MODE);
            var index = checkIndex(tuihuoObj.queryMeterList_total, 'ASSET_NO', meter.ASSET_NO);
            if (index === undefined) {
              tuihuoObj.queryMeterList_total.push(meter);
            } else {
              tuihuoObj.queryMeterList.splice(i, 1);
              i--;
              l--;
            }
          }
          if (tuihuoObj.queryMeterList.length > 0) {
            fillHtmlToTuiHuoPageForOffline(tuihuoObj.queryMeterList);
          } else {
            showDialogOfSecend('查询的结果已在列表中！');
          }
        }
        getSelectedMeterLength();
      } else {
        updateStatusOnPage(asset_no, '资产未确认');
        console.log("设备查询失败,返回码: " + success.PKG.RET);
        showDialogOfSecend(success.PKG.MSG);
      }
    } catch (e) {
      updateStatusOnPage(asset_no, '资产未确认');
      console.log("设备查询异常,原因: " + JSON.stringify(e));
      showDialogOfSecend("设备资产未确认!服务端返回数据错误!");
    }
  }, function(e) {
    updateStatusOnPage(asset_no, '资产未确认');
    console.log("设备查询失败,原因: " + JSON.stringify(e));
    plat_common.loadDialog("设备查询失败!网络连接错误!", 0);
    setTimeout(function() {
      plat_common.closeDialog();
    }, 2000);
  });
}
/*
  修改页面查询状态
 */
function updateStatusOnPage(asset_no, str) {
  var asset_no_arr = asset_no.split(','),
    i = 0,
    l = asset_no_arr.length;
  for (; i < l; i++) {
    var index = checkAssetNoRepeat(asset_no_arr[i]); //校验是否存在，可能执行成功删除
    if (index !== undefined) {
      $('#tuihuoScroll li:eq(' + index + ')').find('span:last').html(str);
      if (str === '查询结果为空') {
        $('#tuihuoScroll li:eq(' + index + ') span:eq(0)').removeClass('checked').addClass('existHidden');
      }
    }
  }
};