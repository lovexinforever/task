//加载平台工具箱
business_com.loadToolKit();
//存储箱表关系的数据
var boxAndMeterArray = [];
var boxAndMeterTemp = [];
var longTemp = '';
var latTemp = '';
//记录是否弹出了增加电能表和修改计量箱编号的弹出框
var addAssetNoIDTxt = "";
document.addEventListener("deviceready",function(){
	$("#reconsHeader p:eq(1)").html(localStorage.area+"-"+localStorage.user_name_str+"-"+localStorage.user_name);
	
	//进行蓝牙连接
	bluetooth_conn(function(e){
		if(e.msg == 1){
			showToast("设备已连接");
		}else if(e.msg==3){
			showToast("扫描设备未设置");
		}else{
			showToast("连接失败");
		}
	});
});
/**
 *拼接请求服务器的参数
 *@param pkg  业务数据 
*/
function jointAjaxData(pkg){
	var len = plat_common.getLenOfChinese(JSON.stringify(pkg));
  	return {"FUN":"0000","LEN":""+len+"","MOD":"2035","PKG":pkg,"REQ":"0","SSN":localStorage.SSN,"USR":localStorage.user_name,"TID":localStorage.TID};
}

//阻止菜单点击冒泡
var menuFlag=true;
//还原冒泡
function bubble(){
	menuFlag=false;
	setTimeout(function(){
	  menuFlag=true;
	},300)
}

/**
 *请求服务器查询当前电能表所在的计量箱下的所有电能表信息和计量箱信息
 *@assetNo 电能表资产编号
 */
function requestAllAssets(assetNo){
	var pkg = {"MOD":"05","FUN":"01","PKG_TYPE":"0","USR":localStorage.user_name,"ORG_NO":localStorage.ORG_NO,"PKG":{"METER_ASSET_NO":assetNo}};  	
	var data = jointAjaxData(pkg);
	boxAndMeterTemp = [];
	plat_common.loadDialog("箱表关系正在查询中...","1");
    plat_common.ajax_req(business_com.requestUrl,"data",data,function(result){
    	console.log(JSON.stringify(result));
    	try{
    		if(result.PKG.RET == "01"){
    			var yearProList = result.PKG.PKG.BOX_METER_INFO;
    			var proNames = [];
    			// reconstrucObj.yearProNumbers = [];
    			 if(null!= yearProList && yearProList.length!=0){
    				for(var i=0,len=yearProList.length;i<len;i++){
	    				boxAndMeterTemp.push(yearProList[i]);
	    			}
	    			var flag = true;
				    for(var i=0;i<boxAndMeterArray.length;i++){
				    	if(boxAndMeterArray[i].BOX_ASSET_NO==boxAndMeterTemp[boxAndMeterTemp.length-1].BOX_ASSET_NO){
				    		boxAndMeterArray[i] = boxAndMeterTemp[boxAndMeterTemp.length-1];
				    		flag = false;
				    		break;
				    	}
				    }
				    if(flag){
		    			setTimeout(function(){
		    				plat_common.closeDialog();
		    				var curr_wrap = $('#query_wrap_cont');
		    				$("#query_wrap_cont").find("input").val("");
							curr_wrap.next('.wrapcontent').length == 0 ? curr_wrap.after('<div class="wrapcontent stayOnRight"></div>') : curr_wrap.next();
							curr_wrap.next().load('./boxAndMeter.html', function() {
								curr_wrap.addClass('moveToLeft');
								curr_wrap.next().removeClass('stayOnRight');
								$('.homeImg').addClass('backImg');
								changeFooterActive();
							});
		    			},1000);
				    }else{
				    	plat_common.loadDialog("您查询的箱表关系记录已经存在!",0);
    				 	setTimeout(function(){plat_common.closeDialog();},2000);
				    }
    			 }else{
    				 plat_common.loadDialog("查询结果为空!",0);
    				 setTimeout(function(){plat_common.closeDialog();},2000);
    			 }
    		}else if(result.PKG.RET == "14"){
    			var msg = result.PKG.PKG.MSG;
    			if(msg.length==0)msg = "服务器返回数据异常!";
    			plat_common.loadDialog(msg,0);
    			setTimeout(function(){plat_common.closeDialog();},1500);
    		}else{
    			plat_common.loadDialog("服务器返回数据异常!",0);
    			setTimeout(function(){plat_common.closeDialog();},1500);
    		}
    	}catch(e){
    		plat_common.loadDialog("服务器返回数据异常!",0);
    		setTimeout(function(){plat_common.closeDialog();},1500);
    	}
    },function(e){
    	console.log(JSON.stringify(e));
    	plat_common.loadDialog("网络连接错误","0");
        setTimeout(function(){plat_common.closeDialog();},1500);
    },30000);
}

/**
 *根据表箱信息和获取该表箱的图片下载地址
 *@project_type 项目类型
 *@gz_box_id 表箱ID
 *@asset_no 表箱资产号
 *@successFun 请求服务器成功回调的方法(已解析到LIST的一层) 
 */
function uploadAllAssets(){
	var boxList = [];
	for(var i=0;i<boxAndMeterArray.length;i++){
		var meterList = [];
		var meterArray = boxAndMeterArray[i].METER_LIST;
		for(var j=0;j<meterArray.length;j++){
			meterList.push({"METER_ASSET_NO":meterArray[j].METER_ASSET_NO,"ORG_NO":localStorage.ORG_NO,"PDA_SN":localStorage.TID,"SYS_USER_NAME":localStorage.user_name,"LONGITUDE":meterArray[j].LONG,"LATITUDE":meterArray[j].LAT })
		}
		boxList.push({"BOX_ASSET_NO":boxAndMeterArray[i].BOX_ASSET_NO,"METER_INFO_LIST":meterList})
	}
	var pkg = {"MOD":"01","FUN":"02","PKG_TYPE":"0","USR":localStorage.user_name,"ORG_NO":localStorage.ORG_NO,"PKG":{"BOX_ASSET_NO_LIST":boxList}};
	var data = jointAjaxData(pkg);
	plat_common.loadDialog("箱表关系正在维护中...","1");
    plat_common.ajax_req(business_com.requestUrl,"data",data,function(result){
    	console.log(JSON.stringify(result));
    	try{
    		if(result.PKG.RET == "01"){
    			var msg = result.PKG.PKG.MSG;
    			plat_common.loadDialog(msg,0);
    			boxAndMeterArray = [];
    			$("#upload_num_ID").addClass("active");
    			$("#query_cont .inner_wrap_cont").html('');
    			setTimeout(function(){plat_common.closeDialog();},1500);
    		}else if(result.PKG.RET == "14"){
    			var msg = result.PKG.PKG.MSG;
    			if(msg.length==0)msg = "服务器返回数据异常!";
    			plat_common.loadDialog(msg,0);
    			setTimeout(function(){plat_common.closeDialog();},1500);
    		}else{
    			plat_common.loadDialog("服务器返回数据异常!",0);
    			setTimeout(function(){plat_common.closeDialog();},1500);
    		}
    	}catch(e){
    		plat_common.loadDialog("服务器返回数据异常!",0);
    		setTimeout(function(){plat_common.closeDialog();},1500);
    	}
    },function(e){
    	plat_common.loadDialog("网络连接错误","0");
        setTimeout(function(){plat_common.closeDialog();},1500);
    },30000);
}
function fillAssetsListHtml(){
	var arr = boxAndMeterTemp[boxAndMeterTemp.length-1];
	var meterList = arr.METER_LIST;
	var len = meterList.length;
	var htm = '';
	fillBoxInfoHtml(arr);
	for(var i=0;i<len;i++){
		htm +=singleAssetHtml(meterList[i]);
	}
	$("#meter_list >div").html(htm);
}
function singleAssetHtml(data){
	var htm ='<div class="meter_list float">'+
	    	'<div class="check_img active"></div>'+
	      '<div class="flex">'+
			  	'<div class="float">'+
		        '<div class="flex">'+
		          '<span>资产编号：</span>'+
		          '<span id="meter_asset_no_id">'+data.METER_ASSET_NO+'</span>'+
		        '</div>'+
		        '<div class="flex">'+
		          '<span>用户编号：</span>'+
		          '<span>'+data.CONS_NO+'</span>'+
		        '</div>'+
		      '</div>'+
	        '<div>'+
	        	'<span>用户名称：</span>'+
	          '<span>'+data.CONS_NAME+'</span>'+
	        '</div>'+
		  	'</div>'+
	    '</div>';
	return htm;
}
function fillBoxInfoHtml(data){
	var htm = '<div class="float">'+
		      '<div class="marg_to_right">'+
		        '<span>计量箱编号：</span>'+
		        '<span id="box_assetNo_a">'+data.BOX_ASSET_NO+'</span>'+
		      '</div>'+
		      '<div>'+
		        '<span>计量箱类别：</span>'+
		        '<span>'+returnSortName(data.BOX_SORT_CODE)+'</span>'+
		      '</div>'+
		    '</div>'+
		    '<div class="float">'+
		      '<div class="marg_to_right">'+
		        '<span>行：</span>'+
		        '<span>'+data.BOX_ROWS+'</span>'+
		      '</div>'+
		      '<div class="marg_to_right">'+
		        '<span>列：</span>'+
		        '<span>'+data.BOX_COLS+'</span>'+
		      '</div>'+
		      '<div>'+
		        '<span>材质：</span>'+
		        '<span>'+returnTypeName(data.DATA_TYPE_CODE)+'</span>'+
		      '</div>'+
		    '</div>'+
		    '<div class="float">'+
		      '<div>'+
		        '<span>安装地址：</span>'+
		        '<span>'+data.INST_LOC+'</span>'+
		      '</div>'+
		    '</div>'+
		    '<div class="float">'+
		      '<div class="marg_to_right">'+
		        '<span>经度：</span>'+
		        '<span id="longSpanID">'+undefindToEmpty(data.LONG)+'</span>'+
		      '</div>'+
		      '<div class="marg_to_right">'+
		        '<span>纬度：</span>'+
		        '<span id="latSpanID">'+undefindToEmpty(data.LAT)+'</span>'+
		      '</div>'+
		      '<div class="GPS_color" id="gps_ID">未定位</div>'+
		      '<div class="selected_meter">'+
		      	'<span>已选择：</span>'+
		      	'<span id="selected_numID">'+data.METER_LIST.length+'</span>'+
		      '</div>'+
		    '</div>';
	$("#boxInfoHtmlID").html(htm);
}
function fillBoxCountHtml(data){
	var htm = '<div>计量箱编号：<span id="box_assetNo_a">'+data.BOX_ASSET_NO+'</span></div>'+
		      '<div>计量箱类别：<span>'+returnSortName(data.BOX_SORT_CODE)+'</span></div>'+
		      '<div>行：<span>'+data.BOX_ROWS+'</span></div>'+
		      '<div>列：<span>'+data.BOX_COLS+'</span></div>'+
		      '<div>材质：<span>'+returnTypeName(data.DATA_TYPE_CODE)+'</span></div>'+
		      '<div>安装地址：<span>'+data.INST_LOC+'</span></div>'+
		      '<div>经度：<span></span>'+undefindToEmpty(data.LONG)+'</div>'+
		      '<div>纬度：<span></span>'+undefindToEmpty(data.LAT)+'</div>';//
	$("#box_cont .box_inner_cont").html(htm);
}
function undefindToEmpty(v){
	if(v==undefined||v=="undefined")return '';
}
/**
 * 解析数据并填充到上装箱表关系的页面
 */
function fillUploadBoxListHtml(){
	var len = boxAndMeterArray.length;
	var htm = '';
	for(var i=0;i<len;i++){
		htm +='<div class="upload_list float">'+
	  			'<div class="list_num_div float box_do_center">'+(i+1)+'</div>'+
	  			'<div class="flex float box_do_center">'+
	  				'<div>计量箱号：</div>'+
	  				'<div>'+boxAndMeterArray[i].BOX_ASSET_NO+'</div>'+
	  			'</div>'+
	  			'<div class="flex float box_do_center">'+
	  				'<div>电表数：</div>'+
	  				'<div class="meter_num">'+boxAndMeterArray[i].METER_LIST.length+'</div>'+
	  			'</div>'+
	  		'</div>';
	}
	$("#query_cont .inner_wrap_cont").html(htm);
}
/**
 * 根据计量箱的材质code获取材质名称
 */
function returnTypeName(code){
	if(code=="01")return "铁";
	if(code=="02")return "不锈钢";
	if(code=="03")return "合金";
	if(code=="04")return "塑料";
	if(code=="05")return "木质";
	if(code=="06")return "全钢";
	if(code=="99")return "其他";
	
}
/**
 * 根据计量箱的类别code获取类别名称
 */
function returnSortName(code){
	if(code=="01")return "单体式";
	if(code=="02")return "整体式";
	if(code=="03")return "虚拟表箱";
	
}
/**
 * 扫描终端扫描的回调方法
 */
function get_barcode(barcode){
	 barcode = business_com.dealWithAssetNO(barcode);
	 if(addAssetNoIDTxt.length!=0){
	 	 $(addAssetNoIDTxt).val(barcode);
	 }else{
		 $("#query_wrap_cont").find("input").val(barcode);
		 requestAllAssets(barcode);
	 }
}
