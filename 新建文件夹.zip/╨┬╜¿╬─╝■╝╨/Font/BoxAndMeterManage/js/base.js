// 查询/上装页
var cont_h = plat_common.getHeight() - 102 - 104 - 86;
$('.wrapcontent >.content').height(cont_h);
$('#query_cont .inner_cont .inner_wrap_cont').height(cont_h - 36 - 8);
// 查询按钮
$('#query_btn').live('click', function() {
	var no = $("#query_wrap_cont").find("input").val();
	if(no.length==0){
	 	plat_common.loadDialog("电能表资产编号不能为空！","0");
        setTimeout(function(){plat_common.closeDialog();},1500);
	 }else if(no.length==10){
	 	requestAllAssets(no);
	 }else{
	 	plat_common.loadDialog("电能表资产编号输入不合法！","0");
        setTimeout(function(){plat_common.closeDialog();},1500);
	 }
});
$("#uploadBtnID").live('click',function(){
	if(boxAndMeterArray.length==0){
		plat_common.loadDialog("没有箱表关系进行维护！","0");
        setTimeout(function(){plat_common.closeDialog();},1500);
	}else{
		var len  = boxAndMeterArray.length;
		navigator.notification.confirm("共有 "+len+" 个计量箱，确认要维护这"+len+"个箱表关系吗？", function(index_s){
           if(index_s==1){
               uploadAllAssets();
           }
        }, "提示", "是,否");
		
	}
});

//返回
$('header').on('click', '.homeImg', function() {
	if (!$(this).hasClass('backImg')) {
		if(boxAndMeterArray.length!=0){
			var len = boxAndMeterArray.length;
			navigator.notification.confirm("共有 "+len+" 个计量箱，确认要放弃吗？", function(index_s){
	           if(index_s==1){
	               closeTools();
	           }
	        }, "提示", "是,否");
		}else{
			closeTools();
		}
		return;
	};
	var curr_wrap = $('.wrapcontent:last');
	curr_wrap.addClass('stayOnRight');
	curr_wrap.prev().removeClass('moveToLeft');
	changeFooterActive(true);
	setTimeout(function() {
		curr_wrap.remove();
		if ($('.wrapcontent').length == 1) {
			$('.homeImg').removeClass('backImg');
			addAssetNoIDTxt = "";
		}
	}, 500);
});

//切换footer
function changeFooterActive(flag) {
	var index = 0;
	var curr_page = $('footer .flex.active');
	var curr_page_index = curr_page.index();
	curr_page_index = curr_page_index > 3 ? 0 : curr_page_index;
	index = curr_page_index / 2 + 1;
	curr_page.removeClass('active');
	if (flag) {
		index = curr_page_index / 2 - 1;
	}
	$('footer .flex:eq(' + index + ')').addClass('active');;
};
