$("#ydjc_loginuser_nav_bl").html("档案核查-用户列表");
var yj_c_cons_list_temp=new Array();//界面用户列表数据集合

document.addEventListener("deviceready", function() {
	 queryUserList(sessionStorage.fvAppNo);
}, false);

/**
 * 返回
 */
function ydjc_loginuser_bl_back(){
	changepage("../../BasicInfoVerify/Businesslist/html/business_list.html");
}

/**
 * 跳转到用户基础信息
 * @param  consCode 用户类别  高压 低压
 */
function goto_userbaseinfo_html(consCode){
	 yj_c_cons_list_temp=null;
	 if(sessionStorage.fvActCode =="0337002"){
	    changepage("../../BasicInfoVerify/Checkuserinfo/Userbaseinfo/html/Userbaseinfo.html");
	 }else{
    	changepage("../../BasicInfoVerify/LowPressureCheck/html/LowPressureCheck.html");
	 }
}
/**
 * 查询用户列表
 * @param app_no
 */
function queryUserList(app_no,where){
	if(!where){
		where = "";
	}
    var sql="select * from P_ACT_CONS where APP_NO=?  "+where+" order by CONS_NO ";
    
	fvPubUI.fvLoading();
	db_execut_oneSQL("dahc.db",sql,[app_no],sucessCB_1,failCB_1);
	
	function sucessCB_1(tx,res){
		 var len = res.rows.length;
		 if(len>0){
			 initUserList(res.rows)
		 }else{
			 sendUserList(app_no);
		 }
	}
	function failCB_1(e){
		fvPubUI.fvMsgShow("查询移动终端数据库失败");
	}
}

/**
 * 请求用户列表
 */
function sendUserList(appNo){
	fvPubUI.fvLoading();
	sendUserListInstance({
		appNo : appNo,
		sysUserName : sessionStorage.user_name,
		callback : function(e) {
			reMsgDeal(e, function(){
				queryUserList(sessionStorage.fvAppNo);
			});}
	});
}

/**
 * 用户下载
 */
function downUserData(consIds,consNos,appNos,sucess_dowanload){
	var type='';
	if(sessionStorage.fvActCode =="0337002"){//高压
		type = "000008";
	}else{
		type = "000004";
	}
	fvPubUI.fvLoading();
	sendDownUserInstance({
		consId : consIds,
		consNo : consNos,
		appNo : appNos,
		type : type,
		sysUserName : sessionStorage.user_name,
		callback : function(e) {
			if(e.flag == -1){
				sucess_dowanload(e.msg);
			}else{
				if(type =="000008"){//高压
					updateMOBILE_EQUIP_ID(sucess_dowanload);
				}else{
					sucess_dowanload(1);
				}
			}
		}
	});
}

/**
 * 初始化用户列表
 * @param {} tx
 * @param {} res
 */
function initUserList(data){
	sessionStorage.fvConsInfo="";
	try{
	var len = data.length;
	if(len==0){
	    if(refresh_flag == "14"){
	          fvPubUI.fvMsgShow("该工单下用户检查工作均已执行完毕");
	    }else{
		      fvPubUI.fvMsgShow("未查询到数据");
    		 return;
	    }
	}
    var rueslt="";
    $("#userlist_html_content").html("");
    
	for(var i=0;i<len;i++){
	    yj_c_cons_list_temp[i]={"cons_id":data.item(i).CONS_ID,"cons_no":data.item(i).CONS_NO,"cons_sort_code":data.item(i).CONS_SORT_CODE,"rrio_code":data.item(i).RRIO_CODE,"downloading_type":data.item(i).DOWNLOADING_TYPE};
             rueslt+='<div class="fvUserList displayflex userlist">'+
                '<div class="boxflex_01 displayflexvertical" onclick="userlist_goto_ubi_01('+i+')">'+
                    '<div class="displayflex">'+
                       ' <div class="fvLinkIcon"></div>'+
                        '<div class="boxflex_01 displayflexvertical">'+
                         '   <div class="boxflex_01 fvGreenFont"><span>用户编号：'+data.item(i).CONS_NO+'</span></div>'+
                          '  <div class="boxflex_01"><span>用户名称：'+data.item(i).CONS_NAME+'</span></div>'+
                       ' </div>'+
                   ' </div>'+
                   '<div class="displayflexvertical">'+
                    '    <div class="boxflex_01"><span>用户分类：'+getcons_sort_code(data.item(i).CONS_SORT_CODE)+'</span></div>'+
                     '   <div class="boxflex_01"><span>计量点地址：'+data.item(i).ELEC_ADDR+'</span></div>'+
                  ' </div>'+
               ' </div>'+
                '<div><img id="ydjcimg_'+data.item(i).CONS_ID+"_"+data.item(i).CONS_NO+'"  onclick ="dowanload_one_data_userlist(this.id)" src="'+init_download_img_userlist(data.item(i).DOWNLOADING_TYPE,data.item(i).CONS_ID)+'" class="img_downloadover"/></div>'+
           ' </div>';
	}
	$("#userlist_html_content").html(rueslt);
	fvPubUI.fvLoadingClose();
	
    }catch(e){
		fvPubUI.fvLoadingClose();
	}
}

/**
 * 点击一个用户列表，跳转到用户信息页面
 * 同时保存选中的用户信息
 * dtl_id=工单id, cons_id=用电客户ID, cons_no=用户编号, cons_sort_code=用户分类中文,
 * rrio_code=重要性等级中文, elec_type_code=用电类别中文, cr_id=检查结果标识
 */
 function userlist_goto_ubi_01(i){
     //当数据包未下载，不能跳转到用检首页
	 if(yj_c_cons_list_temp[i].downloading_type==0){
		  fvPubUI.fvMsgShow("请先下载用户数据包");
		  return;
	 }
	// 用户分类对应的中文
	yj_c_cons_list_temp[i]["cons_sort_code_str"]=getcons_sort_code(yj_c_cons_list_temp[i].cons_sort_code);
	// 重要性等级对应的中文
	yj_c_cons_list_temp[i]["rrio_code_str"]=getrrio_code(yj_c_cons_list_temp[i].rrio_code);
	var rrio_code=yj_c_cons_list_temp[i].rrio_code;
	if(rrio_code=="" || rrio_code==null || rrio_code=="null"){
		rrio_code="0";
	}else{
		rrio_code="1";
	}
   yj_c_cons_list_temp[i].rrio_code=rrio_code;
   sessionStorage.fvConsInfo=JSON.stringify(yj_c_cons_list_temp[i]);
   goto_userbaseinfo_html(yj_c_cons_list_temp[i]["cons_sort_code_str"]);
}
/**
 *刷新
 */
function refresh_userlist_goto(){
	sendUserList(sessionStorage.fvAppNo);
}

/**
 * 用户列表筛选
 * @returns
 */
$("#ydjc_shaixuan_userlist_show_id").click(function(){
    $("#ydjc_userlist_cons_sort_code").val(sessionStorage.CONS_SORT_CODEsx);
    $("#ydjc_userlist_isfishy").val(sessionStorage.ISFISHYsx);
    $("#ydjc_userlist_rrio_code").val(sessionStorage.RRIO_CODEsx);
    $("#ydjc_userlist_cons_no").val(sessionStorage.CONS_NOsx);
    $("#ydjc_userlist_cons_name").val(sessionStorage.CONS_NAMEsx);
    $("#ydjc_userlist_meas_mode").val(sessionStorage.MEAS_MODEsx);
    $("#ydjc_userlist_volt_code").val(sessionStorage.VOLT_CODEsx);
    $("#ydjc_userlist_downloading_type").val(sessionStorage.DOWNLOADING_TYPEsx);
    $("#ydjc_userlist_done_type").val(sessionStorage.PLAN_STATUS_CODEsx);
    $("#ydjc_userlist_ydzyxj_type").val(sessionStorage.YDZYXJ_TYPEsx);
	$("#ydjc_shuaixuan_userlist_show").show();
});

/**
 * 取消
 */
function ydjc_shuaixuan_userlist_calce(){
	$("#ydjc_shuaixuan_userlist_show").hide();
}

/**
 * 确定
 */
function ydjc_shuaixuan_userlist_close(){
	//当前列表长度为0、不能筛选
	if(yj_c_cons_list_temp.length==0){
		 $("#yxzypt_msg").html("列表为空不能筛选");
		 onchange_val();
		 $("#yxzypt_dailog").show();
		 $("#ydjc_shuaixuan_userlist_show").hide();
		 return;
	}
	//用户分类
    var CONS_SORT_CODE=$("#ydjc_userlist_cons_sort_code").attr("name");
    //是否可疑
    var ISFISHY=$("#ydjc_userlist_isfishy").attr("name");
    //重要等级
    var RRIO_CODE=$("#ydjc_userlist_rrio_code").attr("name");
    //用户编号
    var CONS_NO=$("#ydjc_userlist_cons_no").val();
    //用户名称
    var CONS_NAME=$("#ydjc_userlist_cons_name").val();
    //计量方式
    var MEAS_MODE=$("#ydjc_userlist_meas_mode").attr("name");
    //电压等级
    var VOLT_CODE=$("#ydjc_userlist_volt_code").attr("name");
    //下装状态
    var DOWNLOADING_TYPE=$("#ydjc_userlist_downloading_type").attr("name");
    //是否需要使用移动作业终端巡检
    var YDZYXJ_TYPE=$("#ydjc_userlist_ydzyxj_type").attr("name");
    var where={"MEAS_MODE":MEAS_MODE,"VOLT_CODE":VOLT_CODE,"CONS_SORT_CODE":CONS_SORT_CODE,"ISFISHY":ISFISHY,"RRIO_CODE":RRIO_CODE,"DOWNLOADING_TYPE":DOWNLOADING_TYPE};
    var wsql=proce_json_where_ul(where,"cons");
    if(CONS_NAME=="" || CONS_NAME==null || CONS_NAME=="null"){
    }else{
    	wsql+=" AND cons.CONS_NAME like '%"+CONS_NAME+"%' ";
    }
    if(CONS_NO=="" || CONS_NO==null || CONS_NO=="null"){
    }else{
    	wsql+=" AND cons.CONS_NO like '%"+CONS_NO+"%' ";
    }
    
    //执行状态
    var PLAN_STATUS_CODE=$("#ydjc_userlist_done_type").attr("name");
    if(PLAN_STATUS_CODE=="" || PLAN_STATUS_CODE==null || PLAN_STATUS_CODE=="null"){
    }else if(PLAN_STATUS_CODE == "05"){
        wsql+=" AND cons.UPLOADING_TYPE = '1' ";
    }else{
        wsql+=" AND plan_det.PLAN_STATUS_CODE like '%"+PLAN_STATUS_CODE+"%' ";
    }
    //是否需要使用移动作业终端巡检
    if(YDZYXJ_TYPE == "01"){//需要使用终端
        wsql+= " AND ( rrio_code !='' and rrio_code notnull " + 
        " OR volt_code in ('AC05001','AC02201','AC01101','AC00351') "+
        " OR (volt_code in ('AC00201','AC00101') AND meas_mode = 1 ))";
    }else if(YDZYXJ_TYPE == "02"){//不需要
         wsql+= " AND  (rrio_code ='' or rrio_code isnull) " + 
        " AND volt_code in ('AC03802','AC02202','AC00201','AC00101')"+
        " AND meas_mode != 1 ";
    }
    
    sessionStorage.CONS_SORT_CODEsx=$("#ydjc_userlist_cons_sort_code").val();
    sessionStorage.ISFISHYsx=$("#ydjc_userlist_isfishy").val();
    sessionStorage.RRIO_CODEsx=$("#ydjc_userlist_rrio_code").val();
    sessionStorage.CONS_NOsx=$("#ydjc_userlist_cons_no").val();
    sessionStorage.CONS_NAMEsx=$("#ydjc_userlist_cons_name").val();
    sessionStorage.MEAS_MODEsx=$("#ydjc_userlist_meas_mode").val();
    sessionStorage.VOLT_CODEsx=$("#ydjc_userlist_volt_code").val();
    sessionStorage.DOWNLOADING_TYPEsx=$("#ydjc_userlist_downloading_type").val();
    sessionStorage.PLAN_STATUS_CODEsx=$("#ydjc_userlist_done_type").val();
    sessionStorage.YDZYXJ_TYPEsx=$("#ydjc_userlist_ydzyxj_type").val();
	$("#ydjc_shuaixuan_userlist_show").hide();
	queryUserList(sessionStorage.fvAppNo,wsql);
}
/**
 * 显示筛选
 * @param type
 * @returns
 */

$("#ydjc_userlist_cons_sort_code").fvSelect({
    callback:function(obj){/*alert(obj.selectobj.value+"---"+obj.selectobj.name)*/},
    list:[{value:"00",name:"考核"},{value:"01",name:"高压"},{value:"02",name:"低压非居民"},{value:"03",name:"低压居民"}]
});

$("#ydjc_userlist_rrio_code").fvSelect({
    callback:function(obj){},
    list:[{value:"01",name:"特级重要用户"},{value:"02",name:"一级重要用户"},{value:"03",name:"二级重要用户"},{value:"04",name:"临时性重要用户"}]
});

$("#ydjc_userlist_downloading_type").fvSelect({
    callback:function(obj){},
    list:[{value:"1",name:"已下装"},{value:"0",name:"未下装"},{value:"02",name:"低压非居民"},{value:"03",name:"低压居民"}]
});

$("#ydjc_userlist_done_type").fvSelect({
    callback:function(obj){},
    list:[{value:"08",name:"已执行"},{value:"07",name:"已打印"},{value:"06",name:"已派工"},{value:"05",name:"未上装"}]
});


/**
 * 单个数据包下载
 * @param consId
 */
var thisConsId="";
function dowanload_one_data_userlist(consId){
    $("#download_confirm").html("确定下载?");
	$("#confirm_dailog_download").show();//显示确定框
	thisConsId=consId;
}
//单个下载
 function download_onedata(consId){
     $("#"+consId).attr("src","../../Util/Images/dowanload_ing.gif");//改变图标下载状态
     var mconsId = consId.split("_")[1];
     var consNo = consId.split("_")[2];
     downUserData(mconsId,consNo,sessionStorage.fvAppNo,function(msg){
         if(msg==1){
             refresh_flag="";
             queryUserList(sessionStorage.fvAppNo);
         }else{
            $("#"+consId).attr("src","../../Util/Images/download3.png");
            fvPubUI.fvMsgShow(msg);
         }
     });
 }
//确定下载
function download_onedata_ok(){
    $("#confirm_dailog_download").hide();//隐藏确定框
    download_onedata(thisConsId)
    thisConsId="";
}

//取消下载
function confirmConcle_download(){
    $("#confirm_dailog_download").hide();//隐藏确定框
    this_consid="";
}
/**
 * 初始化下载图标
 */
function init_download_img_userlist(type,dtl_id){
    var tempsession = localStorage["val"+sessionStorage.fvAppNo+dtl_id];//处理中
    var tempupload = localStorage["uploading"+sessionStorage.fvAppNo+dtl_id]//处理完成
	if(type==1){// 已下载
	    if(tempsession && tempsession.split(",")[7] == 1){
	        if(tempupload && tempupload == 1){
	             return "../../Util/Images/chuliwancheng.png";//处理完成
	        }
	        return "../../Util/Images/chulizhong.png";//处理中
	    }
		return "../../Util/Images/downloadover.png";
	}else if(type==0){// 未下载
	   return "../../Util/Images/download3.png";
	}
}
/**
 * 用户分类中文翻译 01 高压，02 低压非居民，03 低压居民
 */
function getcons_sort_code(csc){
	if(!csc){
      return "";    
    }else if(csc=="00"){
        return "考核";
    }else if(csc=="01"){
        return "高压";
    }else if(csc=="02"){
        return "低压非居民";
    }else if(csc=="03"){
        return "低压居民";
    }
    return csc;
}
/**
 * 重要性等级中文翻译 01=特级重要用户 02=一级重要用户 03=二级重要用户 ""=普通用户
 */
function getrrio_code(rc){
	if(!rc){
		return "";
	}else if(rc=="01"){
	   return "特级重要用户";	
	}else if(rc=="02"){
	   return "一级重要用户";	
	}else if(rc=="03"){
	   return "二级重要用户";	
	}else if(rc=="04"){
       return "临时性重要用户"; 
    }
   return rc;
}
/**
 * 处理状态中文翻译 08=已执行 07=未执行(已打印)
 * UPLOADING_TYPE 如果等于1，表示检查结果维护点击上装按钮，但是上装失败
 */
function getplan_status_code(upt,uploading_type){
    if(uploading_type == "1"){
        return "未上装";
    }
	if(upt=="07"){
		return "已打印";
	}else if(upt=="08"){
		return "已执行";
	}else if(upt=="06"){
		return "已派工";
	}else{
		return "";
	}
}

/**
 * 根据查询条件返回拼接后的查询条件string: and key='value' and .......
 */
function proce_json_where_ul(str,pix){
	var rst=" ";
	for(i in str){
		var s=str[i];
		if(s=="" || s==null || s=="null"){
			
		}else{
			rst+=("and "+pix+"."+i+"='"+s+"' ");
		}
	}
   return rst;
}

 /**
  * 更新设备关联MOBILE_EQUIP_ID
  * @param {} callback
  */
 function updateMOBILE_EQUIP_ID(callback){
 	var dahc = window.sqlitePlugin.openDatabase("dahc.db", "1.0","dahc.db", 10*1024*1024);
	 var select_MOBILE_EQUIP_ID="SELECT MOBILE_EQUIP_ID,EQUIP_ID,TYPE_CODE FROM YJ_C_EQUIP_RUN";
	 var update_list=new Array();
	 dahc.transaction(function(tx){
		 tx.executeSql(select_MOBILE_EQUIP_ID,[],function(tx,res){
			 if(res.rows.length==0){
				 callback(1);//没有查询到设备id，关闭加载效果。
				 return;
			 }
			 //01自备电厂
			 var update_01="UPDATE YJ_C_SPARE_POWER SET MOBILE_EQUIP_ID=";
			 //04:避雷器
			 var update_04="UPDATE YJ_C_ARRESTER SET MOBILE_EQUIP_ID=";
			 //05:继电保护装置
			 var update_05="UPDATE YJ_C_RELAY_PROTECT_DEV SET MOBILE_EQUIP_ID=";
			 //06:断路器
			 var update_06="UPDATE YJ_C_BREAKER SET MOBILE_EQUIP_ID=";
			 //07:无功补偿设备
			 var update_07="UPDATE YJ_C_RPC_EQUIP SET MOBILE_EQUIP_ID=";
			 //08:自备应急电源
			 var update_08="UPDATE YJ_C_SPARE_GENERATOR SET MOBILE_EQUIP_ID=";
			//09:电缆
			 var update_09="UPDATE YJ_C_JCDDL SET MOBILE_EQUIP_ID=";
			//10:变压器-高压电机
			 var update_10="UPDATE YJ_C_MOTER SET MOBILE_EQUIP_ID=";
			//20:架空线
			 var update_20="UPDATE YJ_C_DL SET MOBILE_EQUIP_ID=";
			//21:负荷开关
			 var update_21="UPDATE YJ_C_SWITCH SET MOBILE_EQUIP_ID=";
			//22:高低压成套(柜)
			 var update_22="UPDATE YJ_C_HDVCT SET MOBILE_EQUIP_ID=";
			//23:直流充电桩
			 var update_23="UPDATE YJ_C_CHARGER_ZL SET MOBILE_EQUIP_ID=";
			//24:交流充电桩
			 var update_24="UPDATE YJ_C_CHARGER_JL SET MOBILE_EQUIP_ID=";
			 
			 for(var i=0;i<res.rows.length;i++){
				 var item=res.rows.item(i);
				 if(!item.EQUIP_ID || item.EQUIP_ID=="" || item.EQUIP_ID=="null"){
				 }else{
					 if(item.TYPE_CODE=="01"){
						 update_list.push(update_01+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
					 }
					 
					 else if(item.TYPE_CODE=="04"){
						 update_list.push(update_04+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
					 }
					 
					 else if(item.TYPE_CODE=="05"){
						 update_list.push(update_05+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
					 }
					 
					 else if(item.TYPE_CODE=="06"){
						 update_list.push(update_06+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
					 }
					 
					 else if(item.TYPE_CODE=="07"){
						 update_list.push(update_07+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
					 }
					 
                     else if(item.TYPE_CODE=="08"){
                    	 update_list.push(update_08+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
					 }
					 
                     else if(item.TYPE_CODE=="09"){
                    	 update_list.push(update_09+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
					 }
                     else if(item.TYPE_CODE=="03"){
                    	 update_list.push(update_10+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
					 }
                     else if(item.TYPE_CODE=="20"){
                    	 update_list.push(update_20+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
					 }
                     else if(item.TYPE_CODE=="21"){
                    	 update_list.push(update_21+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
					 }
                     else if(item.TYPE_CODE=="22"){
                    	 update_list.push(update_22+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
					 }
                     else if(item.TYPE_CODE=="23"){
                    	 update_list.push(update_23+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
					 }
                     else if(item.TYPE_CODE=="24"){
                    	 update_list.push(update_24+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
					 }
				 }
			 }
			 //开始更新
			  dahc.transaction(function(tx){
				  var exe_sum_error=0;
				  var exe_sum_sucess=1;
				 for(var u in update_list){
					 if(exe_sum_error>0){
						 callback("批量更新终端数据库失败");
						 break;
					 }
				   tx.executeSql(update_list[u],[],function(tx,res){
					   if(exe_sum_sucess==update_list.length){
						   callback(1);
						   return;
					   }
					   exe_sum_sucess++;
				   },function(e){
					   callback("更新移动终端设备关联表失败");
					   exe_sum_error++;
				   });
				 }
			 });
		 },function(e){
			 callback("查询移动终端设备表失败");
		 });
		 
	 });
 }
