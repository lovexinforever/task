var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);

var fvLowPC = {

	// 用户ID CONS_ID 申请编号APP_NO
	WHERE : [fvConsInfo.cons_id, sessionStorage.fvAppNo],

	// 用户ID CONS_ID 申请编号APP_NO
	KEY : ["CONS_ID", "APP_NO"],
	
	// 用电地址细信息
	fvAddress : "",
	
	// C_CONS_DY : UI上元素的ID
	consDyIDArr : fvPubUI.returnHtmlIdArr("[id*='fv_']"),

	// C_CONTACT : UI上元素的ID
	contactIDArr : fvPubUI.returnHtmlIdArr("[id*='fv1_']"),

	// C_CERT : UI上元素的ID
	certIDArr : fvPubUI.returnHtmlIdArr("[id*='fv2_']"),

	// C_CUST_AGREEMENT : UI上元素的ID
	custIDArr : fvPubUI.returnHtmlIdArr("[id*='fv3_']"),

	// C_CERT数据库 证件ID是否存在
	flagCert : null,

	/**
	 * 初始化标题和点击事件
	 */
	initHeadClick : function() {
		// 标题
		$("#ydjc_loginuser_nav_bl").html("低压用户档案信息核查");

		// 加载用检用户信息
		$("#fvLowpcCons").html(fvConsInfo.cons_no);
		
		var headInfo = getHeaderInfo(fvConsInfo.cons_sort_code_str,fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str);
		
		$("#fvLowpcConsInfo").html(headInfo);

		// 保存
		$("#fvLowPCheckSave").click(function() {
			fvLowPC.upLoad(function() {
				fvPubUI.fvMsgShow("保存成功");
			});
		 });
		 
		// 补签
		$("#contractReSign").click(function() {
			fvLowPC.contractSign("385");
		 });
		 
		// 续签
		$("#contractContineSign").click(function() {
			fvLowPC.contractSign("384");
		 });
		 
		// 终止
		$("#contractEnding").click(function() {
			fvLowPC.contractSign("386");
		 });
		 
		 //新增联系人
		 $("#addContactMan").click(function(){
		 	changepage("../../BasicInfoVerify/CheckContactInfo/html/ContactAdd.html");
		 });
		 
		 
		 // 身份证明
		 $("#fvTakeCardPhoto").click(function() {
			takePhoto("fvPhotoCardShow", "01",fvConsInfo.cons_no);
		 });
		 // 身份证明上装
		 $("#fvCardUpload").click(function() {
			uploadPhoto("01",fvConsInfo.cons_no);
		 });
		
		// 房产证明
		$("#fvTakeHousePhoto").click(function(){
			takePhoto("fvPhotoHouseShow", "02",fvConsInfo.cons_no);
		});
		// 房产证明上装
		 $("#fvHouseUpload").click(function() {
			uploadPhoto("02",fvConsInfo.cons_no);
		 });
		// 合同证明
		$("#fvContractBtn").click(function(){
			takePhoto("fvContractPhotoShow", "05",fvConsInfo.cons_no);
		});
		// 合同上装
		 $("#fvContractUpload").click(function() {
			uploadPhoto("05",fvConsInfo.cons_no);
		 });
		 
		//图片初始化
		var tPhotoArray =[["fvPhotoCardShow", "01"], ["fvPhotoHouseShow", "02"], ["fvContractPhotoShow", "05"]]; 
		initPhotoDisplay(tPhotoArray, fvConsInfo.cons_no);
	},

	/**
	 * 查询用电申请信息
	 */
	initQueryData : function() {
		
		fvSqlModel.queryInfo("C_ELEC_ADDR", fvLowPC.KEY, fvLowPC.WHERE,fvLowPC.querySucessBack, null);
		
		fvSqlModel.queryInfo("C_CONS_DY", fvLowPC.KEY, fvLowPC.WHERE,fvLowPC.querySucessBack, null);
				
		fvSqlModel.queryInfo("C_CONTACT", fvLowPC.KEY, fvLowPC.WHERE,fvLowPC.querySucessBack, null);
				
		fvSqlModel.queryInfo("C_CERT", fvLowPC.KEY, fvLowPC.WHERE,fvLowPC.querySucessBack, null);
				
		fvSqlModel.queryInfo("C_CUST_AGREEMENT", fvLowPC.KEY, fvLowPC.WHERE,fvLowPC.querySucessBack, null);
		
		setTimeout(function(){
			fvLowPC.bindFvSelect();
		},500);
	},

	/**
	 * 数据查询回调处理
	 */
	querySucessBack : function(tx, res) {
		
		var data = res.rows;
		
		var len = data.length;
		
		if (len > 0) {// 本地未查询
			
			var tableName = data.item(0).tableName;
			
			switch (tableName) {
				
				case "C_CONS_DY" :
				
					fvPubUI.initPageHtml('fv_', data.item(0),fvLowPC.consDyIDArr); // 初始化用户基础信息
					fvPcode.tansformCode("fv_", fvPcode.codeSortJson);// Pcode转码
					break;

				case "C_CONTACT" :
				
					fvLowPC.initContactList(data);// 初始化联系人列表
					fvPubUI.initPageHtml('fv1_', data.item(0),fvLowPC.contactIDArr); // 初始化用户基础信息中联系人信息
					fvPcode.tansformCodeOne("fv1_CONTACT_MODE", "A_29007",fvPcode.codeSortJson);// 联系人类型
					for (var i = 0; i < len; i++) {
						var theID = "listContactType" + i;
						fvPcode.tansformCodeOne(theID, "A_29007",fvPcode.codeSortJson);// 联系人列表中的 联系人类型
					}
					break;

				case "C_CERT" :// 证件信息
				
					fvLowPC.flagCert = data.item(0).CERT_ID;// 证件ID
					fvPubUI.initPageHtml('fv2_', data.item(0),fvLowPC.certIDArr); // 初始证件信息
					fvPcode.tansformCode("fv2_", fvPcode.codeSortJson);// Pcode转码
					break;

				case "C_CUST_AGREEMENT" :
				
					fvLowPC.initFileContractList(data);// 初始化合同编号列表
					fvPubUI.initPageHtml('fv3_', data.item(0),fvLowPC.custIDArr); // 初始化合同内容
					fvPcode.tansformCode("fv3_", fvPcode.codeSortJson);// Pcode转码
					
					break;
				case "C_ELEC_ADDR" :
					
					fvLowPC.fvAddress = data.item(0);
										
					break;

				default :
					break;
			}
		}
	},
	
	/**
	 * 跳转到联系人详情页面
	 * @param {} data 点击项的合同数据
	 */
	toContactEdit : function(id) {
	 	sessionStorage.fvContactId = id;
	 	changepage("../../BasicInfoVerify/CheckContactInfo/html/ContactDetail.html");
	},
	
	/**
	 * 是否设置互动联系人
	 * @param {} contactId 联系人id
	 * @param {} type 类型 0取消  1设置
	 */
	SetOrContact : function(contactId,type) {
		
		fvPubUI.fvLoading();
		
		fvSendEachContract({
			contactID : contactId,
			appNo : sessionStorage.fvAppNo,
			interactFflag : type,
			callback : function(obj) {
				
				reMsgDeal(obj, function() {
					fvSqlModel.queryInfo("C_CONTACT", fvLowPC.KEY, fvLowPC.WHERE,fvLowPC.querySucessBack, null);
					fvPubUI.fvMsgShow("操作成功");
				});
			}
		});
	},
	
	
	/**
	 * 联系人列表
	 * @param {}  contactData 联系人数据 json数组
	 */
	initContactList : function(contactData) {
		
		var contactHtml = "";
		
		if (contactData.length > 0) {
			
			for (var i = 0; i < contactData.length; i++) {
				
				contactHtml += '<div class="fvContent displayflex">'
						+ '<div class="fvManIconGreen"></div>'
						+ '<div class="boxflex_01 fvManPhone displayflexvertical"  id="'+contactData.item(i).CONTACT_ID+'" onclick="fvLowPC.toContactEdit(this.id)">'
						+ '   <div class="boxflex_01 fvGreenFont">'
						+ '<span id="listContactType'+ i+ '">'
						+ contactData.item(i).CONTACT_MODE
						+ '</span>'
						+ '<span>：'
						+ contactData.item(i).CONTACT_NAME
						+ (contactData.item(i).INTERACT_FLAG == "1"? "(互动联系人)": "") + '</span></div>'
						+ '  <div class="boxflex_01"><span>电话：</span><span>'
						+ contactData.item(i).MOBILE + '</span></div>'
						+ ' </div>';
						
				if (contactData.item(i).INTERACT_FLAG == "1") {
					
					contactHtml += '<div class="fvManCancle"  onclick="fvLowPC.SetOrContact('+contactData.item(i).CONTACT_ID+',0)"></div>';
					
				} else if (contactData.item(i).INTERACT_FLAG == "0" && contactData.item(i).CHECK_FLAG =="1") {
					
					contactHtml += '<div class="fvManSet" onclick="fvLowPC.SetOrContact('+contactData.item(i).CONTACT_ID+',1)"></div>';
				}
				contactHtml += ' </div>' + '<div class="fvTopBorder"></div>';
			}
		}
		$("#contactHtmlList").html(contactHtml);
	},
	/**
	 * 合同编号列表
	 * @param {} fileContractData 合同数据 json数组
	 */
	initFileContractList : function(fileContractData) {
		
		var fileContractHtml = "";
		
		if (fileContractData.length > 0) {
			
			for (var i = 0; i < fileContractData.length; i++) {
				
				if (i == 0) {
					fileContractHtml += '<div class="boxflex_01 fvBottomLineCur" onclick="fvLowPC.changeContract('
							+ fileContractData.item(i)+ ')"><span>合同编号'
							+ fileContractData.item(i).CONTRACT_NO
							+ '</span></div>';
					continue;
				}
				
				fileContractHtml += '<div class="boxflex_01 fvBottomLine" onclick="fvLowPC.changeContract('
						+ fileContractData.item(i)+ ')"><span>合同编号'
						+ fileContractData.item(i).MOCONTRACT_NOBILE
						+ '</span></div>';
			}
		}
		$("#fileContractList").html(fileContractHtml);
	},

	/**
	 * 点击合同编号 初始化合同内容
	 * @param {} data 点击项的合同数据
	 */
	changeContract : function(data) {

	},
	
	/**
	 * 上装数据
	 */
	upLoad : function(callback) {
		fvPubUI.fvLoading();
		
		fvLowPC.saveData();// 保存
		
		fvSendLowUser({// 上装
			updateAddr : fvElecAddress(fvLowPC.fvAddress),
			updateArgee : fvCertInfo(),
			userArchives : fvLowUserInfo(),
			callback : function(obj) {
				
				reMsgDeal(obj, function() {
					
					fvPubUI.fvMsgShow("上装成功");
				});
			}
		});
	},

	/**
	 * 保存数据
	 */
	saveData : function() {
		
		// C_CONS_DY
		var consKeyArr = {
			"tableName" : "C_CONS_DY",
			"ELEC_ADDR" : $("#fv_ELEC_ADDR").val(),
			"REAL_NAME_TYPE" : $("#fv_REAL_NAME_TYPE").attr("name"),
			"REAL_NAME_FLAG" : $("#fv_REAL_NAME_FLAG").attr("name"),
			"REAL_CONS_TYPE" : $("#fv_REAL_CONS_TYPE").attr("name")
		};
		
		// C_CERT
		var certKeyArr = {
			"CERT_TYPE_CODE" : $("#fv2_CERT_TYPE_CODE").attr("name"),
			"CERT_NAME" : $("#fv2_CERT_NAME").val(),
			"CERT_NO" : $("#fv2_CERT_NO").val()
		};
		
		var whereArr = {
			"APP_NO" : sessionStorage.fvAppNo,
			"CONS_ID" : fvConsInfo.cons_id
		};

		fvSqlModel.updateInfo(consKeyArr, whereArr, null, null);// 更新用户基础表

		if (!fvLowPC.flagCert && fvLowPC.flagCert == "") {
			
			certKeyArr = $.extend(certKeyArr, whereArr);
			var sqlList = fvSqlModel.insertInfo("C_CERT", [certKeyArr]);// 新增证件
			db_execut_oneSQL("dahc.db", sqlList[0], [], null, null);
			
		} else {
			var certTableName = {"tableName" : "C_CERT"};
			certKeyArr = $.extend(certTableName, certKeyArr);
			fvSqlModel.updateInfo(certKeyArr, whereArr, null, null);// 更新证件
		}
	},
	
	/**
	 * 发送合同相关请求
	 * @param {} type
	 * 384	合同续签, 385合同补签, 386合同终止
	 */
	contractSign : function(type){
		
		fvPubUI.fvLoading();
		
		fvSendContract({
			consId : fvConsInfo.cons_id,
			appTypeCode : type,
			callback : function(obj) {
				reMsgDeal(obj, function(msg) {
					fvPubUI.fvMsgShow(msg);
				});
			}
		});
	},
	
	/**
	 * 绑定下拉框
	 */
	bindFvSelect : function(){
		
		$("#fv2_CERT_TYPE_CODE").fvSelect({
		    callback:null,
		    list:fvPcode.codeSortJson["A_29012"]
		});
		$("#fv_REAL_NAME_TYPE").fvSelect({
		    callback:null,
		    list:fvPcode.codeSortJson["A_11248"]
		});
		$("#fv_REAL_NAME_FLAG").fvSelect({
		    callback:null,
		    list:fvPcode.codeSortJson["A_30022"]
		});
		$("#fv_REAL_CONS_TYPE").fvSelect({
		    callback:function(obj){
		        console.log("-选择了:"+obj.selectobj.value+"---"+obj.selectobj.name);
		    },
		    list:fvPcode.codeSortJson["A_11250"]
		});
	}

}


fvLowPC.initHeadClick();
fvLowPC.initQueryData();

/**
 * 返回
 */
var ydjc_loginuser_bl_back = function() {
	changepage("../../BasicInfoVerify/Userlist/html/userlist.html");
}
