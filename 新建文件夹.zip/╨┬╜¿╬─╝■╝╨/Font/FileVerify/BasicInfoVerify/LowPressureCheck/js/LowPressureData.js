//低压档案用电地址实体
var fvElecAddress =function(data) {
		var tempData = {
			"APP_NO":sessionStorage.fvAppNo,							
			"CONS_ID":fvConsInfo.cons_id,					
			"ELEC_ADDR":$("#fv_ELEC_ADDR").val(),						
			"PROVINCE_CODE":data.PROVINCE_CODE || "321",						
			"CITY_CODE":data.CITY_CODE || "321",						
			"COUNTY_CODE":data.COUNTY_CODE || "12",						
			"STREET_CODE":data.STREET_CODE || "213",						
			"VILLAGE_CODE":data.VILLAGE_CODE || "321",						
			"ROAD_CODE":data.ROAD_CODE || "213",							
			"COMMUNITY_CODE":data.COMMUNITY_CODE || "123",							
			"PLATE_NO":data.PLATE_NO || "123号"							
		}
		return tempData;
}
//证件信息实体
var fvCertInfo =function() {
		var tempData = {
			"APP_NO":sessionStorage.fvAppNo,						
			"CERT_ID":fvLowPC.flagCert || "",					
			"CERT_TYPE_CODE":$("#fv2_CERT_TYPE_CODE").attr("name"),					
			"CERT_NAME":$("#fv2_CERT_NAME").val(),						
			"CERT_NO":$("#fv2_CERT_NO").val(),			
			"CERT_EFFECT_DATE":"",						
			"CERT_EXPIRE_DATE":"",						
			"DIRECTORY":""						
		}
		return tempData;
}
//低压用户档案信息实体
var fvLowUserInfo =function() {
		var tempData = {
			"CONS_ID":fvConsInfo.cons_id,							
			"REAL_NAME_FLAG":$("#fv_REAL_NAME_FLAG").attr("name"),		
			"REAL_NAME_TYPE":$("#fv_REAL_NAME_TYPE").attr("name"),					
			"REAL_CONS_TYPE":$("#fv_REAL_CONS_TYPE").attr("name")				
		}
		return tempData;
}