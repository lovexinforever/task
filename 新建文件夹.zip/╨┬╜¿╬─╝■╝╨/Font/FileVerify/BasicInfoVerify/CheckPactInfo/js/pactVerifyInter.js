<script type="text/javascript">
/**
 * 
 * 查询接口
 *
 */
 
 var pactVerifyInter={
 	
 	/** 
 	 * 请求码
 	 * */
    REQ_CODE : {
        contractFlow:   {modNo: "2034", funcNo:	"030609"}  //发起合同流程请求码
    },
 	
	/**
	 * 发起合同流程
	 *
	 * @param {}  flow_code :382	合同新签, 384	合同续签, 385	合同补签, 386	合同终止
	 * @param {} cons_id :用户ID
	 */
	changeContractFlow:function(flow_code,cons_id){
		
		var code ;   
		var pkg ;
		
 		var obj = {};
		obj.CONS_ID= cons_id.toString();
		obj.APP_TYPE_CODE = flow_code.toString();	    
		
		console.log("发起合同流程传入参数:" +obj);
		
		code = pactVerifyInter.REQ_CODE.contractFlow;   
		pkg = fvElecVUntil.get_fv_pkg_data(code, obj);
		
		send_data(code.funcNo, code.modNo, pkg, pactVerifyInter.contractFlowSuccess, pactVerifyInter.contractFlowFail);	
	},
	
	/**
	 * 合同流程发起流程成功
	 * @param {} data 接口返回数据集合
	 */
	contractFlowSuccess:function(data){
		 
		
		console.log("合同流程发起流程成功接口返回数据:" + data);
		data = JSON.parse(data);
		
		var FLAG =data.PKG.PKG.FLAG;
		if(FLAG=='1'){
			fvPubUI.fvLoadingClose();
			fvPubUI.fvMsgShow(data.PKG.PKG.ERR_MSG+"！申请编号是："+data.PKG.PKG.APP_NO);
		}else{
			fvPubUI.fvLoadingClose();
			fvPubUI.fvMsgShow(data.PKG.PKG.ERR_MSG+"！");
		}
	},
	
	/**
	 * 合同流程发起流程失败
	 */
	contractFlowFail:function(){
		fvPubUI.fvMsgShow("合同流程发起流程失败,请重试！");
	}
	
	
 };
 </script>