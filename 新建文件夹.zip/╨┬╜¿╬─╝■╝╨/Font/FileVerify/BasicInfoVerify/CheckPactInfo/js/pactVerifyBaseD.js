<script type="text/javascript">
/**
 * 
 * 对本地数据库操作
 *
 */
 var fvElecVGBaseData={
 	//存储合同信息
 	ContractData:{},
 	// C_CUST_AGREEMENT : UI上元素的ID
	custIDArr : fvElecVUntil.returnHtmlIdArr("[id*='GF_']"),
	
 	/**
 	 * 查询本地用户数据
 	 * @param CONS_ID 查询条件
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
 	 */
 	selectGConsInfo:function(CONS_ID){
			var sql = "select c.[CONS_ID],"+
							  "c.[CONS_NO],"+
							  "c.[CONS_NAME],"+
							  "(SELECT P1.NAME FROM P_CODE P1  WHERE P1.VALUE = c.[CONS_SORT_CODE]  AND P1.CODE_SORT_ID = '29011') CONS_SORT_CODE,"+
							  "c.[ELEC_ADDR],"+
							  "(SELECT P1.NAME FROM P_CODE P1  WHERE P1.VALUE = c.[MEAS_MODE]  AND P1.CODE_SORT_ID = '19004') MEAS_MODE,"+
							  "(SELECT P1.NAME FROM P_CODE P1  WHERE P1.VALUE = c.[RRIO_CODE]  AND P1.CODE_SORT_ID = '16045') RRIO_CODE, "+
							  "(SELECT P1.NAME FROM P_CODE P1  WHERE P1.VALUE = c.[VOLT_CODE]  AND P1.CODE_SORT_ID = '10005') VOLT_CODE,"+
							  "c.[CONTRACT_CAP]"+
							  " from P_ACT_CONS  c where CONS_ID='"+CONS_ID+"' "
							  "AND APP_NO='"+ sessionStorage.fvAppNo+"'";
			db_execut_oneSQL("dahc.db", sql, [], fvElecVGBaseData.selectGConsBaseSuccess, fvElecVGBaseData.selectGElecConsInfoFail);
 	
 	},
 	
 	/**
 	 * 查询本地用户基本信息成功后调用方法
 	 * @param {} tx
 	 * @param {} res
 	 */
	selectGConsBaseSuccess:function(tx,res){
		    
 			var len = res.rows.length;
 			
			if (len == 0) {// 本地未查询
				fvPubUI.fvMsgShow("未查询到用户信息!");
			} else {
				//页面上所有元素的ID赋值
				$("#GCF_CONS_NO").html(res.rows.item(0).CONS_NO);//用户编号 div用html
				$("#GCF_CONS_NAME").html(res.rows.item(0).CONS_NAME);//用户名称
				$("#GCF_CONS_SORT_CODE").html(res.rows.item(0).CONS_SORT_CODE);//用户分类
//				$("#ELEC_TYPE_CODE").html(res.rows.item(0).ELEC_TYPE_CODE);//用户类别----------
//				$("#STATUS_CODE").html(res.rows.item(0).STATUS_CODE);//用户状态
				$("#GCF_VOLT_CODE").html(res.rows.item(0).VOLT_CODE);//供电电压
				$("#GCF_CONTRACT_CAP").html(res.rows.item(0).CONTRACT_CAP);//合同电容
				$("#GCF_RRIO_CODE").html(res.rows.item(0).RRIO_CODE);//重要性等级
				$("#GCF_MEAS_MODE").html(res.rows.item(0).MEAS_MODE); //计量方式
				$("#GCF_ELEC_ADDR").html(res.rows.item(0).ELEC_ADDR);//用电地址
				
				$("#GCF_CONS_NO").attr("NAME",res.rows.item(0).CONS_ID);//给ID为CONS_NO的DIV的NAME属性赋值，存入CONS_ID
				
				//缓存数据
				sessionStorage.CONS_NO_B=res.rows.item(0).CONS_NO;
				sessionStorage.CONS_NAME_B=res.rows.item(0).CONS_NAME;
				sessionStorage.CONS_SORT_CODE_B=res.rows.item(0).CONS_SORT_CODE;
				sessionStorage.ELEC_TYPE_CODE_B=res.rows.item(0).ELEC_TYPE_CODE;
				sessionStorage.STATUS_CODE_B=res.rows.item(0).STATUS_CODE;
				sessionStorage.VOLT_CODE_B=res.rows.item(0).VOLT_CODE;
				sessionStorage.CONTRACT_CAP_B=res.rows.item(0).CONTRACT_CAP;
				sessionStorage.ELEC_ADDR_B=res.rows.item(0).ELEC_ADDR;
				
				fvPubUI.fvLoadingClose();
			}
	},
	
	/**
	 * 查询接口失败后调用方法
	 */
	selectGElecConsInfoFail:function(){
			fvPubUI.fvLoadingClose();
 			fvPubUI.fvMsgShow("查询失败请重试!");
	},
 	
	 /**
 	 * 查询本地合同数据
 	 * @param CONS_ID 查询条件
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
 	 */
 	selectGContInfo:function(CONS_ID){
			var sql = "select CONTRACT_NO,"+
						     "(SELECT P1.NAME FROM P_CODE P1  WHERE P1.VALUE = c.[TYPE_CODE]  AND P1.CODE_SORT_ID = '12001') TYPE_CODE,"+
							 "(SELECT P1.NAME FROM P_CODE P1  WHERE P1.VALUE = c.[STATUS_CODE]  AND P1.CODE_SORT_ID = '12002') STATUS_CODE,"+
						     "SIGN_DATE,"+
						     "END_DATE "+
						     "FROM C_CUST_AGREEMENT c where  CONS_ID='"+CONS_ID+"' "+
						     "AND APP_NO='"+ sessionStorage.fvAppNo+"'";
						    
			db_execut_oneSQL("dahc.db", sql, [], fvElecVGBaseData.selectGContBaseSuccess, fvElecVGBaseData.selectGElecConsInfoFail);
 	
 	},
 	
 	/**
 	 * 查询本地合同信息成功后调用方法 
 	 * @param {} tx
 	 * @param {} res
 	 */
 	selectGContBaseSuccess:function(tx,res){
		
 			var len = res.rows.length;
			if (len == 0) {// 本地未查询
				fvPubUI.fvMsgShow("未查询到合同信息!");
			} else {
				 
				fvElecVGBaseData.initFileContractList(res.rows);// 初始化合同编号列表
				fvElecVUntil.initPageHtml('GF_', res.rows.item(0),fvElecVGBaseData.custIDArr); // 初始化合同内容
				
//				//页面上所有元素的ID赋值
//				$("#GF_CONTRACT_NO").val(res.rows.item(0).CONTRACT_NO);//合同编号 div用html取值
//				$("#GF_TYPE_CODE").val(res.rows.item(0).TYPE_CODE);//合同类型
//				$("#GF_STATUS_CODE").val(res.rows.item(0).STATUS_CODE);//合同状态
//				$("#GF_SIGN_DATE").val(res.rows.item(0).SIGN_DATE);//签订日期
//				$("#GF_END_DATE").val(res.rows.item(0).END_DATE);//到期日期
//				
				//缓存数据
				sessionStorage.CONTRACT_NO_B=res.rows.item(0).CONS_NO;
				sessionStorage.TYPE_CODE_B=res.rows.item(0).TYPE_CODE;
				sessionStorage.STATUS_CODE_B=res.rows.item(0).STATUS_CODE;
				sessionStorage.SIGN_DATE_B=res.rows.item(0).SIGN_DATE;
				sessionStorage.END_DATE_B=res.rows.item(0).END_DATE;
				
			}
	},
	
	/**
	 * 合同编号列表
	 * @param {} fileContractData 合同数据 json数组
	 */
	initFileContractList : function(fileContractData) {
		
		var fileContractHtml = "";
		ContractData=fileContractData;
		
		if (fileContractData.length > 0) {
			
			for (var i = 0; i < fileContractData.length; i++) {
				
				if (i == 0) {
					fileContractHtml += '<div class="boxflex_01 fvBottomLine" onclick="fvElecVGBaseData.changeContract('
							+ i+ ')"><span>合同'
							+ (i+1)
							+ '</span></div>';
					continue;
				}
				
				fileContractHtml += '<div class="boxflex_01 fvBottomLine" onclick="fvElecVGBaseData.changeContract('
						+ i+ ')"><span>合同'
//						+ fileContractData.item(i).CONTRACT_NO
						+(i+1)
						+ '</span></div>';
			}
		}
		$("#fileContractList").html(fileContractHtml);
	},
	
	/**
	 * 点击合同编号 初始化合同内容
	 * @param {} data 点击项的合同数据
	 */
	changeContract : function(i) {
		
		var child = $("#fileContractList").children();//Menu的4个子元素
		//点击时样式变化
		var barWidth = $("#fileContractList").width();
		$("#boxclip").css("margin-left",(barWidth/4*i)+"px");
		$(child).css("color","#000000");
		$(child[i]).css("color","#007a77");
		
		// 初始化合同内容
        fvElecVUntil.initPageHtml('GF_',ContractData.item(i),fvElecVGBaseData.custIDArr); 
	}
 };
 
  </script>