<script type="text/javascript">
/**
 * 供用电合同逻辑JS
 * @type 
 */	

var CONS_ID=JSON.parse(sessionStorage.fvConsInfo).cons_id; //用户ID

//标题
$("#ydjc_loginuser_nav_bl").html("供用电合同核查");

/**
 * 返回
 */
var ydjc_loginuser_bl_back = function (){
changepage("../../BasicInfoVerify/Checkuserinfo/Userbaseinfo/html/Userbaseinfo.html");
};

/**
 * 初始化
 * @type 
 */
var elecGVinit={
	
	//初始化图片按钮和上传图片按钮
	initBtm:function(){//session里有
		
		// 合同证明
		$("#fvContractBtn").click(function(){
			takePhoto("fvContractPhotoShow", "05",JSON.parse(sessionStorage.fvConsInfo).cons_no);
		});
		// 合同上装
		 $("#fvContractUpload").click(function() {
			uploadPhoto("05",JSON.parse(sessionStorage.fvConsInfo).cons_no);
		 });
		 
	},
	
	/**
	 * 初始化图片显示
	 */
	initPhoto:function ()
	{
		var tPhotoArray =[["fvContractPhotoShow", "05"]]; 
		initPhotoDisplay(tPhotoArray, JSON.parse(sessionStorage.fvConsInfo).cons_no);
	},
	
	//根据CONS_ID去查【用户基本】信息
	fvFindGConsInfoById:function(CONS_ID){
		fvPubUI.fvLoading();
		fvElecVGBaseData.selectGConsInfo(CONS_ID);
	},
	
	//根据CONS_ID查询【合同】信息
	fvFindGContInfoById:function(CONS_ID){
		fvElecVGBaseData.selectGContInfo(CONS_ID);
	},
	
	//发起合同流程：新签,补签,续约,终止
	fvGChangeContFlow:function(CONS_ID){
	  	
		cons_id = CONS_ID;
		
		$("#contractNewSign").click(function(){
			
			cons_id = $("#GCF_CONS_NO").attr("NAME");
 
			if(cons_id ==undefined){
			  fvPubUI.fvMsgShow("请先查询后再发起流程！");
			  return;
			} 
			
			//新签
			if($("#contractNewSign").attr("src")=="../../Util/Images/icon_new.png"){
				fvPubUI.fvLoading();
				pactVerifyInter.changeContractFlow(382,cons_id);
			}
			//补签
			if($("#contractNewSign").attr("src")=="../../Util/Images/icon_supply.png"){
				fvPubUI.fvLoading();
				pactVerifyInter.changeContractFlow(385,cons_id);
			}
		});
		
		//续签
		$("#continueSign").click(function(){
			fvPubUI.fvLoading();
			
			cons_id = $("#GCF_CONS_NO").attr("NAME");
			if(cons_id ==undefined){
			   fvPubUI.fvMsgShow("请先查询后再发起流程！");
			  
			  return;
			} 
			pactVerifyInter.changeContractFlow(384,cons_id);
		});
		//终止
		$("#endSign").click(function(){
			fvPubUI.fvLoading();
			
			cons_id = $("#GCF_CONS_NO").attr("NAME");
			if(cons_id ==undefined){
			   fvPubUI.fvMsgShow("请先查询后再发起流程！");
			  return;
			} 
			pactVerifyInter.changeContractFlow(386,cons_id);
		});
	},
	
	//查询【用户基本】信息接口失败后调用方法
	selectFvElecConsInfoFail:function(){
		 fvPubUI.fvMsgShow("查询【用户基本】信息接口失败，请联系管理员！");
	} 
};
elecGVinit.initBtm();
elecGVinit.initPhoto();
elecGVinit.fvFindGContInfoById(CONS_ID);
elecGVinit.fvFindGConsInfoById(CONS_ID);
elecGVinit.fvGChangeContFlow();

 </script>