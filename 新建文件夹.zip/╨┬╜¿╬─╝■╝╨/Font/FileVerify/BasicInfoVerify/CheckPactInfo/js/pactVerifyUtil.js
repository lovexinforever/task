<script type="text/javascript">
/**
* 供用电合同工具类
*
*/

//获得移动终端编号
var fvTid="";
getTid(function(e){fvTid =e;},null);


var fvElecVUntil={
	
	loadingNode: null,
	
 	 /**
	 * 返回htmlDom元素的ID
	 * @param {}  obj -->类似 "td[id*='am_']"
	 * @return htmlIdArr -->ID数组
	 */
   returnHtmlIdArr : function(obj){
		var htmlDom = $(obj);	          //input html元素  D_PHASEANGLE_CHK_RECORD
		var htmlIdArr = new Array();  //input 的ID  D_PHASEANGLE_CHK_RECORD
		for(var i =0;i<htmlDom.length;i++){//初始化input ID数组
		    htmlIdArr.push(htmlDom[i].id);              
		}
		return htmlIdArr;
	},
	
	/**
	 * 向页面填充数据
	 * @param {} idPre 页面上元素的ID的前缀
	 * @param {} data 数据源
	 * @param {} arr 页面需填充ID数组
	 */
	initPageHtml : function(idPre,data,arr){
	     for(var i=0;i<arr.length;i++){
	     	var dataKey = arr[i].split(idPre)[1];
	     	if($("#"+arr[i]).is("input")) $("#"+arr[i]).val(setUndefined(data[dataKey]));
	     	else  $("#"+arr[i]).html(setUndefined(data[dataKey]));
	     }
	},
	
 	/**
 	 * 弹出框
 	 * @param {} text 提示信息
	 * @param {} cancelCB 取消按钮回调
	 * @param {} okCB 确定按钮回调
	 * @param {} type 按钮个数 1为一个 2为2个按钮 空无按钮
 	 */
 	fvAlert:function(text,type,cancelCB,okCB){
 		var button = []; //提示框按钮数组 class 单个按钮样式 id 按钮id text 按钮文本展示 callback 单个按钮回调
		cancelCB = Elec.setUndefined(cancelCB)==""?fvElecVUntil.fvDialogClose:cancelCB;
		okCB = Elec.setUndefined(okCB)==""?fvElecVUntil.fvDialogClose:okCB;
		var bt1 = {class:"simple",id:"prompt_cancel",text:"取消",callback:cancelCB};
		var bt2 = {class:"simple",id:"prompt_ok",text:"确认",callback:okCB};
		if(type==1) button.push(bt2);//只有确定按钮
		else if(type==2){
			button.push(bt1);
			button.push(bt2);
		}
		$.Elec.prompt({
			text:text,     //提示框文本域
	        buttons:button
		});
 	},
 
 	/**
	 * 增加loading框
	 */
	addLoadingDialog: function() {
		fvElecVUntil.loadingNode = $.Elec.loading({
		 	text:"请求数据中...",    		
	        icon:"pic_loading",  
	        time: 30*1000,
	        timeCallback: fvElecVUntil.removeLoadingDialog
	    });
	},
	
 	/**
	 * 取消loading框
	 */
	removeLoadingDialog: function() {
		if(fvElecVUntil.loadingNode != null) {
			fvElecVUntil.loadingNode.close();
			fvElecVUntil.loadingNode = null;
		}
	},
	
 	/**
	 * 单条SQL语句执行
	 * @dbName  ="",默认为用电检查数据库
	 * @param sql 要执行的SQL语句
	 * @param prarm ？对应的参数
	 * @param sucess 成功回调
	 * @param fail   失败回调
	 */
	db_execut_oneSQL:function (dbName,sql,prarm,sucess,fail){
		//缺省为用电检查数据库
		if(dbName==null){
			dbName="dahc.db";
		}
	   var db = window.sqlitePlugin.openDatabase(dbName, "1.0",dbName, 10*1024*1024);
		
	   db.transaction(function(tx){
			 tx.executeSql(sql,prarm,sucess,fail);
		});
	},
	
	 /**
     * 获取终端编号
     */
    fvGetMyTid:function(){
	getTid(function(e){thisTid =e;},null);
    },
    
	/**
     * 得到请求的数据包
     * @param {JSON} req_code  请求码
     * @param {JSON} data      需要的数据
     */
    get_fv_pkg_data: function(req_code, obj) {
        var modNo = req_code.modNo;
        var funcNo = req_code.funcNo;
  
        var pkg = '{"MOD":"' + modNo + '","FUN":"' + funcNo 
                + '","SYS_USER_NAME":"' + localStorage.user_name + '", "ORG_NO":"' + localStorage.ORG_NO + '", "TERM_NUM":"' + fvTid+ '","PKG":' + JSON.stringify(obj) + '}';
        return pkg;        
    } ,
    
    //正整数验证
 	fvNumberVolite:function(myInput){
		if(myInput<0/*||myInput.value.indexOf(".")!=-1*/){
			alert("请输入非负整数");
			myInput.value="";
			return;
		}
		if(myInput.length>1&&myInput.substring(0,1)==0){
			alert("请输入非负整数");
			myInput.value="";
			return;
		}
	}
    
 } ;
 </script>