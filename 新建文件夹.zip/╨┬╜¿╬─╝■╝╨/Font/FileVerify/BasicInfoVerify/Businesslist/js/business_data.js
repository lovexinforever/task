$("#ydjc_loginuser_nav_bl").html("档案核查-待办事宜");

var fvFinit = true;//首次为true；刷新、筛选为false

document.addEventListener("deviceready", function() {
	queryBusinessList();
}, false);

/**
 * 返回
 */
function ydjc_loginuser_bl_back() {
	window.location.replace("mainContent.html");
}
/**
 * 跳转到用户列表页
 */
function goto_userlist_html(id) {
	sessionStorage.fvAppNo = id.split("_")[0];
	sessionStorage.fvActCode = id.split("_")[1];// 活动实力标识
	changepage("../../BasicInfoVerify/Userlist/html/userlist.html");
}

/**
 * 刷新
 */
$("#refresh_bl_goto_id").click(function() {
	fvFinit = false;
	fvPubUI.fvLoading();
	sendBusinessData();
});

/**
 * 查询待办事宜
 */
function queryBusinessList(where, time) {
	if (!where) {
		where = "";
	}
	if (!time) {
		time = "";
	}
	var sql = "SELECT * FROM P_ACT_INSTANCE S  WHERE SYS_USER_NAME=? "
			+ proce_json_where(where, "S") + time + "  " + " order by S.APP_NO";
	
	fvPubUI.fvLoading();
	db_execut_oneSQL("dahc.db", sql, [sessionStorage.user_name], sucessCB_bl_1,failCB_bl_1);

	function sucessCB_bl_1(tx, res) {
		var count = res.rows.length;
		if (fvFinit && count == 0) {
			fvFinit = false;
			sendBusinessData();// 向服务器请求数据
		} else {
			initBusinessList(res.rows);
		}
	}
	// 查询失败
	function failCB_bl_1(e) {
		fvPubUI.fvMsgShow("未查询到数据");
	}
}

/**
 * 请求待办事宜列表数据
 * 0336002 低压核查
 * 0337002 高压核查
 */
function sendBusinessData() {
	amSendWorkList({
		sysUserName : sessionStorage.user_name,
		actCode : "",
		callback : function(obj) {
			reMsgDeal(obj, function(){
				queryBusinessList();
			});
		}
	});
}

/**
 * 初始化待办事宜列表
 */
function initBusinessList(data){
     try{
     	
        var rueslt="";
        $("#business_list_html_content").html(rueslt);
        
        var len = data.length;
        if(len==0){
             fvPubUI.fvMsgShow("未查询到数据");
             return;
        }
        
        for(var i=0; i<len; i++)
        {
          rueslt+='<div class="displayflexvertical fvWorkList" >'+
               '<div class="displayflex fvWorkListTop">'+
                  '<div class="fvLinkIcon"></div>'+
                  '<div>申请编号'+data.item(i).APP_NO+'</div>'+
              '</div>'+
              '<div class="fvWorkListUp" onclick="goto_userlist_html(this.id)" id="'+data.item(i).APP_NO+'_'+data.item(i).ACT_CODE+'">'+
                  '<div>流程名称：'+data.item(i).INS_NAME+'</div>'+
                  '<div>活动名称：'+data.item(i).ACT_NAME+'</div>'+
                  '<div>说&nbsp;&nbsp;明&nbsp;&nbsp;栏：'+data.item(i).NOTES+'</div>'+
                  '<div>接收时间：'+data.item(i).RCV_TIME+'</div>'+
                  '<div>到期时间：'+data.item(i).DUE_TIME+'</div>'+
              '</div>'+
          '</div>';
        }
          $("#business_list_html_content").html(rueslt+"<div class='empty'></div>");
          fvPubUI.fvLoadingClose();
     }catch(err){
         console.log(err);
         fvPubUI.fvLoadingClose();
     }
}


 /**
 * 筛选
 */
$("#ydjc_shaixuan_bl_show").click(function() {
	$("#ydjc_shaixuan_app_no").val(sessionStorage.app_nosx);
	$("#ydjc_shaixuan_ins_name").val(sessionStorage.ins_namesx);
	$("#ydjc_shaixuan_act_name").val(sessionStorage.act_namesx);
	$("#ydjc_shaixuan_rcv_time1").val(sessionStorage.rcv_time1sx);
	$("#ydjc_shaixuan_rcv_time2").val(sessionStorage.rcv_time2sx);
	$("#ydjc_shaixuan_due_time1").val(sessionStorage.due_time1sx);
	$("#ydjc_shaixuan_due_time2").val(sessionStorage.due_time2sx);
	$("#ydjc_shaixuan_notes").val(sessionStorage.notessx);
	$("#ydjc_shaixuan_b_l_div").show();
});

/**
 * 筛选取消按钮
 */
function ydjc_shaixuan_bl_close_return() {
	$("#ydjc_shaixuan_b_l_div").hide();
}

/**
 * 筛选确定按钮
 */
function ydjc_shaixuan_bl_close() {
	$("#ydjc_shaixuan_b_l_div").hide();
	//申请编号：
	var app_no = $("#ydjc_shaixuan_app_no").val();
	//流程名称
	var ins_name = $("#ydjc_shaixuan_ins_name").val();
	//活动名称
	var act_name = $("#ydjc_shaixuan_act_name").val();
	//接收时间1
	var rcv_time1 = $("#ydjc_shaixuan_rcv_time1").val();
	//接收时间2
	var rcv_time2 = $("#ydjc_shaixuan_rcv_time2").val();
	//到期时间1
	var due_time1 = $("#ydjc_shaixuan_due_time1").val();
	//到期时间2
	var due_time2 = $("#ydjc_shaixuan_due_time2").val();
	//说明
	var notes = $("#ydjc_shaixuan_notes").val();
	//调用底层查询数据
	var sql = {
		"app_no" : app_no,
		"ins_name" : ins_name,
		"act_name" : act_name,
		"notes" : notes
	};
	var time = "";
	if (setUndefined(rcv_time1) == "" || setUndefined(rcv_time2) == "") {
		/**********判断开始日期是否为空***************/
		if (setUndefined(rcv_time1) == "" && setUndefined(rcv_time2) != "") {
			fvPubUI.fvMsgShow("接收日期的开始日期不能为空");
			return;
		} else if (setUndefined(rcv_time1) != ""
				&& setUndefined(rcv_time2) == "") {
			fvPubUI.fvMsgShow("接收日期的结束日期不能为空");
			return;
		}
		/**********判断开始日期是否为空***************/
	} else {
		if (!(rcv_time1 <= rcv_time2 ? true : false)) {
			fvPubUI.fvMsgShow("接收日期的开始日期不能大于结束日期");
			return;
		}
		time += (" AND RCV_TIME BETWEEN '" + rcv_time1 + "' AND '" + rcv_time2 + "'");
	}
	if (setUndefined(due_time1) == "" || setUndefined(due_time2) == "") {
		/**********判断结束日期是否为空***************/
		if (setUndefined(due_time1) == "" && setUndefined(due_time2) != "") {
			fvPubUI.fvMsgShow("到期日期的开始日期不能为空");
			return;
		} else if (setUndefined(due_time1) != ""
				&& setUndefined(due_time2) == "") {
			fvPubUI.fvMsgShow("到期日期的结束日期不能为空");
			return;
		}
		/**********判断结束日期是否为空***************/
	} else {
		if (!(due_time1 <= due_time2 ? true : false)) {
			fvPubUI.fvMsgShow("到期日期的开始日期不能大于结束日期");
			return;
		}
		//到期时间大于接受时间
		if (!(due_time1 >= rcv_time2 ? true : false)
				|| !(due_time1 >= rcv_time1 ? true : false)
				|| !(due_time2 >= rcv_time2 ? true : false)
				|| !(due_time2 >= rcv_time1 ? true : false)) {
			fvPubUI.fvMsgShow("接收时间不能大于到期时间");
			return;
		}
		time += (" AND DUE_TIME BETWEEN '" + due_time1 + "' AND '" + due_time2 + "'");
	}
	$("#remove_input").off("click");
	sessionStorage.app_nosx = $("#ydjc_shaixuan_app_no").val();
	sessionStorage.ins_namesx = $("#ydjc_shaixuan_ins_name").val();
	sessionStorage.act_namesx = $("#ydjc_shaixuan_act_name").val();
	sessionStorage.rcv_time1sx = $("#ydjc_shaixuan_rcv_time1").val();
	sessionStorage.rcv_time2sx = $("#ydjc_shaixuan_rcv_time2").val();
	sessionStorage.due_time1sx = $("#ydjc_shaixuan_due_time1").val();
	sessionStorage.due_time2sx = $("#ydjc_shaixuan_due_time2").val();
	sessionStorage.notessx = $("#ydjc_shaixuan_notes").val();
	
	fvFinit = false;
	queryBusinessList(sql, time);
}

/**
 * 根据查询条件返回拼接后的查询条件string: and key='value' and .......
 * @param str
 */
function proce_json_where(str, pix) {
	var rst = " ";
	for (i in str) {
		var s = str[i];
		if (s == "" || s == null || s == "null") {

		} else {
			rst += ("and " + pix + "." + i + " like '%" + s + "%' ");
		}
	}
	return rst;
}


