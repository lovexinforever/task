// 定义新增联系人操作类
var contactAdd = 
{
	// 新增联系人数据
	contactArray : ["CONTACT_MODE","CONTACT_SOURCE","CONTACT_PRIO","CONTACT_NAME","GENDER","TITLE","OFFICE_TEL","HOMEPHONE","MOBILE",
					"FAX_NO","ADDR","POSTALCODE","EMAIL","FAMILY_ADDR","INTEREST","CONTACT_REMARK","BIRTHDAY","CHECK_FLAG","CONS_ID","APP_NO"],
			
	// 新增联系人
	addContactInfo : function()
	{
		fvPubUI.fvLoading();
		// 动态获取页面输入框/下拉列表数据
		var params = new Array();
		var tempArray = contactAdd.contactArray.slice(0, contactAdd.contactArray.length-2);
		for(var i=0; i<tempArray.length; i++)
		{
			var key = tempArray[i];
			var tempValue;
			if("CONTACT_PRIO"==key || "CONTACT_MODE"==key || "CONTACT_SOURCE"==key || "GENDER"==key || "CHECK_FLAG"==key || "TITLE"==key)
			{
				tempValue = $("#"+key).attr("name");
			}
			else
			{
				tempValue = $("#"+key).val();
			}
			params.push(tempValue);
		}
		params.push(JSON.parse(sessionStorage.fvConsInfo).cons_id);
		params.push(sessionStorage.fvAppNo);
		
		// 调用接口执行联系人新增操作
		publicDataRequest.execDataSendRequest("ADD_CONTACT", contactAdd.contactArray, params, function(data)
		{
			contactAdd.contactArray.push("CONTACT_ID");
			contactAdd.contactArray.push("INTERACT_FLAG");
			params.push(data);
			params.push("0");
			contactDB.addContact(contactAdd.contactArray, params, function(res)
			{
				fvPubUI.fvLoadingClose();
				fvPubUI.fvMsgShow("新增联系人成功");
				// 高压
				if(sessionStorage.fvActCode =="0337002")
				{
					changepage("../../BasicInfoVerify/CheckContactInfo/html/ContactMain.html");	
				}
				else
				{
					changepage("../../BasicInfoVerify/LowPressureCheck/html/LowPressureCheck.html");
				}
			});
		});
	},
	
 	// 初始化界面下拉列表数据
 	initDropDown : function()
 	{
 		for(var i=0; i<contactAdd.contactArray.length; i++)
 		{
 			var key = contactAdd.contactArray[i];
 			if("CONTACT_PRIO"==key || "CONTACT_MODE"==key || "CONTACT_SOURCE"==key || "GENDER"==key || "CHECK_FLAG"==key || "TITLE"==key)
 			{
 				pcodeUtil.initDropDownFromEdit(key, null);
 			}
 		}
 	},

 	// 页面初始化并绑定单击事件
	initData : function()
	{
		// 头部初始化
		$("#ydjc_loginuser_nav_bl").html("互动联系信息验证");
		var consInfo = JSON.parse(sessionStorage.fvConsInfo);
		$("#contactAddConsNo").html(consInfo.cons_no);
		$("#contactAddConsInfo").html(getHeaderInfo(consInfo.cons_sort_code_str, consInfo.rrio_code_str, consInfo.elec_type_code_str));
		
		// 绑定单击事件
		$("#fvAddContact").click(function() {contactAdd.addContactInfo()});
		$("#BIRTHDAY").click(function() {fvPubUI.getDate("BIRTHDAY")});
		
		contactAdd.initDropDown();
	}
};

pcodeUtil.initDropDownData(function(){contactAdd.initData();});

// 回退按钮
function ydjc_loginuser_bl_back()
{
	// 高压
	if(sessionStorage.fvActCode =="0337002")
	{
		changepage("../../BasicInfoVerify/CheckContactInfo/html/ContactMain.html");	
	}
	else
	{
		changepage("../../BasicInfoVerify/LowPressureCheck/html/LowPressureCheck.html");
	}
}