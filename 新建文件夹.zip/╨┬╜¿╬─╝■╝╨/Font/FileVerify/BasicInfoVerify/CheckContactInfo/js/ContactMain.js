// 定义联系人主界面操作类
var contactMain = 
{
	// 查询用户信息和联系人信息
	queryData : function()
	{
		var consId = JSON.parse(sessionStorage.fvConsInfo).cons_id;
		var appNo = sessionStorage.fvAppNo;
		// 查询用户基本信息
		var consInfoArray = ["CONS_NO", "CONS_NAME", "CONS_SORT_CODE", "RRIO_CODE", "VOLT_CODE", "CONTRACT_CAP", "ELEC_ADDR"];
		contactDB.queryConsInfo(consId, appNo, function(data)
		{
			var len = data.rows.length;
			if(len>0)
			{
				for(var i=0; i<len; i++)
				{
					var tempData = data.rows.item(i);
					for(var j=0; j<consInfoArray.length; j++)
					{
						var key = consInfoArray[j];
						if("CONS_SORT_CODE"==key || "RRIO_CODE"==key || "VOLT_CODE"==key)
						{
							pcodeUtil.initReadOnlyFromDetail(key, tempData[key]);
						}
						else
						{
							$("#"+key).html(tempData[key]);
						}
					}
				}
			}
		});
		
		// 查询联系人信息
		contactDB.queryContactInfo(consId, appNo, function(data)
		{
			var len = data.rows.length;
			if(len>0)
			{
				var html = "<div class='fvHead'><span>联系人信息</span></div>";
				// 核查不通过的联系人个数
				var checkContactCount = 0;
				// 非互动联系人个数
				var contactCount = 0;
				for(var i=0; i<len; i++)
				{
					var tempData = data.rows.item(i);
					if(tempData.INTERACT_FLAG != "1")
                    {
                    	contactCount++;
                    }
                    if(tempData.CHECK_FLAG != "1")
                    {
                    	checkContactCount++;
                    }
				}
				for(var i=0; i<len; i++)
				{
					var tempData = data.rows.item(i);
					html += "<div class='fvContent displayflex'>";
					html += "<div class='boxflex_01 displayflexvertical' onclick='contactMain.viewContact("+tempData.CONTACT_ID+")'>";
					html += "<div class='displayflex'>";
					if(tempData.INTERACT_FLAG == "1")
                    {
                    	html += "<div class='fvManIconGreen'>";
                    }
                    else
                    {
                    	html += "<div class='fvManIconGray'>";
                    }
                	html += "</div>";
                	html += "<div class='boxflex_01 fvManPhone displayflexvertical'>";
                    if(tempData.INTERACT_FLAG == "1")
                    {
                    	html += "<div class='boxflex_01 fvGreenFont'>";
                    }
                    else
                    {
                    	html += "<div class='boxflex_01'>";
                    }
                    html += "<span>联系人：</span>";
                    html += "<span>"+tempData.CONTACT_NAME;
                    if(tempData.INTERACT_FLAG == "1")
                    {
                    	html += "(互动联系人)";
                    }
					html += "</span>";
                    html += "</div>";
                    html += "<div class='boxflex_01'><span>联系人类型：</span><span>";
					// 获取联系类型
                    html += pcodeUtil.getValueFromPcodeJson("CONTACT_MODE", tempData.CONTACT_MODE); 
                    html += "</span></div>";
                	html += "</div>";
            		html += "</div>";
           			html += "<div class='fvManPhoneType displayflexvertical'>";
                	html += "<div class='boxflex_01'><span>移动电话：</span><span>"+tempData.MOBILE+"</span></div>";
                	html += "<div class='boxflex_01'><span>是否为互动联系人：</span><span>";
                	// 获取互动联系人标志
                	html += pcodeUtil.getValueFromPcodeJson("CHECK_FLAG", tempData.INTERACT_FLAG);
                	html += "</span></div>";
           			html += "</div>";
        			html += "</div>";
        			
        			if(checkContactCount != len)
        			{
        				if(tempData.INTERACT_FLAG == "1")
	        			{
	        				html += "<div class='fvManCancle' onclick='contactMain.cancelContact("+tempData.CONTACT_ID+")'></div>";
	        				$("#CONTACT_NAME").html(tempData.CONTACT_NAME);
	        				$("#CONTACT_MODE").html(pcodeUtil.getValueFromPcodeJson("CONTACT_MODE", tempData.CONTACT_MODE));
	        			}
	        			else if(contactCount == len)
	        			{
	        				if(tempData.CHECK_FLAG == "1")
	        				{
								html += "<div class='fvManSet' onclick='contactMain.setContact("+tempData.CONTACT_ID+")'></div>";	        					
	        				}
	        			}
        			}
    				html += "</div>";
     				html += "<div class='fvTopBorder'></div>";
				}
				$("#fvContactInfo").html(html);
			}
		});
	},
	
	// 新增联系人
	addContact : function()
	{
		changepage("../../BasicInfoVerify/CheckContactInfo/html/ContactAdd.html");
	},
	
	// 查看联系人
	viewContact : function(contactId)
	{
		sessionStorage.fvContactId = contactId;
		changepage("../../BasicInfoVerify/CheckContactInfo/html/ContactDetail.html");
	},
	
	// 设为互动联系人
	setContact : function(contactId)
	{
		fvPubUI.fvLoading();
		var paramNames = new Array();
		paramNames.push("INTERACT_FLAG");
		paramNames.push("SERVICE_ITEM");
		paramNames.push("CONTACT_ID");
		paramNames.push("APP_NO");
		
		var paramValues = new Array();
		paramValues.push("1");
		paramValues.push("01,02");
		paramValues.push(contactId);
		paramValues.push(sessionStorage.fvAppNo);
		
		// 调用接口执行设置联系人操作
		publicDataRequest.execDataSendRequest("SET_CANCEL_CONTACT", paramNames, paramValues, function()
		{
			contactDB.modifyContact(paramNames, paramValues, function(res)
			{
				fvPubUI.fvLoadingClose();
				fvPubUI.fvMsgShow("设置互动联系人成功");
				changepage("../../BasicInfoVerify/CheckContactInfo/html/ContactMain.html");	
			});
		});
	},
	
	// 取消互动联系人
	cancelContact : function(contactId)
	{
		fvPubUI.fvLoading();
		var paramNames = new Array();
		paramNames.push("INTERACT_FLAG");
		paramNames.push("SERVICE_ITEM");
		paramNames.push("CONTACT_ID");
		paramNames.push("APP_NO");
		
		var paramValues = new Array();
		paramValues.push("0");
		paramValues.push("01,02");
		paramValues.push(contactId);
		paramValues.push(sessionStorage.fvAppNo);
		
		// 调用接口执行取消联系人操作
		publicDataRequest.execDataSendRequest("SET_CANCEL_CONTACT", paramNames, paramValues, function()
		{
			contactDB.modifyContact(paramNames, paramValues, function(res)
			{
				fvPubUI.fvLoadingClose();
				fvPubUI.fvMsgShow("取消互动联系人成功");
				changepage("../../BasicInfoVerify/CheckContactInfo/html/ContactMain.html");	
			});
		});
	},
	
	// 页面初始化并绑定单击事件
	initData : function()
	{
		// 头部初始化
		$("#ydjc_loginuser_nav_bl").html("互动联系信息验证");
		var consInfo = JSON.parse(sessionStorage.fvConsInfo);
		$("#contactMainConsNo").html(consInfo.cons_no);
		$("#contactMainConsInfo").html(getHeaderInfo(consInfo.cons_sort_code_str, consInfo.rrio_code_str, consInfo.elec_type_code_str));
		
		// 绑定单击事件
		$("#fvAddContact").click(function() {contactMain.addContact()});
		
		contactMain.queryData();
	}
};

pcodeUtil.initDropDownData(function(){contactMain.initData();});

// 回退按钮
function ydjc_loginuser_bl_back()
{
	changepage("../../BasicInfoVerify/Checkuserinfo/Userbaseinfo/html/Userbaseinfo.html");
}