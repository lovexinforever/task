// 联系人数据库增删改查操作类
var contactDB = 
{
	// 查询用户基本信息
	queryConsInfo : function(consId, appNo, queryConsInfoSuccCB)
	{
		var sql = "SELECT * FROM P_ACT_CONS WHERE CONS_ID = ? AND APP_NO = ?";
		db_execut_oneSQL("dahc.db", sql, [consId, appNo], function(tx, res)
		{
			queryConsInfoSuccCB(res);
		}, null);
	},
	
	// 查询联系人信息
	queryContactInfo : function(consId, appNo, queryContactInfoSuccCB)
	{
		var sql = "SELECT * FROM C_CONTACT WHERE CONS_ID = ? AND APP_NO = ? ORDER BY INTERACT_FLAG DESC, CHECK_FLAG DESC";
		db_execut_oneSQL("dahc.db", sql, [consId, appNo], function(tx, res)
		{
			queryContactInfoSuccCB(res);
		}, null);
	},
	
	// 查询联系人详情信息
	queryContact : function(contactId, appNo, queryContactSuccCB)
	{
		var sql = "SELECT CONTACT_MODE,CONTACT_SOURCE,CONTACT_PRIO,CONTACT_NAME,GENDER,TITLE,OFFICE_TEL,HOMEPHONE,MOBILE,FAX_NO," +
				  "ADDR,POSTALCODE,EMAIL,FAMILY_ADDR,INTEREST,CONTACT_REMARK,date(BIRTHDAY) BIRTHDAY,CHECK_FLAG,CONS_ID,CONTACT_ID,APP_NO " +
				  "FROM C_CONTACT WHERE CONTACT_ID = ? AND APP_NO = ?";
		db_execut_oneSQL("dahc.db", sql, [contactId, appNo], function(tx, res)
		{
			queryContactSuccCB(res);
		}, null);
	},
	
	// 添加联系人信息 
	addContact : function(array, params, addSuccCB)
	{
		var sql = "INSERT INTO C_CONTACT(";
		for(var i=0; i<array.length; i++)
		{
			sql += array[i];
			if(i != array.length-1)
			{
				sql += ",";
			}
		}
		sql += ") VALUES (";
		for(var i=0; i<array.length; i++)
		{
			sql += "?";
			if(i != array.length-1)
			{
				sql += ",";
			}
		}
		sql += ")";
		db_execut_oneSQL("dahc.db", sql, params, function(tx, res)
		{
			addSuccCB(res);
		}, null);
	},
	
	// 更新联系人信息 
	modifyContact : function(array, params, modifySuccCB)
	{
		var tempArray = array.slice(0, array.length-2);
		var sql = "UPDATE C_CONTACT SET ";
		for(var i=0; i<tempArray.length; i++)
		{
			sql += tempArray[i] + "=?";
			if(i != tempArray.length-1)
			{
				sql += ", ";
			}
		}
		sql += " WHERE CONTACT_ID = ? AND APP_NO = ? ";
		
		db_execut_oneSQL("dahc.db", sql, params, function(tx, res)
		{
			modifySuccCB(res);
		}, null);
	},
	
	// 删除联系人信息 
	deleteContact : function(contactId, appNo, deleteSuccCB)
	{
		var sql = "DELETE FROM C_CONTACT WHERE CONTACT_ID = ? AND APP_NO = ?";
		db_execut_oneSQL("dahc.db", sql, [contactId, appNo], function(tx, res)
		{
			deleteSuccCB(res);
		}, null);
	}
};