// 定义查看联系人操作类
var contactDetail = 
{
	// 查看联系人
	viewContactInfo : function()
	{
		contactDB.queryContact(sessionStorage.fvContactId, sessionStorage.fvAppNo, function(data)
		{
			var len = data.rows.length;
			if(len>0)
			{
				var tempData = data.rows.item(0);
				var contactArray = ["CONTACT_MODE","CONTACT_SOURCE","CONTACT_PRIO","CONTACT_NAME","GENDER","TITLE","OFFICE_TEL",
									"HOMEPHONE","MOBILE","FAX_NO","ADDR","POSTALCODE","EMAIL","FAMILY_ADDR","INTEREST",
									"CONTACT_REMARK","BIRTHDAY","CHECK_FLAG","CONS_ID","CONTACT_ID","APP_NO"];
				for(var i=0; i<contactArray.length; i++)
				{
					var key = contactArray[i];
					if("CONTACT_PRIO"==key || "CONTACT_MODE"==key || "CONTACT_SOURCE"==key || "GENDER"==key || "CHECK_FLAG"==key || "TITLE"==key)
					{
						pcodeUtil.initReadOnlyFromDetail(key, tempData[key]);
					}
					else
					{
						$("#"+key).html(tempData[key]);
					}
				}
			}
		});
	},
	
	// 修改联系人
	editContactInfo : function()
	{
		changepage("../../BasicInfoVerify/CheckContactInfo/html/ContactEdit.html");
	},
	
	// 删除联系人
	deleteContactInfo : function()
	{
		fvPubUI.fvLoading();
		var arrayNames = ["CONTACT_ID", "APP_NO"];
		var arrayValues = [sessionStorage.fvContactId, sessionStorage.fvAppNo];
		// 调用接口执行联系人删除操作
		publicDataRequest.execDataSendRequest("DELETE_CONTACT", arrayNames, arrayValues, function()
		{
			contactDB.deleteContact(sessionStorage.fvContactId, sessionStorage.fvAppNo, function(res)
			{
				fvPubUI.fvLoadingClose();
				fvPubUI.fvMsgShow("删除联系人成功");
				// 高压
				if(sessionStorage.fvActCode =="0337002")
				{
					changepage("../../BasicInfoVerify/CheckContactInfo/html/ContactMain.html");	
				}
				else
				{
					changepage("../../BasicInfoVerify/LowPressureCheck/html/LowPressureCheck.html");
				}
			});
		});
	},
	
	// 页面初始化并绑定单击事件
	initData : function()
	{
		// 头部初始化
		$("#ydjc_loginuser_nav_bl").html("互动联系信息验证");
		var consInfo = JSON.parse(sessionStorage.fvConsInfo);
		$("#contactDetailConsNo").html(consInfo.cons_no);
		$("#contactDetailConsInfo").html(getHeaderInfo(consInfo.cons_sort_code_str, consInfo.rrio_code_str, consInfo.elec_type_code_str));
		
		// 绑定单击事件
		$("#fvEditContact").click(function() {contactDetail.editContactInfo()});
		$("#fvDeleteContact").click(function() {$("#delete_dailog").show();});
		
		contactDetail.viewContactInfo();
	}
};

pcodeUtil.initDropDownData(function(){contactDetail.initData();});

// 回退按钮
function ydjc_loginuser_bl_back()
{
	// 高压
	if(sessionStorage.fvActCode =="0337002")
	{
		changepage("../../BasicInfoVerify/CheckContactInfo/html/ContactMain.html");	
	}
	else
	{
		changepage("../../BasicInfoVerify/LowPressureCheck/html/LowPressureCheck.html");
	}
}

// 删除确定按钮
function delete_data_enter() 
{
    $("#delete_dailog").hide();
    contactDetail.deleteContactInfo();
}

// 删除取消按钮
function delete_data_cancle() 
{
	$("#delete_dailog").hide();
}