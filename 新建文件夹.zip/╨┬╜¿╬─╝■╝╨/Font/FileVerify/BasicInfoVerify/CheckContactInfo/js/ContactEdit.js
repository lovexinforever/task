// 定义修改联系人操作类
var contactModify = 
{
	contactArray : ["CONTACT_MODE","CONTACT_SOURCE","CONTACT_PRIO","CONTACT_NAME","GENDER","TITLE","OFFICE_TEL","HOMEPHONE","MOBILE",
					"FAX_NO","ADDR","POSTALCODE","EMAIL","FAMILY_ADDR","INTEREST","CONTACT_REMARK","BIRTHDAY","CHECK_FLAG","CONS_ID","CONTACT_ID","APP_NO"],
					
	// 更新联系人
	modifyContactInfo : function()
	{
		fvPubUI.fvLoading();
		var params = new Array();
		for(var i=0; i<contactModify.contactArray.length; i++)
		{
			var key = contactModify.contactArray[i];
			var tempValue;
			if("CONTACT_PRIO"==key || "CONTACT_MODE"==key || "CONTACT_SOURCE"==key || "GENDER"==key || "CHECK_FLAG"==key || "TITLE"==key)
			{
				tempValue = $("#"+key).attr("name");
			}
			else if("CONS_ID"==key)
			{
				tempValue = JSON.parse(sessionStorage.fvConsInfo).cons_id;
			}
			else if("CONTACT_ID"==key)
			{
				tempValue = sessionStorage.fvContactId;
			}
			else if("APP_NO"==key)
			{
				tempValue = sessionStorage.fvAppNo;
			}
			else
			{
				tempValue = $("#"+key).val();
			}
			params.push(tempValue);
		}
		
		// 调用接口执行联系人修改操作
		publicDataRequest.execDataSendRequest("MODIFY_CONTACT", contactModify.contactArray, params, function()
		{
			contactDB.modifyContact(contactModify.contactArray, params, function(res)
			{
				fvPubUI.fvLoadingClose();
				fvPubUI.fvMsgShow("更新联系人成功");
				changepage("../../BasicInfoVerify/CheckContactInfo/html/ContactDetail.html");
			});
		});
	},
	
	// 页面初始化并绑定单击事件
	initData : function()
	{
		// 头部初始化
		$("#ydjc_loginuser_nav_bl").html("互动联系信息验证");
		var consInfo = JSON.parse(sessionStorage.fvConsInfo);
		$("#contactEditConsNo").html(consInfo.cons_no);
		$("#contactEditConsInfo").html(getHeaderInfo(consInfo.cons_sort_code_str, consInfo.rrio_code_str, consInfo.elec_type_code_str));
		
		// 绑定单击事件
		$("#fvModifyContact").click(function() {contactModify.modifyContactInfo()});
		$("#BIRTHDAY").click(function() {fvPubUI.getDate("BIRTHDAY")});
		
		contactDB.queryContact(sessionStorage.fvContactId, sessionStorage.fvAppNo, function(data)
		{
			var len = data.rows.length;
			if(len>0)
			{
				var tempData = data.rows.item(0);
				for(var i=0; i<contactModify.contactArray.length; i++)
				{
					var key = contactModify.contactArray[i];
					if("CONTACT_PRIO"==key || "CONTACT_MODE"==key || "GENDER"==key || "CHECK_FLAG"==key || "TITLE"==key)
					{
						pcodeUtil.initDropDownFromEdit(key, tempData[key]);
					}
					else if("CONTACT_SOURCE" == key)
					{
						pcodeUtil.initReadOnlyFromEdit(key, tempData[key]);
					}
					else
					{
						$("#"+key).val(tempData[key]);
					}
				}
			}
		});
	}
};

contactModify.initData();

// 回退按钮
function ydjc_loginuser_bl_back()
{
	changepage("../../BasicInfoVerify/CheckContactInfo/html/ContactDetail.html");
}