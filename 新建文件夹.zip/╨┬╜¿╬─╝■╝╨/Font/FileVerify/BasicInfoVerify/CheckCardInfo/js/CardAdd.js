$("#ydjc_loginuser_nav_bl").html("用户证件信息-新增");
var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);

init();

/********************************************初始化***********************************************/
/**
 * 初始化标题和点击事件
 */
function init() 
{	
	$("#fv_cons_no").html(fvConsInfo.cons_no);
	$("#fv_cons_info").html(getHeaderInfo(fvConsInfo.cons_sort_code_str, fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str));
	
	addItemClickListener();
}

/**
 * 添加点击监听
 */
function addItemClickListener()
{
	pCdoeSelectList({"id":"fv_CERT_TYPE_CODE","pCode":[{"A_29012":"","codeId":29012}]});
	$("#fv_CERT_TYPE_CODE").attr("name","");
	
	//证件生效日期
 	$("#fv_CERT_EFFECT_DATE").click( function()
 	{ 
 		fvPubUI.getDate("fv_CERT_EFFECT_DATE");
 	});
 	
 	//证件失效日期
 	$("#fv_CERT_EXPIRE_DATE").click( function()
 	{ 
 		fvPubUI.getDate("fv_CERT_EXPIRE_DATE");
 	});	
 	
 	//上装
 	$("#fvCertUpload").click( function()
 	{ 
 		uploadData();
 	});	
}

/********************************************保存修改信息***********************************************/
/**
 * 保存修改的数据
 */
function uploadData()
{
	if(checkEmpty())
	{
		fvPubUI.fvLoading();
		sendEditToServer();
	}
}

/**
 * 判断是否为空
 */
function checkEmpty()
{
	if(checkStringTrim($("#fv_CERT_NAME").val()))
	{
		fvPubUI.fvMsgShow("证件名称不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_CERT_TYPE_CODE").attr("name")))
	{
		fvPubUI.fvMsgShow("证件类型不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_CERT_NO").val()))
	{
		fvPubUI.fvMsgShow("证件号码不能为空");
		return false;
	}
	return true;
}
/**
 * 判断字符串是否为空
 */
function checkStringTrim(str)
{
	if(str == "" || str == undefined)
		return true;
	return false;
}




/**
 * 发送修改信息到服务端
 */
function sendEditToServer()
{
	var editObj = 	'"APP_NO":"'			+ sessionStorage.fvAppNo+'",' + 
					'"CERT_TYPE_CODE":"'	+ $("#fv_CERT_TYPE_CODE").attr("name")+'",' +
					'"CERT_NAME":"' 		+ $("#fv_CERT_NAME").val()+'",'+
					'"CERT_NO":"' 			+ $("#fv_CERT_NO").val()+'",'+
					'"CERT_EFFECT_DATE":"' 	+ $("#fv_CERT_EFFECT_DATE").val()+'",'+
					'"CERT_EXPIRE_DATE":"' 	+ $("#fv_CERT_EXPIRE_DATE").val()+'",'+
					'"DIRECTORY":"' 		+ $("#fv_DIRECTORY").val()+'"';
					
					
					
	//1.发送实名制认证基本信息请求到服务器
	var pkg='{"MOD":"2034","FUN":"030605","ORG_NO":"'+sessionStorage.ORG_NO+'","SYS_USER_NAME":"'+ sessionStorage.user_name +'","TERM_NUM":"'+ fvTid +'","PKG":{'+ editObj +'}}';
    send_data("030605","2034",pkg,sendSuccess,sendFail);
}
/**
 * 发送新增信息到服务端回调-成功
 */
function sendSuccess(message)
{	
	try
	{
        fvPubUI.fvLoadingClose();//关闭加载效果框
        var msg_enercb = JSON.parse(message);
        if(msg_enercb.RET=="00")
        {
            var msg_pkg=msg_enercb.PKG.PKG;
            if(msg_pkg.FLAG=="1")
            {
            	insertCertTable(msg_pkg.CERT_ID);
            }else
            {
            	//fvPubUI.fvMsgShow("数据上装失败");
            	fvPubUI.fvMsgShow(msg_pkg.ERR_MSG);
            }
        }else
        {
            fvPubUI.fvMsgShow("数据上装失败");
        }
	}catch(e)
    {
   	 	fvPubUI.fvMsgShow("数据上装失败!返回数据异常");
    }
}
/**
 * 发送新增信息到服务端回调-失败
 */
function sendFail(message)
{	
	//关闭加载效果框
	fvPubUI.fvLoadingClose();
    	
	//操作失败
	fvPubUI.fvMsgShow("数据上装失败");
}

/**
 * 更新充电桩表
 */
function insertCertTable(certID)
{
	var consKeyArr = 
	[{
	
		"APP_NO" 			: sessionStorage.fvAppNo,
		"CONS_ID" 			: fvConsInfo.cons_id,
		"CERT_ID" 			: certID,
		"CERT_TYPE_CODE" 	: $("#fv_CERT_TYPE_CODE").attr("name"),
		"CERT_NAME" 		: $("#fv_CERT_NAME").val(),
		"CERT_NO" 			: $("#fv_CERT_NO").val(),
		"CERT_EFFECT_DATE" 	: $("#fv_CERT_EFFECT_DATE").val(),
		"CERT_EXPIRE_DATE" 	: $("#fv_CERT_EXPIRE_DATE").val(),
		"DIRECTORY" 		: $("#fv_DIRECTORY").val()
	}];
	var sql = fvSqlModel.insertInfo("C_CERT",consKeyArr);
	db_execut_oneSQL("dahc.db", sql[0], [], function(tx,res){
		fvPubUI.fvMsgShow("数据上装成功");
		ydjc_loginuser_bl_back();
	}, null);
}

/**
 * 返回
 */
function ydjc_loginuser_bl_back()
{
 	changepage("../../BasicInfoVerify/CheckCardInfo/html/CheckCardInfoVerify.html");
}