$("#ydjc_loginuser_nav_bl").html("用户证件信息-修改");
var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);
var fvCertId = sessionStorage.cert_id;
var certData;

init();
/********************************************初始化***********************************************/
/**
 * 初始化标题和点击事件
 */
function init() 
{	
	fvPubUI.fvLoading();
	
	$("#fv_cons_no").html(fvConsInfo.cons_no);
	$("#fv_cons_info").html(getHeaderInfo(fvConsInfo.cons_sort_code_str, fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str));
	
	queryCertInfo();
	
	addItemClickListener();
}

/**
 * 添加点击监听
 */
function addItemClickListener()
{
	//证件生效日期
 	$("#fv_CERT_EFFECT_DATE").click( function()
 	{ 
 		fvPubUI.getDate("fv_CERT_EFFECT_DATE");
 	});
 	
 	//证件失效日期
 	$("#fv_CERT_EXPIRE_DATE").click( function()
 	{ 
 		fvPubUI.getDate("fv_CERT_EXPIRE_DATE");
 	});	
 	
 	//上装
 	$("#fvCertUpload").click( function()
 	{ 
 		uploadData();
 	});	
}

/********************************************查询证件信息***********************************************/

/**
 * 查询证件
 */
function queryCertInfo()
{
	var sql = "SELECT * FROM C_CERT WHERE APP_NO="+sessionStorage.fvAppNo + " AND CERT_ID="+fvCertId;
	db_execut_oneSQL("dahc.db", sql, [], queryCertSuccess,queryCertFail);	
}
/**
 * 查询证件成功
 */
function queryCertSuccess(tx,res)
{
	fvPubUI.fvLoadingClose();
	
	var len=res.rows.length;
    if(len > 0)
    {
        fillCertUI(res.rows);
    }else
    {
    	fvPubUI.fvMsgShow("未查询到证件信息");
    }
}
/**
 * 查询证件失败
 */
function queryCertFail(tx,res)
{
	fvPubUI.fvLoadingClose();
	fvPubUI.fvMsgShow("未查询到证件信息");
}
/********************************************填充UI***********************************************/

//页面数据初始化
function fillCertUI(value)
{
	// 获取证件信息
	var data = value.item(0);
	certData = data;
	
	var pcode_29012 = getPcodeItemByValue(fvPcode.codeSortJson["A_29012"], data.CERT_TYPE_CODE);
	
	// 证件名称
	$("#fv_CERT_NAME").val(data.CERT_NAME);
	// 证件类型
	$("#fv_CERT_TYPE_CODE").html(pcode_29012.name);
    $("#fv_CERT_TYPE_CODE").attr("name",pcode_29012.value);
    // 证件号码
	$("#fv_CERT_NO").val(data.CERT_NO);
	// 证件生效时间
	$("#fv_CERT_EFFECT_DATE").val(data.CERT_EFFECT_DATE);
	// 证件失效时间
	$("#fv_CERT_EXPIRE_DATE").val(data.CERT_EXPIRE_DATE);
	// 证件扫描件的存储路径
	$("#fv_DIRECTORY").val(data.DIRECTORY);
	
	pCdoeSelectList({"id":"fv_CERT_TYPE_CODE","pCode":[{"A_29012":"","codeId":29012}]});
}
/**
 * 获取pcode列表中的特定项
 */
function getPcodeItemByValue(pCodeList, value)
{
	for(var i=0;i<pCodeList.length;i++)
    {
    	if(pCodeList[i].value == value)
    	{
    		return pCodeList[i];
    	}else if((i+1) >= pCodeList.length)
    	{
    		var tObj = new Object();
    		tObj.value = value;
    		tObj.name = "";
    		return tObj;
    	}
    }  
}

/********************************************保存修改信息***********************************************/
/**
 * 保存修改的数据
 */
function uploadData()
{
	if(checkEmpty())
	{
		fvPubUI.fvLoading();
		sendEditToServer();
	}
}

/**
 * 判断是否为空
 */
function checkEmpty()
{
	if(checkStringTrim($("#fv_CERT_NAME").val()))
	{
		fvPubUI.fvMsgShow("证件名称不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_CERT_TYPE_CODE").attr("name")))
	{
		fvPubUI.fvMsgShow("证件类型不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_CERT_NO").val()))
	{
		fvPubUI.fvMsgShow("证件号码不能为空");
		return false;
	}
	return true;
}
/**
 * 判断字符串是否为空
 */
function checkStringTrim(str)
{
	if(str == "" || str == undefined)
		return true;
	return false;
}

/**
 * 发送修改信息到服务端
 */
function sendEditToServer()
{
	var editObj = 	'"APP_NO":"'			+ certData.APP_NO+'",' + 
					'"CERT_ID":"'			+ certData.CERT_ID+'",' +					
					'"CERT_TYPE_CODE":"'	+ $("#fv_CERT_TYPE_CODE").attr("name")+'",' +
					'"CERT_NAME":"' 		+ $("#fv_CERT_NAME").val()+'",'+
					'"CERT_NO":"' 			+ $("#fv_CERT_NO").val()+'",'+
					'"CERT_EFFECT_DATE":"' 	+ $("#fv_CERT_EFFECT_DATE").val()+'",'+
					'"CERT_EXPIRE_DATE":"' 	+ $("#fv_CERT_EXPIRE_DATE").val()+'",'+
					'"DIRECTORY":"' 		+ $("#fv_DIRECTORY").val()+'"';
					
					
					
	//1.发送实名制认证基本信息请求到服务器
	var pkg='{"MOD":"2034","FUN":"030606","ORG_NO":"'+sessionStorage.ORG_NO+'","SYS_USER_NAME":"'+ sessionStorage.user_name +'","TERM_NUM":"'+ fvTid +'","PKG":{'+ editObj +'}}';
    send_data("030606","2034",pkg,sendSuccess,sendFail);
}
/**
 * 发送新增信息到服务端回调-成功
 */
function sendSuccess(message)
{	
	try
	{
        fvPubUI.fvLoadingClose();//关闭加载效果框
        var msg_enercb = JSON.parse(message);
        if(msg_enercb.RET=="00")
        {
            var msg_pkg=msg_enercb.PKG.PKG;
            if(msg_pkg.FLAG=="1")
            {
            	updateCertTable();
            }else
            {
            	fvPubUI.fvMsgShow("数据修改失败");
            }
        }else
        {
            fvPubUI.fvMsgShow("数据修改失败");
        }
	}catch(e)
    {
   	 	fvPubUI.fvMsgShow("数据修改失败!返回数据异常");
    }
}
/**
 * 发送新增信息到服务端回调-失败
 */
function sendFail(message)
{	
	//关闭加载效果框
	fvPubUI.fvLoadingClose();
    	
	//操作失败
	fvPubUI.fvMsgShow("数据修改失败");
}

/**
 * 更新充电桩表
 */
function updateCertTable()
{
	var consKeyArr = 
	{
		"tableName" 		: "C_CERT",	
		"CERT_TYPE_CODE" 	: $("#fv_CERT_TYPE_CODE").attr("name"),
		"CERT_NAME" 		: $("#fv_CERT_NAME").val(),
		"CERT_NO" 			: $("#fv_CERT_NO").val(),
		"CERT_EFFECT_DATE" 	: $("#fv_CERT_EFFECT_DATE").val(),
		"CERT_EXPIRE_DATE" 	: $("#fv_CERT_EXPIRE_DATE").val(),
		"DIRECTORY" 		: $("#fv_DIRECTORY").val()
	}
	var whereArr = {"APP_NO" : certData.APP_NO,"CERT_ID" : certData.CERT_ID};
	fvSqlModel.updateInfo(consKeyArr, whereArr, function(){
		fvPubUI.fvMsgShow("数据修改成功");
        ydjc_loginuser_bl_back();
	},null);
}

/**
 * 返回
 */
function ydjc_loginuser_bl_back()
{
 	changepage("../../BasicInfoVerify/CheckCardInfo/html/CardDetail.html");
}


