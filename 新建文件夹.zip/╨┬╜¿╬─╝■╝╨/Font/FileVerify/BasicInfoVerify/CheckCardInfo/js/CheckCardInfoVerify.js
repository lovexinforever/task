$("#ydjc_loginuser_nav_bl").html("证件信息核查");
var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);

init();

/**
 * 初始化标题和点击事件
 */
function init() 
{	
	fvPubUI.fvLoading();
	
	$("#fv_cons_no").html(fvConsInfo.cons_no);
	$("#fv_cons_info").html(getHeaderInfo(fvConsInfo.cons_sort_code_str, fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str));
	
	initPhoto();	
	addListener();
	queryUesrBasicInfo();
}

/**
 * 初始化图片显示
 */
function initPhoto()
{
	var tPhotoArray =[["fv_displayIDCardPhoto", "01"], ["fv_displayHousePhoto", "02"], ["fv_displayElecPhoto", "03"], ["fv_displayContactPhoto", "04"]]; 
	initPhotoDisplay(tPhotoArray, fvConsInfo.cons_no);
}


/**
 * 添加点击监听
 */
function addListener()
{
	// 保存数据
	$("#fv_saveData").click(function()
	{
		saveData();
	});
	
	// 身份证明
	$("#fv_addIDCardPhoto").click(function()
	{
		takePhoto("fv_displayIDCardPhoto", "01", fvConsInfo.cons_no);
	});
	
	// 房产证明
	$("#fv_addHousePhoto").click(function()
	{
		takePhoto("fv_displayHousePhoto", "02", fvConsInfo.cons_no);
	});
	
	// 用电主体证明
	$("#fv_addElecPhoto").click(function()
	{
		takePhoto("fv_displayElecPhoto", "03", fvConsInfo.cons_no);
	});
	
	// 联系人确认单
	$("#fv_addContactPhoto").click(function()
	{
		takePhoto("fv_displayContactPhoto", "04", fvConsInfo.cons_no);
	});
	
	// 身份证明图片上装
	$("#fv_IDCardUpload").click(function()
	{
		uploadPhoto("01", fvConsInfo.cons_no);
	});
	// 房产证明图片上装
	$("#fv_HouseUpload").click(function()
	{
		uploadPhoto("02", fvConsInfo.cons_no);
	});
	// 用电主体证明图片上装
	$("#fv_ElecUpload").click(function()
	{
		uploadPhoto("03", fvConsInfo.cons_no);
	});
	// 联系人确认单图片上装
	$("#fv_ContactUpload").click(function()
	{
		uploadPhoto("04", fvConsInfo.cons_no);
	});
	// 新增证件
	$("#addCertInfo").click(function()
	{
		addCert();
	});
}


/******************************************查询证用户基本信息***********************************************/
/**
 * 查询用户基本信息
 */
function queryUesrBasicInfo()
{
	// 使用工单编号与用户标识查询用户基本信息
	var sql = "SELECT * FROM P_ACT_CONS WHERE APP_NO="+ sessionStorage.fvAppNo +" AND CONS_ID="+fvConsInfo.cons_id;
	db_execut_oneSQL("dahc.db", sql, [], sucessCB_bl_1,failCB_bl_1);
}

// 查询成功
function sucessCB_bl_1(tx, res) 
{	
	fvPubUI.fvLoadingClose();
	var len=res.rows.length;
    if(len > 0)
    {
        fillUserBasicInfo(res.rows);
    }else
    {
    	fvPubUI.fvMsgShow("未查询到基本信息数据");
    }
}
// 查询失败
function failCB_bl_1(e)
{
	fvPubUI.fvLoadingClose();
	fvPubUI.fvMsgShow("查询基本信息失败");
}

/**
 * 填充用户基本信息
 */
function fillUserBasicInfo(value)
{
	var data = value.item(0);
	var pcode_29011 = getPcodeNameByValue(fvPcode.codeSortJson["A_29011"], data.CONS_SORT_CODE);
	var pcode_16045 = getPcodeNameByValue(fvPcode.codeSortJson["A_16045"], data.RRIO_CODE);
	var pcode_10005 = getPcodeNameByValue(fvPcode.codeSortJson["A_10005"], data.VOLT_CODE);
	var pcode_19004 = getPcodeNameByValue(fvPcode.codeSortJson["A_19004"], data.MEAS_MODE);
	try
	{
		// 用户编号
        $("#fv_CONS_NO").html(data.CONS_NO);
        // 用户名称
        $("#fv_CONS_NAME").html(data.CONS_NAME);
        // 用户分类
        $("#fv_CONS_SORT").html(pcode_29011.name);
        // 用电地址
        $("#fv_ELEC_ADDR").html(data.ELEC_ADDR);
        // 重要性等级
        $("#fv_ELEC_RRIO").html(pcode_16045.name);
        // 计量方式
        $("#fv_MEAS_MODE").html(pcode_19004.name);
        // 电压等级
        $("#fv_VOLT_CODE").html(pcode_10005.name);
        // 合同容量
        $("#fv_CONTRACT_CAP").html(data.CONTRACT_CAP);
	}catch(err)
	{
	   	fvPubUI.fvLoadingClose();
	}
	
	// 查询用户实名制等级信息
	queryRealNameLevel();
}

/******************************************查询证用户实名制***********************************************/
/**
 * 查询用户实名制等级信息
 */
function queryRealNameLevel()
{
	fvPubUI.fvLoading();
	// 使用工单编号与用户标识查询用户基本信息
	var sql = "SELECT * FROM C_CONS_GY WHERE APP_NO="+ sessionStorage.fvAppNo +" AND CONS_ID="+fvConsInfo.cons_id;
	db_execut_oneSQL("dahc.db", sql, [], sucessCB_bl_2,failCB_bl_2);
	
	// 查询成功
	function sucessCB_bl_2(tx, res) 
	{	
		fvPubUI.fvLoadingClose();
		
		var count = res.rows.length;
		if (count > 0) 
		{
			fillRealNameLevel(res.rows);
		}else
		{
			fvPubUI.fvMsgShow("未查询到实名制等级数据");
		}
	}
	// 查询失败
	function failCB_bl_2(e)
	{
		fvPubUI.fvLoadingClose();
		fvPubUI.fvMsgShow("查询实名制等级数据失败");
	}
}

/**
 * 填充用户实名信息
 */
function fillRealNameLevel(value)
{
	var data = value.item(0);
	
	var pcode_11248 = getPcodeNameByValue(fvPcode.codeSortJson["A_11248"], data.REAL_NAME_TYPE);
	var pcode_30022 = getPcodeNameByValue(fvPcode.codeSortJson["A_30022"], data.REAL_NAME_FLAG);
	var pcode_11250 = getPcodeNameByValue(fvPcode.codeSortJson["A_11250"], data.REAL_CONS_TYPE);
	
	try
	{
		$("#fv_REAL_NAME_TYPE").html(pcode_11248.name);
		$("#fv_REAL_NAME_TYPE").attr("name",pcode_11248.value);
		
        $("#fv_REAL_NAME_FLAG").html(pcode_30022.name);
        $("#fv_REAL_NAME_FLAG").attr("name",pcode_30022.value);
        
        $("#fv_REAL_CONS_TYPE").html(pcode_11250.name);
        $("#fv_REAL_CONS_TYPE").attr("name",pcode_11250.value);
	    
        setTimeout(function()
        {
			bindFvSelect();
		},500);
        
	}catch(err)
	{
	   	fvPubUI.fvLoadingClose();
	}
	
	// 查询证件信息列表
	queryCertInfoList();
}

/**
 * 绑定下拉框
 */
function bindFvSelect()
{	
	$("#fv_REAL_NAME_TYPE").fvSelect({
	    callback:function(obj){
	        console.log("-选择了:"+obj.selectobj.value+"---"+obj.selectobj.name);
	    },
	    list:fvPcode.codeSortJson["A_11248"]
	});
	$("#fv_REAL_NAME_FLAG").fvSelect({
	    callback:function(obj){
	        console.log("-选择了:"+obj.selectobj.value+"---"+obj.selectobj.name);
	    },
	    list:fvPcode.codeSortJson["A_30022"]
	});
	$("#fv_REAL_CONS_TYPE").fvSelect({
	    callback:function(obj){
	        console.log("-选择了:"+obj.selectobj.value+"---"+obj.selectobj.name);
	    },
	    list:fvPcode.codeSortJson["A_11250"]
	});
}

/******************************************查询证件信息列表***********************************************/
/**
 * 查询证件信息列表
 */
function queryCertInfoList()
{
	var sql = "SELECT * FROM C_CERT WHERE APP_NO="+ sessionStorage.fvAppNo +" AND CONS_ID="+fvConsInfo.cons_id;
	db_execut_oneSQL("dahc.db", sql, [], sucessQueryCert,null);
}
function sucessQueryCert(tx, res)
{
	var count = res.rows.length;
	if (count > 0) 
	{
		fillCertInfoList(res.rows);
	}
}
function fillCertInfoList(data)
{
	var certList="";
	for (var i = 0; i < data.length; i++)
	{
		var cert_type = getPcodeNameByValue(fvPcode.codeSortJson["A_29012"], data.item(i).CERT_TYPE_CODE);
		certList +=	'<div class="fvContent displayflex" id="'+ data.item(i).CERT_ID +'" onclick="clickListItem(this.id)">'
            		+'<div class="fvManIconGreen"></div>'
            		+'<div class="boxflex_01 fvManPhone displayflexvertical">'
                	+'<div class="boxflex_01 fvGreenFont">证件名称：' + data.item(i).CERT_NAME+'</div>'
                	+'<div class="boxflex_01">证件类型：' + cert_type.name +'</div>'
                	+'<div class="boxflex_01">证件号码：' + data.item(i).CERT_NO + '</div>'
            		+'</div>'
        			+'</div>'           
        			+'<div class="fvTopBorder"></div>';
	}
	$("#certInfoList").html(certList);		
}
/**
 * 点击证件列表中的一项
 * 跳转到件列表详情
 */
function clickListItem(certId)
{
	// 记录下被点击的计量点工单编号和计量点标识
	sessionStorage.cert_id=certId;
	// 跳转到计量点详细页面
	changepage("../../BasicInfoVerify/CheckCardInfo/html/CardDetail.html");
}

/**
 * 新增证件信息
 */
function addCert()
{
	// 跳转到计量点详细页面
	changepage("../../BasicInfoVerify/CheckCardInfo/html/CardAdd.html");
}

/**
 * 查看大图
 */
function displayBigPicture(pType)
{
	//alert("查看 "+pType + " 大图");
}

/**
 * 获取pcode列表中的特定项
 */
function getPcodeNameByValue(pCodeList, value)
{
	
	if(pCodeList==undefined || value==undefined || value=="")
	{
		var tObj = new Object();
		tObj.name="";
		tObj.value=value
		return tObj;
	}

	for(var i=0;i<pCodeList.length;i++)
    {
    	if(pCodeList[i].value == value)
    	{
    		return pCodeList[i];
    	}
    }  
}

//////////////////////////////////////////////////保存数据//////////////////////////////////////////////////
/**
 * 保存数据
 * 保存实名制等级
 */
function saveData()
{	
	if(checkEmpty())
	{
		fvPubUI.fvLoading();
		sendCardToServer();
	}
}
/**
 * 判断是否为空
 */
function checkEmpty()
{
	if(checkStringTrim($("#fv_REAL_NAME_FLAG").attr("name")))
	{
		fvPubUI.fvMsgShow("实名认证标志不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_REAL_NAME_TYPE").attr("name")))
	{
		fvPubUI.fvMsgShow("实名认证等级不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_REAL_CONS_TYPE").attr("name")))
	{
		fvPubUI.fvMsgShow("实名认证客户类型不能为空");
		return false;
	}
	return true;
}
/**
 * 判断字符串是否为空
 */
function checkStringTrim(str)
{
	if(str == "" || str == undefined)
		return true;
	return false;
}











/**
 * 发送证件信息到服务器
 */
function sendCardToServer()
{
	var nameType = $("#fv_REAL_NAME_TYPE").attr("name");	
	var nameFlag = $("#fv_REAL_NAME_FLAG").attr("name");
	var consType = $("#fv_REAL_CONS_TYPE").attr("name");
	
	
	
	var json_str= '"CONS_ID":"'			+ fvConsInfo.cons_id +'",' + 
				  '"REAL_NAME_TYPE":"'  + nameType +'",' + 
				  '"REAL_NAME_FLAG":"'  + nameFlag +'",' + 
				  '"REAL_CONS_TYPE":"'  + consType +'"';
	
	//1.发送证件基本信息请求到服务器
	var pkg='{"MOD":"2034","FUN":"030608","ORG_NO":"'+sessionStorage.ORG_NO+'","SYS_USER_NAME":"'+ sessionStorage.user_name +'","TERM_NUM":"'+ fvTid +'","PKG":{'+ json_str +'}}';
    send_data("030608","2034",pkg,uploadSuccess,uploadFail);
}

/**
 * 图片上装成功
 */
function uploadSuccess(message)
{
	try
	{
        fvPubUI.fvLoadingClose();//关闭加载效果框
        var msg = JSON.parse(message);        
        var msg_pkg=msg.PKG.PKG;
        
        if(msg_pkg.FLAG=="1")
        {// 成功        	
        	updateRealNameTable();
        }else
        {// 失败        	
        	fvPubUI.fvMsgShow("数据上装失败");
        }
    }catch(e)
    {
   	 	fvPubUI.fvMsgShow("数据上装失败!返回数据异常");
    }
}
/**
 * 图片上装失败
 */
function uploadFail(msg)
{
	fvPubUI.fvLoadingClose();//关闭加载效果框	
	fvPubUI.fvMsgShow("图片上装失败");
}
 
/**
 * 更新实名制
 */
function updateRealNameTable()
{
	var consKeyArr = 
	{
		"tableName" 	 : "C_CONS_GY",
		"REAL_NAME_TYPE" : $("#fv_REAL_NAME_TYPE").attr("name"),
		"REAL_NAME_FLAG" : $("#fv_REAL_NAME_FLAG").attr("name"),
		"REAL_CONS_TYPE" : $("#fv_REAL_CONS_TYPE").attr("name")
	};
	var whereArr = {"APP_NO" : sessionStorage.fvAppNo,"CONS_ID" : fvConsInfo.cons_id};
	
	fvSqlModel.updateInfo(consKeyArr, whereArr, function(){
		fvPubUI.fvMsgShow("数据上装成功");
	},null);//更新高压用户基础档案表
}

/**
 * 返回
 */
function ydjc_loginuser_bl_back()
{
 	changepage("../../BasicInfoVerify/Checkuserinfo/Userbaseinfo/html/Userbaseinfo.html");
}