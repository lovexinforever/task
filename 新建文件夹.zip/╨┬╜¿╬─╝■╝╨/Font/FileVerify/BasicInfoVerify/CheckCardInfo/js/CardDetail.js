$("#ydjc_loginuser_nav_bl").html("用户证件信息-详情");
var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);
// 设备id
var fvCertId = sessionStorage.cert_id;
var certData;
init();
/********************************************初始化***********************************************/
/**
 * 初始化标题和点击事件
 */
function init() 
{	
	fvPubUI.fvLoading();
	$("#fv_cons_no").html(fvConsInfo.cons_no);
	$("#fv_cons_info").html(getHeaderInfo(fvConsInfo.cons_sort_code_str, fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str));
	
	queryCertInfo();
	addClickListener();
}

function addClickListener()
{
	// 点击修改充电桩信息
	$("#fvEditCert").click(function()
	{
		changepage("../../BasicInfoVerify/CheckCardInfo/html/CardEdit.html");
	});
	
	// 点击删除充电桩
	$("#fvDeleteCert").click(function()
	{
		if(certData.APP_NO=="" || certData.APP_NO==undefined)
		{
			fvPubUI.fvMsgShow("申请编号为空,删除失败!");
		}else
		{
			$("#delete_dailog").show();
		}
	});
}

/********************************************查询证件信息***********************************************/

/**
 * 查询证件
 */
function queryCertInfo()
{
	var sql = "SELECT * FROM C_CERT WHERE APP_NO="+sessionStorage.fvAppNo + " AND CERT_ID="+fvCertId;
	db_execut_oneSQL("dahc.db", sql, [], queryCertSuccess,queryCertFail);	
}
/**
 * 查询证件成功
 */
function queryCertSuccess(tx,res)
{
	fvPubUI.fvLoadingClose();
	
	var len=res.rows.length;
    if(len > 0)
    {
        fillCertUI(res.rows);
    }else
    {
    	fvPubUI.fvMsgShow("未查询到证件信息");
    }
}
/**
 * 查询证件失败
 */
function queryCertFail(tx,res)
{
	fvPubUI.fvLoadingClose();
	fvPubUI.fvMsgShow("未查询到证件信息");
}
/********************************************填充UI***********************************************/

//页面数据初始化
function fillCertUI(value)
{
	// 获取证件信息
	var data = value.item(0);
	certData = data;
	
	var pcode_29012 = getPcodeItemByValue(fvPcode.codeSortJson["A_29012"], data.CERT_TYPE_CODE);
	
	// 工单编号
	$("#fv_APP_NO").html(data.APP_NO);
	// 证件名称
	$("#fv_CERT_NAME").html(data.CERT_NAME);
	// 证件类型
	$("#fv_CERT_TYPE_CODE").html(pcode_29012.name);
    // 证件号码
	$("#fv_CERT_NO").html(data.CERT_NO);
	// 证件生效时间
	$("#fv_CERT_EFFECT_DATE").html(data.CERT_EFFECT_DATE);
	// 证件失效时间
	$("#fv_CERT_EXPIRE_DATE").html(data.CERT_EXPIRE_DATE);
	// 证件扫描件的存储路径
	$("#fv_DIRECTORY").html(data.DIRECTORY);
}
/**
 * 获取pcode列表中的特定项
 */
function getPcodeItemByValue(pCodeList, value)
{
	for(var i=0;i<pCodeList.length;i++)
    {
    	if(pCodeList[i].value == value)
    	{
    		return pCodeList[i];
    	}else if((i+1) >= pCodeList.length)
    	{
    		var tObj = new Object();
    		tObj.value = value;
    		tObj.name = "";
    		return tObj;
    	}
    }  
}

/********************************************删除充电桩***********************************************/

// 删除确定按钮
function delete_data_enter() 
{
    $("#delete_dailog").hide();
    
    fvPubUI.fvLoading();
    // 将删除的记录标示发给服务器
    sendDeleteToServer();
}

/**
 * 将删除的记录标示发给服务器
 */
function sendDeleteToServer()
{
	var delObj= '"APP_NO":"' + certData.APP_NO + '",'+
				'"CERT_ID":"' + fvCertId + '"';
				
	//1.发送实名制认证基本信息请求到服务器
	var pkg='{"MOD":"2034","FUN":"030607","ORG_NO":"'+sessionStorage.ORG_NO+'","SYS_USER_NAME":"'+ sessionStorage.user_name +'","TERM_NUM":"'+ fvTid +'","PKG":{'+ delObj +'}}';
    send_data("030607","2034",pkg,sendDeleteSuccess,sendDeleteFail);
}

/**
 * 删除记录回调-成功
 */
function sendDeleteSuccess(message)
{	
	try
	{
        fvPubUI.fvLoadingClose();//关闭加载效果框
        var msg_enercb = JSON.parse(message);
        if(msg_enercb.RET=="00")
        {
            var msg_pkg=msg_enercb.PKG.PKG;
            if(msg_pkg.FLAG=="1")
            {
            	deleteCert();
            }else
            {
            	fvPubUI.fvMsgShow("数据删除失败");
            }
        }else
        {
            fvPubUI.fvMsgShow("数据删除失败");
        }
	}catch(e)
    {
   	 	fvPubUI.fvMsgShow("数据删除失败!返回数据异常");
    }
}
/**
 * 删除记录回调-失败
 */
function sendDeleteFail(message)
{	
	fvPubUI.fvLoadingClose();//关闭加载效果框
    	
	//操作失败
	fvPubUI.fvMsgShow("数据删除失败");
}
/**
 * 删除充电桩
 */
function deleteCert()
{
	// 删除数据库中运行设备信息表的记录	
	var sql="DELETE FROM C_CERT WHERE APP_NO='"+certData.APP_NO +"' AND CERT_ID="+fvCertId;
    db_execut_oneSQL("dahc.db",sql,[],function()
    {
    
    	fvPubUI.fvMsgShow("数据删除成功");
    	ydjc_loginuser_bl_back();
    },function()
    {
    	fvPubUI.fvMsgShow("数据库记录删除失败");
    });
}

/**
 * 返回
 */
function ydjc_loginuser_bl_back()
{
 	changepage("../../BasicInfoVerify/CheckCardInfo/html/CheckCardInfoVerify.html");
}