$("#ydjc_loginuser_nav_bl").html("计量点信息核查");
var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);

var pointSessionData;

init();

function init()
{
	fvPubUI.fvLoading();
	
	$("#fv_cons_no").html(fvConsInfo.cons_no);
	$("#fv_cons_info").html(getHeaderInfo(fvConsInfo.cons_sort_code_str, fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str));
	
	slect_MeasPointList_Data();
	fillComboList();
	
	/**
	 * 点击返回按钮
	 */  
	$("#fv_measpoint_back").click(function()
	{	
		changepage("../../BasicInfoVerify/Checkuserinfo/Userbaseinfo/html/UserInfoModel.html");
	});
	
	/**
	 * 点击上装按钮
	 */  
	$("#fv_MeasPoint_Upload").click(function()
	{	
		uploadFunc();
	});
}


/**
 * 计量点详情初始化
 */
 
function slect_MeasPointList_Data()
{ 
    var sql = "SELECT * FROM C_MP WHERE APP_NO="+ sessionStorage.measPointItem_APP_NO +" AND MP_ID="+sessionStorage.measPointItem_MP_ID;    
    db_execut_oneSQL("dahc.db",sql,[],queryMeasPointSuccess,null);
}

//成功回调
function queryMeasPointSuccess(tx,res)
{
    var len=res.rows.length;
    if(len > 0)
    {
        fillMeasPointDetail(res.rows);
    }else
    {
    	fvPubUI.fvMsgShow("未查询到计量点数据");
    }
}

/**
 * 填充用户基本信息
 */
function fillMeasPointDetail(value)
{
	var data = value.item(0);
	pointSessionData = data;
	
	var pcode_19033 = getPcodeItemByValue(fvPcode.codeSortJson["A_19033"], data.TYPE_CODE);
	var pcode_19047 = getPcodeItemByValue(fvPcode.codeSortJson["A_19047"], data.MP_ATTR_CODE);
	var pcode_19006;
	var pcode_19006_list = fvPcode.codeSortJson["A_19006"];
	var pcode_30022;	
	var pcode_30022_list = fvPcode.codeSortJson["A_30022"];
	var pcode_14003 = getPcodeItemByValue(fvPcode.codeSortJson["A_14003"], data.CALC_MODE);
	var pcode_MP_LEVEL = (data.MP_LEVEL == "1") ? "顶级" : "次级";
	var pcode_19001 = getPcodeItemByValue(fvPcode.codeSortJson["A_19001"], data.MD_TYPE_CODE);
	var pcode_19005 = getPcodeItemByValue(fvPcode.codeSortJson["A_19005"], data.WIRING_MODE);
	var pcode_10005 = getPcodeItemByValue(fvPcode.codeSortJson["A_10005"], data.VOLT_CODE);
	var pcode_19004 = getPcodeItemByValue(fvPcode.codeSortJson["A_19004"], data.MEAS_MODE);
	var pcode_21004 = getPcodeItemByValue(fvPcode.codeSortJson["A_21004"], data.EXCHG_TYPE_CODE);
	var pcode_19013 = getPcodeItemByValue(fvPcode.codeSortJson["A_19013"], data.SIDE_CODE);
	var pcode_19023 = getPcodeItemByValue(fvPcode.codeSortJson["A_19023"], data.STATUS_CODE);
	var pcode_14007 = getPcodeItemByValue(fvPcode.codeSortJson["A_14007"], data.LL_CALC_MODE);
	var pcode_29005 = getPcodeItemByValue(fvPcode.codeSortJson["A_29005"], data.TRADE_CODE);
	var pcode_14004 = getPcodeItemByValue(fvPcode.codeSortJson["A_14004"], data.TRADE_CODE);
	var pcode_19036 = getPcodeItemByValue(fvPcode.codeSortJson["A_19036"], data.EARTH_MODE);
	
	try
	{
		$("#fv_MP_NO").val(data.MP_NO);		
        $("#fv_MP_NAME").val(data.MP_NAME);
        $("#fv_MP_ADDR").val(data.MP_ADDR);
        
        $("#fv_TYPE_CODE").html(pcode_19033.name);
        $("#fv_TYPE_CODE").attr("name",pcode_19033.value);  
              
       // $("#fv_TYPE_CODE").val(data.TYPE_CODE);
       
        $("#fv_MP_ATTR").html(pcode_19047.name);
        $("#fv_MP_ATTR").attr("name",pcode_19047.value);        
       // $("#fv_MP_ATTR").val(data.MP_ATTR_CODE);    
       
       	pcode_19006 = getPcodeItemByValue(pcode_19006_list, data.USAGE_TYPE_CODE);
        $("#fv_USAGE_TYPE").html(pcode_19006.name); 
        $("#fv_USAGE_TYPE").attr("name",pcode_19006.value);           
        //$("#fv_USAGE_TYPE").val(data.USAGE_TYPE_CODE);
        
        $("#fv_LINE_NAME").val(data.LINE_NAME);
        $("#fv_TG_NAME").val(data.TG_NAME);
        
        pcode_30022 = getPcodeItemByValue(pcode_30022_list, data.LC_FLAG);
        $("#fv_LC_FLAG").val(pcode_30022.name);
        $("#fv_LC_FLAG").attr("name",pcode_30022.value); 
        
        $("#fv_CALC_MODE").html(pcode_14003.name);  
        $("#fv_CALC_MODE").attr("name",pcode_14003.value); 
        //$("#fv_CALC_MODE").val(data.CALC_MODE);  
        
        $("#fv_MP_LEVEL").val(pcode_MP_LEVEL);
        //$("#fv_MP_LEVEL").val(data.MP_LEVEL); 
        
        $("#fv_MD_TYPE").html(pcode_19001.name);
        $("#fv_MD_TYPE").attr("name",pcode_19001.value);        
        //$("#fv_MD_TYPE").val(data.MD_TYPE_CODE);
        
        $("#fv_WIRING_MODE").html(pcode_19005.name);
        $("#fv_WIRING_MODE").attr("name",pcode_19005.value);
        // $("#fv_WIRING_MODE").val(data.WIRING_MODE);
        
        $("#fv_VOLT_CODE").val(pcode_10005.name);  
        $("#fv_FQR_VALUE").val(data.FQR_VALUE);     
        
        pcode_30022 = getPcodeItemByValue(pcode_30022_list, data.FR_DEDUCT_FLAG);
        $("#fv_FR_DEDUCT_FLAG").html(pcode_30022.name);
        $("#fv_FR_DEDUCT_FLAG").attr("name",pcode_30022.value); 
        //$("#fv_FR_DEDUCT_FLAG").val(data.FR_DEDUCT_FLAG);
        
        $("#fv_DEDUCT_ORDER").val(data.DEDUCT_ORDER); 
        $("#fv_MR_SN").val(data.MR_SN);
        $("#fv_MR_SECT_NO").val(data.MR_SECT_NO);
        
        
        pcode_30022 = getPcodeItemByValue(pcode_30022_list, data.METER_FLAG);
        $("#fv_METER_FLAG").val(pcode_30022.name); 
        $("#fv_METER_FLAG").attr("name",pcode_30022.value);
        
        $("#fv_RUN_DATE").val(data.RUN_DATE.split(" ")[0]);
        $("#fv_APP_DATE").val(data.APP_DATE.split(" ")[0]);
        
        $("#fv_MEAS_MODE").html(pcode_19004.name);
       	$("#fv_MEAS_MODE").attr("name",pcode_19004.value);
        //$("#fv_MEAS_MODE").val(data.MEAS_MODE);
        
        $("#fv_ORG_NAME").val(data.ORG_NAME);
        $("#fv_SWITCH_NO").val(data.SWITCH_NO);
        
        $("#fv_EXCHG_TYPE").html(pcode_21004.name);
        $("#fv_EXCHG_TYPE").attr("name",pcode_21004.value);        
        //$("#fv_EXCHG_TYPE").val(data.EXCHG_TYPE_CODE);  
        
        $("#fv_SIDE_CODE").html(pcode_19013.name);
        $("#fv_SIDE_CODE").attr("name",pcode_19013.value);                
        //$("#fv_SIDE_CODE").val(data.SIDE_CODE);
        
        $("#fv_MP_SN").val(data.MP_SN);        
        $("#fv_STATUS_CODE").val(pcode_19023.name); 
        $("#fv_STATUS_CODE").attr("name",pcode_19023.value);
        
        pcode_30022 = getPcodeItemByValue(pcode_30022_list, data.TL_SHARE_FLAG);
        $("#fv_TL_SHARE_FLAG").html(pcode_30022.name);
        $("#fv_TL_SHARE_FLAG").attr("name",pcode_30022.value);
        pcode_30022 = getPcodeItemByValue(pcode_30022_list, data.LL_SHARE_FLAG);
        $("#fv_LL_SHARE_FLAG").html(pcode_30022.name);
        $("#fv_LL_SHARE_FLAG").attr("name",pcode_30022.value);
        pcode_30022 = getPcodeItemByValue(pcode_30022_list, data.TL_BILL_FLAG);
        $("#fv_TL_BILL_FLAG").html(pcode_30022.name);
        $("#fv_TL_BILL_FLAG").attr("name",pcode_30022.value);
        pcode_30022 = getPcodeItemByValue(pcode_30022_list, data.LL_BILL_FLAG);
        $("#fv_LL_BILL_FLAG").html(pcode_30022.name);
        $("#fv_LL_BILL_FLAG").attr("name",pcode_30022.value);
        //$("#fv_TL_SHARE_FLAG").val(data.TL_SHARE_FLAG);        
//        $("#fv_LL_SHARE_FLAG").val(data.LL_SHARE_FLAG);
//        $("#fv_TL_BILL_FLAG").val(data.TL_BILL_FLAG);
//        $("#fv_LL_BILL_FLAG").val(data.LL_BILL_FLAG);

        $("#fv_LL_CALC_MODE").html(pcode_14007.name);
		$("#fv_LL_CALC_MODE").attr("name",pcode_14007.value);		
        //$("#fv_LL_CALC_MODE").val(data.LL_CALC_MODE);
        
        $("#fv_AP_LL_VALUE").val(data.AP_LL_VALUE);        
        $("#fv_RP_LL_VALUE").val(data.RP_LL_VALUE);
        $("#fv_MP_CAP").val(data.MP_CAP);  
        
        pcode_19006 = getPcodeItemByValue(pcode_19006_list, data.USAGE_CODE);
        $("#fv_USAGE_CODE").html(pcode_19006.name); 
        $("#fv_USAGE_CODE").attr("name",pcode_19006.value);  
        
        
        $("#fv_TRADE_CODE").val(pcode_29005.name);  
        $("#fv_TRADE_CODE").attr("name",pcode_29005.value);       
        //$("#fv_TRADE_CODE").val(data.TRADE_CODE);
        
        $("#fv_PRC_CODE").val(data.PRC_CODE); 
        
        $("#fv_PF_STD_CODE").val(pcode_14004.name);  
        $("#fv_PF_STD_CODE").attr("name",pcode_14004.value);       
                
        pcode_30022 = getPcodeItemByValue(pcode_30022_list, data.TS_FLAG);
        $("#fv_TS_FLAG").val(pcode_30022.name);
        $("#fv_TS_FLAG").attr("name",pcode_30022.value); 
                
        $("#fv_FIX_RATIO").val(data.FIX_RATIO);
        
        $("#fv_EARTH_MODE").html(pcode_19036.name);
        $("#fv_EARTH_MODE").attr("name",pcode_19036.value);
        //$("#fv_EARTH_MODE").val(data.EARTH_MODE);
	}catch(err)
	{
	   	fvPubUI.fvLoadingClose();
	}	
	fvPubUI.fvLoadingClose();
}

/**
 * 填充下拉框
 */
function fillComboList()
{
	pCdoeSelectList({"id" : "fv_TYPE_CODE","pCode" : [{"A_19033" : "","codeId" : 19033}]});
	pCdoeSelectList({"id" : "fv_MP_ATTR","pCode" : [{"A_19047" : "","codeId" : 19047}]});
	pCdoeSelectList({"id" : "fv_USAGE_TYPE","pCode" : [{"A_19006" : "","codeId" : 19006}]});
	pCdoeSelectList({"id" : "fv_SIDE_CODE","pCode" : [{"A_19013" : "","codeId" : 19013}]});
	pCdoeSelectList({"id" : "fv_WIRING_MODE","pCode" : [{"A_19005" : "","codeId" : 19005}]});
	pCdoeSelectList({"id" : "fv_MEAS_MODE","pCode" : [{"A_19004" : "","codeId" : 19004}]});
	pCdoeSelectList({"id" : "fv_EXCHG_TYPE","pCode" : [{"A_21004" : "","codeId" : 21004}]});
	pCdoeSelectList({"id" : "fv_MD_TYPE","pCode" : [{"A_19001" : "","codeId" : 19001}]});
	pCdoeSelectList({"id" : "fv_CALC_MODE","pCode" : [{"A_14003" : "","codeId" : 14003}]});
	pCdoeSelectList({"id" : "fv_FR_DEDUCT_FLAG","pCode" : [{"A_30022" : "","codeId" : 30022}]});
	pCdoeSelectList({"id" : "fv_TL_SHARE_FLAG","pCode" : [{"A_30022" : "","codeId" : 30022}]});
	pCdoeSelectList({"id" : "fv_LL_SHARE_FLAG","pCode" : [{"A_30022" : "","codeId" : 30022}]});
	pCdoeSelectList({"id" : "fv_TL_BILL_FLAG","pCode" : [{"A_30022" : "","codeId" : 30022}]});
	pCdoeSelectList({"id" : "fv_LL_BILL_FLAG","pCode" : [{"A_30022" : "","codeId" : 30022}]});
	pCdoeSelectList({"id" : "fv_LL_CALC_MODE","pCode" : [{"A_14007" : "","codeId" : 14007}]});	
	pCdoeSelectList({"id" : "fv_USAGE_CODE","pCode" : [{"A_19006" : "","codeId" : 19006}]});
	pCdoeSelectList({"id" : "fv_TRADE_CODE","pCode" : [{"A_29005" : "","codeId" : 29005}]});
	pCdoeSelectList({"id" : "fv_PF_STD_CODE","pCode" : [{"A_14004" : "","codeId" : 14004}]});	
	pCdoeSelectList({"id" : "fv_EARTH_MODE","pCode" : [{"A_19036" : "","codeId" : 19036}]});
}

/**
 * 获取pcode列表中的特定项
 */
function getPcodeItemByValue(pCodeList, value)
{
	for(var i=0;i<pCodeList.length;i++)
    {
    	if(pCodeList[i].value == value)
    	{
    		return pCodeList[i];
    	}else if((i+1) >= pCodeList.length)
    	{
    		var tObj = new Object();
    		tObj.value = value;
    		tObj.name = "";
    		return tObj;
    	}
    	
    }  
}

/**
 * 上装
 */
function uploadFunc()
{
	if(checkEmpty())
	{
		fvPubUI.fvLoading();
		sendInfoToServer();
	}
}

function checkEmpty()
{
	if(checkStringTrim($("#fv_MP_NAME").val()))
	{
		fvPubUI.fvMsgShow("计量点名称不能为空");	
		return;
	}
	if(checkStringTrim($("#fv_MP_ADDR").val()))
	{
		fvPubUI.fvMsgShow("计量点地址不能为空");	
		return;
	}
	if(checkStringTrim($("#fv_TYPE_CODE").attr("name")))
	{
		fvPubUI.fvMsgShow("计量点分类不能为空");	
		return;
	}
	if(checkStringTrim($("#fv_MP_ATTR").attr("name")))
	{
		fvPubUI.fvMsgShow("计量点性质不能为空");	
		return;
	}
	if(checkStringTrim($("#fv_USAGE_TYPE").attr("name")))
	{
		fvPubUI.fvMsgShow("主用途类型不能为空");	
		return;
	}
	if(checkStringTrim($("#fv_LINE_NAME").val()))
	{
		fvPubUI.fvMsgShow("线路名称不能为空");	
		return;
	}
	if(checkStringTrim($("#fv_TG_NAME").val()))
	{
		fvPubUI.fvMsgShow("台区名称不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_LC_FLAG").val()))
	{
		fvPubUI.fvMsgShow("是否采集不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_MEAS_MODE").attr("name")))
	{
		fvPubUI.fvMsgShow("计量方式不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_MP_LEVEL").val()))
	{
		fvPubUI.fvMsgShow("计量点级数不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_MD_TYPE").attr("name")))
	{
		fvPubUI.fvMsgShow("电能计量装置分类不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_WIRING_MODE").attr("name")))
	{
		fvPubUI.fvMsgShow("接线方式不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_VOLT_CODE").val()))
	{
		fvPubUI.fvMsgShow("电压等级不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_MR_SECT_NO").attr("name")))
	{
		fvPubUI.fvMsgShow("抄表段号不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_MR_SN").val()))
	{
		fvPubUI.fvMsgShow("抄表顺序号不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_METER_FLAG").val()))
	{
		fvPubUI.fvMsgShow("是否装表不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_RUN_DATE").val()))
	{
		fvPubUI.fvMsgShow("投运日期不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_RUN_DATE").val()))
	{
		fvPubUI.fvMsgShow("投运日期不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_MEAS_MODE").attr("name")))
	{
		fvPubUI.fvMsgShow("计量方式不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_ORG_NAME").val()))
	{
		fvPubUI.fvMsgShow("供电单位不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_SIDE_CODE").attr("name")))
	{
		fvPubUI.fvMsgShow("计量点所属侧不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_STATUS_CODE").val()))
	{
		fvPubUI.fvMsgShow("计量点状态不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_LL_CALC_MODE").attr("name")))
	{
		fvPubUI.fvMsgShow("线损计算方式不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_MP_CAP").val()))
	{
		fvPubUI.fvMsgShow("计量点容量不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_TRADE_CODE").val()))
	{
		fvPubUI.fvMsgShow("电价行业类别不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_PRC_CODE").val()))
	{
		fvPubUI.fvMsgShow("电价不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_PRC_CODE").val()))
	{
		fvPubUI.fvMsgShow("电价不能为空");
		return false;
	}
	if(checkStringTrim($("#fv_TS_FLAG").val()))
	{
		fvPubUI.fvMsgShow("是否执行峰谷标志不能为空");
		return false;
	}
	return true;
}

/**
 * 判断字符串是否为空
 */
function checkStringTrim(str)
{
	if(str == "" || str == undefined)
		return true;
	return false;
}

/**
 * 获取pCode集合中的一项
 */
function getItemByCode(pList, pItemCode)
{
	var len = pList.length;
	for(var i = 0; i < len; i++)
	{
		if(pList[i].value == pItemCode)
		{
			return pList[i].name;
		}
	}
}

/**
 * 上装数据
 */
function updateDB()
{
	var t_MP_LEVEL = $("#fv_MP_LEVEL").val() == "顶级" ? "1" : "2";
	//C_MP
	var consKeyArr = 
	{
		"tableName" 		: "C_MP",
		"MP_NAME" 			: $("#fv_MP_NAME").val(),
		"MP_ADDR" 			: $("#fv_MP_ADDR").val(),	
		"TYPE_CODE" 		: $("#fv_TYPE_CODE").attr("name"),	
		"MP_ATTR_CODE" 		: $("#fv_MP_ATTR").attr("name"),
		"USAGE_TYPE_CODE" 	: $("#fv_USAGE_TYPE").attr("name"),	
		"LINE_NAME" 		: $("#fv_LINE_NAME").val(),
		"TG_NAME" 			: $("#fv_TG_NAME").val(),
		"LC_FLAG" 			: $("#fv_LC_FLAG").attr("name"),	
		"CALC_MODE" 		: $("#fv_CALC_MODE").attr("name"),	
		"MP_LEVEL" 			: t_MP_LEVEL,		
		"MD_TYPE_CODE" 		: $("#fv_MD_TYPE").attr("name"),	
		"WIRING_MODE" 		: $("#fv_WIRING_MODE").attr("name"),
		"VOLT_CODE" 		: $("#fv_VOLT_CODE").attr("name"),	
		"FQR_VALUE" 		: $("#fv_FQR_VALUE").val(),
		"FR_DEDUCT_FLAG" 	: $("#fv_FR_DEDUCT_FLAG").attr("name"),
		"DEDUCT_ORDER" 		: $("#fv_DEDUCT_ORDER").val(),
		"MR_SECT_NO" 		: $("#fv_MR_SECT_NO").attr("name"),	
		"MR_SN" 			: $("#fv_MR_SN").val(),
		"METER_FLAG" 		: $("#fv_METER_FLAG").attr("name"),
		"MEAS_MODE" 		: $("#fv_MEAS_MODE").attr("name"),	
		"SWITCH_NO" 		: $("#fv_SWITCH_NO").val(),			
		"EXCHG_TYPE_CODE" 	: $("#fv_EXCHG_TYPE").attr("name"),
		"SIDE_CODE" 		: $("#fv_SIDE_CODE").attr("name"),	
		"MP_SN" 			: $("#fv_MP_SN").val(),
		"TL_SHARE_FLAG" 	: $("#fv_TL_SHARE_FLAG").attr("name"),
		"LL_SHARE_FLAG" 	: $("#fv_LL_SHARE_FLAG").attr("name"),
		"TL_BILL_FLAG" 		: $("#fv_TL_BILL_FLAG").attr("name"),
		"LL_BILL_FLAG" 		: $("#fv_LL_BILL_FLAG").attr("name"),
		"LL_CALC_MODE" 		: $("#fv_LL_CALC_MODE").attr("name"),
		"AP_LL_VALUE" 		: $("#fv_AP_LL_VALUE").val(),
		"RP_LL_VALUE" 		: $("#fv_RP_LL_VALUE").val(),
		"MP_CAP" 			: $("#fv_MP_CAP").val(),
		"USAGE_CODE" 		: $("#fv_USAGE_CODE").attr("name"),
		"TRADE_CODE" 		: $("#fv_TRADE_CODE").attr("name"),	
		"PF_STD_CODE" 		: $("#fv_PF_STD_CODE").attr("name"),	
		"FIX_RATIO" 		: $("#fv_FIX_RATIO").val(),
		"EARTH_MODE" 		: $("#fv_EARTH_MODE").attr("name")
	};
	var whereArr = {"APP_NO" : sessionStorage.fvAppNo,"CONS_ID" : fvConsInfo.cons_id};
	
	fvSqlModel.updateInfo(consKeyArr, whereArr, function(){
	
		fvPubUI.fvMsgShow("数据上装成功");
		ydjc_loginuser_bl_back();
		
	},null);//更新计量点表
}

/**
 * 根据用户编号或者资产编号查询对应基本信息
 */
function sendInfoToServer()
{
	var t_TYPE_CODE = $("#fv_TYPE_CODE").attr("name");
	var t_MP_ATTR = $("#fv_MP_ATTR").attr("name");
	var t_USAGE_TYPE_CODE = $("#fv_USAGE_TYPE").attr("name");
	var t_CALC_MODE = $("#fv_CALC_MODE").attr("name");
	var t_MP_LEVEL = $("#fv_MP_LEVEL").val() == "顶级" ? "1" : "2";
	var t_MD_TYPE = $("#fv_MD_TYPE").attr("name");
	var t_WIRING_MODE = $("#fv_WIRING_MODE").attr("name");
	var t_FR_DEDUCT_FLAG = $("#fv_FR_DEDUCT_FLAG").attr("name");
	var t_MR_SECT_NO = $("#fv_MR_SECT_NO").attr("name");
	var t_MEAS_MODE = $("#fv_MEAS_MODE").attr("name");
	var t_EXCHG_TYPE = $("#fv_EXCHG_TYPE").attr("name");
	var t_SIDE_CODE = $("#fv_SIDE_CODE").attr("name");
	var t_TL_SHARE_FLAG = $("#fv_TL_SHARE_FLAG").attr("name");
	var t_LL_SHARE_FLAG = $("#fv_LL_SHARE_FLAG").attr("name");
	var t_TL_BILL_FLAG = $("#fv_TL_BILL_FLAG").attr("name");
	var t_LL_BILL_FLAG = $("#fv_LL_BILL_FLAG").attr("name");
	var t_LL_CALC_MODE = $("#fv_LL_CALC_MODE").attr("name");
	var t_LL_TRADE_CODE = $("#fv_TRADE_CODE").attr("name");
	var t_EARTH_MODE = $("#fv_EARTH_MODE").attr("name");
	
	
	var objJSON = '"APP_NO":"' 				+ sessionStorage.fvAppNo+'",'+
					'"MP_ID":"' 			+ pointSessionData.MP_ID+'",'+
					'"TARIFF_ID":"' 		+ pointSessionData.TARIFF_ID+'",'+
					'"SP_ID":"' 			+ pointSessionData.SP_ID+'",'+
					'"CONS_ID":"' 			+ pointSessionData.CONS_ID+'",'+
					'"MP_NO":"' 			+ pointSessionData.MP_NO+'",'+
					'"MP_NAME":"' 			+ $("#fv_MP_NAME").val()+'",'+
					'"MP_ADDR":"' 			+ $("#fv_MP_ADDR").val()+'",'+
					'"TYPE_CODE":"' 		+ t_TYPE_CODE +'",'+
					'"MP_ATTR_CODE":"' 		+ t_MP_ATTR+'",'+
					'"USAGE_TYPE_CODE":"' 	+ t_USAGE_TYPE_CODE +'",'+
					'"LINE_NAME":"' 		+ $("#fv_LINE_NAME").val()+'",'+
					'"TG_NAME":"' 			+ $("#fv_TG_NAME").val()+'",'+
					'"LC_FLAG":"' 			+ pointSessionData.LC_FLAG+'",'+
					'"CALC_MODE":"' 		+ t_CALC_MODE+'",'+
					'"MP_LEVEL":"' 			+ t_MP_LEVEL+'",'+
					'"MD_TYPE_CODE":"' 		+ t_MD_TYPE+'",'+
					'"WIRING_MODE":"' 		+ t_WIRING_MODE+'",'+
					'"VOLT_CODE":"' 		+ pointSessionData.VOLT_CODE+'",'+
					'"FQR_VALUE":"' 		+ $("#fv_FQR_VALUE").val()+'",'+
					'"FR_DEDUCT_FLAG":"' 	+ t_FR_DEDUCT_FLAG+'",'+
					'"DEDUCT_ORDER":"' 		+ $("#fv_DEDUCT_ORDER").val()+'",'+
					'"MR_SECT_NO":"' 		+ t_MR_SECT_NO+'",'+
					'"MR_SN":"' 			+ $("#fv_MR_SN").val()+'",'+
					'"METER_FLAG":"' 		+ pointSessionData.METER_FLAG+'",'+
					'"RUN_DATE":"' 			+ pointSessionData.RUN_DATE+'",'+
					'"APP_DATE":"' 			+ pointSessionData.APP_DATE+'",'+
					'"MEAS_MODE":"' 		+ t_MEAS_MODE+'",'+
					'"ORG_NAME":"' 			+ pointSessionData.ORG_NAME+'",'+
					'"SWITCH_NO":"' 		+ $("#fv_SWITCH_NO").val()+'",'+
					'"EXCHG_TYPE_CODE":"' 	+ t_EXCHG_TYPE+'",'+
					'"SIDE_CODE":"' 		+ t_SIDE_CODE+'",'+
					'"MP_SN":"' 			+ $("#fv_MP_SN").val()+'",'+
					'"STATUS_CODE":"' 		+ pointSessionData.STATUS_CODE+'",'+
					'"TL_SHARE_FLAG":"' 	+ t_TL_SHARE_FLAG+'",'+
					'"LL_SHARE_FLAG":"' 	+ t_LL_SHARE_FLAG+'",'+
					'"TL_BILL_FLAG":"' 		+ t_TL_BILL_FLAG+'",'+
					'"LL_BILL_FLAG":"' 		+ t_LL_BILL_FLAG+'",'+
					'"LL_CALC_MODE":"' 		+ t_LL_CALC_MODE+'",'+
					'"AP_LL_VALUE":"' 		+ $("#fv_AP_LL_VALUE").val()+'",'+
					'"RP_LL_VALUE":"' 		+ $("#fv_RP_LL_VALUE").val()+'",'+
					'"MP_CAP":"' 			+ $("#fv_MP_CAP").val()+'",'+
					'"USAGE_CODE":"' 		+ pointSessionData.USAGE_CODE+'",'+
					'"TRADE_CODE":"' 		+ t_LL_TRADE_CODE+'",'+
					'"PRC_CODE":"' 			+ pointSessionData.PRC_CODE+'",'+
					'"PF_STD_CODE":"' 		+ pointSessionData.PF_STD_CODE+'",'+
					'"TS_FLAG":"' 			+ pointSessionData.TS_FLAG+'",'+
					'"FIX_RATIO":"' 		+ $("#fv_FIX_RATIO").val()+'",'+
					'"EARTH_MODE":"' 		+ t_EARTH_MODE+'"';
	
	
	//1.发送实名制认证基本信息请求到服务器
	var pkg='{"MOD":"2034","FUN":"030617","ORG_NO":"'+sessionStorage.ORG_NO+'","SYS_USER_NAME":"'+ sessionStorage.user_name +'","TERM_NUM":"'+ fvTid +'","PKG":{'+ objJSON +'}}';
    send_data("030617","2034",pkg,sendSaveSuccess,sendSaveFail);
}

//发送成功
function sendSaveSuccess(message_ener) 
{
	try
	{
        fvPubUI.fvLoadingClose();//关闭加载效果框
        var msg_enercb = JSON.parse(message_ener);
        if(msg_enercb.RET=="00")
        {
            var msg_pkg=msg_enercb.PKG.PKG;
            if(msg_pkg.FLAG=="1")
            {
            	
            	updateDB();
            }else
            {
                fvPubUI.fvMsgShow("数据上装失败");
            }
        }else
        {
            fvPubUI.fvMsgShow("数据上装失败");
        }
    }catch(e)
    {
   	 	fvPubUI.fvMsgShow("数据上装失败!返回数据异常");
    }
}
//发送失败
function sendSaveFail(msg)
{
	fvPubUI.fvLoadingClose();//关闭加载效果框
	
	fvPubUI.fvMsgShow("数据上装失败");
}

//回退按钮
function ydjc_loginuser_bl_back()
{
    changepage("../../BasicInfoVerify/Checkuserinfo/MeasurePoint/html/MeasurePointDetail.html");
}