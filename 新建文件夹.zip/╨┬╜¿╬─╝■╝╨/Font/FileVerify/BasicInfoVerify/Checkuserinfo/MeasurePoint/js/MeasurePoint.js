var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);

//计量点数据集合
var measPointList = new Array();

init();

/**
 * 初始化
 */
function init()
{
	$("#ydjc_loginuser_nav_bl").html("计量点信息核查");
	$("#fv_cons_no").html(fvConsInfo.cons_no);
	$("#fv_cons_info").html(getHeaderInfo(fvConsInfo.cons_sort_code_str, fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str));
	
	// 计量点列表
	slect_MeasPointList_Data();
	
	/**
	 * 点击返回按钮
	 */  
	$("#fv_measpoint_back").click(function()
	{	
		ydjc_loginuser_bl_back();
	});
}




/**
 * 计量点列表初始化
 */
function slect_MeasPointList_Data()
{
	fvPubUI.fvLoading();
	fvPcode.codeSortJson["A_30022"];
	
    var sql = "SELECT * FROM C_MP WHERE APP_NO="+ sessionStorage.fvAppNo +" AND CONS_ID="+fvConsInfo.cons_id;    
    db_execut_oneSQL("dahc.db",sql,[],queryListSuccess,null);
}

//成功回调
function queryListSuccess(tx,res)
{
	fvPubUI.fvLoadingClose();

    var len=res.rows.length;
    if(len)
    {
        for(var i=0;i<len;i++)
        {
            measPointList[i]=res.rows.item(i);
        }
        val_list_data();
    }else
    {
    	$("#apend_eleclist *").remove();
    	fvPubUI.fvMsgShow("未查询到计量点数据");
    }
}
//页面数据初始化
function val_list_data()
{
    $("#apend_MeasPointList *").remove();
    var result="";
    var meas_mode_obj;
    var mp_level_str;
    for(var i=0;i<measPointList.length;i++)
    {
    	meas_mode_obj = getPcodeNameByValue(fvPcode.codeSortJson["A_19004"], measPointList[i].MEAS_MODE);
    	mp_level_str = (measPointList[i].MP_LEVEL == "1") ? "顶级" : "次级"
    	
         result += '<div class="displayflex fvBaseInfoIcon" onclick="clickListItem('+i+')">'
		         	 +'<div class="displayflex">'
		         	 	+'<div class="boxflex_01"><img  src="../../Util/Images/link_46x46.png"/></div>'
		         		+'<div class="boxflex_01" style="margin:0 10px;"><img  src="../../Util/Images/shuxian_01.png"/></div>'
	         	 	+'</div>'
	         	 	+'<div class="displayflexvertical boxflex_01">'
			         	 +'<div class="displayflex boxflex_01">'             	
			         	 +'<div >计量点名称：</div>'
			         	 +'<div class="boxflex_01">'+measPointList[i].MP_NAME+'</div>'
			         	 +'</div>'
			         	 +'<div class="displayflex boxflex_01">'
			         	 +'<div >计量点层级：</div>'
			         	 +'<div class="boxflex_01">'+ mp_level_str +'</div>'
			         	 +'</div>'
			         	 +'<div class="displayflex boxflex_01">'
			         	 +'<div >计量方式：</div>'			         	 
			         	 +'<div class="boxflex_01">'+ meas_mode_obj +'</div>'
			         	 +'</div>'
	         	 	+'</div>'
	         	 +'</div>'
	         	 +'<div style="line-height: 20px;"><img src="../../Util/Images/greenline.png" width="100%" height="2px"></img></div>'
    }
    $("#apend_MeasPointList").append(result);
}

/**
 * 获取pcode列表中的特定项
 */
function getPcodeNameByValue(pCodeList, value)
{
	for(var i=0;i<pCodeList.length;i++)
    {
    	if(pCodeList[i].value == value)
    	{
    		return pCodeList[i].name;
    	}
    }
        
}

/**
 * 点击计量点列表中的一项
 * 跳转到计量点详情
 */
function clickListItem(index)
{
	// 记录下被点击的计量点工单编号和计量点标识
	sessionStorage.measPointItem_APP_NO=measPointList[index].APP_NO;
	sessionStorage.measPointItem_MP_ID=measPointList[index].MP_ID;
	
	// 跳转到计量点详细页面
	changepage("../../BasicInfoVerify/Checkuserinfo/MeasurePoint/html/MeasurePointDetail.html");
}

//回退按钮
function ydjc_loginuser_bl_back()
{
    changepage("../../BasicInfoVerify/Checkuserinfo/Userbaseinfo/html/UserInfoModel.html");
}