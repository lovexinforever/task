$("#ydjc_loginuser_nav_bl").html("计量点信息核查");

var pointSessionData;
var fvConsInfo;

init();

function init()
{
	fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);
	
	fvPubUI.fvLoading();
	
	$("#fv_cons_no").html(fvConsInfo.cons_no);
	$("#fv_cons_info").html(getHeaderInfo(fvConsInfo.cons_sort_code_str, fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str));
	
	slect_MeasPointList_Data();
	
	/**
	 * 点击返回按钮
	 */  
	$("#fv_measpoint_back").click(function()
	{	
		changepage("../../BasicInfoVerify/Checkuserinfo/Userbaseinfo/html/UserInfoModel.html");
	});
	
	/**
	 * 点击上装按钮
	 */  
	$("#fvMeasPointEdit").click(function()
	{	
		changepage("../../BasicInfoVerify/Checkuserinfo/MeasurePoint/html/MeasurePointEdit.html");
	});
}

/**
 * 计量点详情初始化
 */

function slect_MeasPointList_Data()
{
    var sql = "SELECT * FROM C_MP WHERE APP_NO="+ sessionStorage.measPointItem_APP_NO +" AND MP_ID="+sessionStorage.measPointItem_MP_ID;    
    db_execut_oneSQL("dahc.db",sql,[],queryMeasPointSuccess,null);
}

//成功回调
function queryMeasPointSuccess(tx,res)
{
    var len=res.rows.length;
    if(len > 0)
    {
    	pointSessionData = res.rows;
        fillMeasPointDetail(res.rows);
    }else
    {
    	fvPubUI.fvMsgShow("未查询到计量点数据");
    }
}

/**
 * 填充待修改的基本信息
 */
function fillMeasPointDetail(value)
{
	var data = value.item(0);
	
	var pcode_30022 = fvPcode.codeSortJson["A_30022"];
	var pcode_19006 = fvPcode.codeSortJson["A_19006"];
	var p_mp_level = (data.MP_LEVEL == "1") ? "顶级" : "次级";
	
	try
	{
		$("#fv_MP_NO").html(data.MP_NO);
        $("#fv_MP_NAME").html(data.MP_NAME);
        $("#fv_MP_ADDR").html(data.MP_ADDR);
        $("#fv_TYPE_CODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_19033"], data.TYPE_CODE));        
        // $("#fv_TYPE_CODE").html(data.TYPE_CODE);
        $("#fv_MP_ATTR").html(getPcodeNameByValue(fvPcode.codeSortJson["A_19047"], data.MP_ATTR_CODE));
        //$("#fv_MP_ATTR").html(data.MP_ATTR_CODE);
        $("#fv_USAGE_TYPE").html(getPcodeNameByValue(pcode_19006, data.USAGE_TYPE_CODE));
        //$("#fv_USAGE_TYPE").html(data.USAGE_TYPE_CODE);
        $("#fv_LINE_NAME").html(data.LINE_NAME);
        $("#fv_TG_NAME").html(data.TG_NAME);
        $("#fv_LC_FLAG").html(getPcodeNameByValue(pcode_30022, data.LC_FLAG));
        //$("#fv_LC_FLAG").html(data.LC_FLAG);
        $("#fv_CALC_MODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_14003"], data.CALC_MODE));   
        //$("#fv_CALC_MODE").html(data.CALC_MODE); 
        $("#fv_MP_LEVEL").html(p_mp_level);
        $("#fv_MD_TYPE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_19001"], data.MD_TYPE_CODE));
        //$("#fv_MD_TYPE").html(data.MD_TYPE_CODE);
        $("#fv_WIRING_MODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_19005"], data.WIRING_MODE));
        //$("#fv_WIRING_MODE").html(data.WIRING_MODE);
        $("#fv_VOLT_CODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_10005"], data.VOLT_CODE));
        //$("#fv_VOLT_CODE").html(data.VOLT_CODE);
        $("#fv_FQR_VALUE").html(data.FQR_VALUE);
        $("#fv_FR_DEDUCT_FLAG").html(getPcodeNameByValue(pcode_30022, data.FR_DEDUCT_FLAG));
        //$("#fv_FR_DEDUCT_FLAG").html(data.FR_DEDUCT_FLAG);
        $("#fv_DEDUCT_ORDER").html(data.DEDUCT_ORDER);
        $("#fv_MR_SECT_NO").html(data.MR_SECT_NO);
        $("#fv_MR_SN").html(data.MR_SN);       
        $("#fv_METER_FLAG").html(getPcodeNameByValue(pcode_30022, data.METER_FLAG));  
       // $("#fv_METER_FLAG").html(data.METER_FLAG);  
        $("#fv_RUN_DATE").html(data.RUN_DATE);
        $("#fv_APP_DATE").html(data.APP_DATE);        
        $("#fv_MEAS_MODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_19004"], data.MEAS_MODE));
        //$("#fv_MEAS_MODE").html(data.MEAS_MODE);
        $("#fv_ORG_NAME").html(data.ORG_NAME);
        $("#fv_SWITCH_NO").html(data.SWITCH_NO);        
        $("#fv_EXCHG_TYPE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_21004"], data.EXCHG_TYPE_CODE));
        //$("#fv_EXCHG_TYPE").html(data.EXCHG_TYPE_CODE);        
        $("#fv_SIDE_CODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_19013"], data.SIDE_CODE));
        //$("#fv_SIDE_CODE").html(data.SIDE_CODE);
        $("#fv_MP_SN").html(data.MP_SN);
        $("#fv_STATUS_CODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_19023"], data.STATUS_CODE));
        //$("#fv_STATUS_CODE").html(data.STATUS_CODE);
        $("#fv_TL_SHARE_FLAG").html(getPcodeNameByValue(pcode_30022, data.TL_SHARE_FLAG));        
        $("#fv_LL_SHARE_FLAG").html(getPcodeNameByValue(pcode_30022, data.LL_SHARE_FLAG));
        $("#fv_TL_BILL_FLAG").html(getPcodeNameByValue(pcode_30022, data.TL_BILL_FLAG));
        $("#fv_LL_BILL_FLAG").html(getPcodeNameByValue(pcode_30022, data.LL_BILL_FLAG));
       // $("#fv_TL_SHARE_FLAG").html(data.TL_SHARE_FLAG);        
//        $("#fv_LL_SHARE_FLAG").html(data.LL_SHARE_FLAG);
//        $("#fv_TL_BILL_FLAG").html(data.TL_BILL_FLAG);
//        $("#fv_LL_BILL_FLAG").html(data.LL_BILL_FLAG);
        $("#fv_LL_CALC_MODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_14007"], data.LL_CALC_MODE));
        //$("#fv_LL_CALC_MODE").html(data.LL_CALC_MODE);
        $("#fv_AP_LL_VALUE").html(data.AP_LL_VALUE);        
        $("#fv_RP_LL_VALUE").html(data.RP_LL_VALUE);
        $("#fv_MP_CAP").html(data.MP_CAP);        
        $("#fv_USAGE_CODE").html(getPcodeNameByValue(pcode_19006, data.USAGE_CODE));
        //$("#fv_USAGE_CODE").html(data.USAGE_CODE);
        $("#fv_TRADE_CODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_29005"], data.TRADE_CODE));
        //$("#fv_TRADE_CODE").html(data.TRADE_CODE);
        $("#fv_PRC_CODE").html(data.PRC_CODE);       
        
        $("#fv_PF_STD_CODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_14004"], data.PF_STD_CODE));
        //$("#fv_PF_STD_CODE").html(data.PF_STD_CODE);
        $("#fv_TS_FLAG").html(getPcodeNameByValue(pcode_30022, data.TS_FLAG));
        //$("#fv_TS_FLAG").html(data.TS_FLAG);
        $("#fv_FIX_RATIO").html(data.FIX_RATIO);
        $("#fv_EARTH_MODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_19036"], data.EARTH_MODE));
        //$("#fv_EARTH_MODE").html(data.EARTH_MODE);        
	}catch(err)
	{
	   	fvPubUI.fvLoadingClose();
	}
	
	fvPubUI.fvLoadingClose();
}

/**
 * 获取pcode列表中的特定项
 */
function getPcodeNameByValue(pCodeList, value)
{
	for(var i=0;i<pCodeList.length;i++)
    {
    	if(pCodeList[i].value == value)
    	{
    		return pCodeList[i].name;
    	}
    }  
}

//回退按钮
function ydjc_loginuser_bl_back()
{
    changepage("../../BasicInfoVerify/Checkuserinfo/MeasurePoint/html/MeasurePoint.html");
}