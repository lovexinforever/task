// 定义用户基础档案详情界面操作类
var consInfoDetail = 
{
	// 查询用户基础档案详情信息
	queryConsInfoDetail : function()
	{
		var consId = JSON.parse(sessionStorage.fvConsInfo).cons_id;
		var appNo = sessionStorage.fvAppNo;
		// 查询用户基础档案详情信息
		consInfoDB.queryConsInfoDetail(consId, appNo, function(data)
		{
			var len = data.rows.length;
			if(len > 0)
			{
				var consInfoArray = ["CONS_NO","CONS_NAME","CUST_QUERY_NO","TMP_PAY_RELA_NO","ORGN_CONS_NO","CONS_SORT_CODE","RRIO_CODE","ELEC_ADDR",
					 "TRADE_CODE","ELEC_TYPE_CODE","CONTRACT_CAP","RUN_CAP","SHIFT_NO","LODE_ATTR_CODE","VOLT_CODE","HEC_INDUSTRY_CODE",
					 "HOLIDAY","BUILD_DATE","PS_DATE","CANCEL_DATE","DUE_DATE","NOTIFY_MODE","SETTLE_MODE","STATUS_CODE","ORG_NO",
					 "CHK_CYCLE","POWEROFF_CODE","TRANSFER_CODE","MR_SECT_NO","NOTE_TYPE_CODE","TMP_FLAG","TMP_DATE"];
				for(var i=0; i<len; i++)
			    {
			    	var tempData = data.rows.item(i);
			    	for(var j=0; j<consInfoArray.length; j++)
			    	{
			    		var key = consInfoArray[j];
			    		if("CONS_SORT_CODE"==key || "RRIO_CODE"==key || "TRADE_CODE"==key || "ELEC_TYPE_CODE"==key
			    		   || "LODE_ATTR_CODE"==key || "VOLT_CODE"==key || "HEC_INDUSTRY_CODE"==key || "NOTIFY_MODE"==key
			    		   || "SETTLE_MODE"==key || "STATUS_CODE"==key || "POWEROFF_CODE"==key || "TRANSFER_CODE"==key
			    		   || "NOTE_TYPE_CODE"==key || "TMP_FLAG"==key || "SHIFT_NO"==key)
			    		{
			    			pcodeUtil.initReadOnlyFromDetail(key, tempData[key]);
			    		}
			    		// 厂休日
			    		else if("HOLIDAY"==key)
			    		{
			    			var holidayCode = tempData[key];
			    			var holidayStr = "";
			    			if(holidayCode!="" && holidayCode!=null)
			    			{
								holidayStr = holidayCode.replace("1","星期一");
								holidayStr = holidayStr.replace("2","星期二");
								holidayStr = holidayStr.replace("3","星期三");
								holidayStr = holidayStr.replace("4","星期四");
								holidayStr = holidayStr.replace("5","星期五");
								holidayStr = holidayStr.replace("6","星期六");
								holidayStr = holidayStr.replace("7","星期日");
			    			}
			    			$("#"+key).html(holidayStr);
			    		}
			    		else
			    		{
			    			$("#"+key).html(tempData[key]);
			    		}
			    	}
			    }
			}
			else
    		{
    			fvPubUI.fvMsgShow("未查询到用户基础档案");
    		}
		});
	},
	
	// 修改用户基础档案信息
	editConsInfo : function()
	{
		changepage("../../BasicInfoVerify/Checkuserinfo/Userbasefile/html/ConsInfoEdit.html");
	},
	
	initData : function()
	{
		// 头部初始化
		$("#ydjc_loginuser_nav_bl").html("用户基础档案核查");
		var cons_info = JSON.parse(sessionStorage.fvConsInfo);
		$("#detailConsNo").html(cons_info.cons_no);
		$("#detailConsInfo").html(getHeaderInfo(cons_info.cons_sort_code_str, cons_info.rrio_code_str, cons_info.elec_type_code_str));
		
		// 绑定单击事件
		$("#fvConsInfoEdit").click(function() {consInfoDetail.editConsInfo()});
		$("#fvConsInfoTitle").click(function() {changepage("../../BasicInfoVerify/Checkuserinfo/Userbaseinfo/html/UserInfoModel.html");});
		
		consInfoDetail.queryConsInfoDetail();
	}
};

pcodeUtil.initDropDownData(function(){consInfoDetail.initData();});

// 回退按钮
function ydjc_loginuser_bl_back()
{
    changepage("../../BasicInfoVerify/Checkuserinfo/Userbaseinfo/html/UserInfoModel.html");
}