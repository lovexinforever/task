// 定义用户基础档案数据库操作类
var consInfoDB = 
{
	// 查询用户基础档案
	queryConsInfoDetail : function(consId, appNo, queryCIDetailSuccCB)
	{
		var sql = "SELECT CONS_NO,CONS_NAME,CUST_QUERY_NO,TMP_PAY_RELA_NO,ORGN_CONS_NO,CONS_SORT_CODE,RRIO_CODE,ELEC_ADDR,TRADE_CODE," +
				  "ELEC_TYPE_CODE,CONTRACT_CAP,RUN_CAP,SHIFT_NO,LODE_ATTR_CODE,VOLT_CODE,HEC_INDUSTRY_CODE,HOLIDAY,date(BUILD_DATE) BUILD_DATE," +
				  "date(PS_DATE) PS_DATE,date(CANCEL_DATE) CANCEL_DATE,date(DUE_DATE) DUE_DATE,NOTIFY_MODE,SETTLE_MODE,STATUS_CODE,ORG_NO," +
				  "CHK_CYCLE,POWEROFF_CODE,TRANSFER_CODE,MR_SECT_NO,NOTE_TYPE_CODE,TMP_FLAG,date(TMP_DATE) TMP_DATE " +
				  "FROM C_CONS_GY WHERE CONS_ID = ? AND APP_NO = ?";
		db_execut_oneSQL("dahc.db", sql, [consId, appNo], function(tx, res)
		{
			queryCIDetailSuccCB(res);
		}, null);
	},
	
	// 修改用户基础档案	
	modifyConsInfo : function(array, params, modifyCISuccCB)
	{
		var tempArray = array.slice(0, array.length-2);
		var sql = "UPDATE C_CONS_GY SET ";
		for(var i=0; i<tempArray.length; i++)
		{
			sql += tempArray[i] + "=?";
			if(i != tempArray.length-1)
			{
				sql += ", ";
			}
		}
		sql += " WHERE APP_NO = ? AND CONS_ID = ?";
		
		db_execut_oneSQL("dahc.db", sql, params, function(tx, res)
		{
			modifyCISuccCB(res);
		}, null);
	}
};