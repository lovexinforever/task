// 定义用户基础档案修改界面操作类
var consInfoEdit = 
{
	// 修改用户基础档案详情信息
	modifyConsInfo : function()
	{
		fvPubUI.fvLoading();
		var paramNamesArray = ["CONS_SORT_CODE","RRIO_CODE","ELEC_ADDR","TRADE_CODE","ELEC_TYPE_CODE","CONTRACT_CAP","RUN_CAP","SHIFT_NO",
					 		   "LODE_ATTR_CODE","VOLT_CODE","HEC_INDUSTRY_CODE","HOLIDAY","APP_NO","CONS_ID"];
		var paramValues = new Array();
		var tempArray = paramNamesArray.slice(0, paramNamesArray.length-2);
		for(var i=0; i<tempArray.length; i++)
		{
			var key = tempArray[i];
			var tempValue;
			if("CONS_SORT_CODE"==key || "RRIO_CODE"==key || "TRADE_CODE"==key || "ELEC_TYPE_CODE"==key || "SHIFT_NO"==key
			   || "LODE_ATTR_CODE"==key || "VOLT_CODE"==key || "HEC_INDUSTRY_CODE"==key || "HOLIDAY"==key)
			{
				tempValue = $("#"+key).attr("name");
			}
			else if("ELEC_ADDR"==key || "CONTRACT_CAP"==key || "RUN_CAP"==key)
			{
				tempValue = $("#"+key).val();
			}
			paramValues.push(tempValue);
		}
		paramValues.push(sessionStorage.fvAppNo);
		paramValues.push(JSON.parse(sessionStorage.fvConsInfo).cons_id);
		
		// 调用接口执行用户基础档案修改操作
		publicDataRequest.execDataSendRequest("MODIFY_CONS_INFO", paramNamesArray, paramValues, function()
		{
			// 执行数据库用户基础档案修改操作
			consInfoDB.modifyConsInfo(paramNamesArray, paramValues, function(res)
			{
				fvPubUI.fvLoadingClose();
				fvPubUI.fvMsgShow("更新用户基础档案成功");
				changepage("../../BasicInfoVerify/Checkuserinfo/Userbasefile/html/ConsInfoDetail.html");
			});
		});
	},
	
	initData : function()
	{
		// 头部初始化
		$("#ydjc_loginuser_nav_bl").html("用户基础档案核查");
		var cons_info = JSON.parse(sessionStorage.fvConsInfo);
		$("#editConsNo").html(cons_info.cons_no);
		$("#editConsInfo").html(getHeaderInfo(cons_info.cons_sort_code_str, cons_info.rrio_code_str, cons_info.elec_type_code_str));
		
		// 绑定单击事件
		$("#fvConsInfoModify").click(function() {consInfoEdit.modifyConsInfo()});
		
		var appNo = sessionStorage.fvAppNo;
		var consId = JSON.parse(sessionStorage.fvConsInfo).cons_id;
		// 查询用户基础档案详情信息
		consInfoDB.queryConsInfoDetail(consId, appNo, function(data)
		{
			var len = data.rows.length;
			if(len > 0)
			{
				var consInfoArray = ["CONS_NO","CONS_NAME","CUST_QUERY_NO","TMP_PAY_RELA_NO","ORGN_CONS_NO","CONS_SORT_CODE","RRIO_CODE","ELEC_ADDR",
					 "TRADE_CODE","ELEC_TYPE_CODE","CONTRACT_CAP","RUN_CAP","SHIFT_NO","LODE_ATTR_CODE","VOLT_CODE","HEC_INDUSTRY_CODE",
					 "HOLIDAY","BUILD_DATE","PS_DATE","CANCEL_DATE","DUE_DATE","NOTIFY_MODE","SETTLE_MODE","STATUS_CODE","ORG_NO",
					 "CHK_CYCLE","POWEROFF_CODE","TRANSFER_CODE","MR_SECT_NO","NOTE_TYPE_CODE","TMP_FLAG","TMP_DATE"];
				for(var i=0; i<len; i++)
			    {
			    	var tempData = data.rows.item(i);
			    	for(var j=0; j<consInfoArray.length; j++)
			    	{
			    		var key = consInfoArray[j];
			    		// 界面下拉框数据可编辑
			    		if("CONS_SORT_CODE"==key || "RRIO_CODE"==key || "TRADE_CODE"==key || "ELEC_TYPE_CODE"==key || "SHIFT_NO"==key 
			    		   || "LODE_ATTR_CODE"==key || "VOLT_CODE"==key || "HEC_INDUSTRY_CODE"==key)
						{
							pcodeUtil.initDropDownFromEdit(key, tempData[key]);
						}
						// 界面数据只读且数据来自PCODE
						else if("NOTIFY_MODE"==key || "SETTLE_MODE"==key || "STATUS_CODE"==key || "POWEROFF_CODE"==key
								|| "TRANSFER_CODE"==key || "NOTE_TYPE_CODE"==key || "TMP_FLAG"==key)
						{
							pcodeUtil.initReadOnlyFromEdit(key, tempData[key]);
						}
						// 厂休日
			    		else if("HOLIDAY"==key)
			    		{
			    			var holidayCode = tempData[key];
			    			var holidayStr = "";
			    			if(holidayCode!="" && holidayCode!=null)
			    			{
								holidayStr = holidayCode.replace("1","星期一");
								holidayStr = holidayStr.replace("2","星期二");
								holidayStr = holidayStr.replace("3","星期三");
								holidayStr = holidayStr.replace("4","星期四");
								holidayStr = holidayStr.replace("5","星期五");
								holidayStr = holidayStr.replace("6","星期六");
								holidayStr = holidayStr.replace("7","星期日");
			    			}
			    			$("#"+key).val(holidayStr);
							$("#"+key).attr("name",holidayCode);
			    		}
			    		// 界面数据只读
						else
						{
							$("#"+key).val(tempData[key]);
						}
			    	}
			    }
			}
		});
	}
};

consInfoEdit.initData();

// 回退按钮
function ydjc_loginuser_bl_back()
{
    changepage("../../BasicInfoVerify/Checkuserinfo/Userbasefile/html/ConsInfoDetail.html");
}