<script type="text/javascript">

//加载用检用户信息
$("#ydjc_loginuser_nav_bl").html("档案核查-用户基本信息");

var cons_info = JSON.parse(sessionStorage.fvConsInfo);

$("#cons_no_ubi").html(cons_info.cons_no);

$("#header_info_userbaseinfo").html(getHeaderInfo(cons_info.cons_sort_code_str, cons_info.rrio_code_str, cons_info.elec_type_code_str));

//工单唯一标识
var user_sotrageID = "val" + sessionStorage.APP_NO_bl + cons_info.cons_id;
if(localStorage[user_sotrageID] == undefined) {
	//判断工单是否存在，如果不存在，赋值
	localStorage[user_sotrageID] = [0, 0, 0, 0];
}
var arr = localStorage[user_sotrageID].split(",");
if(arr[0] == 1) {
	$("#user_html_ubi .yclimg").show("slow")
}
if(arr[1] == 1) {
	$("#run_html_ubi .yclimg").show("slow")
}
if(arr[2] == 1) {
	$("#dev_html_ubi .yclimg").show("slow")
}
if(arr[3] == 1) {
	$("#check_html_ubi .yclimg").show("slow")
}

//回退
function ydjc_loginuser_bl_back() {
	cons_info = null;
	changepage("../../BasicInfoVerify/Userlist/html/userlist.html");
}

/**
 * 查询页面数据
 * @param {} sucessCB
 * @param {} failCB
 */
function  get_yj_c_cons_baseinfo(sucessCB,failCB){
    var sql="SELECT A.CONS_NAME , A.ELEC_ADDR , B.CONTACT_NAME , B.OFFICE_TEL , B.MOBILE " +
    		"FROM C_CONS_GY A  " +
    		"LEFT JOIN C_CONTACT B on  A.APP_NO = B.APP_NO and A.CONS_ID=B.CONS_ID  " +
    		"WHERE  A.APP_NO=? AND A.CONS_ID=?";
    db_execut_oneSQL("dahc.db",sql,[sessionStorage.fvAppNo,cons_info.cons_id],sucessCB,failCB);
}

get_yj_c_cons_baseinfo(initPage_userBaseinfo, null);

function initPage_userBaseinfo(tx, res) {
	if(res.rows.length>0){
		$("#CONS_NAME_show").html(res.rows.item(0).CONS_NAME);
		$("#ELEC_ADDR_show").html(res.rows.item(0).ELEC_ADDR);
		$("#CONTACT_NAME_show").html(res.rows.item(0).CONTACT_NAME);
		$("#OFFICE_TEL_show").html(res.rows.item(0).OFFICE_TEL);
		$("#MOBILE_show").html(res.rows.item(0).MOBILE);
	}
}

//核查用户基础信息
$("#user_html_ubi").click(function(t) {
	arr[0] = 1;
	localStorage[user_sotrageID] = arr;
	user_base_info_onclick_goto(1);
});
//核查联系人信息
$("#run_html_ubi").click(function(t) {
	arr[1] = 1;
	localStorage[user_sotrageID] = arr;
	user_base_info_onclick_goto(2);
});
//核查证书信息
$("#dev_html_ubi").click(function(t) {
	arr[2] = 1;
	localStorage[user_sotrageID] = arr;
	user_base_info_onclick_goto(3);
});
//核查设备档案信息
$("#check_html_ubi").click(function(t) {
	arr[3] = 1;
	localStorage[user_sotrageID] = arr;
	user_base_info_onclick_goto(4);
});
//合同信息
$("#check_contract_ubi").click(function(t) {
	arr[4] = 1;
	localStorage[user_sotrageID] = arr;
	user_base_info_onclick_goto(5);
});
/**
 * 界面所有的跳转功能
 */
function user_base_info_onclick_goto(type) {
	//核查用户基础信息
	if(type == 1) {
		changepage("../../BasicInfoVerify/Checkuserinfo/Userbaseinfo/html/UserInfoModel.html");
	}
	//核查联系人信息
	else if(type == 2) {
		changepage("../../BasicInfoVerify/CheckContactInfo/html/ContactMain.html");
		cons_info = null;
	}
	//核查证书信息
	else if(type == 3) {
		changepage("../../BasicInfoVerify/CheckCardInfo/html/CheckCardInfoVerify.html");
		cons_info = null;
	}
	//核查设备档案信息
	else if(type == 4) {
		cons_info = null;
		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
	}
	//合同信息
	else if(type == 5) {
		cons_info = null;
		changepage("../../BasicInfoVerify/CheckPactInfo/html/pactInfo.html");
	}
}
</script>
