// 定义受电点详情界面操作类
var sufferPointDetail = 
{
	// 查询受电点详情信息
	querySufferPointDetail : function()
	{
		var sufferPointId = sessionStorage.fvSufferPointId;
		var appNo = sessionStorage.fvAppNo;
		// 查询受电点详情信息
		sufferPointDB.querySufferPointDetail(sufferPointId, appNo, function(data)
		{
			var len = data.rows.length;
			if(len > 0)
			{
				var spArray = ["SP_NAME","TYPE_CODE","INTERLOCK_MODE","EQUIP_LOC","PS_SWITCH_MODE","PS_NUM_CODE","SPARE_POWER_FLAG",
							   "LOCK_MODE","SPARE_POWER_CAP","SP_REMARK"];
				for(var i=0; i<len; i++)
			    {
			    	var tempData = data.rows.item(i);
			    	for(var j=0; j<spArray.length; j++)
			    	{
			    		var key = spArray[j];
			    		if("TYPE_CODE"==key)
			    		{
			    			pcodeUtil.initReadOnlyFromDetail("SP_"+key, tempData[key]);
			    		}
     					else if("PS_NUM_CODE"==key || "SPARE_POWER_FLAG"==key || "INTERLOCK_MODE"==key || "PS_SWITCH_MODE"==key || "LOCK_MODE"==key)
     					{
     						pcodeUtil.initReadOnlyFromDetail(key, tempData[key]);
     					}
     					else
     					{
							$("#"+key).html(tempData[key]);     						
     					}
			    	}
			    }
			}
			else
    		{
    			fvPubUI.fvMsgShow("未查询到受电点信息");
    		}
		});
	},
	
	// 修改受电点信息
	editSufferPoint : function()
	{
		changepage("../../BasicInfoVerify/Checkuserinfo/SufferPoint/html/SufferPointEdit.html");
	},
	
	initData : function()
	{
		// 头部初始化
		$("#ydjc_loginuser_nav_bl").html("受电点信息核查");
		var cons_info = JSON.parse(sessionStorage.fvConsInfo);
		$("#sufferPointDetailConsNo").html(cons_info.cons_no);
		$("#sufferPointDetailConsInfo").html(getHeaderInfo(cons_info.cons_sort_code_str, cons_info.rrio_code_str, cons_info.elec_type_code_str));
		
		// 绑定单击事件
		$("#fvEditSufferPoint").click(function() {sufferPointDetail.editSufferPoint()});
		
		sufferPointDetail.querySufferPointDetail();
	}
};

sufferPointDetail.initData();

// 回退按钮
function ydjc_loginuser_bl_back()
{
    changepage("../../BasicInfoVerify/Checkuserinfo/SufferPoint/html/SufferPoint.html");
}