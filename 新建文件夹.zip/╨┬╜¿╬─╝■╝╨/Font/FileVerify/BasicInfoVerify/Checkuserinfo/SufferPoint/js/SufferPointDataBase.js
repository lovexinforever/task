// 定义受电点数据库操作类
var sufferPointDB = 
{
	// 查询受电点列表信息
	querySufferPointList : function(consId, appNo, querySPListSuccCB)
	{
		var sql = "SELECT * FROM C_SP WHERE CONS_ID = ? AND APP_NO = ?";
		db_execut_oneSQL("dahc.db", sql, [consId, appNo], function(tx, res)
		{
			querySPListSuccCB(res);
		}, null);
	},
	
	// 查询受电点详情信息
	querySufferPointDetail : function(sufferPointId, appNo, querySPDetailSuccCB)
	{
		var sql = "SELECT * FROM C_SP WHERE SP_ID = ? AND APP_NO = ?";
		db_execut_oneSQL("dahc.db", sql, [sufferPointId, appNo], function(tx, res)
		{
			querySPDetailSuccCB(res);
		}, null);
	},
	
	// 修改受电点信息	
	modifySufferPoint : function(array, params, modifySPSuccCB)
	{
		var tempArray = array.slice(0, array.length-2);
		var sql = "UPDATE C_SP SET ";
		for(var i=0; i<tempArray.length; i++)
		{
			sql += tempArray[i] + "=?";
			if(i != tempArray.length-1)
			{
				sql += ", ";
			}
		}
		sql += " WHERE SP_ID = ? AND APP_NO = ? ";
		
		db_execut_oneSQL("dahc.db", sql, params, function(tx, res)
		{
			modifySPSuccCB(res);
		}, null);
	}
};