// 定义受电点修改界面操作类
var sufferPointEdit = 
{
	spArray : ["SP_NAME","TYPE_CODE","INTERLOCK_MODE","EQUIP_LOC","PS_SWITCH_MODE","PS_NUM_CODE","SPARE_POWER_FLAG","LOCK_MODE","SPARE_POWER_CAP","SP_REMARK",
			   "SP_ID","APP_NO"],
	
	// 修改受电点详情信息
	modifySufferPoint : function()
	{
		fvPubUI.fvLoading();
		var params = new Array();
		var tempArray = sufferPointEdit.spArray.slice(0, sufferPointEdit.spArray.length-2);
		for(var i=0; i<tempArray.length; i++)
		{
			var key = tempArray[i];
			var tempValue;
			if("TYPE_CODE"==key)
			{
				tempValue = $("#SP_"+key).attr("name");
			}
			else if("PS_NUM_CODE"==key || "SPARE_POWER_FLAG"==key || "INTERLOCK_MODE"==key || "PS_SWITCH_MODE"==key || "LOCK_MODE"==key)
			{
				tempValue = $("#"+key).attr("name");
			}
			else
			{
				tempValue = $("#"+key).val();
			}
			params.push(tempValue);
		}
		params.push(sessionStorage.fvSufferPointId);
		params.push(sessionStorage.fvAppNo);
		
		// 调用接口执行受电点修改操作
		publicDataRequest.execDataSendRequest("MODIFY_SUFFER_POINT", sufferPointEdit.spArray, params, function()
		{
			// 执行数据库受电点修改操作
			sufferPointDB.modifySufferPoint(sufferPointEdit.spArray, params, function(res)
			{
				fvPubUI.fvLoadingClose();
				fvPubUI.fvMsgShow("更新受电点信息成功");
				changepage("../../BasicInfoVerify/Checkuserinfo/SufferPoint/html/SufferPointDetail.html");
			});
		});
	},
	
	initData : function()
	{
		// 头部初始化
		$("#ydjc_loginuser_nav_bl").html("受电点信息核查");
		var cons_info = JSON.parse(sessionStorage.fvConsInfo);
		$("#sufferPointEditConsNo").html(cons_info.cons_no);
		$("#sufferPointEditConsInfo").html(getHeaderInfo(cons_info.cons_sort_code_str, cons_info.rrio_code_str, cons_info.elec_type_code_str));
		
		// 绑定单击事件
		$("#fvModifySufferPoint").click(function() {sufferPointEdit.modifySufferPoint()});
		
		var sufferPointId = sessionStorage.fvSufferPointId;
		var appNo = sessionStorage.fvAppNo;
		// 查询受电点详情信息
		sufferPointDB.querySufferPointDetail(sufferPointId, appNo, function(data)
		{
			var len = data.rows.length;
			if(len > 0)
			{
				var tempArray = sufferPointEdit.spArray.slice(0, sufferPointEdit.spArray.length-2);
				for(var i=0; i<len; i++)
			    {
			    	var tempData = data.rows.item(i);
			    	for(var j=0; j<tempArray.length; j++)
			    	{
			    		var key = tempArray[j];
			    		if("TYPE_CODE"==key)
			    		{
			    			pcodeUtil.initDropDownFromEdit("SP_"+key, tempData[key]);
			    		}
			    		else if("PS_NUM_CODE"==key || "SPARE_POWER_FLAG"==key || "INTERLOCK_MODE"==key || "PS_SWITCH_MODE"==key || "LOCK_MODE"==key)
			    		{
			    			pcodeUtil.initDropDownFromEdit(key, tempData[key]);
			    		}
			    		else
			    		{
							$("#"+key).val(tempData[key]);			    			
			    		}
			    	}
			    }
			}
		});
	}
};

sufferPointEdit.initData();

// 回退按钮
function ydjc_loginuser_bl_back()
{
    changepage("../../BasicInfoVerify/Checkuserinfo/SufferPoint/html/SufferPointDetail.html");
}