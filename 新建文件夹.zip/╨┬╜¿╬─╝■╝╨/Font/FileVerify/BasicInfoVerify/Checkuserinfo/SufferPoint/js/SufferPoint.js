// 定义受电点列表界面操作类
var sufferPoint = 
{
	// 查询受电点列表信息
	querySufferPointList : function()
	{
		var consId = JSON.parse(sessionStorage.fvConsInfo).cons_id;
		var appNo = sessionStorage.fvAppNo;
		// 查询受电点列表信息
		sufferPointDB.querySufferPointList(consId, appNo, function(data)
		{
			var html;
			var len = data.rows.length;
			if(len > 0)
			{
				for(var i=0; i<len; i++)
			    {
			    	var tempData = data.rows.item(i);
			    	html = "<div class='displayflex fvBaseInfoIcon' onclick='sufferPoint.viewSufferPoint("+tempData.SP_ID+")'>"+
			    	 	   "<div class='displayflex'>"+
			    		   "<div class='boxflex_01'><img src='../../Util/Images/link_46x46.png'/></div>"+
			    		   "<div class='boxflex_01' style='margin:0 10px;'><img src='../../Util/Images/shuxian_01.png'/></div>"+
					       "</div>"+
					       "<div class='displayflexvertical boxflex_01'>"+
					       "<div class='displayflex boxflex_01'>"+    	
					       "<div>受电点名称：</div>"+
					       "<div class='boxflex_01'>"+tempData.SP_NAME+"</div>"+
					       "</div>"+
					       "<div class='displayflex boxflex_01'>"+
					       "<div>受电点类型：</div>"+
					       "<div class='boxflex_01'>"+ pcodeUtil.getValueFromPcodeJson("SP_TYPE_CODE", tempData.TYPE_CODE) +"</div>"+
					       "</div>"+
					       "<div class='displayflex boxflex_01'>"+
					       "<div>电源数目：</div>"+
					       "<div class='boxflex_01'>"+ pcodeUtil.getValueFromPcodeJson("PS_NUM_CODE", tempData.PS_NUM_CODE) +"</div>"+
					       "</div>"+
					       "<div class='displayflex boxflex_01'>"+
					       "<div>有无自备电源：</div>"+
					       "<div class='boxflex_01'>"+ pcodeUtil.getValueFromPcodeJson("SPARE_POWER_FLAG", tempData.SPARE_POWER_FLAG) +"</div>"+
					       "</div>"+
					       "</div>"+
					       "</div>"+
					       "<div class='listBottmLine'></div>";
			    }
    			$("#sufferPointList").html(html);
			}
			else
    		{
    			fvPubUI.fvMsgShow("未查询到受电点信息");
    		}
		});
	},
	
	// 查看受电点详细信息
	viewSufferPoint : function(sufferPointId)
	{
		sessionStorage.fvSufferPointId = sufferPointId;
		changepage("../../BasicInfoVerify/Checkuserinfo/SufferPoint/html/SufferPointDetail.html");
	},
	
	initData : function()
	{
		// 头部初始化
		$("#ydjc_loginuser_nav_bl").html("受电点信息核查");
		var cons_info = JSON.parse(sessionStorage.fvConsInfo);
		$("#sufferPointConsNo").html(cons_info.cons_no);
		$("#sufferPointConsInfo").html(getHeaderInfo(cons_info.cons_sort_code_str, cons_info.rrio_code_str, cons_info.elec_type_code_str));
		
		// 绑定单击事件
		$("#fvSufferPointTitle").click(function() {changepage("../../BasicInfoVerify/Checkuserinfo/Userbaseinfo/html/UserInfoModel.html");});
		
		sufferPoint.querySufferPointList();
	}
};

pcodeUtil.initDropDownData(function(){sufferPoint.initData();});

// 回退按钮
function ydjc_loginuser_bl_back()
{
    changepage("../../BasicInfoVerify/Checkuserinfo/Userbaseinfo/html/UserInfoModel.html");
}