// 定义定价策略修改界面操作类
var pricePlanEdit = 
{
	pricePlanArray : ["TYPE_CODE","BA_CALC_MODE","DMD_SPEC_VALUE","PF_EVAL_MODE",
					 "APP_NO","TACTIC_ID","SP_ID","CONS_ID"],
	
	// 修改定价策略详情信息
	modifyPricePlan : function()
	{
		fvPubUI.fvLoading();
		var params = new Array();
		var tempArray = pricePlanEdit.pricePlanArray.slice(0, pricePlanEdit.pricePlanArray.length-4);
		for(var i=0; i<tempArray.length; i++)
		{
			var key = tempArray[i];
			var tempValue;
			if("TYPE_CODE"==key || "BA_CALC_MODE"==key || "PF_EVAL_MODE"==key)
			{
				tempValue = $("#"+key).attr("name");
			}
			else
			{
				tempValue = $("#"+key).val();
			}
			params.push(tempValue);
		}
		params.push(sessionStorage.fvAppNo);
		params.push(sessionStorage.fvTacticId);
		params.push(sessionStorage.fvSpId);
		params.push(JSON.parse(sessionStorage.fvConsInfo).cons_id);
		
		// 调用接口执行定价策略修改操作
		publicDataRequest.execDataSendRequest("MODIFY_PRICE_PLAN", pricePlanEdit.pricePlanArray, params, function()
		{
			// 执行数据库定价策略修改操作
			pricePlanDB.modifyPricePlan(pricePlanEdit.pricePlanArray, params, function(res)
			{
				fvPubUI.fvLoadingClose();
				fvPubUI.fvMsgShow("更新定价策略成功");
				changepage("../../BasicInfoVerify/Checkuserinfo/MakePricePlan/html/PricePlanDetail.html");
			});
		});
	},
	
	initData : function()
	{
		// 头部初始化
		$("#ydjc_loginuser_nav_bl").html("定价策略信息核查");
		var cons_info = JSON.parse(sessionStorage.fvConsInfo);
		$("#pricePlanEditConsNo").html(cons_info.cons_no);
		$("#pricePlanEditConsInfo").html(getHeaderInfo(cons_info.cons_sort_code_str, cons_info.rrio_code_str, cons_info.elec_type_code_str));
		
		// 绑定单击事件
		$("#fvModifyPricePlan").click(function() {pricePlanEdit.modifyPricePlan()});
		
		var tacticId = sessionStorage.fvTacticId;
		var appNo = sessionStorage.fvAppNo;
		// 查询定价策略详情信息
		pricePlanDB.queryPricePlanDetail(tacticId, appNo, function(data)
		{
			var len = data.rows.length;
			if(len > 0)
			{
				for(var i=0; i<len; i++)
			    {
			    	var tempData = data.rows.item(i);
			    	for(var j=0; j<pricePlanEdit.pricePlanArray.length; j++)
			    	{
			    		var key = pricePlanEdit.pricePlanArray[j];
			    		if("TYPE_CODE"==key || "BA_CALC_MODE"==key || "PF_EVAL_MODE"==key)
			    		{
			    			pcodeUtil.initDropDownFromEdit(key, tempData[key]);
			    		}
			    		else
			    		{
							$("#"+key).val(tempData[key]);			    			
			    		}
			    	}
			    }
			}
		});
	}
};

pricePlanEdit.initData();

// 回退按钮
function ydjc_loginuser_bl_back()
{
    changepage("../../BasicInfoVerify/Checkuserinfo/MakePricePlan/html/PricePlanDetail.html");
}