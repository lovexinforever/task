// 定义定价策略详情界面操作类
var pricePlanDetail = 
{
	// 查询定价策略详情信息
	queryPricePlan : function()
	{
		var consId = JSON.parse(sessionStorage.fvConsInfo).cons_id;
		var appNo = sessionStorage.fvAppNo;
		// 查询定价策略详情信息
		pricePlanDB.queryPricePlan(consId, appNo, function(data)
		{
			var len = data.rows.length;
			if(len > 0)
			{
				var pricePlanArray = ["TYPE_CODE","BA_CALC_MODE","DMD_SPEC_VALUE","PF_EVAL_MODE"];
				for(var i=0; i<len; i++)
			    {
			    	var tempData = data.rows.item(i);
			    	for(var j=0; j<pricePlanArray.length; j++)
			    	{
			    		var key = pricePlanArray[j];
			    		if("TYPE_CODE"==key || "BA_CALC_MODE"==key || "PF_EVAL_MODE"==key)
			    		{
			    			pcodeUtil.initReadOnlyFromDetail(key, tempData[key]);
			    		}
			    		else
			    		{
			    			$("#"+key).html(tempData[key]);
			    		}
			    	}
			    	sessionStorage.fvTacticId = tempData.TACTIC_ID;
			    	sessionStorage.fvSpId = tempData.SP_ID;
			    }
			}
			else
    		{
    			fvPubUI.fvMsgShow("未查询到定价策略信息");
    		}
		});
	},
	
	// 修改电价策略信息
	editPricePlan : function()
	{
		changepage("../../BasicInfoVerify/Checkuserinfo/MakePricePlan/html/PricePlanEdit.html");
	},
	
	initData : function()
	{
		// 头部初始化
		$("#ydjc_loginuser_nav_bl").html("定价策略信息核查");
		var cons_info = JSON.parse(sessionStorage.fvConsInfo);
		$("#pricePlanDetailConsNo").html(cons_info.cons_no);
		$("#pricePlanDetailConsInfo").html(getHeaderInfo(cons_info.cons_sort_code_str, cons_info.rrio_code_str, cons_info.elec_type_code_str));
		
		// 绑定单击事件
		$("#fvEditPricePlan").click(function() {pricePlanDetail.editPricePlan()});
		$("#fvPricePlanTitle").click(function() {changepage("../../BasicInfoVerify/Checkuserinfo/Userbaseinfo/html/UserInfoModel.html");});
		
		pricePlanDetail.queryPricePlan();
	}
};

pcodeUtil.initDropDownData(function(){pricePlanDetail.initData();});

// 回退按钮
function ydjc_loginuser_bl_back()
{
    changepage("../../BasicInfoVerify/Checkuserinfo/Userbaseinfo/html/UserInfoModel.html");
}