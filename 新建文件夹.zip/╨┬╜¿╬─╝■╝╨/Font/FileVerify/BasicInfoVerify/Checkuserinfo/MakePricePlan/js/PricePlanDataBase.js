// 定义定价策略数据库操作类
var pricePlanDB = 
{
	// 查询定价策略信息
	queryPricePlan : function(consId, appNo, queryPPSuccCB)
	{
		var sql = "SELECT * FROM C_CONS_PRC_TACTIC WHERE CONS_ID = ? AND APP_NO = ?";
		db_execut_oneSQL("dahc.db", sql, [consId, appNo], function(tx, res)
		{
			queryPPSuccCB(res);
		}, null);
	},
	
	// 查询定价策略详细信息
	queryPricePlanDetail : function(consId, appNo, queryPPDetailSuccCB)
	{
		var sql = "SELECT * FROM C_CONS_PRC_TACTIC WHERE TACTIC_ID = ? AND APP_NO = ?";
		db_execut_oneSQL("dahc.db", sql, [consId, appNo], function(tx, res)
		{
			queryPPDetailSuccCB(res);
		}, null);
	},
	
	// 修改定价策略信息	
	modifyPricePlan : function(array, params, modifyPPSuccCB)
	{
		var tempArray = array.slice(0, array.length-4);
		var sql = "UPDATE C_CONS_PRC_TACTIC SET ";
		for(var i=0; i<tempArray.length; i++)
		{
			sql += tempArray[i] + "=?";
			if(i != tempArray.length-1)
			{
				sql += ", ";
			}
		}
		sql += " WHERE APP_NO = ? AND TACTIC_ID = ? AND SP_ID = ? AND CONS_ID = ?";
		
		db_execut_oneSQL("dahc.db", sql, params, function(tx, res)
		{
			modifyPPSuccCB(res);
		}, null);
	}
};