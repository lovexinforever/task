<script type="text/javascript">
	//查询电能表数据
	function jlzz_meter_select(consid){
		var sql = " select * from D_METER where app_no="+sessionStorage.fvAppNo+" and cons_id="+consid+" ";
		db_execut_oneSQL("dahc.db",sql,[],jlzz_meter_success,jlzz_meter_faile);
		function jlzz_meter_success(tx,res){
			var data = res.rows;
			sendfont_d_meter(data);
		}
		function jlzz_meter_faile(e){
			fvPubUI.fvMsgShow("添加移动终端数据库失败");
		}
	}
	
	//查询电能表编号数据
	function jlzz_meter_selectno(meterid){
		var sql = " select * from D_METER where app_no="+sessionStorage.fvAppNo+" and meter_id="+meterid+" ";
		db_execut_oneSQL("dahc.db",sql,[],jlzz_meter_success,jlzz_meter_faile);
		function jlzz_meter_success(tx,res){
			var data = res.rows;
			sendfont_d_meterno(data);
		}
		function jlzz_meter_faile(e){
			fvPubUI.fvMsgShow("添加移动终端数据库失败");
		}
	}
	
	//查询互感器数据
	function jlzz_it_select(consid){
		var sql = "select * from D_IT where app_no="+sessionStorage.fvAppNo+" and cons_id="+consid+" ";
		db_execut_oneSQL("dahc.db",sql,[],jlzz_it_success,jlzz_it_faile);
		function jlzz_it_success(tx,res){
			var data = res.rows;
			sendfont_d_it(data);
		}
		function jlzz_it_faile(e){
			fvPubUI.fvMsgShow("添加移动终端数据库失败");
		}
		
	}
	
	//查询互感器数据编号数据
	function jlzz_it_selectno(itid){
		var sql = "select * from D_IT where app_no="+sessionStorage.fvAppNo+" and it_id="+itid+" ";
		db_execut_oneSQL("dahc.db",sql,[],jlzz_it_success,jlzz_it_faile);
		function jlzz_it_success(tx,res){
			var data = res.rows;
			sendfont_d_itno(data);
		}
		function jlzz_it_faile(e){
			fvPubUI.fvMsgShow("添加移动终端数据库失败");
		}
		
	}
</script>