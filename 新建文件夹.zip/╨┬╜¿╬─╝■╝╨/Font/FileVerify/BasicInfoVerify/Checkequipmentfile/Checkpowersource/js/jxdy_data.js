<script type="text/javascript">
//进线电源第一个页面
function jxdy_data_start(consid){
	var sql=" select * from yj_c_ps where app_no="+sessionStorage.fvAppNo+" and cons_id="+consid+" ";
	db_execut_oneSQL("dahc.db",sql,[],jxdy_first_success,jxdy_first_fail);
	function jxdy_first_success(tx,res){
		var data = res.rows;
		sendfont_yj_c_ps(data);
	}
	function jxdy_first_fail(e){
		fvPubUI.fvMsgShow("未查询到数据");
	}
}

//进线电源编号详情页面
function jxdy_num_start(psid){
	var sql=" select * from yj_c_ps where app_no="+sessionStorage.fvAppNo+" and ps_id="+psid+" ";
	db_execut_oneSQL("dahc.db",sql,[],jxdy_num_success,jxdy_num_fail);
	function jxdy_num_success(tx,res){
		var data=res.rows;
		sendfont_yj_c_ps_num(data);
	}
	function jxdy_num_fail(){}
}

//修改页面
function jxdy_modify_start(id){
	var sql=" select * from yj_c_ps where app_no=?";
	db_execut_oneSQL("dahc.db",sql,[id],jxdy_num_success,jxdy_num_fail);
	function jxdy_num_success(tx,res){
		var data=res.rows;
		sendfont_yj_c_ps_modify(data);
	}
	function jxdy_num_fail(){}
}
function jxdy_ps_save(id){
	var sql="update yj_c_ps set ps_no=?,subs_name=?,line_name=?,tg_name=?,type_code=?,phase_code=?,ps_volt=?,ps_cap=?,ps_attr=?,linein_mode=?,linein_pole_no=?,lv_box_no=?,pr_point=?,protect_mode=?,run_mode=?,relay_protect_mode=?,remark=? where ps_id=?";
	db_execut_oneSQL("dahc.db",sql,id,jxdy_change_success,null);
	
}
</script>