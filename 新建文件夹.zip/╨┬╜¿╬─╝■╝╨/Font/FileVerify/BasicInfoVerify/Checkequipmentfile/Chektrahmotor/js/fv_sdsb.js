var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);

//受电设备数据集合
var sdsbList = new Array();

init();

function init()
{
	$("#ydjc_loginuser_nav_bl").html("受电设备");
	
	$("#fv_cons_no").html(fvConsInfo.cons_no);
	$("#fv_cons_info").html(getHeaderInfo(fvConsInfo.cons_sort_code_str, fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str));
	
	slect_SdsbList_Data();
	
	/**
	 * 点击返回按钮
	 */  
	$("#fv_sdsb_back").click(function()
	{	
		ydjc_loginuser_bl_back();
	});
}

/*************************************查询列表数据****************************************/

/**
 * 计量点列表初始化
 */
function slect_SdsbList_Data()
{
	fvPubUI.fvLoading();
	
    var sql = "SELECT EQUIP_ID,TYPE_CODE,TRAN_NAME,RUN_STATUS_CODE,PLATE_CAP  FROM YJ_G_TRAN WHERE APP_NO="+ sessionStorage.fvAppNo +" AND CONS_ID="+fvConsInfo.cons_id;    
    db_execut_oneSQL("dahc.db",sql,[],queryListSuccess,queryListFail);
}

/**
 * 查询受电设备列表成功回调
 */
function queryListSuccess(tx,res)
{
	fvPubUI.fvLoadingClose();
	$("#apend_sdsbList *").remove();

    var len=res.rows.length;
    
    var result="";
    var equiip_type_name;
    var run_status_name;
    if(len)
    {
        for(var i=0;i<len;i++)
        {
        	sdsbList[i]=res.rows.item(i);
        	
        	equiip_type_name = getPcodeNameByValue(fvPcode.codeSortJson["A_16032"], sdsbList[i].TYPE_CODE);
        	run_status_name = getPcodeNameByValue(fvPcode.codeSortJson["A_23007"], sdsbList[i].RUN_STATUS_CODE);
        	
            result += '<div class="displayflex fvBaseInfoIcon" onclick="clickListItem('+sdsbList[i].EQUIP_ID+')">'
						+'<div class="displayflex">'
							+'<div class="boxflex_01"><img  src="../../Util/Images/link_46x46.png"/></div>'
							+'<div class="boxflex_01" style="margin:0 10px;"><img  src="../../Util/Images/shuxian_01.png"/></div>'
						+'</div>'
						+'<div class="displayflexvertical boxflex_01">'
							+'<div class="displayflex boxflex_01">'             	
								+'<div >设备类型：</div>'
								+'<div class="boxflex_01">'+ equiip_type_name+'</div>'
							+'</div>'
							+'<div class="displayflex boxflex_01">'
								+'<div >设备名称：</div>'
								+'<div class="boxflex_01">'+ sdsbList[i].TRAN_NAME +'</div>'
							+'</div>'
							+'<div class="displayflex boxflex_01">'
								+'<div >铭牌容量：</div>'
								+'<div class="boxflex_01">'+ sdsbList[i].PLATE_CAP +'</div>'
							+'</div>'
							+'<div class="displayflex boxflex_01">'
								+'<div >运行状态：</div>'
								+'<div class="boxflex_01">'+ run_status_name +'</div>'
							+'</div>'
						+'</div>'
					+'</div>'
					+'<div class="fvTopBorder"></div>';
					//+'<div style="line-height: 20px;"><img src="../../Util/Images/greenline.png" width="100%" height="2px"></img></div>'
        }
        $("#apend_sdsbList").append(result);
    }else
    {
    	fvPubUI.fvMsgShow("未查询到受电设备数据");
    }
}

/**
 * 获取pcode列表中的特定项
 */
function getPcodeNameByValue(pCodeList, value)
{
	for(var i=0;i<pCodeList.length;i++)
    {
    	if(pCodeList[i].value == value)
    	{
    		return pCodeList[i].name;
    	}
    }
        
}


/**
 * 查询受电设备列表失败回调
 */
function queryListFail(tx,res)
{
	fvPubUI.fvLoadingClose();
	$("#apend_sdsbList *").remove();
    fvPubUI.fvMsgShow("未查询到受电设备数据");
}

/**
 * 点击受电设备列表中的一项
 * 跳转到受电设备详情
 */
function clickListItem(equipId)
{
	// 记录下被点击的受电设备信息
	sessionStorage.fvSdsbEquipId = equipId;
	
	// 跳转到受电设备详细页面
	changepage("../../BasicInfoVerify/Checkequipmentfile/Chektrahmotor/html/fv_sdsb_detail.html");
}

//回退按钮
function ydjc_loginuser_bl_back()
{
    changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
}