$("#ydjc_loginuser_nav_bl").html("受电设备-修改");

var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);

// 获取缓存中的一条受电设备详情
var equipDetailSessionData;

// 记录厂家
var factory_obj;

/**
 * 调用
 */
init();

/***********************************初始化*************************************/
/**
 * 初始化
 */
function init()
{
	fvPubUI.fvLoading();
	
	$("#ydjc_loginuser_nav_bl").html("受电设备-详情");
	$("#fv_cons_no").html(fvConsInfo.cons_no);
	$("#fv_cons_info").html(getHeaderInfo(fvConsInfo.cons_sort_code_str, fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str));
	
	
	slect_MeasPointList_Data();
	fillCombox();
	/**
	 * 点击返回按钮
	 */  
	$("#fv_sdsb_back").click(function()
	{	
		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
	});
	/**
	 * 点击返回列表
	 */  
	$("#fv_sdsb_back_detail").click(function()
	{	
		ydjc_loginuser_bl_back();
	});
	
	/**
	 * 点击修改按钮
	 */  
	$("#fv_sdsb_save").click(function()
	{	
		saveData();
	});
	
	//安装日期
 	$("#fv_INST_DATE").click( function()
 	{ 
 		fvPubUI.getDate("fv_INST_DATE");
 	});
 	//出厂日期
 	$("#fv_MADE_DATE").click( function()
 	{ 
 		fvPubUI.getDate("fv_MADE_DATE");
 	});
	//到期日期
 	$("#fv_DUE_DATE").click( function()
 	{ 
 		fvPubUI.getDate("fv_DUE_DATE");
 	});
 	//试验日期
 	$("#fv_TEST_DATE").click( function()
 	{ 
 		fvPubUI.getDate("fv_TEST_DATE");
 	});
	
	//点击制造厂
	$("#fv_FACTORY_NAME").click(function()
	{
		fvSmrz.getFactoryData(setFactory);
	});
}

/**********************************************设置制造厂家*************************************************/
function setFactory(data)
{
	/*
		{
			"FACTORY_ID" :厂商ID,
			"FACNAME" : 厂商名字
		};
	*/
	
	factory_obj = data;
	$("#fv_FACTORY_NAME").val(factory_obj.FACNAME);
}

/***********************************查询受电设备详情*************************************/

/**
 * 受电设备详情初始化
 */

function slect_MeasPointList_Data()
{
    var sql = "SELECT * FROM YJ_G_TRAN WHERE APP_NO="+ sessionStorage.fvAppNo +" AND EQUIP_ID="+sessionStorage.fvSdsbEquipId;    
    db_execut_oneSQL("dahc.db",sql,[],querySdsbSuccess,querySdsbFail);
}

//成功回调
function querySdsbSuccess(tx,res)
{	
	fvPubUI.fvLoadingClose();
	
    var len=res.rows.length;
    if(len > 0)
    {
    	// 记录受电设备详情
        fillSdsbEdit(res.rows);
    }else
    {
    	fvPubUI.fvMsgShow("未查询到受电设备数据");
    }
}
//成功回调
function querySdsbFail(tx,res)
{
	fvPubUI.fvLoadingClose();
    fvPubUI.fvMsgShow("未查询到受电设备数据");
}


/***********************************填充受电设备详情UI*************************************/

/**
 * 填充下拉列表
 */
function fillCombox()
{
	pCdoeSelectList({"id" : "fv_TS_ALG_FLAG","pCode" : [{"A_14001" : "","codeId" : 14001}]});
	pCdoeSelectList({"id" : "fv_MS_FLAG","pCode" : [{"A_16059" : "","codeId" : 16059}]});
	pCdoeSelectList({"id" : "fv_PROTECT_MODE","pCode" : [{"A_16060" : "","codeId" : 16060}]});
	pCdoeSelectList({"id" : "fv_PR_CODE","pCode" : [{"A_18006" : "","codeId" : 18006}]});	
	pCdoeSelectList({"id" : "fv_FRSTSIDE_VOLT_CODE","pCode" : [{"A_10005" : "","codeId" : 10005}]});
	pCdoeSelectList({"id" : "fv_SNDSIDE_VOLT_CODE","pCode" : [{"A_10005" : "","codeId" : 10005}]});
	pCdoeSelectList({"id" : "fv_MODEL_NO","pCode" : [{"A_16029" : "","codeId" : 16029}]});
	pCdoeSelectList({"id" : "fv_WIRE_GROUP_CODE","pCode" : [{"A_16010" : "","codeId" : 16010}]});
	pCdoeSelectList({"id" : "fv_COOL_MODE","pCode" : [{"A_16013" : "","codeId" : 16013}]});
	pCdoeSelectList({"id" : "fv_RV_HV","pCode" : [{"A_10001" : "","codeId" : 10001}]});
	pCdoeSelectList({"id" : "fv_RC_HV","pCode" : [{"A_16049" : "","codeId" : 16049}]});
	pCdoeSelectList({"id" : "fv_RV_MV","pCode" : [{"A_10001" : "","codeId" : 10001}]});
	pCdoeSelectList({"id" : "fv_RC_MV","pCode" : [{"A_16049" : "","codeId" : 16049}]});
	pCdoeSelectList({"id" : "fv_RV_LV","pCode" : [{"A_10001" : "","codeId" : 10001}]});
	pCdoeSelectList({"id" : "fv_RC_LV","pCode" : [{"A_16049" : "","codeId" : 16049}]});
	pCdoeSelectList({"id" : "fv_GROUND_FLAG","pCode" : [{"A_30022" : "","codeId" : 30022}]});
	pCdoeSelectList({"id" : "fv_MAIN_WIRING_MODE","pCode" : [{"A_16071" : "","codeId" : 16071}]});
	
}

/**
 * 填充待修改的基本信息
 */
function fillSdsbEdit(value)
{
	
	
	var data = value.item(0);
	
	equipDetailSessionData = data;
	
	var pcode_16032 = getPcodeItemByValue(fvPcode.codeSortJson["A_16032"], data.TYPE_CODE);
	var pcode_23007 = getPcodeItemByValue(fvPcode.codeSortJson["A_23007"], data.RUN_STATUS_CODE);
	var pcode_23002 = getPcodeItemByValue(fvPcode.codeSortJson["A_23002"], data.PUB_PRIV_FLAG);
	var pcode_14001 = getPcodeItemByValue(fvPcode.codeSortJson["A_14001"], data.TS_ALG_FLAG);
	var pcode_11007 = getPcodeItemByValue(fvPcode.codeSortJson["A_11007"], data.CHG_REMARK);
	var pcode_16059 = getPcodeItemByValue(fvPcode.codeSortJson["A_16059"], data.MS_FLAG);
	var pcode_16060 = getPcodeItemByValue(fvPcode.codeSortJson["A_16060"], data.PROTECT_MODE);
	var pcode_18006 = getPcodeItemByValue(fvPcode.codeSortJson["A_18006"], data.PR_CODE);
	var pcode_10005;
	var pcode_10005_list = fvPcode.codeSortJson["A_10005"];
	var pcode_16029 = getPcodeItemByValue(fvPcode.codeSortJson["A_16029"], data.MODEL_NO);
	var pcode_16010 = getPcodeItemByValue(fvPcode.codeSortJson["A_16010"], data.WIRE_GROUP_CODE);
	var pcode_16013 = getPcodeItemByValue(fvPcode.codeSortJson["A_16013"], data.COOL_MODE);
	var pcode_10001;
	var pcode_10001_list = fvPcode.codeSortJson["A_10001"];
	var pcode_16049;
	var pcode_16049_list = fvPcode.codeSortJson["A_16049"];
	var pcode_30022 = getPcodeItemByValue(fvPcode.codeSortJson["A_30022"], data.GROUND_FLAG);
	var pcode_16071 = getPcodeItemByValue(fvPcode.codeSortJson["A_16071"], data.MAIN_WIRING_MODE);
	
	try
	{
		$("#fv_TYPE_CODE").val(pcode_16032.name);
        $("#fv_TYPE_CODE").attr("name",pcode_16032.value);
//        pCdoeSelectList({"id" : "fv_TYPE_CODE","pCode" : [{"A_16032" : "","codeId" : 16032}]});
		
		$("#fv_TRAN_NAME").val(data.TRAN_NAME);
		$("#fv_PLATE_CAP").val(data.PLATE_CAP);
		
		$("#fv_RUN_STATUS_CODE").val(pcode_23007.name);	
		$("#fv_RUN_STATUS_CODE").attr("name",pcode_23007.value);
		
		$("#fv_PUB_PRIV_FLAG").val(pcode_23002.name);
		$("#fv_PUB_PRIV_FLAG").attr("name",pcode_23002.value);		
		
		$("#fv_CHG_CAP").val(data.CHG_CAP);
		$("#fv_TG_NO").val(data.TG_NO);
		$("#fv_LINE_NAME").val(data.LINE_NAME);
		$("#fv_INST_DATE").val(data.INST_DATE);
		$("#fv_INST_ADDR").val(data.INST_ADDR);
		$("#fv_FRST_RUN_DATE").val(data.FRST_RUN_DATE);
		$("#fv_ACTUAL_START_DATE").val(data.ACTUAL_START_DATE);
		$("#fv_MADE_DATE").val(data.MADE_DATE);
		$("#fv_ACTUAL_STOP_USE_DATE").val(data.ACTUAL_STOP_USE_DATE);
		$("#fv_PLAN_RESUME_DATE").val(data.PLAN_RESUME_DATE);
		$("#fv_DUE_DATE").val(data.DUE_DATE);
		$("#fv_TS_NO").val(data.TS_NO);
		
		$("#fv_TS_ALG_FLAG").html(pcode_14001.name);
		$("#fv_TS_ALG_FLAG").attr("name",pcode_14001.value);
		
		$("#fv_CHG_REMARK").val(pcode_11007.name);	
		
		$("#fv_MS_FLAG").html(pcode_16059.name);
		$("#fv_MS_FLAG").attr("name",pcode_16059.value);
		
		$("#fv_PROTECT_MODE").html(pcode_16060.name);
		$("#fv_PROTECT_MODE").attr("name",pcode_16060.value);
        
		$("#fv_PR_CODE").html(pcode_18006.name);
		$("#fv_PR_CODE").attr("name",pcode_18006.value);
		
		pcode_10005 = getPcodeItemByValue(pcode_10005_list, data.FRSTSIDE_VOLT_CODE);
		$("#fv_FRSTSIDE_VOLT_CODE").html(pcode_10005.name);
		$("#fv_FRSTSIDE_VOLT_CODE").attr("name",pcode_10005.value);
       
		pcode_10005 = getPcodeItemByValue(pcode_10005_list, data.SNDSIDE_VOLT_CODE);
		$("#fv_SNDSIDE_VOLT_CODE").html(pcode_10005.name);
		$("#fv_SNDSIDE_VOLT_CODE").attr("name",pcode_10005.value);
		
		$("#fv_MODEL_NO").html(pcode_16029.name);
		$("#fv_MODEL_NO").attr("name",pcode_16029.value);
		
		$("#fv_K_VALUE").val(data.K_VALUE);
		
		$("#fv_FACTORY_NAME").val(data.FACTORY_NAME);
				
		$("#fv_ORG_NO").val(data.ORG_NO);
		$("#fv_ORG_NAME").val(data.ORG_NAME);
		$("#fv_MADE_NO").val(data.MADE_NO);
		
		$("#fv_WIRE_GROUP_CODE").html(pcode_16010.name);
		$("#fv_WIRE_GROUP_CODE").attr("name",pcode_16010.value);
		
		$("#fv_COOL_MODE").html(pcode_16013.name);
		$("#fv_COOL_MODE").attr("name",pcode_16013.value);
		
		pcode_10001 = getPcodeItemByValue(pcode_10001_list, data.RV_HV);
		$("#fv_RV_HV").html(pcode_10001.name);
		$("#fv_RV_HV").attr("name",pcode_10001.value);
		
		pcode_16049 = getPcodeItemByValue(pcode_16049_list, data.RC_HV);
		$("#fv_RC_HV").html(pcode_16049.name);
		$("#fv_RC_HV").attr("name",pcode_16049.value);
		
		pcode_10001 = getPcodeItemByValue(pcode_10001_list, data.RV_MV);		
        $("#fv_RV_MV").html(pcode_10001.name);
		$("#fv_RV_MV").attr("name",pcode_10001.value);
		
		pcode_16049 = getPcodeItemByValue(pcode_16049_list, data.RC_MV);
		$("#fv_RC_MV").html(pcode_16049.name);
		$("#fv_RC_MV").attr("name",pcode_16049.value);
		
		pcode_10001 = getPcodeItemByValue(pcode_10001_list, data.RV_LV);
		$("#fv_RV_LV").html(pcode_10001.name);
		$("#fv_RV_LV").attr("name",pcode_10001.value);
		
		pcode_16049 = getPcodeItemByValue(pcode_16049_list, data.RC_LV);
		$("#fv_RC_LV").html(pcode_16049.name);
		$("#fv_RC_LV").attr("name",pcode_16049.value);
		
		$("#fv_SC_RESI").val(data.SC_RESI);
		$("#fv_K_CURRENT").val(data.K_CURRENT);
		$("#fv_TEST_DATE").val(data.TEST_DATE);
		$("#fv_TEST_CYCLE").val(data.TEST_CYCLE);
		
		$("#fv_GROUND_FLAG").html(pcode_30022.name);
		$("#fv_GROUND_FLAG").attr("name",pcode_30022.value);
		
		$("#fv_MAIN_WIRING_MODE").html(pcode_16071.name);
		$("#fv_MAIN_WIRING_MODE").attr("name",pcode_16071.value);
		
		$("#fv_OIL_NO").val(data.OIL_NO);
		$("#fv_SUBJOINT_GRADE").val(data.SUBJOINT_GRADE);
		$("#fv_SUBJOINT_LOC").val(data.SUBJOINT_LOC);
		$("#fv_GROUND_RESI").val(data.GROUND_RESI);
		$("#fv_RP_TL_VALUE").val(data.RP_TL_VALUE);
		$("#fv_AP_TL_VALUE").val(data.AP_TL_VALUE);        
	}catch(err)
	{
	   	fvPubUI.fvLoadingClose();
	}
	
	fvPubUI.fvLoadingClose();
}

/**
 * 获取pcode列表中的特定项
 */
function getPcodeItemByValue(pCodeList, value)
{
	for(var i=0;i<pCodeList.length;i++)
    {
    	if(pCodeList[i].value == value)
    	{
    		return pCodeList[i];
    	}else if((i + 1) >= pCodeList.length)
    	{
    		var obj = {name:"", value:0}
    		return obj;
    	}
    	
    }  
}

/**********************************保存数据*************************************/

/**
 * 保存数据
 */
function saveData()
{
	if(checkEmpty())
	{
		fvPubUI.fvLoading();
		sendInfoToServer();
	}
}

/**
 * 判断是否为空
 */
function checkEmpty()
{
	if(checkStringTrim($("#fv_TYPE_CODE").val()))
	{
		fvPubUI.fvMsgShow("设备类型不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_TRAN_NAME").val()))
	{
		fvPubUI.fvMsgShow("设备名称不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_PLATE_CAP").val()))
	{
		fvPubUI.fvMsgShow("铭牌容量不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_RUN_STATUS_CODE").val()))
	{
		fvPubUI.fvMsgShow("运行状态不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_PUB_PRIV_FLAG").val()))
	{
		fvPubUI.fvMsgShow("公变专变标识不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_TG_NO").val()))
	{
		fvPubUI.fvMsgShow("台区编号不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_LINE_NAME").val()))
	{
		fvPubUI.fvMsgShow("线路名称不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_INST_DATE").val()))
	{
		fvPubUI.fvMsgShow("安装日期不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_FRST_RUN_DATE").val()))
	{
		fvPubUI.fvMsgShow("首次运行日期不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_ACTUAL_START_DATE").val()))
	{
		fvPubUI.fvMsgShow("实际启用日期不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_TS_ALG_FLAG").attr("name")))
	{
		fvPubUI.fvMsgShow("变损算法标志不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_MS_FLAG").attr("name")))
	{
		fvPubUI.fvMsgShow("变压器主备性质不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_PROTECT_MODE").attr("name")))
	{
		fvPubUI.fvMsgShow("保护方式不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_PR_CODE").attr("name")))
	{
		fvPubUI.fvMsgShow("产权不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_FRSTSIDE_VOLT_CODE").attr("name")))
	{
		fvPubUI.fvMsgShow("一次侧电压不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_SNDSIDE_VOLT_CODE").attr("name")))
	{
		fvPubUI.fvMsgShow("二次侧电压不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_MODEL_NO").attr("name")))
	{
		fvPubUI.fvMsgShow("设备型号不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_ORG_NAME").val()))
	{
		fvPubUI.fvMsgShow("变压器管理单位名称不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_WIRE_GROUP_CODE").val()))
	{
		fvPubUI.fvMsgShow("接线组别不能为空");	
		return false;
	}
	if(checkStringTrim($("#fv_COOL_MODE").val()))
	{
		fvPubUI.fvMsgShow("冷却方式不能为空");	
		return false;
	}
	return true;
}
/**
 * 判断字符串是否为空
 */
function checkStringTrim(str)
{
	if(str == "" || str == undefined)
		return true;
	return false;
}





// 针对有pcode项的属性取出对应值
var t_TYPE_CODE;
var t_RUN_STATUS_CODE;
var t_PUB_PRIV_FLAG;
var t_TS_ALG_FLAG;
var t_MS_FLAG;
var t_PROTECT_MODE;
var t_PR_CODE;
var t_FRSTSIDE_VOLT_CODE;
var t_SNDSIDE_VOLT_CODE;
var t_MODEL_NO;
var t_WIRE_GROUP_CODE;
var t_COOL_MODE;
var t_RV_HV;
var t_RC_HV;
var t_RV_MV;
var t_RC_MV;
var t_RV_LV;
var t_RC_LV;
var t_GROUND_FLAG;
var t_MAIN_WIRING_MODE;
/**
 * 根据用户编号或者资产编号查询对应基本信息
 */
function sendInfoToServer()
{	
	 t_TYPE_CODE = $("#fv_TYPE_CODE").attr("name");
	 t_RUN_STATUS_CODE = $("#fv_RUN_STATUS_CODE").attr("name");
	 t_PUB_PRIV_FLAG = $("#fv_PUB_PRIV_FLAG").attr("name");
	 t_TS_ALG_FLAG = $("#fv_TS_ALG_FLAG").attr("name");
	 t_MS_FLAG = $("#fv_MS_FLAG").attr("name");
	 t_PROTECT_MODE = $("#fv_PROTECT_MODE").attr("name");
	 t_PR_CODE = $("#fv_PR_CODE").attr("name");
	 t_FRSTSIDE_VOLT_CODE = $("#fv_FRSTSIDE_VOLT_CODE").attr("name");
	 t_SNDSIDE_VOLT_CODE = $("#fv_SNDSIDE_VOLT_CODE").attr("name");
	 t_MODEL_NO = $("#fv_MODEL_NO").attr("name");
	 t_WIRE_GROUP_CODE = $("#fv_WIRE_GROUP_CODE").attr("name");
	 t_COOL_MODE = $("#fv_COOL_MODE").attr("name");
	 t_RV_HV = $("#fv_RV_HV").attr("name");
	 t_RC_HV = $("#fv_RC_HV").attr("name");
	 t_RV_MV = $("#fv_RV_MV").attr("name");
	 t_RC_MV= $("#fv_RC_MV").attr("name");
	 t_RV_LV= $("#fv_RV_LV").attr("name");
	 t_RC_LV= $("#fv_RC_LV").attr("name");
	 t_GROUND_FLAG= $("#fv_GROUND_FLAG").attr("name");
	 t_MAIN_WIRING_MODE= $("#fv_MAIN_WIRING_MODE").attr("name");
	

	var objJSON = '"APP_NO":"'			+equipDetailSessionData.APP_NO +'",' + 
					'"EQUIP_ID":"'			+equipDetailSessionData.EQUIP_ID +'",' + 
					'"CONS_ID":"'			+equipDetailSessionData.CONS_ID +'",' + 
					'"CONS_NAME":"'			+fvConsInfo.cons_name +'",' + 
					'"TYPE_CODE":"'			+t_TYPE_CODE +'",' + 
					'"TRAN_NAME":"'			+$("#fv_TRAN_NAME").val()+'",'+
					'"PLATE_CAP":"'			+$("#fv_PLATE_CAP").val()+'",'+
					'"RUN_STATUS_CODE":"'	+t_RUN_STATUS_CODE+'",' + 
					'"PUB_PRIV_FLAG":"'		+t_PUB_PRIV_FLAG+'",' + 		
					'"CHG_CAP":"'			+$("#fv_CHG_CAP").val()+'",'+
					'"TG_ID":"'				+equipDetailSessionData.TG_ID+'",' + 
					'"TG_NO":"'				+$("#fv_TG_NO").val()+'",'+
					'"LINE_ID":"'			+equipDetailSessionData.LINE_ID+'",' + 
					'"LINE_NAME":"'			+$("#fv_LINE_NAME").val()+'",'+
					'"INST_DATE":"'			+$("#fv_INST_DATE").val()+'",'+
					'"INST_ADDR":"'			+$("#fv_INST_ADDR").val()+'",'+
					'"FRST_RUN_DATE":"'		+equipDetailSessionData.FRST_RUN_DATE+'",' + 
					'"ACTUAL_START_DATE":"'	+equipDetailSessionData.ACTUAL_START_DATE+'",' + 
					'"MADE_DATE":"'			+$("#fv_MADE_DATE").val()+'",'+
					'"ACTUAL_STOP_USE_DATE":"'+equipDetailSessionData.ACTUAL_STOP_USE_DATE+'",' + 
					'"PLAN_RESUME_DATE":"'	+equipDetailSessionData.PLAN_RESUME_DATE+'",' + 
					'"DUE_DATE":"'			+$("#fv_DUE_DATE").val()+'",'+
					'"TS_NO":"'				+$("#fv_TS_NO").val()+'",'+
					'"TS_ALG_FLAG":"'		+t_TS_ALG_FLAG+'",'+
					'"CHG_REMARK":"'		+equipDetailSessionData.CHG_REMARK+'",' + 
					'"MS_FLAG":"'			+t_MS_FLAG+'",'+
					'"PROTECT_MODE":"'		+t_PROTECT_MODE+'",'+
					'"PR_CODE":"'			+t_PR_CODE+'",'+
					'"FRSTSIDE_VOLT_CODE":"'+t_FRSTSIDE_VOLT_CODE+'",'+
					'"SNDSIDE_VOLT_CODE":"'	+t_SNDSIDE_VOLT_CODE+'",'+
					'"MODEL_NO":"'			+t_MODEL_NO+'",'+
					'"K_VALUE":"'			+$("#fv_K_VALUE").val()+'",'+
					'"FACTORY_NAME":"'		+$("#fv_FACTORY_NAME").val()+'",'+
					'"ORG_NO":"'			+equipDetailSessionData.ORG_NO+'",' + 
					'"ORG_NAME":"'			+equipDetailSessionData.ORG_NAME+'",' + 
					'"MADE_NO":"'			+$("#fv_MADE_NO").val()+'",'+
					'"WIRE_GROUP_CODE":"'	+t_WIRE_GROUP_CODE+'",'+
					'"COOL_MODE":"'			+t_COOL_MODE+'",'+
					'"RV_HV":"'				+t_RV_HV+'",'+
					'"RC_HV":"'				+t_RC_HV+'",'+
					'"RV_MV":"'				+t_RV_MV+'",'+
					'"RC_MV":"'				+t_RC_MV+'",'+
					'"RV_LV":"'				+t_RV_LV+'",'+
					'"RC_LV":"'				+t_RC_LV+'",'+
					'"SC_RESI":"'			+$("#fv_SC_RESI").val()+'",'+
					'"K_CURRENT":"'			+$("#fv_K_CURRENT").val()+'",'+
					'"TEST_DATE":"'			+$("#fv_TEST_DATE").val()+'",'+
					'"TEST_CYCLE":"'		+$("#fv_TEST_CYCLE").val()+'",'+
					'"GROUND_FLAG":"'		+t_GROUND_FLAG+'",'+
					'"MAIN_WIRING_MODE":"'	+t_MAIN_WIRING_MODE+'",'+
					'"OIL_NO":"'			+$("#fv_OIL_NO").val()+'",'+
					'"SUBJOINT_GRADE":"'	+$("#fv_SUBJOINT_GRADE").val()+'",'+
					'"SUBJOINT_LOC":"'		+$("#fv_SUBJOINT_LOC").val()+'",'+
					'"GROUND_RESI":"'		+$("#fv_GROUND_RESI").val()+'",'+
					'"RP_TL_VALUE":"'		+$("#fv_RP_TL_VALUE").val()+'",'+
					'"AP_TL_VALUE":"'		+$("#fv_AP_TL_VALUE").val()+'"';
	
	//1.发送实名制认证基本信息请求到服务器
	var pkg='{"MOD":"2034","FUN":"030615","ORG_NO":"'+sessionStorage.ORG_NO+'","SYS_USER_NAME":"'+ sessionStorage.user_name +'","TERM_NUM":"'+ fvTid +'","PKG":{'+ objJSON +'}}';
    send_data("030615","2034",pkg,sendSaveSuccess,sendSaveFail);
}

//发送成功
function sendSaveSuccess(message_ener) 
{
	try
	{
        fvPubUI.fvLoadingClose();//关闭加载效果框
        var msg_enercb = JSON.parse(message_ener);
        if(msg_enercb.RET=="00")
        {
            var msg_pkg=msg_enercb.PKG.PKG;
            if(msg_pkg.FLAG=="1")
            {
            	// 更新数据库
				updateDB();
            }else
            {
                fvPubUI.fvMsgShow("数据上装失败");
            }
        }else
        {
            fvPubUI.fvMsgShow("数据上装失败");
        }
    }catch(e)
    {
   	 	fvPubUI.fvMsgShow("数据上装失败!返回数据异常");
    }
}
//发送失败
function sendSaveFail(msg)
{
	fvPubUI.fvLoadingClose();//关闭加载效果框
	
	fvPubUI.fvMsgShow("数据上装失败");
}


/**
 * 更新数据库
 */
function updateDB()
{
	var consKeyArr = 
	{
		"tableName" 		: "YJ_G_TRAN",
		"TYPE_CODE"			:t_TYPE_CODE,
		"TRAN_NAME"			:$("#fv_TRAN_NAME").val(),
		"PLATE_CAP"			:$("#fv_PLATE_CAP").val(),
		"RUN_STATUS_CODE"	:t_RUN_STATUS_CODE,
		"PUB_PRIV_FLAG"		:t_PUB_PRIV_FLAG,
		"CHG_CAP"			:$("#fv_CHG_CAP").val(),
		"TG_NO"				:$("#fv_TG_NO").val(),
		"LINE_NAME"			:$("#fv_LINE_NAME").val(),
		"INST_DATE"			:$("#fv_INST_DATE").val(),
		"INST_ADDR"			:$("#fv_INST_ADDR").val(),
		"MADE_DATE"			:$("#fv_MADE_DATE").val(),		
		"DUE_DATE"			:$("#fv_DUE_DATE").val(),
		"TS_NO"				:$("#fv_TS_NO").val(),
		"TS_ALG_FLAG"		:t_TS_ALG_FLAG,
		"MS_FLAG"			:t_MS_FLAG,
		"PROTECT_MODE"		:t_PROTECT_MODE,
		"PR_CODE"			:t_PR_CODE,
		"FRSTSIDE_VOLT_CODE":t_FRSTSIDE_VOLT_CODE,
		"SNDSIDE_VOLT_CODE"	:t_SNDSIDE_VOLT_CODE,
		"MODEL_NO"			:t_MODEL_NO,
		"K_VALUE"			:$("#fv_K_VALUE").val(),
		"FACTORY_NAME"		:$("#fv_FACTORY_NAME").val(),
		"MADE_NO"			:$("#fv_MADE_NO").val(),
		"WIRE_GROUP_CODE"	:t_WIRE_GROUP_CODE,
		"COOL_MODE"			:t_COOL_MODE,
		"RV_HV"				:t_RV_HV,
		"RC_HV"				:t_RC_HV,
		"RV_MV"				:t_RV_MV,
		"RC_MV"				:t_RC_MV,
		"RV_LV"				:t_RV_LV,
		"RC_LV"				:t_RC_LV,
		"SC_RESI"			:$("#fv_SC_RESI").val(),
		"K_CURRENT"			:$("#fv_K_CURRENT").val(),
		"TEST_DATE"			:$("#fv_TEST_DATE").val(),
		"TEST_CYCLE"		:$("#fv_TEST_CYCLE").val(),
		"GROUND_FLAG"		:t_GROUND_FLAG,
		"MAIN_WIRING_MODE"	:t_MAIN_WIRING_MODE,
		"OIL_NO"			:$("#fv_OIL_NO").val(),
		"SUBJOINT_GRADE"	:$("#fv_SUBJOINT_GRADE").val(),
		"SUBJOINT_LOC"		:$("#fv_SUBJOINT_LOC").val(),
		"GROUND_RESI"		:$("#fv_GROUND_RESI").val(),
		"RP_TL_VALUE"		:$("#fv_RP_TL_VALUE").val(),
		"AP_TL_VALUE"		:$("#fv_AP_TL_VALUE").val()
	};
	var whereArr = {"APP_NO" : equipDetailSessionData.APP_NO,"EQUIP_ID" : equipDetailSessionData.EQUIP_ID};	
	fvSqlModel.updateInfo(consKeyArr, whereArr, function(){
		fvPubUI.fvMsgShow("数据上装成功");
        changepage("../../BasicInfoVerify/Checkequipmentfile/Chektrahmotor/html/fv_sdsb_detail.html");
	},null);//更新计量点表
}

/******************************************************************************************************/

//回退按钮
function ydjc_loginuser_bl_back()
{
    changepage("../../BasicInfoVerify/Checkequipmentfile/Chektrahmotor/html/fv_sdsb_detail.html");
}

