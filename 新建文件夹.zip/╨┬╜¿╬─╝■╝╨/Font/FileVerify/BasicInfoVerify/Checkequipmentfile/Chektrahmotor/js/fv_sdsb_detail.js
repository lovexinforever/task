
// 获取缓存中的设备标示信息
var equipIdSessionData =sessionStorage.fvSdsbEquipId

/**
 * 调用
 */
 init();
 
/***********************************初始化*************************************/
/**
 * 初始化
 */
function init()
{
	fvPubUI.fvLoading();
	
	$("#ydjc_loginuser_nav_bl").html("受电设备-详情");
	
	$("#fv_cons_no").html(fvConsInfo.cons_no);
	$("#fv_cons_info").html(getHeaderInfo(fvConsInfo.cons_sort_code_str, fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str));
	
	
	// 查询受电设备详细
	slect_MeasPointList_Data();
	
	/**
	 * 点击返回按钮
	 */  
	$("#fv_sdsb_back").click(function()
	{	
		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
	});
	
	/**
	 * 点击返回列表
	 */  
	$("#fv_sdsb_backList").click(function()
	{	
		ydjc_loginuser_bl_back();
	});
	
	/**
	 * 点击修改按钮
	 */  
	$("#fv_sdsb_edit").click(function()
	{	
		changepage("../../BasicInfoVerify/Checkequipmentfile/Chektrahmotor/html/fv_sdsb_edit.html");
	});
}

/***********************************查询受电设备详情*************************************/

/**
 * 受电设备详情初始化
 */

function slect_MeasPointList_Data()
{
    var sql = "SELECT * FROM YJ_G_TRAN WHERE APP_NO="+ sessionStorage.fvAppNo +" AND EQUIP_ID="+equipIdSessionData;    
    db_execut_oneSQL("dahc.db",sql,[],querySdsbSuccess,querySdsbFail);
}

//成功回调
function querySdsbSuccess(tx,res)
{	
	fvPubUI.fvLoadingClose();
	
    var len=res.rows.length;
    if(len > 0)
    {
    	fillSdsbDetail(res.rows);
    }else
    {
    	fvPubUI.fvMsgShow("未查询到受电设备数据");
    }
}
//成功回调
function querySdsbFail(tx,res)
{
	fvPubUI.fvLoadingClose();
    fvPubUI.fvMsgShow("未查询到受电设备数据");
}


/***********************************填充受电设备详情UI*************************************/
/**
 * 填充基本信息
 */
function fillSdsbDetail(value)
{
	var data = value.item(0);
	var pcode_10005 = fvPcode.codeSortJson["A_10005"];
	var pcode_10001 = fvPcode.codeSortJson["A_10001"];
	var pcode_16049 = fvPcode.codeSortJson["A_16049"];
	try
	{
		$("#fv_TYPE_CODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_16032"], data.TYPE_CODE));
		$("#fv_TRAN_NAME").html(data.TRAN_NAME);		
		$("#fv_PLATE_CAP").html(data.PLATE_CAP);
		$("#fv_RUN_STATUS_CODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_23007"], data.RUN_STATUS_CODE));
		$("#fv_PUB_PRIV_FLAG").html(getPcodeNameByValue(fvPcode.codeSortJson["A_23002"], data.PUB_PRIV_FLAG));
		$("#fv_CHG_CAP").html(data.CHG_CAP);
		$("#fv_TG_NO").html(data.TG_NO);
		$("#fv_LINE_NAME").html(data.LINE_NAME);
		$("#fv_INST_DATE").html(data.INST_DATE);
		$("#fv_INST_ADDR").html(data.INST_ADDR);
		$("#fv_FRST_RUN_DATE").html(data.FRST_RUN_DATE);
		$("#fv_ACTUAL_START_DATE").html(data.ACTUAL_START_DATE);
		$("#fv_MADE_DATE").html(data.MADE_DATE);
		$("#fv_ACTUAL_STOP_USE_DATE").html(data.ACTUAL_STOP_USE_DATE);
		$("#fv_PLAN_RESUME_DATE").html(data.PLAN_RESUME_DATE);
		$("#fv_DUE_DATE").html(data.DUE_DATE);
		$("#fv_TS_NO").html(data.TS_NO);
		$("#fv_TS_ALG_FLAG").html(getPcodeNameByValue(fvPcode.codeSortJson["A_14001"], data.TS_ALG_FLAG));
		$("#fv_CHG_REMARK").html(getPcodeNameByValue(fvPcode.codeSortJson["A_11007"], data.CHG_REMARK));
		$("#fv_MS_FLAG").html(getPcodeNameByValue(fvPcode.codeSortJson["A_16059"], data.MS_FLAG));
		$("#fv_PROTECT_MODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_16060"], data.PROTECT_MODE));
		$("#fv_PR_CODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_18006"], data.PR_CODE));
		$("#fv_FRSTSIDE_VOLT_CODE").html(getPcodeNameByValue(pcode_10005, data.FRSTSIDE_VOLT_CODE));
		$("#fv_SNDSIDE_VOLT_CODE").html(getPcodeNameByValue(pcode_10005, data.SNDSIDE_VOLT_CODE));
		$("#fv_MODEL_NO").html(getPcodeNameByValue(fvPcode.codeSortJson["A_16029"], data.MODEL_NO));
		$("#fv_K_VALUE").html(data.K_VALUE);
		$("#fv_FACTORY_NAME").html(data.FACTORY_NAME);
		$("#fv_ORG_NO").html(data.ORG_NO);
		$("#fv_ORG_NAME").html(data.ORG_NAME);		
		$("#fv_MADE_NO").html(data.MADE_NO);
		$("#fv_WIRE_GROUP_CODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_16010"], data.WIRE_GROUP_CODE));				
		$("#fv_COOL_MODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_16013"], data.COOL_MODE));
		$("#fv_RV_HV").html(getPcodeNameByValue(pcode_10001, data.RV_HV));
		$("#fv_RC_HV").html(getPcodeNameByValue(pcode_16049, data.RC_HV));
		$("#fv_RV_MV").html(getPcodeNameByValue(pcode_10001, data.RV_MV));
		$("#fv_RC_MV").html(getPcodeNameByValue(pcode_16049, data.RC_MV));
		$("#fv_RV_LV").html(getPcodeNameByValue(pcode_10001, data.RV_LV));
		$("#fv_RC_LV").html(getPcodeNameByValue(pcode_16049, data.RC_LV));
		$("#fv_SC_RESI").html(data.SC_RESI);
		$("#fv_K_CURRENT").html(data.K_CURRENT);
		$("#fv_TEST_DATE").html(data.TEST_DATE);
		$("#fv_TEST_CYCLE").html(data.TEST_CYCLE);
		$("#fv_GROUND_FLAG").html(getPcodeNameByValue(fvPcode.codeSortJson["A_30022"], data.GROUND_FLAG));
		$("#fv_MAIN_WIRING_MODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_16071"], data.MAIN_WIRING_MODE));
		$("#fv_OIL_NO").html(data.OIL_NO);
		$("#fv_SUBJOINT_GRADE").html(data.SUBJOINT_GRADE);
		$("#fv_SUBJOINT_LOC").html(data.SUBJOINT_LOC);
		$("#fv_GROUND_RESI").html(data.GROUND_RESI);
		$("#fv_RP_TL_VALUE").html(data.RP_TL_VALUE);
		$("#fv_AP_TL_VALUE").html(data.AP_TL_VALUE);
	}catch(err)
	{
	   	fvPubUI.fvLoadingClose();
	}
	
	fvPubUI.fvLoadingClose();
}

/**
 * 获取pcode列表中的特定项
 */
function getPcodeNameByValue(pCodeList, value)
{
	for(var i=0;i<pCodeList.length;i++)
    {
    	if(pCodeList[i].value == value)
    	{
    		return pCodeList[i].name;
    	}
    }  
}

//回退按钮
function ydjc_loginuser_bl_back()
{
    changepage("../../BasicInfoVerify/Checkequipmentfile/Chektrahmotor/html/fv_sdsb.html");
}

