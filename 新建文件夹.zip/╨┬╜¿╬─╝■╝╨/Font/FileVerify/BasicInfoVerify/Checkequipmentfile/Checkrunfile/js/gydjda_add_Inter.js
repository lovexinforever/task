<script type="text/javascript">

/**
 * 
 * 调用接口
 *
 */
 
 var gydjdaAInter={
 	
 	/** 
 	 * 请求码
 	 * */
    REQ_CODE : {
        insertGydjdaFun:   {modNo: "2034", funcNo:	"030328"}  //设备档案-新增高压电机档案
    },
    
	/**
	 * 新增新高压电机档案
	 *
	 * @param {}  APP_NO :工单
	 * @param {} CONS_ID :用户ID
	 */
	insertGydjdaInfo:function(APP_NO,CONS_ID){
		var code ;   
		var pkg ;
		
 		//组装OBJ，调用修改高压电机档案用
		var objA={};
		
		objA.CONS_ID = CONS_ID;
		objA.APP_NO =  APP_NO;
		objA.SP_ID = $("#GYDJ_SP_NAME").attr("name");
		objA.TYPE_CODE = $("#GYDJ_TYPE_CODE").attr("name");
		objA.EQUIP_NAME = $("#GYDJ_EQUIP_NAME").val();
		objA.FACTORY = sessionStorage.FACTORYID;//$("#GYDJ_FACTORY").attr("name");
		objA.FACTORY_NAME = sessionStorage.FACNAME;//$("#GYDJ_FACTORY").val();
		objA.MADE_DATE = $("#GYDJ_MADE_DATE").val();
		objA.INST_DATE =   $("#GYDJ_INST_DATE").val();
		objA.TEST_CYCLE =   $("#GYDJ_TEST_CYCLE").val();
		objA.TEST_DATE =    $("#GYDJ_TEST_DATE").val();
		objA.RV_CODE =   $("#GYDJ_RV_CODE").attr("name");
		objA.RC_CODE =   $("#GYDJ_RC_CODE").attr("name");
		objA.RUN_STATUS_CODE = $("#GYDJ_RUN_STATUS_CODE").attr("name");
		objA.MEMO =   $("#GYDJ_MEMO").val();
		objA.MODEL_NO =    $("#GYDJ_MODEL_NO").val();
		objA.MADE_NO =   $("#GYDJ_MADE_NO").val();
		objA.CAP =   $("#GYDJ_CAP").val();
		objA.PROTECT_DEV = $("#GYDJ_PROTECT_DEV").val();
		objA.START_MODE = $("#GYDJ_START_MODE").val();
		
		console.log("调用新增高压电机档案接口传入参数:" +objA);
		
		code = gydjdaAInter.REQ_CODE.insertGydjdaFun;   
		pkg = gydjdnAddUntil.get_fv_pkg_data(code, objA);
		
		send_data(code.funcNo, code.modNo, pkg, gydjdaAInter.gydjdaASuccess, gydjdaAInter.gydjdaAFail);	
	},
	
	/**
	 * 新增高压电机档案用成功
	 * @param {} data 接口返回数据集合
	 */
	gydjdaASuccess:function(data){
		console.log("新增高压电机档案用成功接口返回数据:" + data);
		data = JSON.parse(data);
		
		var FLAG =data.PKG.PKG.FLAG;
		if(FLAG=='1'){
				//将接口返回的EQUIP_ID放入SESSION中
		        sessionStorage.A_EQUIP_ID = data.PKG.PKG.EQUIP_ID;
		        //将接口返回的MOTER_ID放入SESSION中
		 		sessionStorage.A_MOTER_ID = data.PKG.PKG.MOTER_ID;
		
//			    alert(data.PKG.PKG.ERR_MSG+"！");
				//调用插入本地数据库方法
				gydjdaABData.addGydjdnInfoBData(sessionStorage.A_CONS_ID,sessionStorage.A_APP_NO);
		}else{
			    fvPubUI.fvLoadingClose();
			    fvPubUI.fvMsgShow(data.PKG.PKG.ERR_MSG+"！");
		}
	},
	
	/**
	 * 新增高压电机档案接口失败
	 */
	gydjdaAFail:function(){
		alert("修改高压电机档案接口失败,请重试！");
	}
	
	
 };
 </script>