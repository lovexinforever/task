$("#getparentID_ChargerZL").html("负压开关");
init();
queryChargerInfo();
/**
 * 初始化标题和点击事件
 */
function init() {
	// 点击修改负压开关信息
	$("#fvEditCharger")
			.click(
					function() {
					
					//	$("#pop_deviceList").show();
						changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/fv_fykg_edit.html");
				
					});

	// 点击新增负压开关
	$("#fvAddCharger")
			.click(
					function() {
						// deleteCharger();
						changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/fv_fykg_addd.html");
						//fvSmrz.getFactoryData();
					});
	// 点击删除负压开关
	$("#fvDeleteCharger").click(function() {
		deleteCharger();
		// changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/fv_fykg_add.html");
	});


}
/**
 * 查询负压开关信息集合
 */
function queryChargerInfo() {
	fvPubUI.fvLoading();
	// 使用工单编号与用户标识查询用户基本信息
	/*var sql = "SELECT * FROM YJ_C_EQUIP_RUN " + "WHERE APP_NO="
			+ sessionStorage.fvAppNo + " AND EQUIP_ID="
			+ sessionStorage.fvEquipId;*/
	/*var sql = "SELECT * FROM YJ_C_EQUIP_RUN A LEFT JOIN YJ_C_SWITCH B ON A.[APP_NO] = B.[APP_NO] AND A.[EQUIP_ID] = B.[EQUIP_ID]"
		+"	WHERE A.APP_NO="+sessionStorage.fvAppNo + " AND EQUIP_ID="+sessionStorage.fvEquipId;	
	db_execut_oneSQL("dahc.db", sql[0], [], queryChargerSuccess,
			queryChargerFail);*/
	/**
	 * 简单查询
	 * @param {} tableName 表名 （C_CONS_DY低压用户基础表  C_CONTACT联系人 C_CUST_AGREEMENT合同 C_CERT证件）
	 * @param {} KeyArr 条件Key  例子 ["APP_NO","CONS_NO"]
	 * @param {} whereArr 		例子 ["123","546"]
	 */
	var ketArr = ["APP_NO","EQUIP_ID"];
	var whereArr = [sessionStorage.fvAppNo,sessionStorage.equip_id_my];
	
	//fvSqlModel.queryInfo("YJ_C_SWITCH",ketArr,whereArr,queryChargerSuccess,queryChargerFail);
	var sql = "SELECT * FROM YJ_C_EQUIP_RUN A LEFT JOIN YJ_C_SWITCH B ON A.[APP_NO] = B.[APP_NO] AND A.[EQUIP_ID] = B.[EQUIP_ID]"
	+"	WHERE A.APP_NO="+sessionStorage.fvAppNo + " AND B.EQUIP_ID="+sessionStorage.equip_id_my;	
	db_execut_oneSQL("dahc.db", sql, [], queryChargerSuccess,
		queryChargerFail);
}

/**
 * 查询负压开关成功
 */
function queryChargerSuccess(tx, res) {
	fvPubUI.fvLoadingClose();
	var len = res.rows.length;
	if (len > 0) {
		pointSessionData = res.rows;
		fillChargerUI(res.rows);
	} else {
		fvPubUI.fvMsgShow("未查询到负压开关数据");
	}
}
/**
 * 查询负压开关失败
 */
function queryChargerFail(tx, res) {
	fvPubUI.fvLoadingClose();
	fvPubUI.fvMsgShow("未查询到负压开关数据");
}
var ydjc_loginuser_bl_back = function() {
	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
}
//页面数据初始化
function fillChargerUI()
{
	var data = pointSessionData;
	
    // 设备类型
    var equip_type = (data.TYPE_CODE == "21") ? "负荷开关" : "负荷开关";
    $("#fv_TYPE_CODE").html(equip_type);
    
    // 电压
    var pcode_10005 = fvPcode.codeSortJson["A_10005"];
    // 电流
    var pcode_16049 = fvPcode.codeSortJson["A_16049"];
    
    $("#fv_EQUIP_NAME").html(data.EQUIP_NAME);
    $("#fv_FACTORY").html(data.FACTORY_NAME);
    $("#fv_MADE_DATE").html(data.MADE_DATE);
    $("#fv_INST_DATE").html(data.INST_DATE);
    $("#fv_TEST_CYCLE").html(data.TEST_CYCLE);
    $("#fv_TEST_DATE").html(data.TEST_DATE);
    
    $("#fv_RV_CODE").html(getPcodeNameByValue(pcode_10005, data.RV_CODE));
    $("#fv_RC_CODE").html(getPcodeNameByValue(pcode_16049, data.RC_CODE));
    $("#fv_RUN_STATUS_CODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_23007"], data.RUN_STATUS_CODE));
    
    $("#fv_MEMO").html(data.MEMO);    
    $("#fv_MADE_NO").html(data.MADE_NO);
    $("#fv_MAX_OUT_VOLT").html(getPcodeNameByValue(pcode_10005, data.MAX_OUT_VOLT));
    $("#fv_R_MAX_CC_CODE").html(getPcodeNameByValue(pcode_16049, data.R_MAX_CC_CODE));
    $("#fv_MAX_POWER").html(data.MAX_POWER);
    $("#fv_PROTECTION_LEVEL").html(protect_level);
    $("#fv_COMM_MODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_19043"], data.COMM_MODE));
    $("#fv_CHARGE_MODE").html(data.CHARGE_MODE);
    $("#fv_MODEL_CODE").html(data.MODEL_CODE);
    $("#fv_FREQ_CODE").html(data.FREQ_CODE);
    $("#fv_CURRENT_PRE_LEVEL").html(data.CURRENT_PRE_LEVEL);
    $("#fv_VOLT_PRE_LEVEL").html(data.VOLT_PRE_LEVEL);
    $("#fv_HARMONIC_RATIO").html(data.HARMONIC_RATIO);
    $("#fv_ABERRATION_RATIO").html(data.ABERRATION_RATIO);
    $("#fv_EFFICIENCY").html(data.EFFICIENCY);
    $("#fv_PF").html(data.PF);
    
    // 查询受电点
	var sql = "SELECT SP_NAME FROM C_SP WHERE SP_ID=" + data.SP_ID;
	db_execut_oneSQL("dahc.db", sql, [], function(tx, res){
		
		var len=res.rows.length;
	    if(len > 0)
	    {
    		$("#fv_SP_ID").html(res.rows.item(0).SP_NAME);
    	}		
	},null);
}
