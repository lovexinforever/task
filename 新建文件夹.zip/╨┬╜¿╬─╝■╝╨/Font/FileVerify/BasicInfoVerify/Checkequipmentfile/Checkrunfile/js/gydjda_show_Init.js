<script type="text/javascript">

/**
 * 高压电机档案JS
 * 
 * @type
 */	

// 标题
$("#ydjc_loginuser_nav_bl").html("高压电机详细信息");

/**
 * 返回
 */
var ydjc_loginuser_bl_back = function (){
//	window.location.replace("mainContent.html");
		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
};

/**
 * 返回
 */
var ydjc_loginuser_bl_back = function (){
//	window.location.replace("mainContent.html");
		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
};

// 初始化头部信息
var cons_info = JSON.parse(sessionStorage.fvConsInfo);
$("#cons_no_sbdn_yxsb_zk01").html(cons_info.cons_no);
$("#header_info_yxsbzk01").html(getHeaderInfo(cons_info.cons_sort_code_str, cons_info.rrio_code_str, cons_info.elec_type_code_str));


/*
 * 初始化 @type
 */
var gydjdaVinit={
      
      EQUIP_ID :sessionStorage.equip_id_my,// 高压电机设备ID，传入
      APP_NO:sessionStorage.fvAppNo,// 传入
      CONS_ID :JSON.parse(sessionStorage.fvConsInfo).cons_id,// //传入
      
	// 初始化按钮点击事件
	btnInit:function(EQUIP_ID,APP_NO){
		// 返回按钮
		$("#gyShowBack").click(function(){
			changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
		});
		//头部点击触发事件
        $("#gydjda_show_head").click(function(){
         		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
        });
		
		// 修改按钮
		$("#editBtn").click(function(){
		 	// 跳转到修改页面
		 	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/fv_gydjda_edit.html");
				 	
		});
		// 删除按钮
		$("#deleteBtn").click(function(EQUIP_ID,APP_NO){
		 	
		 	$("#delete_dailog").show();
		 	
		});
		
	},
	
	// 根据EQUIP_ID、APP_NO调用接口查询【高压电机】信息
	seachGydjInfo:function(EQUIP_ID,APP_NO){
        fvPubUI.fvLoading();
		if(EQUIP_ID==""||APP_NO==""){
			alert("缺少查询条件,请确保设备ID和工单都有值！");
			return;
		}
		gydjdnBData.gydjdnInfoBData(EQUIP_ID,APP_NO);
	},
	
	// 执行YJ_C_EQUIP_RUN和YJ_C_MOTER信息操作
	deleteGydjdaInfo:function(){
		gydjdnBData.deleteGydjdnInfoBData();
	}
	
};
gydjdaVinit.btnInit(gydjdaVinit.EQUIP_ID,gydjdaVinit.APP_NO);
gydjdaVinit.seachGydjInfo(gydjdaVinit.EQUIP_ID,gydjdaVinit.APP_NO);
gydjdaVinit.delete_data_enter();
gydjdaVinit.delete_data_cancle();

// 删除确定按钮
function delete_data_enter(){
	    $("#delete_dailog").hide();
	   	// 删除YJ_C_EQUIP_RUN和YJ_C_MOTER信息
	  	fvPubUI.fvLoading();
		gydjdaVinit.deleteGydjdaInfo(gydjdaVinit.EQUIP_ID,gydjdaVinit.APP_NO);
 }
	 	
// 删除取消按钮
function delete_data_cancle(){
	    $("#delete_dailog").hide();
 }
 
 </script>