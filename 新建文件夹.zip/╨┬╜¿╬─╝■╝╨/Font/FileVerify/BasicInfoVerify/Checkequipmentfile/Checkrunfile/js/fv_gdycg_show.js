$("#ydjc_loginuser_nav_bl").html("高低压成柜");

init();
queryChargerInfo();
/**
 * 初始化标题和点击事件
 */
function init() {
	// 点击修改负压开关信息
	$("#fvEditCharger")
			.click(
					function() {
						changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/fv_gdycg_edit.html");
					});

	// 点击新增负压开关
	$("#fvAddCharger")
			.click(
					function() {
						// deleteCharger();
						changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/fv_gdycg_add.html");
					});

	// 点击删除负压开关
	$("#fvDeleteCharger").click(function() {
		deleteCharger();
		// changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/fv_fykg_add.html");
	});
}

/**
 * 查询高低压成柜信息集合
 */
function queryChargerInfo() {
	fvPubUI.fvLoading();
	// 使用工单编号与用户标识查询用户基本信息
	/*
	 * var sql = "SELECT * FROM YJ_C_EQUIP_RUN " + "WHERE APP_NO=" +
	 * sessionStorage.fvAppNo + " AND EQUIP_ID=" + sessionStorage.fvEquipId;
	 */
	/*
	 * var sql = "SELECT * FROM YJ_C_EQUIP_RUN A LEFT JOIN YJ_C_SWITCH B ON
	 * A.[APP_NO] = B.[APP_NO] AND A.[EQUIP_ID] = B.[EQUIP_ID]" +" WHERE
	 * A.APP_NO="+sessionStorage.fvAppNo + " AND
	 * EQUIP_ID="+sessionStorage.fvEquipId; db_execut_oneSQL("dahc.db", sql[0],
	 * [], queryChargerSuccess, queryChargerFail);
	 */
	/**
	 * 简单查询
	 * 
	 * @param {}
	 *            tableName 表名 （C_CONS_DY低压用户基础表 C_CONTACT联系人 C_CUST_AGREEMENT合同
	 *            C_CERT证件）
	 * @param {}
	 *            KeyArr 条件Key 例子 ["APP_NO","CONS_NO"]
	 * @param {}
	 *            whereArr 例子 ["123","546"]
	 */
	var ketArr = [ "APP_NO", "EQUIP_ID" ];
	var whereArr = [ sessionStorage.fvAppNo, sessionStorage.equip_id_my ];

	// fvSqlModel.queryInfo("YJ_C_HDVCT",ketArr,whereArr,queryChargerSuccess,queryChargerFail);

	var sql = "SELECT * FROM YJ_C_EQUIP_RUN A LEFT JOIN YJ_C_HDVCT B ON A.[APP_NO] = B.[APP_NO] AND A.[EQUIP_ID] = B.[EQUIP_ID]"
			+ "	WHERE A.APP_NO="
			+ sessionStorage.fvAppNo
			+ " AND B.EQUIP_ID="
			+ sessionStorage.equip_id_my;
	db_execut_oneSQL("dahc.db", sql, [], queryChargerSuccess, queryChargerFail);
}

/**
 * 查询高低压成柜成功
 */
function queryChargerSuccess(tx, res) {
	fvPubUI.fvLoadingClose();

	var len = res.rows.length;
	if (len > 0) {
		pointSessionData = res.rows;
		fillChargerUI(res.rows);
	} else {
		fvPubUI.fvMsgShow("未查询到高压成套(柜)数据");
	}
}
/**
 * 查询高低压成柜失败
 */
function queryChargerFail(tx, res) {
	fvPubUI.fvLoadingClose();
	fvPubUI.fvMsgShow("未查询到高压成套(柜)数据");
}
// 页面数据初始化
function fillChargerUI(data) {

	$("#fv_APP_NO").html(data.APP_NO);
	$("#fv_EQUIP_ID").html(data.EQUIP_NAME);
	$("#fv_SP_ID").html(data.SP_ID);
	$("#fv_HDVCT_ID").html(data.HDVCT_ID);
	$("#fv_TYPE_CODE").html(data.TYPE_CODE);
	$("#fv_EQUIP_NAME").html(data.EQUIP_NAME);
	$("#fv_FACTORY").html(data.FACTORY);
	$("#fv_FACTORY_NAME").html(data.FACTORY_NAME);
	$("#fv_MADE_DATE").html(data.MADE_DATE);
	$("#fv_INST_DATE").html(data.INST_DATE);
	$("#fv_TEST_CYCLE").html(data.TEST_CYCLE);
	$("#fv_TEST_DATE").html(data.TEST_DATE);

	$("#fv_RV_CODE").html(data.RV_CODE);
	$("#fv_RC_CODE").html(data.RC_CODE);
	$("#fv_RUN_STATUS_CODE").html(data.RUN_STATUS_CODE);
	$("#fv_RUN_DATE").html(data.RUN_DATE);
	$("#fv_MODEL_NO").html(data.MODEL_NO);
}

/**
 * 删除高低压成套柜
 */
function deleteCharger() {
	// 删除数据库中运行设备信息表的记录
	var sql = "DELETE from YJ_C_EQUIP_RUN WHERE APP_NO="
			+ sessionStorage.fvAppNo + " AND EQUIP_ID="
			+ sessionStorage.fvEquipId;
	db_execut_oneSQL(null, sql, [], null, null);
	// 删除数据库中直流高低压成套柜表的记录
	sql = "DELETE from YJ_C_HDVCT WHERE APP_NO=" + sessionStorage.fvAppNo
			+ " AND EQUIP_ID=" + sessionStorage.fvEquipId;
	db_execut_oneSQL(null, sql, [], null, null);
	// 将删除的记录标示发给服务器
	sendDeleteToServer();
}

/**
 * 将删除的记录标示发给服务器
 */
function sendDeleteToServer() {
	var delObj = {
		"EQUIP_ID" : sessionStorage.fvEquipId,
		"APP_NO" : sessionStorage.fvAppNo,
		"CONS_ID" : sessionStorage.cons_id
	};
	// 1.发送实名制认证基本信息请求到服务器
	var pkg = '{"MOD":"2034","FUN":"03030036","ORG_NO":"'
			+ sessionStorage.ORG_NO
			+ '","SYS_USER_NAME":"010062","TERM_NUM":"352204061401792","PKG":'
			+ delObj + '}';
	send_data("03030036", "2034", pkg, sendDeleteSuccess, sendDeleteFail);
}
/**
 * 删除记录回调-成功
 */
function sendDeleteSuccess(message) {
	try {
		fvPubUI.fvLoadingClose();// 关闭加载效果框
		var msg_enercb = JSON.parse(message);
		if (msg_enercb.RET == "00") {
			var msg_pkg = msg_enercb.PKG.PKG;
			var fun = msg_enercb.FUN;
			if (msg_pkg.SUCCESS_FLAG == "1") {
				fvPubUI.fvMsgShow("数据删除成功");
				// /TODO 待改为正确的返回
				changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
			} else {
				fvPubUI.fvMsgShow("数据删除失败");
			}
		} else {
			fvPubUI.fvMsgShow("数据删除失败");
		}
	} catch (e) {
		fvPubUI.fvMsgShow("数据删除失败!返回数据异常");
	}
}
/**
 * 删除记录回调-失败
 */
function sendDeleteFail(message) {
	fvPubUI.fvLoadingClose();// 关闭加载效果框

	// 操作失败
	fvPubUI.fvMsgShow("数据删除失败");
}

/**
 * 返回
 */
var ydjc_loginuser_bl_back = function() {
	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
}