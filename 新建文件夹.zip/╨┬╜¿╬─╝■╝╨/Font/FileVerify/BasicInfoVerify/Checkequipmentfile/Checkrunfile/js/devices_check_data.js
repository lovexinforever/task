<script type="text/javascript">
/**
 * 
 * @param sql  查询语句
 * @param value  查询条件
 * @param sucessCB
 * @param errorCB
 * @return
 */
function selectInfo(sql,value,sucessCB,errorCB){
	var ydjc_db = window.sqlitePlugin.openDatabase("dahc.db", "1.0", "dahc.db", 10*1024*1024);
	ydjc_db.transaction(queryDB);

	function queryDB(tx){
		 tx.executeSql(sql,value,sucessCB,errorCB);
	}
	
}

</script>



	
	
	