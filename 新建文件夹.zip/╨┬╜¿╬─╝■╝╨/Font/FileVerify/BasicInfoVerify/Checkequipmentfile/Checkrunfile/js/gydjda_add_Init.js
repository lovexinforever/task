<script type="text/javascript">

/**
 * 高压电机档案逻辑JS
 * @type 
 */	


/**
 * 返回
 */
var ydjc_loginuser_bl_back = function (){
//	window.location.replace("mainContent.html");
	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
};

// 初始化头部信息
$("#ydjc_loginuser_nav_bl").html("高压电机新增");
var cons_info = JSON.parse(sessionStorage.fvConsInfo);
$("#cons_no_sbdn_yxsb_zk01").html(cons_info.cons_no);
$("#header_info_yxsbzk01").html(getHeaderInfo(cons_info.cons_sort_code_str, cons_info.rrio_code_str, cons_info.elec_type_code_str));

/**
 * 初始化
 * @type 
 */
var gydjdaAVinit={
	  APP_NO:sessionStorage.fvAppNo,//传入
      CONS_ID :JSON.parse(sessionStorage.fvConsInfo).cons_id,////传入
   
	//初始化按钮点击事件
	btnInit:function(){
		//临时放入session
         sessionStorage.A_APP_NO = sessionStorage.fvAppNo,
         sessionStorage.A_CONS_ID = JSON.parse(sessionStorage.fvConsInfo).cons_id,
         
         //头部点击触发事件
         $("#gydjda_add_head").click(function(){
         		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
         });
		 //保存按钮
		 $("#saveBtn").click(function(){
		 
			 //验证输入非空等
			 if(gydjdnAddUntil.checkDetail()){
			 	//调用接口后，保存本地
				 fvPubUI.fvLoading();
				 gydjdaAInter.insertGydjdaInfo(gydjdaAVinit.APP_NO,gydjdaAVinit.CONS_ID);
			 }
		 	
		 });
		 //出厂日期
		 $("#GYDJ_MADE_DATE").click( function(){ 
		 	fvPubUI.getDate("GYDJ_MADE_DATE");
		 });
		 
		 //安装日期
		$("#GYDJ_INST_DATE").click(function(){
			 fvPubUI.getDate("GYDJ_INST_DATE");
		});
		//监测日期
		$("#GYDJ_MONITOR_DATE").click(function(){
		    fvPubUI.getDate("GYDJ_MONITOR_DATE");
		});
		//试验日期
		$("#GYDJ_TEST_DATE").click(function(){
		    fvPubUI.getDate("GYDJ_TEST_DATE");
		});
		//点击制造厂
		$("#GYDJ_FACTORY").click(function(){
			fvSmrz.getFactoryData(gydjdaAVinit.findFactory);
		});
	
	},
	
	//根据CONS_ID、APP_NO调用接口查询【高压电机】信息
	seachGydjInfo:function(){
		if(CONS_ID==""||APP_NO==""){
		    fvPubUI.fvMsgShow("缺少查询条件,请确保设备ID和工单都有值！");
			return;
		}
		//先调用插入接口，再本地插入
		fvPubUI.fvLoading();
		gydjdaAInter.insertGydjdaInfo(CONS_ID,APP_NO);
	} ,
	
	//生产厂赋值
	findFactory:function(obj){
		$("#GYDJ_FACTORY").html(obj.FACNAME);
		$("#GYDJ_FACTORY").attr("NAME",obj.FACTORY_ID);
		sessionStorage.FACTORYID=obj.FACTORY_ID;
		sessionStorage.FACNAME=obj.FACNAME;
	}
};

gydjdaAVinit.btnInit();
 
 </script>