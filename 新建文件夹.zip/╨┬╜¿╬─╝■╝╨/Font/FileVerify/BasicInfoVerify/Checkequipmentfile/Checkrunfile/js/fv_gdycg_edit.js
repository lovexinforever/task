$("#ydjc_loginuser_nav_bl").html("高低压成柜编辑");

// 标示是直流充电桩（true）还是交流充电桩（false）
var isChargerZL = true;

// 获取缓存中的充电桩数据
var chargerData = sessionStorage.fv_gdycg_show;

//获得移动终端编号
var fvTid="";
getTid(function(e){fvTid =e;},null);

/**
 * 调用
 */
init();

/********************************************初始化***********************************************/
/**
 * 初始化标题和点击事件
 */
function init() 
{	
	// 点击保存修改数据
	$("#fvChargerSave").click(function()
	{
		saveData();
	});
	
	$("#fv_cdz_back").click(function() {
		//	alert("保存");
			
			changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/fv_fykg_show.html");
			
		});
	
	$("#fv_cons_no").html(fvConsInfo.cons_no);
	$("#fv_cons_info").html(getHeaderInfo(fvConsInfo.cons_sort_code_str, fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str));

	
	
	fillChargerUI();
}


/********************************************填充UI***********************************************/

//页面数据初始化
function fillChargerUI()
{
	fvPubUI.fvLoading();
	
	// 获取充电桩信息
	var data = chargerData;

	$("#fv_APP_NO").html(data.APP_NO);
	$("#fv_EQUIP_ID").html(data.EQUIP_NAME);
	$("#fv_SP_ID").html(data.SP_ID);
	$("#fv_HDVCT_ID").html(data.HDVCT_ID);
	$("#fv_TYPE_CODE").html(data.TYPE_CODE);
	$("#fv_EQUIP_NAME").html(data.EQUIP_NAME);
	$("#fv_FACTORY").html(data.FACTORY);
	$("#fv_FACTORY_NAME").html(data.FACTORY_NAME);
	$("#fv_MADE_DATE").html(data.MADE_DATE);
	$("#fv_INST_DATE").html(data.INST_DATE);
	$("#fv_TEST_CYCLE").html(data.TEST_CYCLE);
	$("#fv_TEST_DATE").html(data.TEST_DATE);

	$("#fv_RV_CODE").html(data.RV_CODE);
	$("#fv_RC_CODE").html(data.RC_CODE);
	$("#fv_RUN_STATUS_CODE").html(data.RUN_STATUS_CODE);
	$("#fv_RUN_DATE").html(data.RUN_DATE);
	$("#fv_MODEL_NO").html(data.MODEL_NO);
    
    
    fvPubUI.fvLoadingClose();//关闭加载效果框
}

/********************************************保存修改信息***********************************************/
/**
 * 保存修改的数据
 */
function saveData()
{
	fvPubUI.fvLoading();
	//更新运行设备信息表
	updateEquipTable();
	//更新充电桩表
	updateChargerTable();
}

/**
 * 发送修改信息到服务端回调-成功
 */
function sendDeleteSuccess(message)
{	
	try
	{
        fvPubUI.fvLoadingClose();//关闭加载效果框
        var msg_enercb = JSON.parse(message);
        if(msg_enercb.RET=="00")
        {
            var msg_pkg=msg_enercb.PKG.PKG;
            var fun=msg_enercb.FUN;
            if(msg_pkg.SUCCESS_FLAG=="1")
            {
            	fvPubUI.fvMsgShow("数据修改成功");
            	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/fv_gdycg_show.html");
            }else
            {
            	fvPubUI.fvMsgShow("数据修改失败");
            }
        }else
        {
            fvPubUI.fvMsgShow("数据修改失败");
        }
	}catch(e)
    {
   	 	fvPubUI.fvMsgShow("数据修改失败!返回数据异常");
    }
}
/**
 * 发送修改信息到服务端回调-失败
 */
function sendDeleteFail(message)
{	
	//关闭加载效果框
	fvPubUI.fvLoadingClose();
    	
	//操作失败
	fvPubUI.fvMsgShow("数据修改失败");
}

/**
 * 发送修改信息到服务端
 */
function sendEditToServer()
{
	var editObj=
	{
		"EQUIP_ID"			:sessionStorage.fvEquipId,
		"APP_NO"			:sessionStorage.fvAppNo,
		"CONS_ID"			:sessionStorage.cons_id,
		"SP_ID"				:chargerData.SP_ID,
		"TYPE_CODE"			:chargerData.TYPE_CODE,
		"HDVCT_ID"		:chargerData.HDVCT_ID
		"EQUIP_NAME" 		: $("#fv_EQUIP_NAME").val(),
		"TYPE_CODE" 		: $("#fv_TYPE_CODE").val(),
		"FACTORY" 			: chargerData.FACTORY,
		"MADE_DATE" 		: $("#fv_MADE_DATE").val(),
		"INST_DATE" 		: $("#fv_INST_DATE").val(),
		"TEST_CYCLE" 		: $("#fv_TEST_CYCLE").val(),
		"TEST_DATE" 		: $("#fv_TEST_DATE").val(),
		"RV_CODE" 			: $("#fv_RV_CODE").val(),
		"RC_CODE" 			: $("#fv_RC_CODE").val(),
		"RUN_STATUS_CODE" 	: $("#fv_RUN_STATUS_CODE").val(),
		"MEMO" 				: $("#fv_MEMO").val()
		"MADE_NO" 			: $("#fv_MADE_NO").val(),
		"RUN_DATE"				:$("#fv_RUN_DATE").val()
	};
	//1.发送实名制认证基本信息请求到服务器
	var pkg='{"MOD":"2034","FUN":"03030035","ORG_NO":"'+sessionStorage.ORG_NO+'","SYS_USER_NAME":'+ sessionStorage.user_name +',"TERM_NUM":'+ fvTid +',"PKG":'+ editObj +'}';
    send_data("03030035","2034",pkg,sendDeleteSuccess,sendDeleteFail);
}

/**
 * 更新充电桩表
 */
function updateChargerTable()
{
	var consKeyArr = 
	{
		if(isChargerZL == true)
		{// 直流充电桩
			"tableName" 	: "YJ_C_CHARGER_ZL",
			
			"FREQ_CODE" 	: $("#fv_FREQ_CODE").val(),
			"CURRENT_PRE_LEVEL": $("#fv_CURRENT_PRE_LEVEL").val(),
			"VOLT_PRE_LEVEL": $("#fv_VOLT_PRE_LEVEL").val(),
			"HARMONIC_RATIO": $("#fv_HARMONIC_RATIO").val(),
			"ABERRATION_RATIO": $("#fv_ABERRATION_RATIO").val(),
			"EFFICIENCY"	: $("#fv_EFFICIENCY").val(),
			"PF"			: $("#fv_PF").val(),
		}else
		{// 交流充电桩
			"tableName" 	: "YJ_C_CHARGER_JL",
		}
		
		"EQUIP_NAME" 		: $("#fv_EQUIP_NAME").val(),
		"MADE_NO" 			: $("#fv_MADE_NO").val(),
		"MAX_OUT_VOLT" 		: $("#fv_MAX_OUT_VOLT").val(),
		"R_MAX_CC_CODE" 	: $("#fv_R_MAX_CC_CODE").val(),
		"MAX_POWER" 		: $("#fv_MAX_POWER").val(),
		"PROTECTION_LEVEL" 	: $("#fv_PROTECTION_LEVEL").val(),
		"COMM_MODE" 		: $("#fv_COMM_MODE").val(),
		"CHARGE_MODE" 		: $("#fv_CHARGE_MODE").val(),
		"MODEL_CODE" 		: $("#fv_MODEL_CODE").val()
	};
	var whereArr = {"APP_NO" : sessionStorage.fvAppNo,"EQUIP_ID" : sessionStorage.fvEquipId};
	fvSqlModel.updateInfo(consKeyArr, whereArr, null,null);
}

/**
 * 更新运行设备信息表
 */
function updateEquipTable()
{
	//YJ_C_EQUIP_RUN(运行设备信息表)
	var consKeyArr = 
	{
		"tableName" 		: "YJ_C_EQUIP_RUN",
		"EQUIP_NAME" 		: $("#fv_EQUIP_NAME").val(),
		"TYPE_CODE" 		: $("#fv_TYPE_CODE").val(),
		"FACTORY_NAME" 		: $("#fv_FACTORY").val(),
		"MADE_DATE" 		: $("#fv_MADE_DATE").val(),
		"INST_DATE" 		: $("#fv_INST_DATE").val(),
		"TEST_CYCLE" 		: $("#fv_TEST_CYCLE").val(),
		"TEST_DATE" 		: $("#fv_TEST_DATE").val(),
		"RV_CODE" 			: $("#fv_RV_CODE").val(),
		"RC_CODE" 			: $("#fv_RC_CODE").val(),
		"RUN_STATUS_CODE" 	: $("#fv_RUN_STATUS_CODE").val(),
		"MEMO" 				: $("#fv_MEMO").val()
	};
	var whereArr = {"APP_NO" : sessionStorage.fvAppNo,"EQUIP_ID" : sessionStorage.fvEquipId};
	fvSqlModel.updateInfo(consKeyArr, whereArr, null,null);
}

/**
 * 返回
 */
var ydjc_loginuser_bl_back = function ()
{
 	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/fv_gdycg_show.html");
}

