$("#ydjc_loginuser_nav_bl").html("新增负荷开关");
init();
var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);
var sqlsld = "select sp_name as NAME,sp_id as VALUE from C_SP where CONS_ID="
		+ fvConsInfo.cons_id;
querySelectList({
	"id" : "fv_SP_ID",
	"sql" : sqlsld
});
var factory_obj;
var flg;
var server_back_equip_id;
var server_back_charger_id;
$("#fv_cons_no").html(fvConsInfo.cons_no);
/**
 * 初始化标题和点击事件
 */
function init() {
	
	// 点击上装
	$("#fvChargerAdd").click(function() {
		// insert();
		fvPubUI.fvLoading();
		sendEditToServer();
	});
	// 受电
	// $("#fv_SP_ID").click(function() {

	// });

	// 返回点击
	$("#fv_cdz_back")
			.click(
					function() {
						changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
					});
	// 出厂时间点击
	$("#fv_MADE_DATE").click(function() {
		fvPubUI.getDate("fv_MADE_DATE");
	});

	// 安装日期点击
	$("#fv_INST_DATE").click(function() {
		fvPubUI.getDate("fv_INST_DATE");
	});
	// 测试时间点击
	$("#fv_TEST_DATE").click(function() {
		fvPubUI.getDate("fv_TEST_DATE");
	});
	// 返回设备档案信息
	$("#fykg_goto_head")
			.click(
					function() {
						changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
					});
	// 厂家列表
	$("#fv_FACTORY").click(function() {
		// fvPubUI.getDate("fv_TEST_DATE");
		// alert("factory");
		fvSmrz.getFactoryData(getData);
		// getData();
	});
	$("#fv_TYPE_CODE").val("负荷开关");
	// 运行状态点击
	pCdoeSelectList({
		"id" : "fv_RUN_STATUS_CODE",
		"pCode" : [ {
			"A_23007" : "",
			"codeId" : 23007
		} ]
	});

	// 额定电压的点击
	pCdoeSelectList({
		"id" : "fv_RV_CODE",
		"pCode" : [ {
			"A_10005" : "",
			"codeId" : 10005
		} ]
	});

	// 额定电流的点击
	pCdoeSelectList({
		"id" : "fv_RC_CODE",
		"pCode" : [ {
			"A_16049" : "",
			"codeId" : 16049
		} ]
	});
	
	// 额定开断电流的点击
	pCdoeSelectList({
		"id" : "fv_ON_OFF_RC",
		"pCode" : [ {
			"A_16049" : "",
			"codeId" : 16049
		} ]
	});
	
	//是否负压开关点击
	pCdoeSelectList({
		"id" : "fv_CHARGE_FLAG",
		"pCode" : [ {
			"A_30022" : "",
			"codeId" : 30022
		} ]
	});
	
	//是否负联络关点击
	pCdoeSelectList({
		"id" : "fv_ISLVSWITCH",
		"pCode" : [ {
			"A_30022" : "",
			"codeId" : 30022
		} ]
	});
}
function getData(obj) {

	// alert("123");
	factory_obj = obj;
	$("#fv_FACTORY").val(factory_obj.FACNAME);
}
function insert() {
	// cons_id = 110000000086
	// appno = 300000072931
	// alert("cons_id = " + fvConsInfo.cons_id);
	// alert("APP_NO=" + sessionStorage.fvAppNo);
	var editObj = [ {
		"CONS_ID" : fvConsInfo.cons_id,
		"APP_NO" : sessionStorage.fvAppNo,
		"SP_ID" : $("#fv_SP_ID").attr("name"),
		"TYPE_CODE" : "21",
		"EQUIP_NAME" : $("#fv_EQUIP_NAME").val(),
		"FACTORY" : factory_obj.FACTORY_ID,
		"MADE_DATE" : $("#fv_MADE_DATE").val(),
		"INST_DATE" : $("#fv_INST_DATE").val(),
		"TEST_CYCLE" : $("#fv_TEST_CYCLE").val(),
		"TEST_DATE" : $("#fv_TEST_DATE").val(),
		"RV_CODE" : $("#fv_RV_CODE").attr("name"),
		"RC_CODE" : $("#fv_RC_CODE").attr("name"),
		"RUN_STATUS_CODE" : $("#fv_RUN_STATUS_CODE").attr("name"),
		"MEMO" : $("#fv_MEMO").val(),
	} ];
	var editObj2 = [ {
		"CONS_ID" : fvConsInfo.cons_id,
		"APP_NO" : sessionStorage.fvAppNo,
		"MACHINARY_MODEL" : $("#fv_MACHINARY_MODEL").val(),
		"ZDRL" : $("#fv_ZDRL").val(),
		"ON_OFF_RC" : $("#fv_ON_OFF_RC").val(),
		"CHARGE_FLAG" : $("#fv_CHARGE_FLAG").val(),
		"KGLX" : $("#fv_KGLX").val(),
		"ISLVSWITCH" : $("#fv_ISLVSWITCH").val()
	} ];
	flg = 0;
	var str2 = fvSqlModel.insertInfo("YJ_C_SWITCH", editObj2);
	var str = fvSqlModel.insertInfo("YJ_C_EQUIP_RUN", editObj);
	db_execut_oneSQL("dahc.db", str[0], [], InsertSuccess, InsertFail);
	db_execut_oneSQL("dahc.db", str2[0], [], InsertSuccess, InsertFail);
}
/**
 * 发送修改信息到服务端
 */
function sendEditToServer() {
	var typeCode = "21";
	var editObj = '"CONS_ID":"' + fvConsInfo.cons_id + '",' + '"APP_NO":"'
			+ sessionStorage.fvAppNo + '",' + '"SP_ID":"'
			+ $("#fv_SP_ID").attr("name") + '",' + '"TYPE_CODE":"21",' + '"EQUIP_NAME":"'
			+ $("#fv_EQUIP_NAME").val() + '",' + '"FACTORY":"'
			+ factory_obj.FACTORY_ID + '",' + '"FACTORY_NAME":"'
			+ $("#fv_FACTORY").val() + '",' + '"MADE_DATE":"'
			+ $("#fv_MADE_DATE").val() + '",' + '"INST_DATE":"'
			+ $("#fv_INST_DATE").val() + '",' + '"TEST_CYCLE":"'
			+ $("#fv_TEST_CYCLE").val() + '",' + '"TEST_DATE":"'
			+ $("#fv_TEST_DATE").val() + '",' + '"RV_CODE":"'
			+ $("#fv_RV_CODE").attr("name") + '",' + '"RC_CODE":"'
			+ $("#fv_RC_CODE").attr("name") + '",' + '"RUN_STATUS_CODE":"'
			+ $("#fv_RUN_STATUS_CODE").attr("name") + '",' + '"MEMO":"'
			+ $("#fv_MEMO").val() + '",' + '"MACHINARY_MODEL":"'
			+ $("#fv_MACHINARY_MODEL").val() + '",' + '"KGLX":"'
			+ $("#fv_KGLX").val() + '",' + '"ON_OFF_RC":"'
			+ $("#fv_ON_OFF_RC").attr("name") + '",' + '"ZDRL":"'
			+ $("#fv_ZDRL").val() + '",' + '"CHARGE_FLAG":"'
			+ $("#fv_CHARGE_FLAG").attr("name") + '",' + '"ISLVSWITCH":"'
			+ $("#fv_ISLVSWITCH").attr("name") + '"';

	// 1.发送实名制认证基本信息请求到服务器
	var pkg = '{"MOD":"2034","FUN":"030304","ORG_NO":"' + sessionStorage.ORG_NO
			+ '","SYS_USER_NAME":"' + sessionStorage.user_name
			+ '","TERM_NUM":"' + fvTid + '","PKG":{' + editObj + '}}';
	send_data("030304", "2034", pkg, sendSuccess, sendFail);
}
function sendSuccess(message) {
	try {
		//alert(0000);
		fvPubUI.fvLoadingClose();// 关闭加载效果框
		//alert(11111);
		var msg_enercb = JSON.parse(message);
		//alert(222);
		if (msg_enercb.RET == "00") {
			var msg_pkg = msg_enercb.PKG.PKG;
			if (msg_pkg.FLAG == "1") {
				//alert(333);
				server_back_equip_id = msg_pkg.EQUIP_ID;
				server_back_charger_id = msg_pkg.CHARGER_ID;
				//insertDB();
				//alert(777);
				insert();
			} else {
				fvPubUI.fvMsgShow(msg_pkg.ERR_MSG);
			}
		} else {
			fvPubUI.fvMsgShow("数据上装失败");
		}
	} catch (e) {
		fvPubUI.fvMsgShow("数据上装失败!返回数据异常");
	}
}

function sendFail(message) {
	// 关闭加载效果框
	fvPubUI.fvLoadingClose();

	// 操作失败
	fvPubUI.fvMsgShow("数据上装失败");
}
var successCount;
function insertDB() {
	//alert(444);
	var editObj;
	successCount = 0;

	editObj = [ {
		"APP_NO" : sessionStorage.fvAppNo,
		"EQUIP_ID" : server_back_equip_id,
		"CONS_ID" : fvConsInfo.cons_id,
		"SP_ID" : $("#fv_SP_ID").attr("name"),
		"EQUIP_NAME" : $("#fv_EQUIP_NAME").val(),
		"TYPE_CODE" : 21,
		"FACTORY" : factory_obj.FACTORY_ID,
		"FACTORY_NAME" : $("#fv_FACTORY").val(),
		"MADE_DATE" : $("#fv_MADE_DATE").val(),
		"INST_DATE" : $("#fv_INST_DATE").val(),
		"TEST_CYCLE" : $("#fv_TEST_CYCLE").val(),
		"RV_CODE" : $("#fv_RV_CODE").attr("name"),
		"RC_CODE" : $("#fv_RC_CODE").attr("name"),
		"RUN_STATUS_CODE" : $("#fv_RUN_STATUS_CODE").attr("name"),
		"MEMO" : $("#fv_MEMO").val(),
		"TEST_DATE" : $("#fv_TEST_DATE").val(),
	} ];
	startInsertDB("YJ_C_EQUIP_RUN", editObj);
}
function InsertSuccess(tx, res) {
	fvPubUI.fvLoadingClose();
	
	if(flg>0){
		fvPubUI.fvMsgShow("数据上装成功");
		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
	}else{
		flg++;
	}
	
}
function InsertFail() {
	alert("fail");
}
function startInsertDB(tableName, value) {
	//alert(555);
	/*	var str2 = fvSqlModel.insertInfo("YJ_C_SWITCH", editObj2);
		var str = fvSqlModel.insertInfo("YJ_C_EQUIP_RUN", editObj);
		db_execut_oneSQL("dahc.db", str[0], [], InsertSuccess, InsertFail);
		db_execut_oneSQL("dahc.db", str2[0], [], InsertSuccess, InsertFail);
	 * 
	 * */
	var sql = fvSqlModel.insertInfo(tableName, value);
	db_execut_oneSQL(
			"dahc.db",sql[0],[],function(tx, res) {
				//alert(454545);
				successCount++;
				if (successCount > 1) {
					fvPubUI.fvMsgShow("数据上装成功");
					changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
				} else {
					insertChargerData();
				}
			}, InsertFail);
}
function insertChargerData() {
//	alert(666);
	var editObj;
	var editObj = [ {
		"CONS_ID" : fvConsInfo.cons_id,
		"APP_NO" : sessionStorage.fvAppNo,
		"MACHINARY_MODEL" : $("#fv_MACHINARY_MODEL").val(),
		"ZDRL" : $("#fv_ZDRL").val(),
		"ON_OFF_RC" : $("#fv_ON_OFF_RC").val(),
		"CHARGE_FLAG" : $("#fv_CHARGE_FLAG").val(),
		"KGLX" : $("#fv_KGLX").val(),
		"ISLVSWITCH" : $("#fv_ISLVSWITCH").val()
	} ];

	startInsertDB("YJ_C_SWITCH", editObj);
}
function fillChargerUI(data) {
	$("#fv_APP_NO").html(data.APP_NO);
	$("#fv_CONS_ID").html(data.CONS_ID);
	$("#fv_EQUIP_ID").html(data.EQUIP_NAME);
	$("#fv_SWITCH_ID").html(data.FACTORY_NAME);
	$("#fv_SP_ID").html(data.SP_ID);
	$("#fv_TYPE_CODE").html(data.TYPE_CODE);
	$("#fv_EQUIP_NAME").html(data.EQUIP_NAME);
	$("#fv_FACTORY").html(data.FACTORY);
	$("#fv_MADE_DATE").html(data.MADE_DATE);
	$("#fv_INST_DATE").html(data.INST_DATE);
	$("#fv_TEST_CYCLE").html(data.TEST_CYCLE);
	$("#fv_TEST_DATE").html(data.TEST_DATE);

	$("#fv_RV_CODE").html(data.RV_CODE);
	$("#fv_RC_CODE").html(data.RC_CODE);
	$("#fv_RUN_STATUS_CODE").html(data.RUN_STATUS_CODE);
	$("#fv_MEMO").html(data.MEMO);
	$("#fv_MACHINARY_MODEL").html(data.PROTECTION_LEVEL);
	$("#fv_KGLX").html(data.COMM_MODE);
	$("#fv_ON_OFF_RC").html(data.CHARGE_MODE);
	$("#fv_ZDRL").html(data.MODEL_CODE);
	$("#fv_CHARGE_FLAG").html(data.FREQ_CODE);
	$("#fv_ISLVSWITCH").html(data.CURRENT_PRE_LEVEL);
}
/**
 * 返回
 */
var ydjc_loginuser_bl_back = function() {
	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
}
