$("#ydjc_loginuser_nav_bl").html("充电桩-新增");

var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);

// 标示是直流充电桩（true）还是交流充电桩（false）
var isChargerZL = true;

// 受电点记录
var elec_point_obj;
// 记录厂家
var factory_obj;

/**
 * 调用
 */
init();


/********************************************初始化***********************************************/
/**
 * 初始化标题和点击事件
 */
function init() 
{	
	$("#fv_cons_no").html(fvConsInfo.cons_no);
	$("#fv_cons_info").html(getHeaderInfo(fvConsInfo.cons_sort_code_str, fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str));
	
	if(sessionStorage.equip_type_my == "23")
	{	
		$("#ydjc_loginuser_nav_bl").html("直流充电桩-新增");
		isChargerZL = true;
	}else if(sessionStorage.equip_type_my == "24")
	{
		$("#ydjc_loginuser_nav_bl").html("交流充电桩-新增");
		isChargerZL = false;
	}
	slect_Point_Data();	
	initBuildUI();
	addItemClickListener();
}
/**
 * 添加点击监听
 */
function addItemClickListener()
{
	// 点击返回
	$("#fv_cdz_back").click(function()
	{
		ydjc_loginuser_bl_back();
	});
	// 点击返回头部
	$("#fv_cdz_back_to_head").click(function()
	{
		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
	});
	
	// 点击保存修改数据
	$("#fvChargerAdd").click(function()
	{
		if(checkEmpty()==true)
		{
			fvPubUI.fvLoading();
			sendEditToServer();
		}
	});
	
	//点击制造厂
	$("#fv_FACTORY").click(function()
	{
		fvSmrz.getFactoryData(setFactory);
	});
	
	//出厂日期
 	$("#fv_MADE_DATE").click( function()
 	{ 
 		fvPubUI.getDate("fv_MADE_DATE");
 	});
 	
 	//安装日期
 	$("#fv_INST_DATE").click( function()
 	{ 
 		fvPubUI.getDate("fv_INST_DATE");
 	});
 	
 	//试验日期
 	$("#fv_TEST_DATE").click( function()
 	{ 
 		fvPubUI.getDate("fv_TEST_DATE");
 	});	
}


/**********************************************查询受电点***************************************************/
/**
 * 查询数据库，查出受电点
 */
function slect_Point_Data()
{
    var sqlsld = "select sp_name as NAME,sp_id as VALUE from C_SP where CONS_ID=" + fvConsInfo.cons_id;
	querySelectList({"id":"fv_SP_ID","sql":sqlsld});
}

/**********************************************填充UI*************************************************/
/**
 * 初始化UI
 */
function initBuildUI()
{
	if(isChargerZL == false)	
	{
		$("#fv_TYPE_CODE").val("交流充电桩");	
	
		// 交流充电桩时部分组件不显示
		$("#div_FREQ_CODE").hide();
		$("#div_VOLT_PRE_LEVEL").hide();
		$("#div_HARMONIC_RATIO").hide();
		$("#div_ABERRATION_RATIO").hide();
		$("#div_EFFICIENCY").hide();
		$("#div_CURRENT_PRE_LEVEL").hide();
		$("#div_PF").hide();
	}else
	{
		$("#fv_TYPE_CODE").val("直流充电桩");
	}
	
	fillComboList();
}

/**
 * 设置下拉菜单
 */
function fillComboList()
{
	//运行状态点击
    pCdoeSelectList({"id":"fv_RUN_STATUS_CODE","pCode":[{"A_23007":"","codeId":23007}]});
    
    //额定电压的点击
    pCdoeSelectList({"id":"fv_RV_CODE","pCode":[{"A_10005":"","codeId":10005}]});
    
    //额定电流的点击
    pCdoeSelectList({"id":"fv_RC_CODE","pCode":[{"A_16049":"","codeId":16049}]});
    
    //输出电压的点击
    pCdoeSelectList({"id":"fv_MAX_OUT_VOLT","pCode":[{"A_10005":"","codeId":10005}]});
    
    //最大输出电流的点击
    pCdoeSelectList({"id":"fv_R_MAX_CC_CODE","pCode":[{"A_16049":"","codeId":16049}]});
    
    //通讯方式的点击
    pCdoeSelectList({"id":"fv_COMM_MODE","pCode":[{"A_19043":"","codeId":19043}]});
    
    // 防护等级
    $("#fv_PROTECTION_LEVEL").fvSelect({
	    //callback:function(obj){alert(obj.selectobj.value+"---"+obj.selectobj.name)},
	    list:[{value:1,name:"一级"},{value:2,name:"二级"},{value:3,name:"三级"}]
	});
	
	$("#fv_RUN_STATUS_CODE").attr("name","");
	$("#fv_RV_CODE").attr("name","");
	$("#fv_RC_CODE").attr("name","");
	$("#fv_MAX_OUT_VOLT").attr("name","");
	$("#fv_R_MAX_CC_CODE").attr("name","");
	$("#fv_COMM_MODE").attr("name","");
	$("#fv_PROTECTION_LEVEL").attr("name","");
	
}

/**********************************************设置制造厂家*************************************************/
function setFactory(data)
{
	/*
		{
			"FACTORY_ID" :厂商ID,
			"FACNAME" : 厂商名字
		};
	*/
	
	factory_obj = data;
	$("#fv_FACTORY").val(factory_obj.FACNAME);
}


/**********************************************插入新充电桩*************************************************/



/**
 * 发送修改信息到服务端
 */
function sendEditToServer()
{
	var editObj = '"CONS_ID":"'			+fvConsInfo.cons_id+'",' + 
				  '"APP_NO":"'			+sessionStorage.fvAppNo+'",'+
				  '"SP_ID":"'			+$("#fv_SP_ID").attr("name")+'",' + 
				  '"TYPE_CODE":"'		+sessionStorage.equip_type_my+'",'+
				  '"EQUIP_NAME":"'		+$("#fv_EQUIP_NAME").val()+'",' + 
				  '"FACTORY":"'			+factory_obj.FACTORY_ID+'",'+
				  '"FACTORY_NAME":"'	+$("#fv_FACTORY").val()+'",'+	
				  '"MADE_DATE":"'		+$("#fv_MADE_DATE").val()+'",'+
				  '"INST_DATE":"'		+$("#fv_INST_DATE").val()+'",'+
				  '"TEST_CYCLE":"'		+$("#fv_TEST_CYCLE").val()+'",'+
				  '"TEST_DATE":"'		+$("#fv_TEST_DATE").val()+'",'+
				  '"RV_CODE":"'			+$("#fv_RV_CODE").attr("name")+'",'+
				  '"RC_CODE":"'			+$("#fv_RC_CODE").attr("name")+'",'+
				  '"RUN_STATUS_CODE":"'	+$("#fv_RUN_STATUS_CODE").attr("name")+'",'+
				  '"MEMO":"'			+$("#fv_MEMO").val()+'",'+
				  '"MADE_NO":"'			+$("#fv_MADE_NO").val()+'",'+
				  '"MAX_OUT_VOLT":"'	+$("#fv_MAX_OUT_VOLT").attr("name")+'",'+
				  '"R_MAX_CC_CODE":"'	+$("#fv_R_MAX_CC_CODE").attr("name")+'",'+
				  '"MAX_POWER":"'		+$("#fv_MAX_POWER").val()+'",'+
				  '"PROTECTION_LEVEL":"'+$("#fv_PROTECTION_LEVEL").attr("name")+'",'+
				  '"COMM_MODE":"'		+$("#fv_COMM_MODE").attr("name")+'",'+
				  '"CHARGE_MODE":"'		+$("#fv_CHARGE_MODE").val()+'",'+
				  '"MODEL_CODE":"'		+$("#fv_MODEL_CODE").val() + '"';
	if(isChargerZL == true)
	{
		editObj += ',"FREQ_CODE":"'		+$("#fv_FREQ_CODE").val() +'",'+
				   '"CURRENT_PRE_LEVEL":"'+$("#fv_CURRENT_PRE_LEVEL").val() +'",'+
				   '"VOLT_PRE_LEVEL":"'	+$("#fv_VOLT_PRE_LEVEL").val() +'",'+
				   '"HARMONIC_RATIO":"'	+$("#fv_HARMONIC_RATIO").val() +'",'+
				   '"ABERRATION_RATIO":"'+$("#fv_ABERRATION_RATIO").val() +'",'+
				   '"EFFICIENCY":"'		+$("#fv_EFFICIENCY").val() +'",'+
				   '"PF":"'				+$("#fv_PF").val()+'"';
	}
	
	//1.发送实名制认证基本信息请求到服务器
	var pkg='{"MOD":"2034","FUN":"030334","ORG_NO":"'+sessionStorage.ORG_NO+'","SYS_USER_NAME":"'+ sessionStorage.user_name +'","TERM_NUM":"'+ fvTid +'","PKG":{'+ editObj +'}}';
    send_data("030334","2034",pkg,sendSuccess,sendFail);
}

// 提交服务器成功后返回的字段值
var server_back_equip_id;
var server_back_charger_id;
/**
 * 发送新增信息到服务端回调-成功
 */
function sendSuccess(message)
{	
	try
	{
        fvPubUI.fvLoadingClose();//关闭加载效果框
        var msg_enercb = JSON.parse(message);
        if(msg_enercb.RET=="00")
        {
            var msg_pkg=msg_enercb.PKG.PKG;
            if(msg_pkg.FLAG=="1")
            {
            	server_back_equip_id = msg_pkg.EQUIP_ID;
            	server_back_charger_id = msg_pkg.CHARGER_ID;
            	insertDB();
            	
            }else
            {
            	fvPubUI.fvMsgShow(msg_pkg.ERR_MSG);
            }
        }else
        {
            fvPubUI.fvMsgShow("数据上装失败");
        }
	}catch(e)
    {
   	 	fvPubUI.fvMsgShow("数据上装失败!返回数据异常");
    }
}
/**
 * 发送新增信息到服务端回调-失败
 */
function sendFail(message)
{	
	//关闭加载效果框
	fvPubUI.fvLoadingClose();
    	
	//操作失败
	fvPubUI.fvMsgShow("数据上装失败");
}

// 记录插入数据库成功次数
var successCount;
/**
 * 插入数据库
 */
function insertDB()
{
	var editObj;
	successCount = 0;
	
	editObj=
		[{
			"APP_NO"			: sessionStorage.fvAppNo,
			"EQUIP_ID"			: server_back_equip_id,
			"CONS_ID"			: fvConsInfo.cons_id,
			"SP_ID"				: $("#fv_SP_ID").attr("name"),
			"EQUIP_NAME" 		: $("#fv_EQUIP_NAME").val(),
			"TYPE_CODE" 		: sessionStorage.equip_type_my,
			"FACTORY"			: factory_obj.FACTORY_ID,
			"FACTORY_NAME" 		: $("#fv_FACTORY").val(),			
			"MADE_DATE" 		: $("#fv_MADE_DATE").val(),
			"INST_DATE" 		: $("#fv_INST_DATE").val(),
			"TEST_CYCLE" 		: $("#fv_TEST_CYCLE").val(),			
			"RV_CODE" 			: $("#fv_RV_CODE").attr("name"),
			"RC_CODE" 			: $("#fv_RC_CODE").attr("name"),
			"RUN_STATUS_CODE" 	: $("#fv_RUN_STATUS_CODE").attr("name"),			
			"MEMO" 				: $("#fv_MEMO").val(),
			"TEST_DATE" 		: $("#fv_TEST_DATE").val(),
		}];	
	startInsertDB("YJ_C_EQUIP_RUN", editObj);
}

/**
 * 向充电桩表中插入记录
 */
function insertChargerData(insertId)
{
	var editObj;
	if(isChargerZL == true)
	{
		editObj=
		[{
			"APP_NO"			: sessionStorage.fvAppNo,
			"EQUIP_ID"			: server_back_equip_id,
			"MOBILE_EQUIP_ID"	: insertId,			
			"CHARGER_ID"		: server_back_charger_id,
			"MADE_NO" 			: $("#fv_MADE_NO").val(),
			"MAX_OUT_VOLT" 		: $("#fv_MAX_OUT_VOLT").attr("name"),
			"R_MAX_CC_CODE" 	: $("#fv_R_MAX_CC_CODE").attr("name"),
			"MAX_POWER" 		: $("#fv_MAX_POWER").val(),
			"PROTECTION_LEVEL" 	: $("#fv_PROTECTION_LEVEL").attr("name"),
			"COMM_MODE" 		: $("#fv_COMM_MODE").attr("name"),
			"CHARGE_MODE" 		: $("#fv_CHARGE_MODE").val(),
			"MODEL_CODE" 		: $("#fv_MODEL_CODE").val(),
			"FREQ_CODE" 		: $("#fv_FREQ_CODE").val(),
			"CURRENT_PRE_LEVEL"	: $("#fv_CURRENT_PRE_LEVEL").val(),
			"VOLT_PRE_LEVEL"	: $("#fv_VOLT_PRE_LEVEL").val(),
			"HARMONIC_RATIO"	: $("#fv_HARMONIC_RATIO").val(),
			"ABERRATION_RATIO"	: $("#fv_ABERRATION_RATIO").val(),
			"EFFICIENCY"		: $("#fv_EFFICIENCY").val(),
			"PF"				: $("#fv_PF").val(),
			"CONS_ID"			: fvConsInfo.cons_id
		}];
		
		startInsertDB("YJ_C_CHARGER_ZL", editObj);
		
	}else
	{
		editObj=
		[{
			"APP_NO"			: sessionStorage.fvAppNo,
			"EQUIP_ID"			: server_back_equip_id,
			"MOBILE_EQUIP_ID"	: insertId,	
			"CHARGER_ID"		: server_back_charger_id,
			"MADE_NO" 			: $("#fv_MADE_NO").val(),
			"MAX_OUT_VOLT" 		: $("#fv_MAX_OUT_VOLT").attr("name"),
			"R_MAX_CC_CODE" 	: $("#fv_R_MAX_CC_CODE").attr("name"),
			"MAX_POWER" 		: $("#fv_MAX_POWER").val(),
			"PROTECTION_LEVEL" 	: $("#fv_PROTECTION_LEVEL").attr("name"),
			"COMM_MODE" 		: $("#fv_COMM_MODE").attr("name"),
			"CHARGE_MODE" 		: $("#fv_CHARGE_MODE").val(),
			"MODEL_CODE" 		: $("#fv_MODEL_CODE").val(),
			"CONS_ID"			: fvConsInfo.cons_id
		}];
		
		
		startInsertDB("YJ_C_CHARGER_JL", editObj);
	}
}

/**
 * 插入记录
 */
function startInsertDB(tableName, value)
{
	var sql = fvSqlModel.insertInfo(tableName,value);
	db_execut_oneSQL("dahc.db", sql[0], [], function(tx,res){
		successCount++;
		if(successCount>1)
		{
			fvPubUI.fvMsgShow("数据上装成功");
			changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
		}else
		{
			insertChargerData(res.insertId);
		}
	}, null);
}

/**
 * 提示输入内容是否为空
 */
function checkEmpty()
{
	 if(checkStringTrim($("#fv_SP_ID").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("受电点不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_TYPE_CODE").val()))
	 {
	 	fvPubUI.fvMsgShow("设备类型不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_EQUIP_NAME").val()))
	 {
	 	fvPubUI.fvMsgShow("设备名称不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_FACTORY").val()))
	 {
	 	fvPubUI.fvMsgShow("制造厂家不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_MADE_DATE").val()))
	 {
	 	fvPubUI.fvMsgShow("出厂日期不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_INST_DATE").val()))
	 {
	 	fvPubUI.fvMsgShow("安装日期不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_TEST_CYCLE").val()))
	 {
	 	fvPubUI.fvMsgShow("试验周期不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_TEST_DATE").val()))
	 {
	 	fvPubUI.fvMsgShow("试验日期不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_RV_CODE").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("额定电压不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_RC_CODE").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("额定电流不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_RUN_STATUS_CODE").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("运行状态不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_MAX_OUT_VOLT").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("输出电压不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_R_MAX_CC_CODE").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("最大输出电流不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_PROTECTION_LEVEL").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("防护等级不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_COMM_MODE").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("通讯方式不能为空");
	 	return false;
	 }
	 
	return true;
}

/**
 * 判断字符串是否为空
 */
function checkStringTrim(str)
{
	//var tStr = fvSqlModel.stringTrim(str);
	if(str == "" || str == undefined)
		return true;
	return false;
}

/**
 * 获取pcode列表中的特定项
 */
function getPcodeItemByValue(pCodeList, value)
{
	for(var i=0;i<pCodeList.length;i++)
    {
    	if(pCodeList[i].value == value)
    	{
    		return pCodeList[i];
    	}else if((i + 1) >= pCodeList.length)
    	{
    		var obj = {name:"", value:value}
    		return obj;
    	}
    	
    }  
}




/**
 * 返回
 */
function ydjc_loginuser_bl_back()
{
 	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
}

