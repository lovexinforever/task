<script type="text/javascript">

/**
 * 
 * 调用接口JS
 *
 */
 
 var gydjdaInter={
 	
 	/** 
 	 * 请求码
 	 * */
    REQ_CODE : {
        deleteGydjda:   {modNo: "2034", funcNo:	"030330"}  //发起删除高压电机信息流程
    },
 	
	/**
	 * 调用删除高压电机档案信息接口
	 *
	 * @param {}  EQUIP_ID  设备ID
	 * @param {} APP_NO 工单号
	 * @param {} CONS_ID 用户ID
	 */
	deleteGydjdaInfo:function(){
		var code ;   
		var pkg ;
 		var objD = {};
		objD.EQUIP_ID= sessionStorage.GY_EQUIP_ID;
		objD.APP_NO = sessionStorage.GY_APP_NO;	
		objD.CONS_ID = sessionStorage.GY_CONS_ID;
		
		console.log("调用删除高压电机档案信息接口参数:" +objD);
		
		code = gydjdaInter.REQ_CODE.deleteGydjda;   
		pkg = gydjdnShowUntil.get_fv_pkg_data(code, objD);
		
		send_data(code.funcNo, code.modNo, pkg, gydjdaInter.deleteDydjdaSuccess, gydjdaInter.deleteDydjdaFail);	
	},
	
	/**
	 * 删除高压电机档案信息成功
	 * @param {} data 接口返回数据集合
	 */
	deleteDydjdaSuccess:function(data){
		console.log("删除高压电机档案信息接口返回数据:" + data);
		data = JSON.parse(data);
		
		var FLAG =data.PKG.PKG.FLAG;
		if(FLAG=='1'){
			//删除YJ_C_EQUIP_RUN表信息
			gydjdnBData.deleteYJ_C_EQUIP_RUNInfo();
			//删除YJ_C_MOTER表信息
			gydjdnBData.deleteYJ_C_MOTERInfo();
			
		}else{
			fvPubUI.fvLoadingClose();
			fvPubUI.fvMsgShow("数据解析异常,请联系管理员！");
		}
	},
	
	/**
	 * 删除高压电机档案信息失败
	 */
	deleteDydjdaFail:function(){
			fvPubUI.fvLoadingClose();
			fvPubUI.fvMsgShow("删除高压电机档案信息失败,请重试！");
	}
	
	
 };
 </script>