<script type="text/javascript">

/**
 * 
 * 查询接口
 *
 */
 
 var gydjdaEInter={
 	
 	/** 
 	 * 请求码
 	 * */
    REQ_CODE : {
        updateGydjdaFun:   {modNo: "2034", funcNo:	"030329"}  //设备档案-修改高压电机档案
    },
    
	/**
	 * 调用高压电机档案修改接口
	 *
	 * @param {}  flow_code :382	合同新签, 384	合同续签, 385	合同补签, 386	合同终止
	 * @param {} cons_id :用户ID
	 */
	updateGydjdaInfo:function(EQUIP_ID,APP_NO){
//		alert("调用高压电机档案修改接口！");
		var code ;   
		var pkg ;
		
 		//组装OBJ，调用修改高压电机档案用
		var OBJ={};

		OBJ.EQUIP_ID = EQUIP_ID.toString();
		OBJ.APP_NO =  APP_NO.toString();
		
		OBJ.MOTER_ID =sessionStorage.GY_MOTER_ID;
		OBJ.CONS_ID =sessionStorage.GY_CONS_ID;
		OBJ.SP_ID = sessionStorage.GY_SP_ID;
		
		OBJ.TYPE_CODE = "03";//$("#GYDJ_TYPE_CODE").val();
		OBJ.EQUIP_NAME = $("#GYDJ_EQUIP_NAME").val();
		OBJ.FACTORY =$("#GYDJ_FACTORY").attr("NAME");
		OBJ.MADE_DATE =  $("#GYDJ_MADE_DATE").val();
		OBJ.INST_DATE =   $("#GYDJ_INST_DATE").val();
		OBJ.TEST_CYCLE =   $("#GYDJ_TEST_CYCLE").val();
		OBJ.TEST_DATE =    $("#GYDJ_TEST_DATE").val();
		OBJ.RV_CODE =    $("#GYDJ_RV_CODE").attr("NAME");
		OBJ.RC_CODE =  $("#GYDJ_RC_CODE").attr("NAME");
		OBJ.RUN_STATUS_CODE = $("#GYDJ_RUN_STATUS_CODE").attr("NAME");
		OBJ.MEMO =   $("#GYDJ_MEMO").val();
		OBJ.MODEL_NO =  $("#GYDJ_MODEL_NO").val();
		OBJ.MADE_NO =   $("#GYDJ_MADE_NO").val();
		OBJ.CAP =  $("#GYDJ_CAP").val();
		OBJ.PROTECT_DEV = $("#GYDJ_PROTECT_DEV").val();
		OBJ.START_MODE = $("#GYDJ_START_MODE").val();    
		
		console.log("修改高压电机档案用传入参数:" +OBJ);
		
		code = gydjdaEInter.REQ_CODE.updateGydjdaFun;   
		pkg = gydjdnEditUntil.get_fv_pkg_data(code, OBJ);
		
		send_data(code.funcNo, code.modNo, pkg, gydjdaEInter.gydjdaESuccess, gydjdaEInter.gydjdaEFail);	
	},
	
	/**
	 * 修改高压电机档案用成功
	 * @param {} data 接口返回数据集合
	 */
	gydjdaESuccess:function(data){
		console.log("修改高压电机档案用成功接口返回数据:" + data);
		data = JSON.parse(data);
		
		var FLAG =data.PKG.PKG.FLAG;
		if(FLAG=='1'){
			//接口成功后调用本地修改
			gydjdaEBData.updataGydjdnInfoBData();
	 
		}else{
			fvPubUI.fvLoadingClose();
 			fvPubUI.fvMsgShow(data.PKG.PKG.ERR_MSG+"！");
		}
	},
	
	/**
	 * 修改高压电机档案接口失败
	 */
	gydjdaEFail:function(){
		alert("修改高压电机档案接口失败,请重试！");
	}
	
	
 };
 </script>