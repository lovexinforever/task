<script type="text/javascript">

/**
 * 供用电合同逻辑JS
 * @type 
 */	

//标题
$("#ydjc_loginuser_nav_bl").html("高压电机信息修改");

/**
 * 返回
 */
var ydjc_loginuser_bl_back = function (){
//	window.location.replace("mainContent.html");
		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
};


// 初始化头部信息
var cons_info = JSON.parse(sessionStorage.fvConsInfo);
$("#cons_no_sbdn_yxsb_zk01").html(cons_info.cons_no);
$("#header_info_yxsbzk01").html(getHeaderInfo(cons_info.cons_sort_code_str, cons_info.rrio_code_str, cons_info.elec_type_code_str));


/**
 * 初始化
 * @type 
 */
var gydjdaEVinit={
	
	APP_NO :sessionStorage.GY_APP_NO,//增加属性，存储APP_NO；
	EQUIP_ID:sessionStorage.GY_EQUIP_ID,//增加属性，存储EQUIP_ID；
	CONS_ID: sessionStorage.GY_CONS_ID,//增加属性，存储CONS_ID；
	
	//初始化按钮点击事件
	btnInit:function(EQUIP_ID,APP_NO){
		 //保存按钮
		 $("#saveBtn").click(function(){
		 	
			 //验证输入非空等
			 gydjdnEditUntil.checkDetail();
			 
		 	//保存YJ_C_EQUIP_RUN和YJ_C_MOTER信息
		 	fvPubUI.fvLoading();
		 	gydjdaEVinit.saveGydjdaInfo(EQUIP_ID,APP_NO);
		 	
		 });
		 	// 返回按钮
		$("#gydjdaEditBack").click(function(){
			changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
		});
		 //出厂日期
		 $("#GYDJ_MADE_DATE").click( function(){ 
		 	fvPubUI.getDate("GYDJ_MADE_DATE");
		 });
		 
		 //安装日期
		$("#GYDJ_INST_DATE").click(function(){
		    fvPubUI.getDate("GYDJ_INST_DATE");
		});
		//监测日期
		$("#GYDJ_MONITOR_DATE").click(function(){
		    fvPubUI.getDate("GYDJ_MONITOR_DATE");
		});
		//试验日期
		$("#GYDJ_TEST_DATE").click(function(){
		    fvPubUI.getDate("GYDJ_TEST_DATE");
		});
		//头部点击触发事件
        $("#gydjda_edit_head").click(function(){
         		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
        });
        //点击制造厂
		$("#GYDJ_FACTORY").click(function(){
			fvSmrz.getFactoryData(gydjdaEVinit.findFactory);
		});
	
	},
	
	//根据EQUIP_ID、APP_NO调用接口查询【高压电机】信息
	seachGydjInfo:function(EQUIP_ID,APP_NO){
		if(EQUIP_ID==""||APP_NO==""){
			fvPubUI.fvMsgShow("缺少查询条件,请确保设备ID和工单都有值！");
			return;
		}
		
		fvPubUI.fvLoading();
		gydjdaEBData.gydjdnInfoBData(EQUIP_ID,APP_NO);
	},
	
	//调用接口后执行YJ_C_EQUIP_RUN和YJ_C_MOTER修改信息操作
	saveGydjdaInfo:function(EQUIP_ID,APP_NO){
		//调用设备档案-修改高压电机档案
		gydjdaEInter.updateGydjdaInfo(EQUIP_ID,APP_NO);
	},
	
	//生产厂赋值
	findFactory:function(obj){
		$("#GYDJ_FACTORY").html(obj.FACNAME);
		$("#GYDJ_FACTORY").attr("NAME",obj.FACTORY_ID);
		sessionStorage.FACTORYID=obj.FACTORY_ID;
		sessionStorage.FACNAME=obj.FACNAME;
	}
	
};
gydjdaEVinit.seachGydjInfo(gydjdaEVinit.EQUIP_ID,gydjdaEVinit.APP_NO);
gydjdaEVinit.btnInit(gydjdaEVinit.EQUIP_ID,gydjdaEVinit.APP_NO);
 
 </script>