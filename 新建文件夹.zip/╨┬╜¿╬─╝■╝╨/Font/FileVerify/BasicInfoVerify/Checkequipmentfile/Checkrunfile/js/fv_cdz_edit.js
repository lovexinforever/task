$("#ydjc_loginuser_nav_bl").html("直流充电桩");
var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);
// 设备id
var fvEquipId = sessionStorage.equip_id_my;

// 标示是直流充电桩（true）还是交流充电桩（false）
var isChargerZL = true;

// 获取充电桩数据
var chargerData;

// 记录厂家
var factory_obj;

/**
 * 调用
 */
init();

/********************************************初始化***********************************************/
/**
 * 初始化标题和点击事件
 */
function init() 
{	
	fvPubUI.fvLoading();
	
	$("#fv_cons_no").html(fvConsInfo.cons_no);
	$("#fv_cons_info").html(getHeaderInfo(fvConsInfo.cons_sort_code_str, fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str));
	
	
	// 判断直流还是交流
	if(sessionStorage.equip_type_my == "23")
	{	// 直流
		$("#ydjc_loginuser_nav_bl").html("直流充电桩-修改");
		isChargerZL = true;
	}else if(sessionStorage.equip_type_my == "24")
	{	// 交流
		$("#ydjc_loginuser_nav_bl").html("交流充电桩-修改");
		isChargerZL = false;
	}
	queryChargerInfo();		
	addItemClickListener();
}

/**********************************************查询受电点***************************************************/

/**
 * 添加点击监听
 */
function addItemClickListener()
{
	// 点击返回
	$("#fv_cdz_back").click(function()
	{
		ydjc_loginuser_bl_back();
	});
	// 点击返回头部
	$("#fv_cdz_back_to_head").click(function()
	{
		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
	});
	
	//点击制造厂
	$("#fv_FACTORY").click(function()
	{
		fvSmrz.getFactoryData(setFactory);
	});
	
	//出厂日期
 	$("#fv_MADE_DATE").click( function()
 	{ 
 		fvPubUI.getDate("fv_MADE_DATE");
 	});
 	
 	//安装日期
 	$("#fv_INST_DATE").click( function()
 	{ 
 		fvPubUI.getDate("fv_INST_DATE");
 	});
 	
 	//试验日期
 	$("#fv_TEST_DATE").click( function()
 	{ 
 		fvPubUI.getDate("fv_TEST_DATE");
 	});	
 	
 	//上装
 	$("#fvChargerSave").click( function()
 	{ 
 		saveData();
 	});	
}
/**********************************************设置制造厂家*************************************************/
function setFactory(data)
{
	/*
		{
			"FACTORY_ID" :厂商ID,
			"FACNAME" : 厂商名字
		};
	*/
	
	factory_obj = data;
	$("#fv_FACTORY").val(factory_obj.FACNAME);
}

/********************************************查询充电桩信息***********************************************/

/**
 * 查询充电桩信息集合
 */
function queryChargerInfo()
{
	// 使用工单编号与用户标识查询用户基本信息
	var sql;
	if(isChargerZL == true)
	{
		sql = "SELECT * FROM YJ_C_EQUIP_RUN A LEFT JOIN YJ_C_CHARGER_ZL B ON A.[MOBILE_EQUIP_ID] = B.[MOBILE_EQUIP_ID]"
			+" WHERE A.APP_NO="+sessionStorage.fvAppNo + " AND A.MOBILE_EQUIP_ID="+fvEquipId;	
	}else
	{
		sql = "SELECT * FROM YJ_C_EQUIP_RUN A LEFT JOIN YJ_C_CHARGER_JL B ON A.[MOBILE_EQUIP_ID] = B.[MOBILE_EQUIP_ID]"
			+" WHERE A.APP_NO="+sessionStorage.fvAppNo + " AND A.MOBILE_EQUIP_ID="+fvEquipId;	
	}
	db_execut_oneSQL("dahc.db", sql, [], queryChargerSuccess,queryChargerFail);
}

/**
 * 查询充电桩成功
 */
function queryChargerSuccess(tx,res)
{
	fvPubUI.fvLoadingClose();
	
	var len=res.rows.length;
    if(len > 0)
    {
        fillChargerUI(res.rows);
    }else
    {
    	fvPubUI.fvMsgShow("未查询到计量点数据");
    }
}
/**
 * 查询充电桩失败
 */
function queryChargerFail(tx,res)
{
	fvPubUI.fvLoadingClose();
	fvPubUI.fvMsgShow("未查询到计量点数据");
}


/********************************************填充UI***********************************************/

//页面数据初始化
function fillChargerUI(value)
{
	// 获取充电桩信息
	var data = value.item(0);
	
	chargerData = data;
	
	// 查询到的制造厂信息
	var tObj = new Object();
	tObj.FACTORY_ID = chargerData.FACTORY;
	tObj.FACNAME = chargerData.FACTORY_NAME;
	factory_obj = tObj;
	
    var pcode_23007;
    var pcode_23007_list = fvPcode.codeSortJson["A_23007"];
    var pcode_10005;
    var pcode_10005_list = fvPcode.codeSortJson["A_10005"];
    var pcode_16049;
    var pcode_16049_list = fvPcode.codeSortJson["A_16049"];
    var pcode_19043;
    var pcode_19043_list = fvPcode.codeSortJson["A_19043"];	
    
    // 查询受电点
	var sql = "SELECT SP_NAME FROM C_SP WHERE SP_ID=" + data.SP_ID;
	db_execut_oneSQL("dahc.db", sql, [], function(tx, res){
		
		var len=res.rows.length;
	    if(len > 0)
	    {
    		$("#fv_SP_ID").html(res.rows.item(0).SP_NAME);
    		$("#fv_SP_ID").attr("name",data.SP_ID);
    		
    		var sqlsld = "select sp_name as NAME,sp_id as VALUE from C_SP where CONS_ID=" + fvConsInfo.cons_id;
			querySelectList({"id":"fv_SP_ID","sql":sqlsld});
    	}		
	},null);
	// 设备类型
    var equip_type = (data.TYPE_CODE == "23") ? "直流充电桩" : "交流充电桩";
    $("#fv_TYPE_CODE").html(equip_type);
    
    $("#fv_EQUIP_NAME").val(data.EQUIP_NAME);
    $("#fv_FACTORY").val(data.FACTORY_NAME);
    $("#fv_MADE_DATE").val(data.MADE_DATE);
    $("#fv_INST_DATE").val(data.INST_DATE);
    $("#fv_TEST_CYCLE").val(data.TEST_CYCLE);
    $("#fv_TEST_DATE").val(data.TEST_DATE);
    
    pcode_10005 = getPcodeItemByValue(pcode_10005_list, data.RV_CODE);
    $("#fv_RV_CODE").html(pcode_10005.name);
    $("#fv_RV_CODE").attr("name",pcode_10005.value);
    
    pcode_16049 = getPcodeItemByValue(pcode_16049_list, data.RC_CODE);
    $("#fv_RC_CODE").html(pcode_16049.name);
    $("#fv_RC_CODE").attr("name",pcode_16049.value);
    
    pcode_23007 = getPcodeItemByValue(pcode_23007_list, data.RUN_STATUS_CODE);
    $("#fv_RUN_STATUS_CODE").html(pcode_23007.name); 
    $("#fv_RUN_STATUS_CODE").attr("name",pcode_23007.value);   
    
    $("#fv_MEMO").val(data.MEMO);    
    $("#fv_MADE_NO").val(data.MADE_NO);
    
   	pcode_10005 = getPcodeItemByValue(pcode_10005_list, data.MAX_OUT_VOLT);
    $("#fv_MAX_OUT_VOLT").html(pcode_10005.name);  
    $("#fv_MAX_OUT_VOLT").attr("name",pcode_10005.value);     
    
    pcode_16049 = getPcodeItemByValue(pcode_16049_list, data.R_MAX_CC_CODE);
    $("#fv_R_MAX_CC_CODE").html(pcode_16049.name);
    $("#fv_R_MAX_CC_CODE").attr("name",pcode_16049.value);     
    
    $("#fv_MAX_POWER").val(data.MAX_POWER);
    
    $("#fv_PROTECTION_LEVEL").html(checkProtectionLevel(data.PROTECTION_LEVEL));
    $("#fv_PROTECTION_LEVEL").attr("name",data.PROTECTION_LEVEL);   
    
    pcode_19043 = getPcodeItemByValue(pcode_19043_list, data.COMM_MODE);
    $("#fv_COMM_MODE").html(pcode_19043.name);
    $("#fv_COMM_MODE").attr("name",pcode_19043.value);   
    
    $("#fv_CHARGE_MODE").val(data.CHARGE_MODE);
    $("#fv_MODEL_CODE").val(data.MODEL_CODE);
    
    if(isChargerZL==false)
    {
    	$("#fv_TYPE_CODE").val("交流充电桩");	
	
		// 交流充电桩时部分组件不显示
		$("#div_FREQ_CODE").hide();
		$("#div_VOLT_PRE_LEVEL").hide();
		$("#div_HARMONIC_RATIO").hide();
		$("#div_ABERRATION_RATIO").hide();
		$("#div_EFFICIENCY").hide();
		$("#div_CURRENT_PRE_LEVEL").hide();
		$("#div_PF").hide();
    	
    	$("#ydjc_loginuser_nav_bl").html("交流充电桩");  	
    }else
    {// 直流充电桩隐藏部分项目
    
    	$("#fv_TYPE_CODE").val("直流充电桩");
    	
    	$("#fv_FREQ_CODE").val(data.FREQ_CODE);
	    $("#fv_CURRENT_PRE_LEVEL").val(data.CURRENT_PRE_LEVEL);
	    $("#fv_VOLT_PRE_LEVEL").val(data.VOLT_PRE_LEVEL);
	    $("#fv_HARMONIC_RATIO").val(data.HARMONIC_RATIO);
	    $("#fv_ABERRATION_RATIO").val(data.ABERRATION_RATIO);
	    $("#fv_EFFICIENCY").val(data.EFFICIENCY);
	    $("#fv_PF").val(data.PF);
    
    	$("#div_FREQ_CODE").show();
    	$("#div_CURRENT_PRE_LEVEL").show();
    	$("#div_VOLT_PRE_LEVEL").show();
    	$("#div_HARMONIC_RATIO").show();
    	$("#div_ABERRATION_RATIO").show();
    	$("#div_EFFICIENCY").show();
    	$("#div_PF").show();   
    	
    	$("#ydjc_loginuser_nav_bl").html("直流充电桩");  	
    }
    
    fillComboList();
}

/**
 * 检索出查询到的防护等级
 */
function checkProtectionLevel(data)
{
	if(data=="01" || data=="1")
	{
		return "一级";
	}else if(data=="02" || data=="2")
	{
		return "二级";
	}else if(data=="03" || data=="3")
	{
		return "三级";
	}
}

/**
 * 设置下拉菜单
 */
function fillComboList()
{
	//运行状态点击
    pCdoeSelectList({"id":"fv_RUN_STATUS_CODE","pCode":[{"A_23007":"","codeId":23007}]});
    
    //额定电压的点击
    pCdoeSelectList({"id":"fv_RV_CODE","pCode":[{"A_10005":"","codeId":10005}]});
    
    //额定电流的点击
    pCdoeSelectList({"id":"fv_RC_CODE","pCode":[{"A_16049":"","codeId":16049}]});
    
    //输出电压的点击
    pCdoeSelectList({"id":"fv_MAX_OUT_VOLT","pCode":[{"A_10005":"","codeId":10005}]});
    
    //最大输出电流的点击
    pCdoeSelectList({"id":"fv_R_MAX_CC_CODE","pCode":[{"A_16049":"","codeId":16049}]});
    
    //通讯方式的点击
    pCdoeSelectList({"id":"fv_COMM_MODE","pCode":[{"A_19043":"","codeId":19043}]});
    
    // 防护等级
    $("#fv_PROTECTION_LEVEL").fvSelect({
	    //callback:function(obj){alert(obj.selectobj.value+"---"+obj.selectobj.name)},
	    list:[{value:1,name:"一级"},{value:2,name:"二级"},{value:3,name:"三级"}]
	});
}

/**
 * 获取pcode列表中的特定项
 */
function getPcodeItemByValue(pCodeList, value)
{
	for(var i=0;i<pCodeList.length;i++)
    {
    	if(pCodeList[i].value == value)
    	{
    		return pCodeList[i];
    	}else if((i + 1) >= pCodeList.length)
    	{
    		var obj = {name:"", value:value}
    		return obj;
    	}
    }  
}

/********************************************保存修改信息***********************************************/
/**
 * 保存修改的数据
 */
function saveData()
{
	if(checkEmpty())
	{
		fvPubUI.fvLoading();	
		sendEditToServer();
	}
}

/**
 * 提示输入内容是否为空
 */
function checkEmpty()
{
	 if(checkStringTrim($("#fv_SP_ID").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("受电点不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_TYPE_CODE").val()))
	 {
	 	fvPubUI.fvMsgShow("设备类型不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_EQUIP_NAME").val()))
	 {
	 	fvPubUI.fvMsgShow("设备名称不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_FACTORY").val()))
	 {
	 	fvPubUI.fvMsgShow("制造厂家不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_MADE_DATE").val()))
	 {
	 	fvPubUI.fvMsgShow("出厂日期不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_INST_DATE").val()))
	 {
	 	fvPubUI.fvMsgShow("安装日期不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_TEST_CYCLE").val()))
	 {
	 	fvPubUI.fvMsgShow("试验周期不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_TEST_DATE").val()))
	 {
	 	fvPubUI.fvMsgShow("试验日期不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_RV_CODE").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("额定电压不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_RC_CODE").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("额定电流不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_RUN_STATUS_CODE").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("运行状态不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_MAX_OUT_VOLT").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("输出电压不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_R_MAX_CC_CODE").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("最大输出电流不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_PROTECTION_LEVEL").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("防护等级不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_COMM_MODE").attr("name")))
	 {
	 	fvPubUI.fvMsgShow("通讯方式不能为空");
	 	return false;
	 }
	 
	return true;
}

/**
 * 判断字符串是否为空
 */
function checkStringTrim(str)
{
	//var tStr = fvSqlModel.stringTrim(str);
	
	if(str == "" || str == undefined)
		return true;
	return false;
}



/**
 * 发送修改信息到服务端
 */
function sendEditToServer()
{
	var editObj = 	'"MOBILE_EQUIP_ID":"'	+ fvEquipId+'",' + 
					'"EQUIP_ID":"'			+ chargerData.EQUIP_ID+'",' + 
				  	'"APP_NO":"'			+ chargerData.APP_NO+'",' + 
				  	'"CHARGER_ID":"'		+ chargerData.CHARGER_ID+'",' + 
				  	'"CONS_ID":"'			+ fvConsInfo.cons_id+'",' + 
				  	'"SP_ID":"'				+ $("#fv_SP_ID").attr("name")+'",' +
				  	'"TYPE_CODE":"'			+ chargerData.TYPE_CODE+'",' +					
					'"EQUIP_NAME":"' 		+ $("#fv_EQUIP_NAME").val()+'",'+
					'"FACTORY":"' 			+ factory_obj.FACTORY_ID+'",'+
					'"FACTORY_NAME":"' 		+ $("#fv_FACTORY").val()+'",'+
					'"MADE_DATE":"' 		+ $("#fv_MADE_DATE").val()+'",'+
					'"INST_DATE":"' 		+ $("#fv_INST_DATE").val()+'",'+
					'"TEST_CYCLE":"' 		+ $("#fv_TEST_CYCLE").val()+'",'+
					'"TEST_DATE":"' 		+ $("#fv_TEST_DATE").val()+'",'+
					'"RV_CODE":"' 			+ $("#fv_RV_CODE").attr("name")+'",'+
					'"RC_CODE":"' 			+ $("#fv_RC_CODE").attr("name")+'",'+
					'"RUN_STATUS_CODE":"' 	+ $("#fv_RUN_STATUS_CODE").attr("name")+'",'+
					'"MEMO":"' 				+ $("#fv_MEMO").val()+'",'+
					'"MADE_NO":"' 			+ $("#fv_MADE_NO").val()+'",'+
					'"MAX_OUT_VOLT":"' 		+ $("#fv_MAX_OUT_VOLT").attr("name")+'",'+
					'"R_MAX_CC_CODE":"' 	+ $("#fv_R_MAX_CC_CODE").attr("name")+'",'+
					'"MAX_POWER":"' 		+ $("#fv_MAX_POWER").val()+'",'+
					'"PROTECTION_LEVEL":"' 	+ $("#fv_PROTECTION_LEVEL").attr("name")+'",'+
					'"COMM_MODE":"' 		+ $("#fv_COMM_MODE").attr("name")+'",'+
					'"CHARGE_MODE":"' 		+ $("#fv_CHARGE_MODE").val()+'",'+
					'"MODEL_CODE":"' 		+ $("#fv_MODEL_CODE").val()+'"';
					
					
	if(isChargerZL == true)
	{
		editObj += 	',"FREQ_CODE":"' 		+ $("#fv_FREQ_CODE").val()+'",'+
					'"CURRENT_PRE_LEVEL":"'	+ $("#fv_CURRENT_PRE_LEVEL").val()+'",'+
					'"VOLT_PRE_LEVEL":"'	+ $("#fv_VOLT_PRE_LEVEL").val()+'",'+
					'"HARMONIC_RATIO":"'	+ $("#fv_HARMONIC_RATIO").val()+'",'+
					'"ABERRATION_RATIO":"'	+ $("#fv_ABERRATION_RATIO").val()+'",'+
					'"EFFICIENCY":"'		+ $("#fv_EFFICIENCY").val()+'",'+
					'"PF":"'				+ $("#fv_PF").val()+'"';
	}
	//1.发送实名制认证基本信息请求到服务器
	var pkg='{"MOD":"2034","FUN":"030335","ORG_NO":"'+sessionStorage.ORG_NO+'","SYS_USER_NAME":"'+ sessionStorage.user_name +'","TERM_NUM":"'+ fvTid +'","PKG":{'+ editObj +'}}';
    send_data("030335","2034",pkg,sendSuccess,sendFail);
}

/**
 * 发送新增信息到服务端回调-成功
 */
function sendSuccess(message)
{	
	try
	{
        fvPubUI.fvLoadingClose();//关闭加载效果框
        var msg_enercb = JSON.parse(message);
        if(msg_enercb.RET=="00")
        {
            var msg_pkg=msg_enercb.PKG.PKG;
            if(msg_pkg.FLAG=="1")
            {
            	updateChargerTable();
            	updateEquipTable();
            }else
            {
            	fvPubUI.fvMsgShow("数据修改失败");
            }
        }else
        {
            fvPubUI.fvMsgShow("数据修改失败");
        }
	}catch(e)
    {
   	 	fvPubUI.fvMsgShow("数据修改失败!返回数据异常");
    }
}
/**
 * 发送新增信息到服务端回调-失败
 */
function sendFail(message)
{	
	//关闭加载效果框
	fvPubUI.fvLoadingClose();
    	
	//操作失败
	fvPubUI.fvMsgShow("数据修改失败");
}

/**
 * 更新充电桩表
 */
function updateChargerTable()
{
	var consKeyArr;
	if(isChargerZL == true)
	{// 直流充电桩
		consKeyArr = 
		{
			"tableName" 		: "YJ_C_CHARGER_ZL",	
			"MADE_NO" 			: $("#fv_MADE_NO").val(),
			"MAX_OUT_VOLT" 		: $("#fv_MAX_OUT_VOLT").attr("name"),
			"R_MAX_CC_CODE" 	: $("#fv_R_MAX_CC_CODE").attr("name"),
			"MAX_POWER" 		: $("#fv_MAX_POWER").val(),
			"PROTECTION_LEVEL" 	: $("#fv_PROTECTION_LEVEL").attr("name"),
			"COMM_MODE" 		: $("#fv_COMM_MODE").attr("name"),
			"CHARGE_MODE" 		: $("#fv_CHARGE_MODE").val(),
			"MODEL_CODE" 		: $("#fv_MODEL_CODE").val(),
			"FREQ_CODE" 		: $("#fv_FREQ_CODE").val(),
			"CURRENT_PRE_LEVEL"	: $("#fv_CURRENT_PRE_LEVEL").val(),
			"VOLT_PRE_LEVEL"	: $("#fv_VOLT_PRE_LEVEL").val(),
			"HARMONIC_RATIO"	: $("#fv_HARMONIC_RATIO").val(),
			"ABERRATION_RATIO"	: $("#fv_ABERRATION_RATIO").val(),
			"EFFICIENCY"		: $("#fv_EFFICIENCY").val(),
			"PF"				: $("#fv_PF").val()
		}
	}else
	{// 交流充电桩
		consKeyArr = 
		{
			"tableName" 		: "YJ_C_CHARGER_JL",			
			"MADE_NO" 			: $("#fv_MADE_NO").val(),
			"MAX_OUT_VOLT" 		: $("#fv_MAX_OUT_VOLT").attr("name"),
			"R_MAX_CC_CODE" 	: $("#fv_R_MAX_CC_CODE").attr("name"),
			"MAX_POWER" 		: $("#fv_MAX_POWER").val(),
			"PROTECTION_LEVEL" 	: $("#fv_PROTECTION_LEVEL").attr("name"),
			"COMM_MODE" 		: $("#fv_COMM_MODE").attr("name"),
			"CHARGE_MODE" 		: $("#fv_CHARGE_MODE").val(),
			"MODEL_CODE" 		: $("#fv_MODEL_CODE").val()
		}
	};
	var whereArr = {"APP_NO" : chargerData.APP_NO,"MOBILE_EQUIP_ID" : fvEquipId};
	fvSqlModel.updateInfo(consKeyArr, whereArr, null,null);
}

/**
 * 更新运行设备信息表
 */
function updateEquipTable()
{
	//YJ_C_EQUIP_RUN(运行设备信息表)
	var consKeyArr = 
	{
		"tableName" 		: "YJ_C_EQUIP_RUN",
		"EQUIP_NAME" 		: $("#fv_EQUIP_NAME").val(),
		"TYPE_CODE" 		: chargerData.TYPE_CODE,
		"FACTORY" 			: factory_obj.FACTORY_ID,
		"FACTORY_NAME" 		: $("#fv_FACTORY").val(),
		"MADE_DATE" 		: $("#fv_MADE_DATE").val(),
		"INST_DATE" 		: $("#fv_INST_DATE").val(),
		"TEST_CYCLE" 		: $("#fv_TEST_CYCLE").val(),
		"TEST_DATE" 		: $("#fv_TEST_DATE").val(),
		"RV_CODE" 			: $("#fv_RV_CODE").attr("name"),
		"RC_CODE" 			: $("#fv_RC_CODE").attr("name"),
		"RUN_STATUS_CODE" 	: $("#fv_RUN_STATUS_CODE").attr("name"),
		"MEMO" 				: $("#fv_MEMO").val()
	};
	var whereArr = {"APP_NO" : chargerData.APP_NO,"MOBILE_EQUIP_ID" : fvEquipId};
	fvSqlModel.updateInfo(consKeyArr, whereArr, function()
	{
		fvPubUI.fvMsgShow("数据修改成功");
        ydjc_loginuser_bl_back();
		
	},null);
}

/**
 * 返回
 */
function ydjc_loginuser_bl_back()
{
 	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/fv_cdz_show.html");
}

