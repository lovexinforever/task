/*$("#ydjc_loginuser_nav_bl").html("新增高低压成柜");

var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);

// 标示是直流高低压成柜（true）还是交流高低压成柜（false）
var isChargerZL = true;

//获得移动终端编号
var fvTid="";
getTid(function(e){fvTid =e;},null);

 *//**
 * 调用
 */
/*
init();


 *//********************************************初始化***********************************************/
/*
 *//**
 * 初始化标题和点击事件
 */
/*
function init() 
{	
	// 点击保存修改数据
	$("#fvChargerAdd").click(function()
	{
		uploadCharger();
	});
}

 *//**
 * 上装新增高低压成柜
 */
/*
function uploadCharger()
{
	if(checkEmpty() == true)
	{
		sendEditToServer();
	}
}

 *//**
 * 发送修改信息到服务端
 */
/*
function sendEditToServer()
{
	var editObj=
	{
		"CONS_ID"			:fvConsInfo.cons_id,
		"APP_NO"			:sessionStorage.fvAppNo,
		"SP_ID"				:$("#fv_SP_ID").val(),
		"TYPE_CODE" 		: $("#fv_TYPE_CODE").val(),
		"EQUIP_NAME" 		: $("#fv_EQUIP_NAME").val(),
		"FACTORY" 			: $("#fv_FACTORY").val(),
		"MADE_DATE" 		: $("#fv_MADE_DATE").val(),
		"INST_DATE" 		: $("#fv_INST_DATE").val(),
		"TEST_CYCLE" 		: $("#fv_TEST_CYCLE").val(),
		"TEST_DATE" 		: $("#fv_TEST_DATE").val(),
		"RV_CODE" 			: $("#fv_RV_CODE").val(),
		"RC_CODE" 			: $("#fv_RC_CODE").val(),
		"RUN_STATUS_CODE" 	: $("#fv_RUN_STATUS_CODE").val(),
		"MEMO" 				: $("#fv_MEMO").val(),
		"MADE_NO" 			: $("#fv_MADE_NO").val(),
		"MAX_OUT_VOLT" 		: $("#fv_MAX_OUT_VOLT").val(),
		"R_MAX_CC_CODE" 	: $("#fv_R_MAX_CC_CODE").val(),
		"MAX_POWER" 		: $("#fv_MAX_POWER").val(),
		"PROTECTION_LEVEL" 	: $("#fv_PROTECTION_LEVEL").val(),
		"COMM_MODE" 		: $("#fv_COMM_MODE").val(),
		"CHARGE_MODE" 		: $("#fv_CHARGE_MODE").val(),
		"MODEL_CODE" 		: $("#fv_MODEL_CODE").val()
	};
}

 *//**
 * 发送修改信息到服务端回调-成功
 */
/*
function sendDeleteSuccess(message)
{	
	try
	{
        fvPubUI.fvLoadingClose();//关闭加载效果框
        var msg_enercb = JSON.parse(message);
        if(msg_enercb.RET=="00")
        {
            var msg_pkg=msg_enercb.PKG.PKG;
            var fun=msg_enercb.FUN;
            if(msg_pkg.SUCCESS_FLAG=="1")
            {
            	fvPubUI.fvMsgShow("数据修改成功");
            	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
            }else
            {
            	fvPubUI.fvMsgShow("数据修改失败");
            }
        }else
        {
            fvPubUI.fvMsgShow("数据修改失败");
        }
	}catch(e)
    {
   	 	fvPubUI.fvMsgShow("数据修改失败!返回数据异常");
    }
}
 *//**
 * 发送修改信息到服务端回调-失败
 */
/*
function sendDeleteFail(message)
{	
	//关闭加载效果框
	fvPubUI.fvLoadingClose();
    	
	//操作失败
	fvPubUI.fvMsgShow("数据修改失败");
}

 *//**
 * 提示输入内容是否为空
 */
/*
function checkEmpty()
{
	 if(checkStringTrim($("#fv_SP_ID").html()))
	 {
	 	fvPubUI.fvMsgShow("受电点不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_TYPE_CODE").html())
	 {
	 	fvPubUI.fvMsgShow("设备类型不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_EQUIP_NAME").html())
	 {
	 	fvPubUI.fvMsgShow("设备名称不能为空");
	 	return false;
	 }else if(checkStringTrim($("#fv_FACTORY").html())
	 {
	 	fvPubUI.fvMsgShow("制造厂家不能为空");
	 	return false;
	 }
	 
	return true;
}

 *//**
 * 判断字符串是否为空
 */
/*
function checkStringTrim(str)
{
	var tStr = fvSqlModel.stringTrim(str);
	
	if(tStr == "")
		return false;
	return true
}



 *//**
 * 返回
 */
/*
var ydjc_loginuser_bl_back = function ()
{
 	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/fv_cdz_show.html");
}

 */
/**
 * 返回
 */

$("#ydjc_loginuser_nav_bl").html("添加高低压成套(柜)");
init();
var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);
var sqlsld = "select sp_name as NAME,sp_id as VALUE from C_SP where CONS_ID="
		+ fvConsInfo.cons_id;
querySelectList({
	"id" : "fv_SP_ID",
	"sql" : sqlsld
});
$("#fv_cons_no").html(fvConsInfo.cons_no);
/**
 * 初始化标题和点击事件
 */
var server_back_equip_id;
var server_back_charger_id;
function init() {
	// 点击修改负压开关信息
	$("#fvChargerAdd").click(function() {
		// insert();
		fvPubUI.fvLoading();
		sendEditToServer();
	});
	// 出厂时间点击
	$("#fv_MADE_DATE").click(function() {

		fvPubUI.getDate("fv_MADE_DATE");

	});
	// 投运日期点击fv_RUN_DATE
	$("#fv_RUN_DATE").click(function() {

		fvPubUI.getDate("fv_RUN_DATE");

	});

	// 安装日期点击
	$("#fv_INST_DATE").click(function() {

		fvPubUI.getDate("fv_INST_DATE");

	});
	// 测试时间点击
	$("#fv_TEST_DATE").click(function() {

		fvPubUI.getDate("fv_TEST_DATE");

	});
	// 返回设备档案信息
	$("#fykg_goto_head")
			.click(
					function() {

						changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");

					});
	$("#fv_FACTORY").click(function() {
		// fvPubUI.getDate("fv_TEST_DATE");
		// alert("factory");
		fvSmrz.getFactoryData(getFactory);
		// getData();
	});
	$("#fv_TYPE_CODE").val("高低压成套(柜)");
	// 运行状态点击
	pCdoeSelectList({
		"id" : "fv_RUN_STATUS_CODE",
		"pCode" : [ {
			"A_23007" : "",
			"codeId" : 23007
		} ]
	});

	// 额定电压的点击
	pCdoeSelectList({
		"id" : "fv_RV_CODE",
		"pCode" : [ {
			"A_10005" : "",
			"codeId" : 10005
		} ]
	});

	// 额定电流的点击
	pCdoeSelectList({
		"id" : "fv_RC_CODE",
		"pCode" : [ {
			"A_16049" : "",
			"codeId" : 16049
		} ]
	});
}
function getFactory(obj) {
	factory_obj = obj;
	$("#fv_FACTORY").val(factory_obj.FACNAME);
}

/**
 * 发送修改信息到服务端
 */
function sendEditToServer() {
	var typeCode = "21";
	var editObj = '"CONS_ID":"' + fvConsInfo.cons_id + '",' + '"APP_NO":"'
			+ sessionStorage.fvAppNo + '",' + '"SP_ID":"'
			+ $("#fv_SP_ID").attr("name") + '",' + '"TYPE_CODE":"22",'
			+ '"EQUIP_NAME":"' + $("#fv_EQUIP_NAME").val() + '",'
			+ '"FACTORY":"' + factory_obj.FACTORY_ID + '",'
			+ '"FACTORY_NAME":"' + $("#fv_FACTORY").val() + '",'
			+ '"MADE_DATE":"' + $("#fv_MADE_DATE").val() + '",'
			+ '"INST_DATE":"' + $("#fv_INST_DATE").val() + '",'
			+ '"TEST_CYCLE":"' + $("#fv_TEST_CYCLE").val() + '",'
			+ '"TEST_DATE":"' + $("#fv_TEST_DATE").val() + '",' + '"RV_CODE":"'
			+ $("#fv_RV_CODE").attr("name") + '",' + '"RC_CODE":"'
			+ $("#fv_RC_CODE").attr("name") + '",' + '"RUN_STATUS_CODE":"'
			+ $("#fv_RUN_STATUS_CODE").attr("name") + '",' + '"MEMO":"'
			+ $("#fv_MEMO").val() + '",' + '"MODEL_NO":"'
			+ $("#fv_MODEL_NO").val() + '",' + '"RUN_DATE":"'
			+ $("#fv_RUN_DATE").val() + '"';

	// 1.发送实名制认证基本信息请求到服务器
	var pkg = '{"MOD":"2034","FUN":"030331","ORG_NO":"' + sessionStorage.ORG_NO
			+ '","SYS_USER_NAME":"' + sessionStorage.user_name
			+ '","TERM_NUM":"' + fvTid + '","PKG":{' + editObj + '}}';
	send_data("030331", "2034", pkg, sendSuccess, sendFail);
}
function sendSuccess(message) {
	try {
		fvPubUI.fvLoadingClose();// 关闭加载效果框
		var msg_enercb = JSON.parse(message);
		if (msg_enercb.RET == "00") {
			var msg_pkg = msg_enercb.PKG.PKG;
			if (msg_pkg.FLAG == "1") {
				server_back_equip_id = msg_pkg.EQUIP_ID;
				server_back_charger_id = msg_pkg.CHARGER_ID;
				insertDB();

			} else {
				fvPubUI.fvMsgShow(msg_pkg.ERR_MSG);
			}
		} else {
			fvPubUI.fvMsgShow("数据上装失败");
		}
	} catch (e) {
		fvPubUI.fvMsgShow("数据上装失败!返回数据异常");
	}
}

function sendFail(message) {
	// 关闭加载效果框
	fvPubUI.fvLoadingClose();

	// 操作失败
	fvPubUI.fvMsgShow("数据上装失败");
}

function insert() {
	// cons_id = 110000000086
	// appno = 300000072931
	// alert("cons_id = "+fvConsInfo.cons_id);
	// alert("APP_NO="+sessionStorage.fvAppNo);
	var editObj = [ {
		"CONS_ID" : fvConsInfo.cons_id,
		"APP_NO" : sessionStorage.fvAppNo,
		"SP_ID" : "22",
		"TYPE_CODE" : "22",
		"EQUIP_NAME" : "负压开关",
		"FACTORY" : $("#fv_FACTORY").val(),
		"MADE_DATE" : $("#fv_MADE_DATE").val(),
		"INST_DATE" : $("#fv_INST_DATE").val(),
		"TEST_CYCLE" : $("#fv_TEST_CYCLE").val(),
		"TEST_DATE" : $("#fv_TEST_DATE").val(),
		"RV_CODE" : $("#fv_RV_CODE").val(),
		"RC_CODE" : $("#fv_RC_CODE").val(),
		"RUN_STATUS_CODE" : $("#fv_RUN_STATUS_CODE").val(),
		"MEMO" : $("#fv_MEMO").val(),
	} ];
	var editObj2 = [ {
		"CONS_ID" : fvConsInfo.cons_id,
		"APP_NO" : sessionStorage.fvAppNo,
		"EQUIP_ID" : sessionStorage.equip_id_my,
		"RUN_DATE" : $("#fv_RUN_DATE").val(),
		"MODEL_NO" : $("#fv_MODEL_NO").val(),
		"UPLOADING_TYPE" : "",
		"UPLOADING_DATE" : "",
	} ];
	var str1 = fvSqlModel.insertInfo("YJ_C_HDVCT", editObj2);
	var str = fvSqlModel.insertInfo("YJ_C_EQUIP_RUN", editObj);
	alert("init3" + str);
	db_execut_oneSQL("dahc.db", str[0], [], InsertSuccess, InsertFail);
	db_execut_oneSQL("dahc.db", str1[0], [], InsertSuccess, InsertFail);
}
function InsertSuccess(tx, res) {
	fvPubUI.fvLoadingClose();
	alert("success");
	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
}
function InsertFail() {
	alert("fail");
}
var successCount;
function insertDB() {
	var editObj;
	successCount = 0;

	editObj = [ {
		"APP_NO" : sessionStorage.fvAppNo,
		"EQUIP_ID" : server_back_equip_id,
		"CONS_ID" : fvConsInfo.cons_id,
		"SP_ID" : $("#fv_SP_ID").attr("name"),
		"EQUIP_NAME" : $("#fv_EQUIP_NAME").val(),
		"TYPE_CODE" : 21,
		"FACTORY" : factory_obj.FACTORY_ID,
		"FACTORY_NAME" : $("#fv_FACTORY").val(),
		"MADE_DATE" : $("#fv_MADE_DATE").val(),
		"INST_DATE" : $("#fv_INST_DATE").val(),
		"TEST_CYCLE" : $("#fv_TEST_CYCLE").val(),
		"RV_CODE" : $("#fv_RV_CODE").attr("name"),
		"RC_CODE" : $("#fv_RC_CODE").attr("name"),
		"RUN_STATUS_CODE" : $("#fv_RUN_STATUS_CODE").attr("name"),
		"MEMO" : $("#fv_MEMO").val(),
		"TEST_DATE" : $("#fv_TEST_DATE").val(),
	} ];
	startInsertDB("YJ_C_EQUIP_RUN", editObj);
}
function startInsertDB(tableName, value) {
	var sql = fvSqlModel.insertInfo(tableName, value);
	db_execut_oneSQL(
			"dahc.db",
			sql[0],
			[],
			function(tx, res) {
				successCount++;
				if (successCount > 1) {
					fvPubUI.fvMsgShow("数据上装成功");
					changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
				} else {
					insertChargerData(res.insertId);
				}
			}, null);
}
function insertChargerData(insertId) {
	var editObj;
	var editObj = [ {
		"CONS_ID" : fvConsInfo.cons_id,
		"APP_NO" : sessionStorage.fvAppNo,
		"EQUIP_ID":server_back_equip_id,
		"RUN_DATE" : $("#fv_MACHINARY_MODEL").val(),
		"MODEL_NO" : $("#fv_MODEL_NO").val()
	} ];

	startInsertDB("YJ_C_HDVCT", editObj);
}

/**
 * 查询高低压成柜信息集合
 */
function queryChargerInfo() {
	fvPubUI.fvLoading();
	// 使用工单编号与用户标识查询用户基本信息
	var sql = "SELECT * FROM YJ_C_EQUIP_RUN WHERE APP_NO="
			+ sessionStorage.fvAppNo + "AND EQUIP_ID="
			+ sessionStorage.fvEquipId;
	alert(sql);

	db_execut_oneSQL("dahc.db", sql[0], [], queryChargerSuccess,
			queryChargerFail);

}

/**
 * 查询负荷开关成功
 */
function queryChargerSuccess(tx, res) {
	fvPubUI.fvLoadingClose();

	var len = res.rows.length;
	if (len > 0) {
		pointSessionData = res.rows;
		fillChargerUI(res.rows);
	} else {
		fvPubUI.fvMsgShow("未查询到计量点数据");
	}
}
/**
 * 查询高低压成柜失败
 */
function queryChargerFail(tx, res) {
	fvPubUI.fvLoadingClose();
	fvPubUI.fvMsgShow("未查询到计量点数据");
}
// 页面数据初始化
function fillChargerUI(data) {
	$("#fv_APP_NO").html(data.APP_NO);
	$("#fv_CONS_ID").html(data.CONS_ID);
	$("#fv_EQUIP_ID").html(data.EQUIP_NAME);
	$("#fv_SWITCH_ID").html(data.FACTORY_NAME);
	$("#fv_SP_ID").html(data.SP_ID);
	$("#fv_TYPE_CODE").html(data.TYPE_CODE);
	$("#fv_EQUIP_NAME").html(data.EQUIP_NAME);
	$("#fv_FACTORY").html(data.FACTORY);
	$("#fv_MADE_DATE").html(data.MADE_DATE);
	$("#fv_INST_DATE").html(data.INST_DATE);
	$("#fv_TEST_CYCLE").html(data.TEST_CYCLE);
	$("#fv_TEST_DATE").html(data.TEST_DATE);

	$("#fv_RV_CODE").html(data.RV_CODE);
	$("#fv_RC_CODE").html(data.RC_CODE);
	$("#fv_RUN_STATUS_CODE").html(data.RUN_STATUS_CODE);
	$("#fv_MEMO").html(data.MEMO);
	$("#fv_MACHINARY_MODEL").html(data.PROTECTION_LEVEL);
	$("#fv_KGLX").html(data.COMM_MODE);
	$("#fv_ON_OFF_RC").html(data.CHARGE_MODE);
	$("#fv_ZDRL").html(data.MODEL_CODE);
	$("#fv_CHARGE_FLAG").html(data.FREQ_CODE);
	$("#fv_ISLVSWITCH").html(data.CURRENT_PRE_LEVEL);
}

/**
 * 删除负压开关
 */
function deleteCharger() {
	// 删除数据库中运行设备信息表的记录
	var sql = "DELETE from YJ_C_EQUIP_RUN WHERE APP_NO="
			+ sessionStorage.fvAppNo + " AND EQUIP_ID="
			+ sessionStorage.fvEquipId;
	db_execut_oneSQL(null, sql, [], null, null);
	// 删除数据库中直流高低压成柜表的记录
	sql = "DELETE from YJ_C_SWITCH WHERE APP_NO=" + sessionStorage.fvAppNo
			+ " AND EQUIP_ID=" + sessionStorage.fvEquipId;
	db_execut_oneSQL(null, sql, [], null, null);
	// 将删除的记录标示发给服务器
	sendDeleteToServer();
}

/**
 * 将删除的记录标示发给服务器
 */
function sendDeleteToServer() {
	var delObj = {
		"EQUIP_ID" : sessionStorage.fvEquipId,
		"APP_NO" : sessionStorage.fvAppNo,
		"CONS_ID" : sessionStorage.cons_id
	};
	// 1.发送实名制认证基本信息请求到服务器
	var pkg = '{"MOD":"2034","FUN":"03030036","ORG_NO":"'
			+ sessionStorage.ORG_NO
			+ '","SYS_USER_NAME":"010062","TERM_NUM":"352204061401792","PKG":'
			+ delObj + '}';
	send_data("03030036", "2034", pkg, sendDeleteSuccess, sendDeleteFail);
}
/**
 * 删除记录回调-成功
 */
function sendDeleteSuccess(message) {
	try {
		fvPubUI.fvLoadingClose();// 关闭加载效果框
		var msg_enercb = JSON.parse(message);
		if (msg_enercb.RET == "00") {
			var msg_pkg = msg_enercb.PKG.PKG;
			var fun = msg_enercb.FUN;
			if (msg_pkg.SUCCESS_FLAG == "1") {
				fvPubUI.fvMsgShow("数据删除成功");
				// /TODO 待改为正确的返回
				changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
			} else {
				fvPubUI.fvMsgShow("数据删除失败");
			}
		} else {
			fvPubUI.fvMsgShow("数据删除失败");
		}
	} catch (e) {
		fvPubUI.fvMsgShow("数据删除失败!返回数据异常");
	}
}
/**
 * 删除记录回调-失败
 */
function sendDeleteFail(message) {
	fvPubUI.fvLoadingClose();// 关闭加载效果框

	// 操作失败
	fvPubUI.fvMsgShow("数据删除失败");
}

/**
 * 返回
 */
var ydjc_loginuser_bl_back = function() {
	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
}
