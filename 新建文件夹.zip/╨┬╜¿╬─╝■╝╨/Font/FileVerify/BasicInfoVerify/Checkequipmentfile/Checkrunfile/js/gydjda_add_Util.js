<script type="text/javascript">


/**
* 供用电合同工具类
*
*/

//获得移动终端编号
var fvTid="";
getTid(function(e){fvTid =e;},null);


var gydjdnAddUntil={
	
	loadingNode: null,
	
 	/**
	 * 返回htmlDom元素的ID
	 * @param {}  obj -->类似 "td[id*='elec_']"
	 * @return htmlIdArr -->ID数组
	 */
   returnFvHtmlIdArr:function(obj){
   	   
		var htmlDom = $(obj);	      //input html元素  D_PHASEANGLE_CHK_RECORD
		var htmlIdArr = new Array();  //input 的ID  D_PHASEANGLE_CHK_RECORD
		for(var i =0;i<htmlDom.length;i++){//初始化input ID数组
		    htmlIdArr.push(htmlDom[i].id);              
		}
		return htmlIdArr;
	},
 	
	/**
	 * 向页面填充数据
	 * @param {} data 数据源
	 * @param {} arr 页面需填充ID数组
	 */
	initFvPageHtml : function(data,arr){
	     for(var i=0;i<arr.length;i++){
	     	var dataKey = arr[i].split("elec_")[1];
	     	if($("#"+arr[i]).is("input")) $("#"+arr[i]).val(data[dataKey]);
	     	else  $("#"+arr[i]).html(data[dataKey]);
	     }
	},
	
 	/**
 	 * 弹出框
 	 * @param {} text 提示信息
	 * @param {} cancelCB 取消按钮回调
	 * @param {} okCB 确定按钮回调
	 * @param {} type 按钮个数 1为一个 2为2个按钮 空无按钮
 	 */
 	fvAlert:function(text,type,cancelCB,okCB){
 		var button = []; //提示框按钮数组 class 单个按钮样式 id 按钮id text 按钮文本展示 callback 单个按钮回调
		cancelCB = Elec.setUndefined(cancelCB)==""?fvElecVUntil.fvDialogClose:cancelCB;
		okCB = Elec.setUndefined(okCB)==""?fvElecVUntil.fvDialogClose:okCB;
		var bt1 = {class:"simple",id:"prompt_cancel",text:"取消",callback:cancelCB};
		var bt2 = {class:"simple",id:"prompt_ok",text:"确认",callback:okCB};
		if(type==1) button.push(bt2);//只有确定按钮
		else if(type==2){
			button.push(bt1);
			button.push(bt2);
		}
		$.Elec.prompt({
			text:text,     //提示框文本域
	        buttons:button
		});
 	},
 
 	/**
	 * 增加loading框
	 */
	addLoadingDialog: function() {
		fvElecVUntil.loadingNode = $.Elec.loading({
		 	text:"请求数据中...",    		
	        icon:"pic_loading",  
	        time: 30*1000,
	        timeCallback: fvElecVUntil.removeLoadingDialog
	    });
	},
	
 	/**
	 * 取消loading框
	 */
	removeLoadingDialog: function() {
		if(fvElecVUntil.loadingNode != null) {
			fvElecVUntil.loadingNode.close();
			fvElecVUntil.loadingNode = null;
		}
	},
	
 	/**
	 * 单条SQL语句执行
	 * @dbName  ="",默认为用电检查数据库
	 * @param sql 要执行的SQL语句
	 * @param prarm ？对应的参数
	 * @param sucess 成功回调
	 * @param fail   失败回调
	 */
	db_execut_oneSQL:function (dbName,sql,prarm,sucess,fail){
		//缺省为用电检查数据库
		if(dbName==null){
			dbName="dahc.db";
		}
	   var db = window.sqlitePlugin.openDatabase(dbName, "1.0",dbName, 10*1024*1024);
		
	   db.transaction(function(tx){
			 tx.executeSql(sql,prarm,sucess,fail);
		});
	},
	
	 /**
     * 获取终端编号
     */
    fvGetMyTid:function(){
	getTid(function(e){thisTid =e;},null);
    },
    
	/**
     * 得到请求的数据包
     * @param {JSON} req_code  请求码
     * @param {JSON} data      需要的数据
     */
    get_fv_pkg_data: function(req_code, obj) {
        var modNo = req_code.modNo;
        var funcNo = req_code.funcNo;
  
        var pkg = '{"MOD":"' + modNo + '","FUN":"' + funcNo 
                + '","SYS_USER_NAME":"' + localStorage.user_name + '", "ORG_NO":"' + localStorage.ORG_NO + '", "TERM_NUM":"' + fvTid+ '","PKG":' + JSON.stringify(obj) + '}';
        return pkg;        
    } ,
   
    /*
     * 验证输入框里的内容
     */
    checkDetail:function(){
    	
    	//受电点名称
    	if($("#GYDJ_SP_NAME").attr("NAME")==null ||$("#GYDJ_SP_NAME").attr("NAME")==""){
    			fvPubUI.fvMsgShow("请选择受电点！");
    			return false;
    	};
    	//设备名称
    	if($("#GYDJ_EQUIP_NAME").val()==null ||$("#GYDJ_EQUIP_NAME").val()==""){
    			fvPubUI.fvMsgShow("请输入设备名称！");
    			return false;
    	};
    	//制造厂
    	if($("#GYDJ_FACTORY").attr("NAME")==null ||$("#GYDJ_FACTORY").attr("NAME")==""){
    			fvPubUI.fvMsgShow("请选择制造厂！");
    			return false;
    	};
    	//出厂日期
    	if($("#GYDJ_MADE_DATE").val()==null ||$("#GYDJ_MADE_DATE").val()==""){
    			fvPubUI.fvMsgShow("请选择出厂日期！");
    			return false;
    	};
    	//安装日期
    	if($("#GYDJ_INST_DATE").val()==null ||$("#GYDJ_INST_DATE").val()==""){
    			fvPubUI.fvMsgShow("请选择安装日期！");
    			return false;
    	};
//    	//监测日期 --接口里没有该字段，暂时不展示也不验证
//    	if($("#GYDJ_MONITOR_DATE").val()==null ||$("#GYDJ_MONITOR_DATE").val()==""){
//    			fvPubUI.fvMsgShow("请选择监测日期！");
//    			return;
//    	};
    	//试验日期
    	if($("#GYDJ_TEST_DATE").val()==null ||$("#GYDJ_TEST_DATE").val()==""){
    			fvPubUI.fvMsgShow("请选择试验日期！");
    			return false;
    	};
    	
    	//正则表达式，判断是否全部是数字
    	var reg = new RegExp("^[0-9]*$");
    	
    	//试验周期 23007 必须全是数字
    	if($("#GYDJ_TEST_CYCLE").val()==null ||$("#GYDJ_TEST_CYCLE").val()==""){
    			fvPubUI.fvMsgShow("请选择试验周期！");
    			return false;
    	}else{
    		if(!reg.test($("#GYDJ_TEST_CYCLE").val())){
    			fvPubUI.fvMsgShow("试验周期请输入数字！");
    			return false;
    		}
    	};
    	//额定电压
    	if($("#GYDJ_RV_CODE").attr("NAME")==null ||$("#GYDJ_RV_CODE").attr("NAME")==""){
    			fvPubUI.fvMsgShow("请选择额定电压！");
    			return false;
    	};
    	//额定电流
    	if($("#GYDJ_RC_CODE").attr("NAME")==null ||$("#GYDJ_RC_CODE").attr("NAME")==""){
    			fvPubUI.fvMsgShow("请选择额定电流！");
    			return false;
    	};
    	//运行状态
    	if($("#GYDJ_RUN_STATUS_CODE").attr("NAME")==null ||$("#GYDJ_RUN_STATUS_CODE").attr("NAME")==""){
    			fvPubUI.fvMsgShow("请选择运行状态！");
    			return false;
    	};
    	//型号
    	if($("#GYDJ_MODEL_NO").val()==null ||$("#GYDJ_MODEL_NO").val()==""){
    			fvPubUI.fvMsgShow("请填入型号！");
    			return false;
    	}
    	if($("#GYDJ_MODEL_NO").val().length>8){
    			fvPubUI.fvMsgShow("型号长度最多限8位,请重新输入！");
    			return false;
    	};
    	//出厂编号
    	if($("#GYDJ_MADE_NO").val()==null ||$("#GYDJ_MADE_NO").val()==""){
    			fvPubUI.fvMsgShow("请填入出厂编号！");
    			return false;
    	};
    	//容量 必须是数字
    	if($("#GYDJ_CAP").val()==null ||$("#GYDJ_CAP").val()==""){
    			fvPubUI.fvMsgShow("请填入容量！");
    			return false;
    	}else{
    		if(!reg.test($("#GYDJ_CAP").val())){
    			fvPubUI.fvMsgShow("容量请输入数字！");
    			return false;
    		}
    	};
    	//保护装置 16002/16060
    	if($("#GYDJ_PROTECT_DEV").val()==null ||$("#GYDJ_PROTECT_DEV").val()==""){
    			fvPubUI.fvMsgShow("请选择保护装置！");
    			return false;
    	};
    	//启动方式
    	if($("#GYDJ_START_MODE").val()==null ||$("#GYDJ_START_MODE").val()==""){
    			fvPubUI.fvMsgShow("请填入启动方式！");
    			return false;
    	};
    	//备注
    	if($("#GYDJ_MEMO").val()==null ||$("#GYDJ_MEMO").val()==""){
    			fvPubUI.fvMsgShow("请填入备注！");
    			return false;
    	};
    	
    	return true;
    	
    }
    
 } ;
 </script>