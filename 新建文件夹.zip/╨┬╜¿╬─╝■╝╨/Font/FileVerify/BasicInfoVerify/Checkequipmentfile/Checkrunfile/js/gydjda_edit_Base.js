<script type="text/javascript">

/**
 * 
 * 对本地数据库操作
 *
 */
 var gydjdaEBData={
 		
 	/**
 	 * 查询本地数据
 	 * @param EQUIP_ID 设备ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
 	 */
 	gydjdnInfoBData:function(EQUIP_ID,APP_NO){
			var sql = "SELECT "+
	  						   "JLD.APP_NO,"+
	  						   "JLD.[SP_NAME],  "+
	  						   "YXSB.[SP_ID],  "+ 
	  						   "YXSB.[EQUIP_NAME],  "+
	  						   "YXSB.[TYPE_CODE], "+ 
	  						   "YXSB.[FACTORY],  "+
	  						   "YXSB.[FACTORY_NAME],  "+
	  						   "YXSB.[MADE_DATE], "+ 
	  						   "YXSB.[INST_DATE],  "+
	  						   "YXSB.TEST_CYCLE, "+ 
	  						   "YXSB.[MONITOR_DATE],  "+
	  						   "YXSB.[RV_CODE],  "+
	  						   "(SELECT P1.NAME FROM P_CODE P1  WHERE P1.VALUE = YXSB.[RV_CODE] AND P1.CODE_SORT_ID = '10005')  RV_CODE_NAME,"+
	  						   "YXSB.[RC_CODE], "+ 
	  						    "(SELECT P1.NAME FROM P_CODE P1  WHERE P1.VALUE = YXSB.[RC_CODE] AND P1.CODE_SORT_ID = '16049')  RC_CODE_NAME,"+
	  						   "YXSB.[RUN_STATUS_CODE], "+ 
	  						    "(SELECT P1.NAME FROM P_CODE P1  WHERE P1.VALUE = YXSB.[RUN_STATUS_CODE] AND P1.CODE_SORT_ID = '23007')  RUN_STATUS_CODE_NAME,"+
	  						   "YXSB.[MEMO],  "+
	  						   "YXSB.[TEST_DATE],"+
	  						   "YXSB.EQUIP_ID,  "+
	  						   "GYDJ.[MODEL_NO], "+ 
	  						   "GYDJ.[MOTER_ID], "+ 
	  						   "GYDJ.[MADE_NO],  "+
	  						   "GYDJ.[CAP],  "+
	  						   "GYDJ.[PROTECT_DEV],  "+
	   						   "GYDJ.[START_MODE],"+
	   						   "GYDJ.[CONS_ID]"+
  						   "FROM "+
	  						   "C_SP JLD ,"+
	  						   "YJ_C_EQUIP_RUN YXSB ,"+  
	   						   "YJ_C_MOTER   GYDJ"+
  						   " WHERE "+
	  						   "JLD.[SP_ID] = YXSB.[SP_ID] AND JLD.[APP_NO] = YXSB.[APP_NO] "+
	  						   "AND YXSB.[APP_NO] = GYDJ.[APP_NO] AND YXSB.[EQUIP_ID] = GYDJ.[EQUIP_ID]  "+ 
	  						   "AND GYDJ.[APP_NO] = '"+APP_NO+"' AND GYDJ.[EQUIP_ID]='"+EQUIP_ID+"'";
	  						   
			db_execut_oneSQL("dahc.db", sql, [], gydjdaEBData.selectBaseSuccess, gydjdaEBData.selectBaseFail);
 	
 	},
 	
 	/**
 	 * 查询本地高压基本信息成功后调用方法
 	 */
	selectBaseSuccess:function(tx,res){
		
 			var len = res.rows.length;
			if (len == 0) {// 本地未查询
				fvPubUI.fvLoadingClose();
				fvPubUI.fvMsgShow("未查询到数据！");
			} else {
				//椤甸潰涓婃墍鏈夊厓绱犵殑ID璧嬪�
				$("#GYDJ_SP_NAME").html(res.rows.item(0).SP_NAME);// 璁￠噺鐐瑰悕绉�锛�div鐢╤tml input鐢╲al
				$("#GYDJ_SP_NAME").attr("name",res.rows.item(0).SP_ID);
				
				$("#GYDJ_EQUIP_NAME").val(res.rows.item(0).EQUIP_NAME);//璁惧鍚嶇О
				
//				$("#GYDJ_TYPE_CODE").val(res.rows.item(0).TYPE_CODE);//璁惧绫诲瀷
//				$("#GYDJ_TYPE_CODE").attr("NAME","10");//澧炲姞灞炴�瀛樺偍璁惧绫诲瀷VALUE鍊硷細03锛岄珮鍘嬬數鏈�
				
				$("#GYDJ_FACTORY").html(res.rows.item(0).FACTORY_NAME);//鍒堕�鍘�
				$("#GYDJ_FACTORY").attr("NAME",res.rows.item(0).FACTORY);//澧炲姞NAME灞炴�,瀛樻斁鍒堕�鍘侷D
				
				$("#GYDJ_MADE_DATE").val(res.rows.item(0).MADE_DATE);//鍑哄巶鏃ユ湡
				$("#GYDJ_INST_DATE").val(res.rows.item(0).INST_DATE);//瀹夎鏃ユ湡
				$("#GYDJ_TEST_CYCLE").val(res.rows.item(0).TEST_CYCLE);//璇曢獙鍛ㄦ湡
				$("#GYDJ_MONITOR_DATE").val(res.rows.item(0).MONITOR_DATE);//鐩戞祴鏃ユ湡
				
				$("#GYDJ_RV_CODE").html(res.rows.item(0).RV_CODE_NAME);//棰濆畾鐢靛帇 CODE鏀綨AME閲�
				$("#GYDJ_RV_CODE").attr("name",res.rows.item(0).RV_CODE);
				
				$("#GYDJ_RC_CODE").html(res.rows.item(0).RC_CODE_NAME);//棰濆畾鐢垫祦
				$("#GYDJ_RC_CODE").attr("name",res.rows.item(0).RC_CODE);
				
				$("#GYDJ_RUN_STATUS_CODE").html(res.rows.item(0).RUN_STATUS_CODE_NAME);//璁惧杩愯鐘舵�
				$("#GYDJ_RUN_STATUS_CODE").attr("name",res.rows.item(0).RUN_STATUS_CODE);
				
				$("#GYDJ_MEMO").val(res.rows.item(0).MEMO);//澶囨敞
				$("#GYDJ_TEST_DATE").val(res.rows.item(0).TEST_DATE);//璇曢獙鏃ユ湡
				$("#GYDJ_MODEL_NO").val(res.rows.item(0).MODEL_NO);//鍨嬪彿
				$("#GYDJ_MADE_NO").val(res.rows.item(0).MADE_NO);//鍑哄巶缂栧彿
				$("#GYDJ_CAP").val(res.rows.item(0).CAP);//瀹归噺
				$("#GYDJ_PROTECT_DEV").val(res.rows.item(0).PROTECT_DEV);//淇濇姢瑁呯疆
				$("#GYDJ_START_MODE").val(res.rows.item(0).START_MODE);//鍚姩鏂瑰紡
				
				sessionStorage.GY_APP_NO = res.rows.item(0).APP_NO;//SESSION瀛樺偍APP_NO锛�
				sessionStorage.GY_EQUIP_ID = res.rows.item(0).EQUIP_ID;//SESSION瀛樺偍EQUIP_ID锛�
				sessionStorage.GY_CONS_ID = res.rows.item(0).CONS_ID;//SESSION瀛樺偍CONS_ID锛�
				sessionStorage.GY_SP_ID = res.rows.item(0).SP_ID;//SESSION瀛樺偍SP_ID锛�
				sessionStorage.GY_MOTER_ID=res.rows.item(0).MOTER_ID;//SESSION瀛樺偍MOTER_ID锛�
				
				fvPubUI.fvLoadingClose();
				fvPubUI.fvLoadingClose();
			}
	},
	
	/**
	 * 查询接口失败后调用方法
	 */
	selectBaseFail:function(){
 			fvPubUI.fvLoadingClose();
			fvPubUI.fvMsgShow("查询失败，请重试！");
	},
	
	/**
	 * 更新操作
 	 * @param EQUIP_ID 设备ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	updataGydjdnInfoBData:function(){
 
		//更新YJ_C_EQUIP_RUN表信息
		gydjdaEBData.updateYJ_C_EQUIP_RUNInfo(sessionStorage.GY_EQUIP_ID,sessionStorage.GY_APP_NO);
		//更新YJ_C_MOTER表信息
		gydjdaEBData.updateYJ_C_MOTERInfo(sessionStorage.GY_EQUIP_ID,sessionStorage.GY_APP_NO);
		
		
	},
	
	/**
	 * 更新YJ_C_EQUIP_RUN表信息
 	 * @param EQUIP_ID 设备ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	updateYJ_C_EQUIP_RUNInfo:function(EQUIP_ID,APP_NO){
		 
		var sql = "UPDATE  YJ_C_EQUIP_RUN  SET "+
							"SP_ID  ='"+sessionStorage.GY_SP_ID+ "',  "+
							"EQUIP_NAME  ='"+$("#GYDJ_EQUIP_NAME").val()+ "',  "+
							"TYPE_CODE  = '03',  "+ 
							" FACTORY_NAME   = '"+$("#GYDJ_FACTORY").html()+ "',  "+   
							"FACTORY    = '"+$("#GYDJ_FACTORY").attr("NAME")+ "',  "+
							"MADE_DATE   ='"+$("#GYDJ_MADE_DATE").val()+ "' , "+ 
							"INST_DATE   ='"+$("#GYDJ_INST_DATE").val()+ "' ,  "+ 
							"TEST_CYCLE   ='"+$("#GYDJ_TEST_CYCLE").val()+ "' , "+ 
							"MONITOR_DATE  ='"+$("#GYDJ_MONITOR_DATE").val()+ "' , "+ 
							"RV_CODE  ='"+$("#GYDJ_RV_CODE").attr("NAME")+ "' ,  "+    
							"RC_CODE  ='"+$("#GYDJ_RC_CODE").attr("NAME")+ "' ,  "+     
							"RUN_STATUS_CODE ='"+$("#GYDJ_RUN_STATUS_CODE").attr("NAME")+ "' ,  "+   
							"MEMO  ='"+$("#GYDJ_MEMO").val()+ "' ,   "+   
							"TEST_DATE  = '"+$("#GYDJ_TEST_DATE").val()+ "' "+
					 "WHERE EQUIP_ID ='"+EQUIP_ID+ "'"+
							"AND APP_NO=  '"+APP_NO+"'";
							
							
		db_execut_oneSQL("dahc.db", sql, []);
 	
	},
	
	/**
	 * 更新YJ_C_MOTER表信息
 	 * @param EQUIP_ID 设备ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	updateYJ_C_MOTERInfo:function(EQUIP_ID,APP_NO){
		var sql = "UPDATE  YJ_C_MOTER  SET "+
							"MADE_NO  ='"+$("#GYDJ_MADE_NO").val()+ "',  "+
							"MODEL_NO  = '"+$("#GYDJ_MODEL_NO").val()+ "',  "+ 
							"CAP    = '"+$("#GYDJ_CAP").val()+ "',  "+   
							"PROTECT_DEV   ='"+$("#GYDJ_PROTECT_DEV").val()+ "' , "+ 
							"START_MODE   ='"+$("#GYDJ_START_MODE").val()+ "' " 
					 "WHERE EQUIP_ID ='"+EQUIP_ID+ "'"+
							"AND APP_NO=  '"+APP_NO+"'";
		db_execut_oneSQL("dahc.db", sql, [],gydjdaEBData.updateSuccess,gydjdaEBData.updateFail);
	},
	
	/**
	 *更新成功回调
 	 * @param EQUIP_ID 设备ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	updateSuccess:function(tx,res){
		fvPubUI.fvLoadingClose();
 		fvPubUI.fvMsgShow("高压电机档案信息修改成功！");
	},
	
	/**
	 * 更新失败回调
 	 * @param EQUIP_ID 设备ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调 
	 */
	updateFail:function(){
		fvPubUI.fvMsgShow("高压电机档案信息修改失败！");
	}
 };
 
  </script>