var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);
var fvFKXEquipId = sessionStorage.equip_id_my;
var fvFKXType = sessionStorage.equip_type_my;

var fvJKX = {

	fkxEquipId : "",//设备ID
	
	fkxData : "",
	
	// UI上元素的ID
	consDyIDArr : fvPubUI.returnHtmlIdArr("[id*='fv_']"),

	/**
	 * 初始化标题和点击事件
	 */
	initHeadClick : function() {
		// 标题
		$("#ydjc_loginuser_nav_bl").html("架空线设备档案维护");

		// 加载用检用户信息
		$("#fvJKXCons").html(fvConsInfo.cons_no);
		
		var headInfo = getHeaderInfo(fvConsInfo.cons_sort_code_str,fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str);
		
		$("#fvJKXConsInfo").html(headInfo);

		// 设备档案按钮
		$("#fvJKXHead").click(function() {
			 changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
		 });
		 
		// 返回
		$("#fvJKXBack").click(function() {
			changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
		 });
		 
		// 删除
		$("#fvJKXDelete").click(function() {
			 $("#delete_dailog").show();
		 });
		 
		 //修改
		 $("#fvJKXChange").click(function(){
		 	sessionStorage.JKXTYPE = "JKX_EDIT";
		 	sessionStorage.JKXData = JSON.stringify(fvJKX.fkxData);
		 	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/fv_jkx_edit.html");
		 });
		 
	},

	/**
	 * 查询用电申请信息
	 */
	initQueryData : function() {
	    var sql = "SELECT C.SP_ID,C.SP_NAME,E.TYPE_CODE,E.EQUIP_NAME,E.FACTORY,E.FACTORY_NAME,E.MADE_DATE,E.INST_DATE," +
	    		"E.TEST_CYCLE,E.TEST_DATE,E.RV_CODE,E.RC_CODE,E.RUN_STATUS_CODE,E.MEMO,J.ZZDD,J.TYRQ,J.SDDD,J.ZDDD,J.XH,J.FSFS,J.CD,J.JM,J.GLQS,J.JXDL," +
	    		"E.MOBILE_EQUIP_ID,E.EQUIP_ID FROM  YJ_C_EQUIP_RUN E,YJ_C_DL J, C_SP C "
            + "WHERE E.MOBILE_EQUIP_ID=J.MOBILE_EQUIP_ID AND E.CONS_ID=J.CONS_ID AND E.SP_ID=C.SP_ID AND E.CONS_ID = C.CONS_ID AND"
            + " E.TYPE_CODE=? AND E.CONS_ID=? AND J.MOBILE_EQUIP_ID=?";
        var whereVal= [fvFKXType,fvConsInfo.cons_id,fvFKXEquipId];
		db_execut_oneSQL("dahc.db", sql, whereVal, fvJKX.initPageData, null);
	},

	/**
	 * 数据查询回调处理
	 */
	initPageData : function(tx, res) {
		var data = res.rows;
		var len = data.length;
		
		if (len > 0) {
			fvJKX.fkxEquipId = data.item(0).EQUIP_ID;
			fvJKX.fkxData = data.item(0);
			fvPubUI.initPageHtml('fv_', data.item(0),fvJKX.consDyIDArr); // 初始化用户基础信息
			$("#fv_SP_ID").html(data.item(0).SP_NAME);
			$("#fv_FACTORY").html(data.item(0).FACTORY_NAME);
			fvPcode.tansformCodeOne("fv_RV_CODE", "A_10005",fvPcode.codeSortJson);// 额定电压
			fvPcode.tansformCodeOne("fv_RC_CODE", "A_16049",fvPcode.codeSortJson);// 额定电流
			fvPcode.tansformCodeOne("fv_RUN_STATUS_CODE", "A_23007",fvPcode.codeSortJson);//运行状态
		}
	},

	/**
	 * 删除数据
	 */
	deleteData : function() {
		var sql = "DELETE FROM YJ_C_EQUIP_RUN WHERE CONS_ID=? AND MOBILE_EQUIP_ID=?";
        var sql2 = "DELETE FROM YJ_C_DL  WHERE CONS_ID=? AND MOBILE_EQUIP_ID=?";
        db_execut_oneSQL("dahc.db", sql, [fvConsInfo.cons_id, fvFKXEquipId], null, null);
        db_execut_oneSQL("dahc.db", sql2, [fvConsInfo.cons_id, fvFKXEquipId], function(tx,res){
        	 changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
        }, null);
	},
	
	/**
	 * 删除的上装
	 */
	uploadDel : function() {
	    fvPubUI.fvLoading();
	    var pkg = '{"MOD":"2034","SYS_USER_NAME":"' + sessionStorage.user_name
	        + '","TERM_NUM":"' + fvTid + '","FUN":"030312","ORG_NO":"'
	        + sessionStorage.ORG_NO + '","PKG":{ "EQUIP_ID":"'
	        + fvJKX.fkxEquipId + '","APP_NO":"'
	        + sessionStorage.fvAppNo + '","CONS_ID":"' + fvConsInfo.cons_id + '"}}';   
	    send_data("030312", "2034", pkg, successCallBack, deletefail);
	    function successCallBack(msg) {
	        fvPubUI.fvLoadingClose();
	        var msg_ret = JSON.parse(msg);
	        if (msg_ret.RET == "00") {
	            var pkg = msg_ret.PKG.PKG;
	
	            if (pkg.FLAG == "1") {
	                fvPubUI.fvMsgShow("删除成功");
	                fvJKX.deleteData();
	            } else {
	                fvPubUI.fvMsgShow("删除失败");
	            }
	
	        } else {
	            fvPubUI.fvMsgShow("删除失败！");
	        }
	    }
	
	    function deletefail(e) {
	        fvPubUI.fvMsgShow("删除失败！");
	    }
	}
	
}


fvJKX.initHeadClick();
fvJKX.initQueryData();

/**
 * 返回
 */
var ydjc_loginuser_bl_back = function() {
	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
}

// 删除确定按钮
function delete_data_enter() {
    $("#delete_dailog").hide();
    fvJKX.uploadDel();
}

// 删除取消按钮
function delete_data_cancle() {
    $("#delete_dailog").hide();
}
