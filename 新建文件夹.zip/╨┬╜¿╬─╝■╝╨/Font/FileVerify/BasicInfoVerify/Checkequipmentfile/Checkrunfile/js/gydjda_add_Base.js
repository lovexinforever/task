<script type="text/javascript">

/**
 * 
 * 对本地数据库操作
 *
 */
 var gydjdaABData={
 		
 	/**
 	 * 插入本地数据
 	 * @param CONS_ID 用户ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
 	 */
 	addGydjdnInfoBData:function(CONS_ID,APP_NO){
	 	//插入YJ_C_EQUIP_RUN表信息
		gydjdaABData.insertYJ_C_EQUIP_RUNInfo(CONS_ID,APP_NO);
 	
 	},
 	
	/**
	 * 插入接口失败后调用方法
	 */
	selectBaseFail:function(){
 			alert("插入失败，请重试！");
	},
	
	/**
	 * 插入YJ_C_EQUIP_RUN表信息
 	 * @param CONS_ID 用户ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	insertYJ_C_EQUIP_RUNInfo:function(CONS_ID,APP_NO){
		 
		var sql = "insert into YJ_C_EQUIP_RUN(  APP_NO ,"+
					   "EQUIP_ID,"+
					   "CONS_ID ,"+
					   "SP_ID,"+
					   "EQUIP_NAME,"+
					   "TYPE_CODE,"+
					   "FACTORY,"+
					   "FACTORY_NAME ,"+
					   "MADE_DATE,"+
					   "INST_DATE ,"+
					   "TEST_CYCLE ,"+
					   "MONITOR_DATE ,"+
					   "RV_CODE ,"+
					   "RC_CODE,"+
					   "RUN_STATUS_CODE ,"+
					   "MEMO ,"+
					   "TEST_DATE)values('"+APP_NO+"','"+sessionStorage.A_EQUIP_ID+"','"+CONS_ID+"','"+$("#GYDJ_SP_NAME").attr("name")+"','"+ $("#GYDJ_EQUIP_NAME").val()+"','03','"+sessionStorage.FACTORYID+"','"+sessionStorage.FACNAME+"','"+$("#GYDJ_MADE_DATE").val()+"','"+$("#GYDJ_INST_DATE").val()+"','"+$("#GYDJ_TEST_CYCLE").val()+"','"+$("#GYDJ_MONITOR_DATE").val()+"','"+$("#GYDJ_RV_CODE").attr("name")+"','"+$("#GYDJ_RC_CODE").attr("name")+"','"+ $("#GYDJ_RUN_STATUS_CODE").attr("name")+"','"+$("#GYDJ_MEMO").val()+"','"+$("#GYDJ_TEST_DATE").val()+"')";
							
		db_execut_oneSQL("dahc.db", sql, [], gydjdaABData.updataYxdjTable,gydjdaABData.insertFail);
 	
	},
	
	/**
	 *  更新YJ_C_EQUIP_RUN表的MOBILE_EQUIP_ID字段
	 * @param {} tx
	 * @param {} res
	 */
	updataYxdjTable:function(tx,res){
		//缓存里放入MOBILE_EQUIP_ID
		sessionStorage.A_MOBILE_EQUIP_ID=res.insertId;
		var sql = " update  YJ_C_EQUIP_RUN set  MOBILE_EQUIP_ID='"+res.insertId+"' where EQUIP_ID='"+sessionStorage.A_EQUIP_ID+"' and APP_NO='"+sessionStorage.fvAppNo+ "'";
		db_execut_oneSQL("dahc.db", sql, [],gydjdaABData.insertYjMoter,gydjdaABData.insertFail);
	},
	
	/**
	 *插入YJ_C_MOTER表信息
 	 * @param CONS_ID 用户ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	insertYjMoter:function(tx,res){
		//插入YJ_C_MOTER表信息
		gydjdaABData.insertYJ_C_MOTERInfo(JSON.parse(sessionStorage.fvConsInfo).cons_id,sessionStorage.fvAppNo);
	},
		
	/**
	 * 插入YJ_C_MOTER表信息
 	 * @param CONS_ID 用户ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	insertYJ_C_MOTERInfo:function(CONS_ID,APP_NO){
		var sql = "insert into YJ_C_MOTER(APP_NO  ,"+
					   "EQUIP_ID ,"+
					   "MOBILE_EQUIP_ID ,"+
					   "MOTER_ID ,"+
					   "MADE_NO  ,"+
					   "MODEL_NO ,"+
					   "CAP  ,"+
					   "PROTECT_DEV  ,"+
					   "START_MODE  ,"+
					   "CONS_ID )values('"+APP_NO+"','"+sessionStorage.A_EQUIP_ID+"','" +sessionStorage.A_MOBILE_EQUIP_ID+"','"+sessionStorage.A_MOTER_ID+"','"+$("#GYDJ_MADE_NO").val()+"','"+$("#GYDJ_MODEL_NO").val()+"','" +$("#GYDJ_CAP").val()+"','" +$("#GYDJ_PROTECT_DEV").val()+"','"+$("#GYDJ_START_MODE").val()+"','"+CONS_ID  +"')";
		db_execut_oneSQL("dahc.db", sql, [],gydjdaABData.insertSuccess,gydjdaABData.insertFail);
	},
	
	/**
	 * 插入成功回调
 	 * @param CONS_ID 用户ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调 
	 */
	insertSuccess:function(){
		fvPubUI.fvLoadingClose();
		fvPubUI.fvMsgShow("新增成功！");
	},
		
	/**
	 * 插入失败回调
 	 * @param CONS_ID 用户ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调 
	 */
	insertFail:function(){
		fvPubUI.fvLoadingClose();
		fvPubUI.fvMsgShow("新增失败！");
	}
 };
 
  </script>