$("#ydjc_loginuser_nav_bl").html("充电桩");
var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);
// 设备id
var fvEquipId = sessionStorage.equip_id_my;

// 标示是直流充电桩（true）还是交流充电桩（false）
var isChargerZL = true;

/**
 * 调用
 */
init();

/********************************************初始化***********************************************/
/**
 * 初始化标题和点击事件
 */
function init() 
{	
	fvPubUI.fvLoading();
	$("#fv_cons_no").html(fvConsInfo.cons_no);
	$("#fv_cons_info").html(getHeaderInfo(fvConsInfo.cons_sort_code_str, fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str));
	
	// 判断直流还是交流
	if(sessionStorage.equip_type_my == "23")
	{	// 直流
		$("#ydjc_loginuser_nav_bl").html("直流充电桩");
		isChargerZL = true;
	}else if(sessionStorage.equip_type_my == "24")
	{	// 交流
		$("#ydjc_loginuser_nav_bl").html("交流充电桩");
		isChargerZL = false;
	}
	
	queryChargerInfo();
	addClickListener();
}

function addClickListener()
{
	// 点击返回
	$("#fv_cdz_back").click(function()
	{
		ydjc_loginuser_bl_back();
	});
	// 点击返回头部
	$("#fv_cdz_back_to_head").click(function()
	{
		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
	});
	
	// 点击修改充电桩信息
	$("#fvEditCharger").click(function()
	{
		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/fv_cdz_edit.html");
	});
	
	// 点击删除充电桩
	$("#fvDeleteCharger").click(function()
	{
		$("#delete_dailog").show();
	});
}

/********************************************查询充电桩信息***********************************************/

/**
 * 查询充电桩信息集合
 */
function queryChargerInfo()
{
	
	// 使用工单编号与用户标识查询用户基本信息
	var sql;	
	if(isChargerZL == true)
	{
		sql = "SELECT * FROM YJ_C_EQUIP_RUN A LEFT JOIN YJ_C_CHARGER_ZL B ON A.[MOBILE_EQUIP_ID] = B.[MOBILE_EQUIP_ID]"
			+" WHERE A.APP_NO="+sessionStorage.fvAppNo + " AND A.MOBILE_EQUIP_ID="+fvEquipId;	
	}else
	{
		sql = "SELECT * FROM YJ_C_EQUIP_RUN A LEFT JOIN YJ_C_CHARGER_JL B ON A.[MOBILE_EQUIP_ID] = B.[MOBILE_EQUIP_ID]"
			+" WHERE A.APP_NO="+sessionStorage.fvAppNo + " AND A.MOBILE_EQUIP_ID="+fvEquipId;
	}
	db_execut_oneSQL("dahc.db", sql, [], queryChargerSuccess,queryChargerFail);
}

/**
 * 查询充电桩成功
 */
function queryChargerSuccess(tx,res)
{
	fvPubUI.fvLoadingClose();
	
	var len=res.rows.length;
    if(len > 0)
    {
    	pointSessionData = res.rows.item(0);
        fillChargerUI();
    }else
    {
    	fvPubUI.fvMsgShow("未查询到充电桩数据");
    }
}
/**
 * 查询充电桩失败
 */
function queryChargerFail(tx,res)
{
	fvPubUI.fvLoadingClose();
	fvPubUI.fvMsgShow("未查询到充电桩数据");
}
/********************************************填充UI***********************************************/



//页面数据初始化
function fillChargerUI()
{
	var data = pointSessionData;
	
    // 设备类型
    var equip_type = (data.TYPE_CODE == "23") ? "直流充电桩" : "交流充电桩";
    $("#fv_TYPE_CODE").html(equip_type);
    
    // 电压
    var pcode_10005 = fvPcode.codeSortJson["A_10005"];
    // 电流
    var pcode_16049 = fvPcode.codeSortJson["A_16049"];
    // 防护等级
    var protect_level = (data.PROTECTION_LEVEL=="1") ? "一级" : (data.PROTECTION_LEVEL == "2") ? "二级" : "三级";
    
    $("#fv_EQUIP_NAME").html(data.EQUIP_NAME);
    $("#fv_FACTORY").html(data.FACTORY_NAME);
    $("#fv_MADE_DATE").html(data.MADE_DATE);
    $("#fv_INST_DATE").html(data.INST_DATE);
    $("#fv_TEST_CYCLE").html(data.TEST_CYCLE);
    $("#fv_TEST_DATE").html(data.TEST_DATE);
    
    $("#fv_RV_CODE").html(getPcodeNameByValue(pcode_10005, data.RV_CODE));
    $("#fv_RC_CODE").html(getPcodeNameByValue(pcode_16049, data.RC_CODE));
    $("#fv_RUN_STATUS_CODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_23007"], data.RUN_STATUS_CODE));    
    $("#fv_MEMO").html(data.MEMO);    
    $("#fv_MADE_NO").html(data.MADE_NO);
    $("#fv_MAX_OUT_VOLT").html(getPcodeNameByValue(pcode_10005, data.MAX_OUT_VOLT));
    $("#fv_R_MAX_CC_CODE").html(getPcodeNameByValue(pcode_16049, data.R_MAX_CC_CODE));
    $("#fv_MAX_POWER").html(data.MAX_POWER);
    $("#fv_PROTECTION_LEVEL").html(protect_level);
    $("#fv_COMM_MODE").html(getPcodeNameByValue(fvPcode.codeSortJson["A_19043"], data.COMM_MODE));
    $("#fv_CHARGE_MODE").html(data.CHARGE_MODE);
    $("#fv_MODEL_CODE").html(data.MODEL_CODE);
    $("#fv_FREQ_CODE").html(data.FREQ_CODE);
    $("#fv_CURRENT_PRE_LEVEL").html(data.CURRENT_PRE_LEVEL);
    $("#fv_VOLT_PRE_LEVEL").html(data.VOLT_PRE_LEVEL);
    $("#fv_HARMONIC_RATIO").html(data.HARMONIC_RATIO);
    $("#fv_ABERRATION_RATIO").html(data.ABERRATION_RATIO);
    $("#fv_EFFICIENCY").html(data.EFFICIENCY);
    $("#fv_PF").html(data.PF);
    
    
    if(isChargerZL==false)
    {// 交流充电桩隐藏部分项目
    	$("#div_FREQ_CODE").hide();
    	$("#div_CURRENT_PRE_LEVEL").hide();
    	$("#div_VOLT_PRE_LEVEL").hide();
    	$("#div_HARMONIC_RATIO").hide();
    	$("#div_ABERRATION_RATIO").hide();
    	$("#div_EFFICIENCY").hide();
    	$("#div_PF").hide();
    	
    	$("#ydjc_loginuser_nav_bl").html("交流充电桩");  	
    }else
    {// 直流充电桩隐藏部分项目
    	$("#div_FREQ_CODE").show();
    	$("#div_CURRENT_PRE_LEVEL").show();
    	$("#div_VOLT_PRE_LEVEL").show();
    	$("#div_HARMONIC_RATIO").show();
    	$("#div_ABERRATION_RATIO").show();
    	$("#div_EFFICIENCY").show();
    	$("#div_PF").show();   
    	
    	$("#ydjc_loginuser_nav_bl").html("直流充电桩");  	
    }
    
    // 查询受电点
	var sql = "SELECT SP_NAME FROM C_SP WHERE SP_ID=" + data.SP_ID;
	db_execut_oneSQL("dahc.db", sql, [], function(tx, res){
		
		var len=res.rows.length;
	    if(len > 0)
	    {
    		$("#fv_SP_ID").html(res.rows.item(0).SP_NAME);
    	}		
	},null);
	console.log("充电桩填充完毕");
}

/**
 * 获取pcode列表中的特定项
 */
function getPcodeNameByValue(pCodeList, value)
{
	if(pCodeList == undefined)
	{
		return "";
	}
	for(var i=0;i<pCodeList.length;i++)
    {
    	if(pCodeList[i].value == value)
    	{
    		return pCodeList[i].name;
    	}
    }  
}


/********************************************删除充电桩***********************************************/

// 删除确定按钮
function delete_data_enter() 
{
    $("#delete_dailog").hide();
    
    fvPubUI.fvLoading();
    // 将删除的记录标示发给服务器
    sendDeleteToServer();
}

/**
 * 将删除的记录标示发给服务器
 */
function sendDeleteToServer()
{
	var delObj='"EQUIP_ID":"' + pointSessionData.EQUIP_ID + '",'+
				'"APP_NO":"' + pointSessionData.APP_NO + '",'+
				'"CONS_ID":"' + fvConsInfo.cons_id + '"';
				
	//1.发送实名制认证基本信息请求到服务器
	var pkg='{"MOD":"2034","FUN":"030336","ORG_NO":"'+sessionStorage.ORG_NO+'","SYS_USER_NAME":"'+ sessionStorage.user_name +'","TERM_NUM":"'+ fvTid +'","PKG":{'+ delObj +'}}';
    send_data("030336","2034",pkg,sendDeleteSuccess,sendDeleteFail);
}

/**
 * 删除记录回调-成功
 */
function sendDeleteSuccess(message)
{	
	try
	{
        fvPubUI.fvLoadingClose();//关闭加载效果框
        var msg_enercb = JSON.parse(message);
        if(msg_enercb.RET=="00")
        {
            var msg_pkg=msg_enercb.PKG.PKG;
            if(msg_pkg.FLAG=="1")
            {
            	deleteCharger();
            }else
            {
            	fvPubUI.fvMsgShow("数据删除失败");
            }
        }else
        {
            fvPubUI.fvMsgShow("数据删除失败");
        }
	}catch(e)
    {
   	 	fvPubUI.fvMsgShow("数据删除失败!返回数据异常");
    }
}
/**
 * 删除记录回调-失败
 */
function sendDeleteFail(message)
{	
	fvPubUI.fvLoadingClose();//关闭加载效果框
    	
	//操作失败
	fvPubUI.fvMsgShow("数据删除失败");
}


// 删除取消按钮
//function delete_data_cancle() 
//{
//    $("#delete_dailog").hide();
//}


/**
 * 删除充电桩
 */
function deleteCharger()
{
	// 删除数据库中运行设备信息表的记录	
	var sql="DELETE FROM YJ_C_EQUIP_RUN WHERE APP_NO='"+pointSessionData.APP_NO +"' AND MOBILE_EQUIP_ID="+fvEquipId;
    db_execut_oneSQL("dahc.db",sql,[],null,null);
    
    // 删除数据库中直流充电桩表的记录	
    if(isChargerZL == true)
    {
        	sql="DELETE FROM YJ_C_CHARGER_ZL WHERE APP_NO='"+pointSessionData.APP_NO +"' AND MOBILE_EQUIP_ID="+fvEquipId;
    }else				 
    {
    	sql="DELETE FROM YJ_C_CHARGER_JL WHERE APP_NO='"+pointSessionData.APP_NO +"' AND MOBILE_EQUIP_ID="+fvEquipId;
    }
    	
    db_execut_oneSQL("dahc.db",sql,[],function()
    {
    
    	fvPubUI.fvMsgShow("数据删除成功");
    	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
    	
    },function()
    {
    	fvPubUI.fvMsgShow("数据库记录删除失败");
    });
}

/**
 * 返回
 */
function ydjc_loginuser_bl_back()
{
 	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
}


