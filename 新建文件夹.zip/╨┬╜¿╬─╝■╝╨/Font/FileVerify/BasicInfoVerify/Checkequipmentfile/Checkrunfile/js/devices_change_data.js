<script type="text/javascript">
/**
 * 
 */

function changeInfo(sql1,value1,sql2,value2,sucessCB_c,errorCB_c){
	var ydjc_db = window.sqlitePlugin.openDatabase("dahc.db", "1.0", "dahc.db", 10*1024*1024);
	//开始使用事务操作数据库
	ydjc_db.transaction(queryDB_c);
	//操作数据库
	function queryDB_c(tx){
		 tx.executeSql(sql1,value1,sucessCB_c,errorCB_c);
		 tx.executeSql(sql2,value2,sucessCB_c,errorCB_c);
	}
}

//正整数验证
function numberVolite(myInput){
	if(myInput.value<0||myInput.value.indexOf(".")!=-1){
		alert("请输入非负整数");
		myInput.value="";
		return;
	}
	if(myInput.value.length>1&&myInput.value.substring(0,1)==0){
		alert("请输入非负整数");
		myInput.value="";
		return;
	}
}

//非负数验证以及最大数验证
function numberVoliteMax(myInput,maxnumber){
	
	if(myInput.value<0||myInput.value>maxnumber){
		alert("请输入0到"+maxnumber+"之间的数");
		myInput.value="";
	}
}

//检验字符长度,长度不能超过length
function voliteLength(obj,length){
	var str = obj.value;
	var bytelen = 0,len = str.length;
	if(str){
		for(var i=0;i<len;i++){
			if (str.charCodeAt(i)>255) {
				bytelen +=2;
			}else{
				bytelen ++;
			}
		}
		if(bytelen>length){
			obj.value="";
			fvPubUI.fvMsgShow("字节长度不能超过"+length);
			
		}
	}
	
}

/**
 * @param obj 控件对象
 * @param integersize 整数的位数
 * @param ysize 小数的位数
 * @param max 最大数
 * @return 错误信息
 */
function validate(obj,ysize,max){ 
	if(obj.value!=""){
		var regstring = "^[0-9]+(.[0-9]{1,"+ysize+"})?$";
		var reg = new RegExp(regstring); 
		if(!reg.test(obj.value)){
			alert("请输入小数位不超过"+ysize+"位的正数!")
			obj.value="";
		}
		else if(obj.value>=max){
			 alert("请输小于"+max+"的正数!")
			 obj.value="";
		}
	}
}

</script>

