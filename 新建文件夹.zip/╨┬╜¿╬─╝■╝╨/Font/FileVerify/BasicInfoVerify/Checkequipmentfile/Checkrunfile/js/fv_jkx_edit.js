var fvConsInfo = JSON.parse(sessionStorage.fvConsInfo);
var jkxType = sessionStorage.JKXTYPE;// = "JKX_EDIT";  区分修改和新增

var fkxData = "";// 当前页面数据
var fvFKXMobileEquipId = "";//设备的MOBILE_EQUIP_ID
var fvfkxEquipId = ""; //设备EQUIP_ID

var fvJKX = {
	
	fvJXDL : new Array("进线","出线"),
	
	fvGLQS : new Array("自管","供电公司","用户自管","联合管理"),
	
	// YJ_C_EQUIP_RUN UI上元素的ID
	equipRunIDArr : fvPubUI.returnHtmlIdArr("[id*='fv1_']"),
	
	// YJ_C_DL UI上元素的ID
	DLIDArr : fvPubUI.returnHtmlIdArr("[id*='fv2_']"),

	/**
	 * 初始化标题和点击事件
	 */
	initHeadClick : function() {
		// 标题
		$("#ydjc_loginuser_nav_bl").html("架空线设备档案维护");

		// 加载用检用户信息
		$("#fvJKXCons").html(fvConsInfo.cons_no);
		
		var headInfo = getHeaderInfo(fvConsInfo.cons_sort_code_str,fvConsInfo.rrio_code_str, fvConsInfo.elec_type_code_str);
		
		$("#fvJKXConsInfo").html(headInfo);

		// 设备档案按钮
		$("#yxsb_fkx01_goto_head").click(function() {
			 changepage("../../BasicInfoVerify/Checkequipmentfile/Checkpowersource/html/sbdn_lb.html");
		 });
		 
		// 返回
		$("#button_back_jkx01add").click(function() {
			changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
		 });
		 
		 //上装
		 $("#button_save_jkx01add").click(function(){
		 	fvJKX.dealData();
		 });
		 
	},

	/**
	 * 查询用电申请信息
	 */
	initQueryData : function() {
		if(jkxType == "JKX_EDIT"){
			fkxData = JSON.parse(sessionStorage.JKXData);
			fvFKXMobileEquipId = sessionStorage.equip_id_my;
			fvfkxEquipId = fkxData.EQUIP_ID;
			fvJKX.initPage(fkxData);
		}else{
			var timerFlag = new Date();
			fvfkxEquipId = ""+timerFlag.getTime();//数据库为空，给EQUIP_ID一个时间标记
		}
	},

	/**
	 * 初始化页面数据
	 */
	initPage : function(data) {
		
		if(data){
			fvPubUI.initPageHtml('fv1_', data,fvJKX.equipRunIDArr); // 初始化用户基础信息
			fvPubUI.initPageHtml('fv2_', data,fvJKX.DLIDArr); // 初始化用户基础信息
			
			$("#fv1_SP_ID").attr("name",data.SP_ID);//受电点
			$("#fv1_SP_ID").html(data.SP_NAME);//受电点
			$("#fv1_FACTORY").attr("name",data.FACTORY);//制造厂家ID
			$("#fv1_FACTORY").val(data.FACTORY_NAME);//制造厂家NAME
			$("#fv1_RV_CODE").attr("name",data.RV_CODE);//额定电压
			$("#fv1_RC_CODE").attr("name",data.RC_CODE);//额定电流
			$("#fv1_RUN_STATUS_CODE").attr("name",data.RUN_STATUS_CODE);//运行状态
			
			fvPcode.tansformCodeOne("fv1_RV_CODE", "A_10005",fvPcode.codeSortJson);// 额定电压
			fvPcode.tansformCodeOne("fv1_RC_CODE", "A_16049",fvPcode.codeSortJson);// 额定电流
			fvPcode.tansformCodeOne("fv1_RUN_STATUS_CODE", "A_23007",fvPcode.codeSortJson);//运行状态
			
			var index1= fvJKX.fvGLQS.indexOf(data.GLQS);
			var index2= fvJKX.fvJXDL.indexOf(data.JXDL);
			if(index1 !=-1)
				$("#fv2_GLQS").attr("name",index1);//管理权属
			if(index2 !=-1)
				$("#fv2_JXDL").attr("name",index2);//架空线用途
				
		}
	},

	/**
	 * 本地数据 update 或者 insert
	 */
	dealData : function() {
		
		var whereId = {
			"APP_NO" : sessionStorage.fvAppNo,
			"CONS_ID" : fvConsInfo.cons_id,
			"EQUIP_ID" : fvfkxEquipId
		};
		var upDatedata1 = fvPubUI.localJsonData("fv1_",fvJKX.equipRunIDArr);
		var upDatedata2 = fvPubUI.localJsonData("fv2_",fvJKX.DLIDArr);
		upDatedata1.SP_ID = $("#fv1_SP_ID").attr("name");//受电点
		upDatedata1.FACTORY = $("#fv1_FACTORY").attr("name");//制造厂家ID
		upDatedata1.FACTORY_NAME = $("#fv1_FACTORY").val();//制造厂家NAME
		upDatedata1.RV_CODE = $("#fv1_RV_CODE").attr("name");//额定电压
		upDatedata1.RC_CODE = $("#fv1_RC_CODE").attr("name");//额定电流
		upDatedata1.RUN_STATUS_CODE = $("#fv1_RUN_STATUS_CODE").attr("name");//运行状态
		upDatedata2.GLQS = fvJKX.fvGLQS[$("#fv2_GLQS").attr("name")] || "";//管理权属
		upDatedata2.JXDL = fvJKX.fvJXDL[$("#fv2_JXDL").attr("name")] || "";//架空线用途
		
		if(jkxType == "JKX_EDIT"){
			//修改
			var equipRun = {"tableName" : "YJ_C_EQUIP_RUN"};// 设备运行表
			var yJCDL = {"tableName" : "YJ_C_DL"};// 架空线
			
			equipRun = $.extend(equipRun, upDatedata1);
			yJCDL = $.extend(yJCDL, upDatedata2);
			
			fvSqlModel.updateInfo(equipRun, whereId, null, null);
			fvSqlModel.updateInfo(yJCDL, whereId, fvJKX.uploadDel, null);
			
		}else{
			//新增
			var equipRun = $.extend(upDatedata1, whereId);
			equipRun["TYPE_CODE"] = "20";
			var eqSql = fvSqlModel.insertInfo("YJ_C_EQUIP_RUN", [equipRun]);// 新增设备运行表
			
			db_execut_oneSQL("dahc.db", eqSql[0], [], function(tx,res){
				
				whereId["MOBILE_EQUIP_ID"] = res.insertId;
				var yJCDL = $.extend(upDatedata2, whereId);
				
				var jkxSql = fvSqlModel.insertInfo("YJ_C_DL", [yJCDL]);// 新增架空线
				
				db_execut_oneSQL("dahc.db", jkxSql[0], [], fvJKX.uploadDel, null);
				
			}, null);
			
		}
	},
	
	/**
	 * 数据上装 服务器
	 */
	uploadDel : function() {
	    fvPubUI.fvLoading();
	    
	    var pkg = fvJKX.uploadData();
	    var theFun = "";
		
		if(jkxType == "JKX_EDIT"){
			
			pkg["EQUIP_ID"] = fkxData.EQUIP_ID;
			pkg["DL_ID"] = fkxData.DL_ID;
			theFun = "030311";
		}else{
			theFun = "030310";
		}
	    
		var execData = function(data) {
			if(jkxType == "JKX_EDIT"){
				
				fvPubUI.fvMsgShow("上装成功");
			}else{
				//新增
				var sql1 = "update YJ_C_EQUIP_RUN set EQUIP_ID=? where MOBILE_EQUIP_ID=?";
				var sql2 = "update YJ_C_DL set EQUIP_ID=?,DL_ID=?  where MOBILE_EQUIP_ID=?";
				db_execut_oneSQL("dahc.db", sql1, [data.EQUIP_ID,fvFKXMobileEquipId], null, null);
				db_execut_oneSQL("dahc.db", sql2, [data.EQUIP_ID,data.DL_ID,fvFKXMobileEquipId], function(tx,res){
					fvPubUI.fvMsgShow("上装成功");
				}, null);
			}
		}
		
		pkg = JSON.stringify(pkg);
		fvSendSpecial(theFun, pkg, execData, function(obj){
			if(obj.flag == -1){
				fvPubUI.fvMsgShow(obj.msg);
			}
		});
		
	},
	
	/**
	 * 架空线数据实体
	 * @return {}
	 */
	uploadData : function() {
		var upData = {
			"APP_NO" : sessionStorage.fvAppNo,//申请编号
			"CONS_ID" : fvConsInfo.cons_id,//用户编号
			"SP_ID" : $("#fv1_SP_ID").attr("name") || "",//受电点
			"TYPE_CODE" : "20",//设备类型
			"EQUIP_NAME" : $("#fv1_EQUIP_NAME").val() || "",//设备名称
			"FACTORY" : $("#fv1_FACTORY").attr("name") || "",//制造厂家
			"MADE_DATE" : $("#fv1_MADE_DATE").val() || "",//出厂日期
			"INST_DATE" : $("#fv1_INST_DATE").val() || "",//安装日期
			"TEST_CYCLE" : $("#fv1_TEST_CYCLE").val() || "",//试验周期
			"TEST_DATE" : $("#fv1_TEST_DATE").val() || "",//试验日期
			"RV_CODE" : $("#fv1_RV_CODE").attr("name") || "",//额定电压
			"RC_CODE" : $("#fv1_RC_CODE").attr("name") || "",//额定电流
			"RUN_STATUS_CODE" : $("#fv1_RUN_STATUS_CODE").attr("name") || "",//运行状态
			"MEMO" : $("#fv1_MEMO").val() || "",//备注
			"ZZDD" : $("#fv2_ZZDD").val() || "",//装置地点
			"TYRQ" : $("#fv2_TYRQ").val() || "",//投运日期
			"SDDD" : $("#fv2_SDDD").val() || "",//始端地点
			"ZDDD" : $("#fv2_ZDDD").val() || "",//终端地点
			"XH" : $("#fv2_XH").val() || "",//架空线型号
			"FSFS" : $("#fv2_FSFS").val() || "",//敷设方式
			"CD" : $("#fv2_CD").val() || "",//长度（M）
			"JM" : $("#fv2_JM").val() || "",//截面（平方毫米）
			"GLQS" : fvJKX.fvGLQS[$("#fv2_GLQS").attr("name")] || "",//管理权属
			"JXDL" : fvJKX.fvJXDL[$("#fv2_JXDL").attr("name")] || ""//架空线用途
		}
		return upData
	},
	
	initSelectClick : function(){
		//厂家
	    $("#fv1_FACTORY").click(function(){
	        fvSmrz.getFactoryData(function(obj){
	            $("#fv1_FACTORY").val(obj.FACNAME);
	            $("#fv1_FACTORY").attr("name",obj.FACTORY_ID);
        })});
	
		//受力点点击
	    var sql = "select sp_name as NAME,sp_id as VALUE from C_SP where CONS_ID=" + fvConsInfo.cons_id;
	    querySelectList({"id":"fv1_SP_ID","sql":sql});
	    
	    //运行状态点击
	    pCdoeSelectList({"id":"fv1_RUN_STATUS_CODE","pCode":[{"A_23007":"","codeId":23007}]});
	    
	    //额定电压的点击
	    pCdoeSelectList({"id":"fv1_RV_CODE","pCode":[{"A_10005":"","codeId":10005}]});
	    
	    //额定电流的点击
	    pCdoeSelectList({"id":"fv1_RC_CODE","pCode":[{"A_16049":"","codeId":16049}]});
	    
	    //管理权属
       $("#fv2_GLQS").fvSelect({
	        callback:function(obj){console.log("-选择了:"+obj.selectobj.value+"---"+obj.selectobj.name);},
	        list:[{value:0,name:"自管"},{value:1,name:"供电公司"},{value:2,name:"用户自管"},{value:3,name:"联合管理"}]
	    });
	    
	    //架空线用途
	   $("#fv2_JXDL").fvSelect({
	        callback:function(obj){console.log("-选择了:"+obj.selectobj.value+"---"+obj.selectobj.name);},
	        list:[{value:0,name:"进线"},{value:1,name:"出线"}]
	    });
	    
	    //出场日期
	    $("#fv1_MADE_DATE").click(function() {
	        fvPubUI.getDate("fv1_MADE_DATE");
	    });
	    
	    //安装日期
	    $("#fv1_INST_DATE").click(function() {
	        fvPubUI.getDate("fv1_INST_DATE");
	    });
	    
	    //实验日期
	    $("#fv1_TEST_DATE").click(function() {
	        fvPubUI.getDate("fv1_TEST_DATE");
	    });
	    
		//登记日期
	    $("#fv2_TYRQ").click(function() {
	        fvPubUI.getDate("fv2_TYRQ");
	    });
	}
	
}


fvJKX.initHeadClick();
fvJKX.initQueryData();
fvJKX.initSelectClick(); //下拉框和日期框的初始化

/**
 * 返回
 */
var ydjc_loginuser_bl_back = function() {
	changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
}

// 删除确定按钮
function delete_data_enter() {
    $("#delete_dailog").hide();
    fvJKX.uploadDel();
}

// 删除取消按钮
function delete_data_cancle() {
    $("#delete_dailog").hide();
}

/**
 * 数据请求（由于接口返回格式不统一，另外单独写一个）
 * @param {} fun
 * @param {} pkg
 * @param {} execData
 * @param {} callback
 */
function fvSendSpecial(fun, pkg, execData, callback) {
	var basePkg = '{"MOD":"2034","FUN":"' + fun + '","SYS_USER_NAME":"'
			+ sessionStorage.user_name + '","TERM_NUM":"' + fvTid
			+ '","ORG_NO":"' + sessionStorage.ORG_NO + '","PKG":' + pkg + '}';
	try {
		send_data(fun, "2034", basePkg, function(msg) {
			msg = JSON.parse(msg);
			if (msg.RET == "00") // 平台通讯成功
			{
				var ret = msg.PKG.RET;
				if (ret == "10") // 数据返回成功
				{
					var returnData = msg.PKG.PKG;
					if (returnData.FLAG == 1){ // 接口业务成功
						execData(returnData,callback);
					} else {
						if (returnData.ERR_MSG)
							callback({"flag":"-1","msg":returnData.ERR_MSG});
						else
							callback({"flag":"-1","msg":amMsg.I});
					}
				} else{
					var tpMsg = msg.PKG.PKG.ERR_MSG;
					tpMsg = tpMsg?tpMsg:amMsg.I;
					callback({"flag":"-1","msg":tpMsg});// 数据返回失败
				}
			} else
				callback({"flag":"-1","msg":amMsg.F});// 平台通讯异常

		}, function(msg) {
			callback({"flag":"-1","msg":amMsg.F});
		});
	} catch (e) {
		console.log("err->"+e);
		callback({"flag":"-1","msg":amMsg.W});
	}
}

