<script type="text/javascript">

/**
 * 下拉菜单初始化JS
 * @type 
 */	

// 受电点点击
var sql = "SELECT SP_ID VALUE,SP_NAME NAME FROM C_SP WHERE CONS_ID= '"+JSON.parse(sessionStorage.fvConsInfo).cons_id+"'  AND APP_NO='"+sessionStorage.fvAppNo+"'";
querySelectList({
            "id" : "GYDJ_SP_NAME",
            "sql" : sql
});

// 额定电压
pCdoeSelectList({
            "id" : "GYDJ_RV_CODE",
            "pCode" : [{
                        "A_10005" : "",
                        "codeId" : 10005
                         }]
});

// 额定电流
pCdoeSelectList({
            "id" : "GYDJ_RC_CODE",
            "pCode" : [{
                        "A_16049" : "",
                        "codeId" : 16049
                         }]
});

// 运行状态
pCdoeSelectList({
            "id" : "GYDJ_RUN_STATUS_CODE",
            "pCode" : [{
                        "A_23007" : "",
                        "codeId" : 23007
                         }]
});
 </script>
 