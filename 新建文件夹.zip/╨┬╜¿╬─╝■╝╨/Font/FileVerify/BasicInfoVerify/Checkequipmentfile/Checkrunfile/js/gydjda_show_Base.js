<script type="text/javascript">

/**
 * 
 * 对本地数据库操作
 *
 */
 var gydjdnBData={
 		
 	/**
 	 * 查询本地数据
 	 * @param EQUIP_ID 设备ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
 	 */
 	gydjdnInfoBData:function(EQUIP_ID,APP_NO){
			 
	  		 var sql = " SELECT   "+ 
  							  " JLD.APP_NO ,   "+ 
  							   " JLD.[SP_NAME] ,   "+ 
  							   " YXSB.[EQUIP_NAME] ,   "+ 
  							   " (SELECT P1.NAME FROM P_CODE P1  WHERE P1.VALUE = YXSB.[TYPE_CODE]  AND P1.CODE_SORT_ID = '16048') TYPE_CODE,  "+ 
  							   " YXSB.[FACTORY] ,   "+ 
  							    " YXSB.[FACTORY_NAME] ,   "+ 
  							   " YXSB.[MADE_DATE] ,   "+ 
  							   " YXSB.[INST_DATE] ,   "+ 
  							   " YXSB.TEST_CYCLE ,   "+ 
  							   " YXSB.[MONITOR_DATE] ,   "+ 
  							   " (SELECT P1.NAME FROM P_CODE P1  WHERE P1.VALUE = YXSB.[RV_CODE]  AND P1.CODE_SORT_ID = '10005') RV_CODE,    "+             
  							   " (SELECT P1.NAME FROM P_CODE P1  WHERE P1.VALUE = YXSB.[RC_CODE]  AND P1.CODE_SORT_ID = '16049') RC_CODE,  "+ 
  							   " (SELECT P1.NAME FROM P_CODE P1  WHERE P1.VALUE = YXSB.[RUN_STATUS_CODE]  AND P1.CODE_SORT_ID = '23007') RUN_STATUS_CODE,  "+ 
  							   " YXSB.[MEMO] ,   "+ 
  							   " YXSB.[TEST_DATE] ,   "+ 
  							   " YXSB.EQUIP_ID ,   "+ 
  							   " GYDJ.[MODEL_NO] ,   "+ 
  							   " GYDJ.[MADE_NO] ,   "+ 
  							   " GYDJ.[CAP] ,   "+ 
  							   " GYDJ.[PROTECT_DEV] ,   "+ 
  							   " GYDJ.[START_MODE] ,   "+ 
  							   " GYDJ.[CONS_ID]   "+ 
  							 " FROM   "+ 
  							   " C_SP JLD ,   "+ 
  							   " YJ_C_EQUIP_RUN YXSB ,   "+ 
  							   " YJ_C_MOTER GYDJ   "+ 
  							 " WHERE   "+ 
  							   " JLD.[SP_ID] = YXSB.[SP_ID] AND JLD.[APP_NO] = YXSB.[APP_NO] AND YXSB.[APP_NO] = GYDJ.[APP_NO] AND YXSB.[EQUIP_ID] = GYDJ.[EQUIP_ID] AND GYDJ.[APP_NO] = '"+APP_NO+"'  AND GYDJ.[MOBILE_EQUIP_ID] ='"+EQUIP_ID+"'";
			db_execut_oneSQL("dahc.db", sql, [], gydjdnBData.selectBaseSuccess, gydjdnBData.selectBaseFail);
 	},
 	
 	/**
 	 * 查询本地高压基本信息成功后调用方法
 	 */
	selectBaseSuccess:function(tx,res){
		
 			var len = res.rows.length;
			if (len == 0) {// 本地未查询
				fvPubUI.fvLoadingClose();
 			 	fvPubUI.fvMsgShow("未查询到数据！");
			} else {
				//页面上所有元素的ID赋值
//				alert(res.rows.item(0).SP_NAME);
				$("#GYDJ_SP_NAME").html(res.rows.item(0).SP_NAME);// 计量点名称 ， div用html
				$("#GYDJ_EQUIP_NAME").html(res.rows.item(0).EQUIP_NAME);//设备名称
				$("#GYDJ_TYPE_CODE").html(res.rows.item(0).TYPE_CODE);//设备类型
				$("#GYDJ_FACTORY").html(res.rows.item(0).FACTORY_NAME);//制造厂
				$("#GYDJ_MADE_DATE").html(res.rows.item(0).MADE_DATE);//出厂日期
				$("#GYDJ_INST_DATE").html(res.rows.item(0).INST_DATE);//安装日期
				$("#GYDJ_TEST_CYCLE").html(res.rows.item(0).TEST_CYCLE);//试验周期
				$("#GYDJ_MONITOR_DATE").html(res.rows.item(0).MONITOR_DATE);//监测日期
				$("#GYDJ_RV_CODE").html(res.rows.item(0).RV_CODE);//额定电压
				$("#GYDJ_RC_CODE").html(res.rows.item(0).RC_CODE);//额定电流
				$("#GYDJ_RUN_STATUS_CODE").html(res.rows.item(0).RUN_STATUS_CODE);//设备运行状态
				$("#GYDJ_MEMO").html(res.rows.item(0).MEMO);//备注
				$("#GYDJ_TEST_DATE").html(res.rows.item(0).TEST_DATE);//试验日期
				$("#GYDJ_MODEL_NO").html(res.rows.item(0).MODEL_NO);//型号
				$("#GYDJ_MADE_NO").html(res.rows.item(0).MADE_NO);//出厂编号
				$("#GYDJ_CAP").html(res.rows.item(0).CAP);//容量
				$("#GYDJ_PROTECT_DEV").html(res.rows.item(0).PROTECT_DEV);//保护装置
				$("#GYDJ_START_MODE").html(res.rows.item(0).START_MODE);//启动方式
				
				sessionStorage.GY_APP_NO = res.rows.item(0).APP_NO;//增加属性，存储APP_NO；
				sessionStorage.GY_EQUIP_ID = res.rows.item(0).EQUIP_ID;//增加属性，存储EQUIP_ID；
				sessionStorage.GY_CONS_ID = res.rows.item(0).CONS_ID;//增加属性，存储CONS_ID；
				sessionStorage.GY_SP_ID = res.rows.item(0).SP_ID;//SESSION存储SP_ID；
				sessionStorage.GY_MOTER_ID=res.rows.item(0).MOTER_ID;//SESSION存储MOTER_ID；
				fvPubUI.fvLoadingClose();
			}
	},
	
	/**
	 * 查询接口失败后调用方法
	 */
	selectBaseFail:function(){
			fvPubUI.fvLoadingClose();
 			fvPubUI.fvMsgShow("查询失败，请重试！");
	},
	
	/**
	 * 删除操作
 	 * @param EQUIP_ID 设备ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	deleteGydjdnInfoBData:function(){
		//调用接口设备档案-删除高压电机档案
 		gydjdaInter.deleteGydjdaInfo();
	
	},
	
	/**
	 * 删除YJ_C_EQUIP_RUN表信息
 	 * @param EQUIP_ID 设备ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	deleteYJ_C_EQUIP_RUNInfo:function(){
		var sql = "DELETE FROM YJ_C_EQUIP_RUN  WHERE EQUIP_ID ='"+sessionStorage.GY_EQUIP_ID+"' AND APP_NO='"+sessionStorage.GY_APP_NO+"'" ;
	  						   
		db_execut_oneSQL("dahc.db", sql, []);
 	
	},
	
	/**
	 * 删除YJ_C_MOTER表信息
 	 * @param EQUIP_ID 设备ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	deleteYJ_C_MOTERInfo:function(tx,res){
		var sql = "DELETE FROM YJ_C_MOTER  WHERE EQUIP_ID ='"+sessionStorage.GY_EQUIP_ID+"' AND APP_NO='"+sessionStorage.GY_APP_NO+"'" ;
	  						   
		db_execut_oneSQL("dahc.db", sql, [],gydjdnBData.deleteSuccess,gydjdnBData.deleteFail);
	},
	
	/**
	 *删除成功回调
 	 * @param EQUIP_ID 设备ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	deleteSuccess:function(tx,res){
		
		fvPubUI.fvLoadingClose();
		fvPubUI.fvMsgShow("删除成功！");
		changepage("../../BasicInfoVerify/Checkequipmentfile/Checkrunfile/html/yxsb_zk01.html");
	},
	
	/**
	 * 删除失败回调
 	 * @param EQUIP_ID 设备ID
 	 * @param APP_NO 工单号
	 * @param successCB 成功回调
	 * @param ailCB 失败回调 
	 */
	deleteFail:function(){
		fvPubUI.fvMsgShow("删除失败，请重试！");
	}
 };
 
  </script>