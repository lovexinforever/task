// 定义新增联系人操作类
var contactAdd = 
{
	contactArray : ['CONTACT_MODE','CONTACT_SOURCE','CONTACT_PRIO','CONTACT_NAME','GENDER','TITLE','OFFICE_TEL','HOMEPHONE','MOBILE',
					'FAX_NO','ADDR','POSTALCODE','EMAIL','FAMILY_ADDR','INTEREST','CONTACT_REMARK','BIRTHDAY','CHECK_FLAG','CONS_ID',"APP_NO"],
			
	// 新增联系人
	addContactInfo : function()
	{
		// 动态获取页面输入框/下拉列表数据
		var params = new Array();
		var tempArray = contactAdd.contactArray.slice(0, contactAdd.contactArray.length-2);
		for(var i=0; i<tempArray.length; i++)
		{
			var key = tempArray[i];
			var tempValue;
			if("CONTACT_PRIO"==key || "CONTACT_MODE"==key || "CONTACT_SOURCE"==key || "GENDER"==key || "CHECK_FLAG"==key)
			{
				tempValue = $("#"+key).attr("name");
			}
			else
			{
				tempValue = $("#"+key).val();
			}
			params.push(tempValue);
		}
		alert("新增联系人参数"+params);
		
		params.push(sessionStorage.FV_CONS_ID);
		params.push(sessionStorage.FV_APP_NO);
		
		// 调用接口执行联系人新增操作
		contactDS.contactManage("addContact", contactAdd.contactArray, params, function(data)
		{
			alert("data====="+data);
			contactAdd.contactArray.push("CONTACT_ID");
			params.push(data);
			contactDB.addContact(contactAdd.contactArray, params);
		});
	},
	
 	// 初始化界面下拉列表数据
 	initDropDown : function()
 	{
		for (var pcode in contactMain.jsonString)
		{
			for(var k=0; k<contactMain.jsonString[pcode].length; k++)
			{
				var name = contactMain.jsonString[pcode][k].name;
				var value = contactMain.jsonString[pcode][k].value;
				for(var m=0; m<contactMain.pCodeArray.length; m++)
		 		{
		 			var codeId = contactMain.pCodeArray[m].CODE_ID;
		 			if(codeId == pcode)
		 			{
		 				var codeName = contactMain.pCodeArray[m].CODE_NAME;
		 				$("#"+codeName).val(name);
		 				$("#"+codeName).attr("name",value);
		 				break;
		 			}
		 		}
			}
		}
 	},

 	// 页面初始化并绑定单击事件
	initData : function()
	{
		$("#ydjc_loginuser_nav_bl").html("联系人详细信息");
		$("#fvAddContact").click(function() {contactAdd.addContactInfo()});
		contactAdd.initDropDown();
	}
};

contactAdd.initData();

// 回退按钮
function ydjc_loginuser_bl_back()
{
	window.location.replace("mainContent.html");
}