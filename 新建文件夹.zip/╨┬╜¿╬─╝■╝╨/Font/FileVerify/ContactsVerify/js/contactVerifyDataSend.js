// 定义联系人接口操作类
var contactDS = 
{
	mod : "2034",
	funCode : 
	{
		queryUserInfo:{"funNo":"020001"},
		addContact:{"funNo":"030602"},
		modifyContact:{"funNo":"030603"},
		deleteContact:{"funNo":"030604"}
	},
	funNames : ["addContact", "modifyContact", "deleteContact"],
	
	// 调用接口查询用户信息和联系人信息
	queryConsInfoAndContactInfo : function(consNo, assetNo, callback)
	{
		var paramObj = {};
		paramObj.CONS_NO = consNo;
		paramObj.ASSET_NO = assetNo;
		var modStr = "MOD"+":"+'"'+contactDS.mod+'"';
		var funStr = "FUN"+":"+'"'+contactDS.funCode.queryUserInfo.funNo+'"';
		var sysUserNameStr = "SYS_USER_NAME"+":"+'"'+localStorage.user_name+'"';
		var orgNoStr = "ORG_NO"+":"+'"'+localStorage.ORG_NO+'"';
		var termNumStr = "TERM_NUM"+":"+'"'+localStorage.ORG_NO+'"';
		var pkgStr = "PKG"+":"+JSON.stringify(paramObj);
		
		var pkg = "{"+modStr+","+funStr+","+sysUserNameStr+","+orgNoStr+","+termNumStr+","+pkgStr+"}";
		// 发送请求
		send_data(contactDS.funCode.queryUserInfo.funNo, contactDS.mod,pkg, function(msg)
		{
			msg = JSON.parse(msg);
			// 发送请求失败
			if(msg.RET != "00")
			{
				alert("发送请求失败");
//				close_loading_view(getErrorMsg(msg.RET));
			}
			// 发送请求成功
			else
			{
				try
				{
					var pkg = msg.PKG;
					// 数据返回成功
					if(pkg.RET == "10")
					{
						if("1" == pkg.PKG.FLAG)
						{
							callback(pkg.PKG.DATA);
						}
						else
						{
							alert(pkg.PKG.ERR_MSG);
						}
					}
					else
					{
						alert(pkg.RET);
					}
				}
				catch(e)
				{
					alert(e);
//						close_loading_view("营销系统返回JSON格式错误");
					alert("营销系统返回JSON格式错误");
				}
			}
		}, contactDS.sendDataFailCB);
	},
	
	// 发送报文失败
	sendDataFailCB : function(msg)
	{
		alert("sendDataFailCB");
	},
	
	// 调用接口新增/修改/删除联系人
	contactManage : function(operateType, paramNames, paramValues, callback)
	{
		var paramObj = {};
		var funNo;
		for(var i=0; i<contactDS.funNames.length; i++)
		{
			var funName = contactDS.funNames[i];
			if(operateType == funName)
			{
				funNo = contactDS.funCode[funName].funNo;
				break;
			}
		}
		
		for(var j=0; j<paramNames.length; j++)
		{
			var paramName = paramNames[j];
			paramObj[paramName] = paramValues[j];
		}

		var modStr = "MOD"+":"+'"'+contactDS.mod+'"';
		var funStr = "FUN"+":"+'"'+funNo+'"';
		var sysUserNameStr = "SYS_USER_NAME"+":"+'"'+localStorage.user_name+'"';
		var orgNoStr = "ORG_NO"+":"+'"'+localStorage.ORG_NO+'"';
		var termNumStr = "TERM_NUM"+":"+'"'+localStorage.ORG_NO+'"';
		var pkgStr = "PKG"+":"+JSON.stringify(paramObj);
		
		var pkg = "{"+modStr+","+funStr+","+sysUserNameStr+","+orgNoStr+","+termNumStr+","+pkgStr+"}";
		alert(pkg);
		// 发送请求
		send_data(funNo, contactDS.mod, pkg, function(msg)
		{
			msg = JSON.parse(msg);
			// 发送请求失败
			if(msg.RET != "00")
			{
				alert("发送请求失败");
//				close_loading_view(getErrorMsg(msg.RET));
			}
			// 发送请求成功
			else
			{
				try
				{
					var pkg = msg.PKG;
					// 数据返回成功
					if(pkg.RET == "10")
					{
						if("1" == pkg.PKG.FLAG)
						{
							callback(pkg.PKG.CONTACT_ID);
						}
						else
						{
							alert(pkg.PKG.ERR_MSG);
						}
					}
					else
					{
						alert("RET="+pkg.RET);
					}
				}
				catch(e)
				{
					alert(e);
//						close_loading_view("营销系统返回JSON格式错误");
					alert("营销系统返回JSON格式错误");
				}
			}
		}, contactDS.sendDataFailCB);
	}
}