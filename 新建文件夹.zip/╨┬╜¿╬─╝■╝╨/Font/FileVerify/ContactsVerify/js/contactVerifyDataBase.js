// 联系人数据库增删改查操作类
var contactDB = 
{
	// 查询联系人详情信息
	queryContact : function(contactId, appNo, queryFlag, queryContactSuccCB)
	{
		alert("查询：contactId="+contactId+"  appNo="+appNo);
		var sql = "SELECT * FROM C_CONTACT WHERE CONTACT_ID = ? AND APP_NO = ?";
		
		// 查看联系人操作
		if("simpleQuery" == queryFlag)
		{
			db_execut_oneSQL("dahc.db", sql, [contactId, appNo], function(tx, res)
			{
				queryContactSuccCB(res);
			}, 
			contactDB.queryContactFailCB);
		}
		// 更新联系人操作之前查询数据
		if("modifyInitQuery" == queryFlag)
		{
			db_execut_oneSQL("dahc.db", sql, [contactId, appNo], function(tx, res)
			{
				queryContactSuccCB(res);
			}, 
			contactDB.queryContactFailCB);
		}
	},
	
	// 查询失败
	queryContactFailCB : function(e)
	{
		alert("查询联系人信息失败");
	},
	
	// 添加联系人信息 
	addContact : function(array, params)
	{
		var sql = "INSERT INTO C_CONTACT(";
		for(var i=0; i<array.length; i++)
		{
			sql += array[i];
			if(i != array.length-1)
			{
				sql += ",";
			}
		}
		sql += ") VALUES (";
		for(var i=0; i<array.length; i++)
		{
			sql += "?";
			if(i != array.length-1)
			{
				sql += ",";
			}
		}
		sql += ")";
		alert("新增联系人sql="+sql);
		alert("新增联系人字段信息="+params);
		db_execut_oneSQL("dahc.db", sql, params, contactDB.insertSuccCB, contactDB.insertFailCB);
	},
	
	// 添加成功
	insertSuccCB : function(tx, res)
	{
		alert("新增联系人信息成功");
	},
	
	// 添加失败
	insertFailCB : function(e)
	{
		alert("新增联系人信息失败");
	},
	
	// 更新联系人信息 
	modifyContact : function(array, params)
	{
		var tempArray = array.slice(0, array.length-2);
		alert(tempArray);
		var sql = "UPDATE C_CONTACT SET ";
		for(var i=0; i<tempArray.length; i++)
		{
			sql += tempArray[i] + "=?";
			if(i != tempArray.length-1)
			{
				sql += ", ";
			}
		}
		sql += " WHERE CONTACT_ID = ? AND APP_NO = ? ";
		
		alert("更新sql：" + sql);
		alert("更新params：" + params);
		db_execut_oneSQL("dahc.db", sql, params, contactDB.updateSuccCB, contactDB.updateFailCB);
	},
	
	// 更新成功
	updateSuccCB : function(tx, res)
	{
		alert("更新联系人信息成功");
	},
	
	// 更新失败
	updateFailCB : function(e)
	{
		alert("更新联系人信息失败");
	},
	
	// 删除联系人信息 
	deleteContact : function(contactId, appNo)
	{
		var sql = "DELETE FROM C_CONTACT WHERE CONTACT_ID = ? AND APP_NO = ?";
		db_execut_oneSQL("dahc.db", sql, [contactId, appNo], contactDB.deleteSuccCB, contactDB.deleteFailCB);
	},
	
	// 删除成功
	deleteSuccCB : function(tx, res)
	{
		alert("删除联系人信息成功");
	},
	
	// 删除失败
	deleteFailCB : function(e)
	{
		alert("删除联系人信息失败");
	},
	
	// 查询pcode
	queryPcode : function(parmCodes, queryPcodeSuccCB)
	{
		var sql = "SELECT CODE_SORT_ID,NAME,VALUE FROM P_CODE WHERE CODE_SORT_ID IN(" + parmCodes + ")";
		db_execut_oneSQL("dahc.db", sql, [], function(tx, res)
		{
			queryPcodeSuccCB(res);
		}, 
		contactDB.queryPcodeFailCB);
	},
	
	// 查询pcode信息失败
	queryPcodeFailCB : function(e)
	{
		alert("查询pcode信息失败");
	}
};