/**
 * Copy Right Information   : STATE GRID
 * author                   : wangjun
 * Comments                 : 蓝牙扫描的公共模块
 * Version                  : 0.0.1
 * Modification history     : 2014-09-02
 */

var G_ASSET_NO_PREFIX = {"32101": "", "32401": "A", "32402": "B", "32403": "C", "32404": "D","32405": "E","32406": "F",
                        "32407": "G", "32408": "H", "32409": "J", "32410": "K", "32411": "L","32412": "M","32413": "N"};

var fm_bluetooth_connect_cb;

/**
 * 调用蓝牙扫描的接口
 * @param {function} succ_cb: 回调结果的方法，方法的原型为：function succ(value) {}
 */
function fm_bluetooth_connect(succ_cb) {
    fm_bluetooth_connect_cb = succ_cb;
    _bluetooth_connect(1);
}

/**
 * 蓝牙连接成功回调
 * @param val 资产编号
 */
get_barcode = function(value) {
    var barcode = value.replace(/[\r\n]/g, "");//去掉换行
    barcode = _getlast_assetno(barcode);   
    fm_bluetooth_connect_cb(barcode);
}

/**
 * 蓝牙连接断开回调
 */
changeState = function(status){
    if(status == 0) {
        showToast("扫描设备连接已断开");
    }
}

function _bluetooth_connect(num) {
    bluetooth_conn(function(e) {
        if(e.msg == 1) {
            showToast("设备已连接，请扫描电表资产编号");
        } else if(e.msg == 3) {
            showToast("扫描设备未设置，请到设置页面中设置");
        } else {
            if(num < 3) {
                showToast("连接失败，正在尝试重新连接");
                num++;
                _bluetooth_connect(num);
            }
            else {
                showToast("连接失败");
            }
        }
    });
}

function _getlast_assetno(assetNo) {
    var assetno_org = _deal_assetno(localStorage.ORG_NO, assetNo);
    return assetno_org;
}

function _deal_assetno(orgNo, assetNo) {
    var str = assetNo.indexOf("-");
    if(str != -1) {
        assetNo = assetNo.substring(0, str);
    }
    assetNo = assetNo.replace(/[ ]/g, "");
    // 去掉前面与后面的空格
    orgNo = orgNo.replace(/[ ]/g, "");
    var sResult = assetNo + "";

    if(assetNo.length == 13) {
        sResult = G_ASSET_NO_PREFIX[orgNo.substr(0, 5)] + assetNo.substring(4, assetNo.length);
    }
    else if(assetNo.length == 22) {
        // 截取第12位到第21位共10位作为资产编号
        sResult = assetNo.substr(11, 10);
    }

    if(sResult.length > 10) {
        sResult = sResult.substring((sResult.length - 10), sResult.length);
    }

    return sResult;
}




