var list_ex = {
	list_item_click_callback:null,  
	list_userdata:null,
	more_callback:null,
	loading_more_status:0,
	bg_callback:null,
	hasMore : true,
	show : function(data, args) {
	    list_ex.list_userdata = args;
	    list_ex.bg_callback = data.bgCallback;
	    list_ex.loading_more_status = 0;
	    list_ex.hasMore = data.hasMore;
	    var html = list_ex.private_list_init(data.data, data.title, data.item_click_callback, data.bgColor,data.more_callback);
	    $.Elec.dialog({        
	        htmlObj: $(html),
	        bgCallback: function(args){
	        	if(list_ex.loading_more_status==1){
	        		return;
	        	}
	        	list_ex.bg_callback(args);
	        },
	        args: args
	    });
	    $('.dialog_box').css('height','auto');
	},
	private_list_init: function(data, title, item_click_callback, bg_color,more_callback) {
	    var bgStyle = "";
	    if(bg_color != undefined) {
	        bgStyle = " " + bg_color;
	    }
	    var html = '<div class="dialog_box' + bgStyle + '"><div class="head">' + title + '</div>'
	             + '<div class="body" id="list_ex_body">';
	    var lastStr;
	    list_ex.list_item_click_callback = item_click_callback;  
		list_ex.more_callback = more_callback;
	
	    if(typeof(data) == "string") {
	        data = JSON.parse(data);
	    } 
		html += '<div class="item listitem line" id="list_ex_empty" onclick="list_ex.list_item_click(this.id)">请选择</div>';
	    for(node in data) {            
	        lastStr = '<div class="item listitem line" id="' + node + '" onclick="list_ex.list_item_click(this.id)">' + data[node] + '</div>';
	        html += lastStr;
	    }
	    if(true == list_ex.hasMore){	
	    	html += '<div class="item" style="text-align: center;display: block;" id="list_ex_more" onclick="list_ex.more()">查看更多</div>';
	    }
	    html += '</div></div>';
	        
	    return html;
	},
	list_item_click: function(id) { 
		if(list_ex.loading_more_status == 1){
			return;
		} 
		$.cache["dialog"].close();
	    if(list_ex.list_item_click_callback != undefined && list_ex.list_item_click_callback != null) {
	        list_ex.list_item_click_callback(id, list_ex.list_userdata);    
	    }    
	},
	more : function(){
		
		if(list_ex.more_callback != undefined && list_ex.more_callback != null) { 
			list_ex.loading_more_status = 1;
			$("#list_ex_more").text('');
	        $("#list_ex_more").html('<div style="width: 100%;min-height: 50px;" class="icon pic_loading"></div>');
	        list_ex.more_callback(list_ex.append_data);  
	    } 
	},
	append_data : function(data,moreFlag){
		var html = '';
		var lastStr = '';
		$("#list_ex_more").remove();
		if(typeof(data) == "string") {
	        data = JSON.parse(data);
	    } 
	    for(node in data) {            
	        lastStr = '<div class="item listitem line" id="' + node + '" onclick="list_ex.list_item_click(this.id)">' + data[node] + '</div>';
	        html += lastStr;
	    }
	    
		if(moreFlag != '-1'){
			html += '<div class="item" style="text-align: center;display: block;" id="list_ex_more" onclick="list_ex.more()">查看更多</div>';
		}
	    $('#list_ex_body').append(html);
		list_ex.loading_more_status = 0;
		
		var dlg_top = (window.innerHeight - $('.dialog_box').height())/2;
		$('.dialog_box').css('top',dlg_top + 'px');
	}
}

/*****************使用例子*********************/

