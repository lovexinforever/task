(function($){
    /*jquery 对象级别插件*/
    $.fn.addListClickListener = function(handel){
        return this.each(function(m){
            EventUtil.addClickListener({
                id:this,
                clk:handel
            });
        });
    }

    $.fn.elecSelect = function(options){
        return $.Elec.select.call($(this[0]),options); 
    }

    $.fn.elecSearch = function(options){
        return $.Elec.search.call($(this[0]),options); 
    }

})(jQuery)