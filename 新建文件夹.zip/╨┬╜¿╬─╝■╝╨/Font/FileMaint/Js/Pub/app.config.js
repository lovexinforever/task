
/**
 * 应用的配置管理工具
 */
window.AppConfig = {
	/**
	 * 动画配置
	 */
	animations : {
		"flip" : {//动画名称
			"dx_show" : {//显示页面的动画
				"dx_class" : "contentPageTwo"
			},
			"dx_hide" : {//关闭页面的动画
				"dx_class" : "contentPageOne"
			}
		}
	},
	
	/**
	 * 切换页面的默认动画类型
	 */
	navigationType : "flip",
	/**
	 * 页面配置
	 */
	navigation : [{
		name : "main_conent", //页面名称
		uri : "main_conent.html" //页面的地址，相对于主界面而言
		//animation:"" 切换到该页面时使用的动画
	}, {
		name : "page_two",
		uri : "temp_two.html"
	}]
}