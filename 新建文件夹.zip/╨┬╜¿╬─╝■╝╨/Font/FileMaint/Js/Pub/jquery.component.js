(function($){
    /*jquery类级别插件*/
    $.Elec = $.Elec || {} ;     //命名空间

    $.Elec.defaultParam = $.Elec.defaultParam || {} ;    //默认参数

    $.Elec.defaultParam.search = {
        changeTextCallback:null,
    	callback:null,
        template:'<div class="backdrop"> </div><div class="content"><div><div class="select"></div><div class="v_line"></div><div class="inputDiv"><input type="search"/></div><div class="icon search_icon"></div></div></div>'      
    };

    $.Elec.defaultParam.dialog = {
        bgCallback:null,
        htmlObj:$("div"),
        template:'<div class="backdrop"> </div><div class="content"> </div>',
        args: null
    };

    $.Elec.defaultParam.select = {
        selectId:1,
        callback: null,
        list: [{id:1,text:"X"},{id:2,text:"XX"},{id:3,text:"XXX"},{id:4,text:"XXXX"},{id:5,text:"XXXXX"},{id:6,text:"XXXXXXXXXX"}],
        template:'<div class="backdrop"> </div><div class="content"><span>XXXX</span><div class="icon select_icon"></div></div><div class="list" style="display:none"><ul> </ul></div>'
    };

    //解析器 解析 原框架的 单击事件
    //EventUtil.addClickListener
    $.Elec.event = {
        click:function(fun){
            return EventUtil.addClickListener({id:this,clk:fun});
        },
        unclick:function(fun){
            return EventUtil.remveClickListener(this);
        }
    }
    //查询框组件
    /*
        固定模板
    */
    $.Elec.search = function(options){
        var g = $(this), p = options || {};
        //数据复写
        p = $.extend({},$.Elec.defaultParam.search,p);
        //增加组件识别样式
        g.addClass("search");
        //将模板导入页面形成对象
        g.append(p.template);

        //分离的公共变量
        g = $.extend(g,{
            bg:$(".backdrop",g),
            select:$(".select",g),
            input:$(".inputDiv input",g),
            icon:$(".icon",g)
        });

        //绑定外部使用方法
        g = $.extend(g,{
            changeIcon:function(iconClass){
                if(!g.icon.length) return ;
                g.icon.removeAttr("class");
                g.icon.addClass("icon " + iconClass); 
            },
            changeSelect:function(options){
                if(!g.select.length) return ;
                g.select = $.Elec.select.call(g.select,options);
            },
            changeBg:function(bgClass){
                if(!g.bg.length) return ; 
                g.bg.removeAttr("class");
                g.bg.addClass("backdrop " + iconClass);
            }
        });


        //定义内部方法对象
        var op = {
            build:function(){
                //构建基础
            },
            buildSelect:function(){
                //构建下拉组件
                if(!g.select.length) return ;
                g.select = $.Elec.select.call(g.select,p.select);
            },
            addEvent:function(){
                if(!!g.input[0])
                {
                    // 监听回车事件
                    g.input[0].onkeypress = function(){
                        if(event.which == 13)
                        {
                            op.doSearch();
                        }
                    }
                    // 监听键盘点击
                    g.input[0].oninput = function(){
                        p.changeTextCallback && p.changeTextCallback({
                            selectobj: g.select.getSelectObj(),
                            searchText: op.getInputValue()
                        })
                                }
                }

                g.icon[0] && $.Elec.event.click.call(g.icon[0],op.doSearch);
            },
            removeEvent:function(){
                //移除事件监听
                g.input[0] && (g.input[0].onkeypress = null);
                g.input[0] && (g.input[0].oninput = null);
                g.icon[0] && $.Elec.event.unclick.call(g.icon[0]);
            },
            getInputValue:function(){
                return !g.input[0] ? "" :  g.input.val();
            },
            doSearch:function(){
                return !!p.callback && p.callback({
                    selectobj: !!g.select[0] ? g.select.getSelectObj() : {},
                    searchText: op.getInputValue()
                });
            }
        };

        op.build();
        op.addEvent();
        op.buildSelect();

        return g;
    }

    //对话框组件
    //先实现单个淡出框
    $.Elec.dialog = function(options){
        var g = $(".dialog"), p = options||{};
        //数据复写
        p = $.extend({},$.Elec.defaultParam.dialog,p);
        //增加组件识别样式
        //g.addClass("dialog");

        //将模板导入页面形成对象
        g.empty();
        g.append(p.template);

        //分离的公共变量
        g = $.extend(g,{
            bg:$(".backdrop",g),
            content:$(".content",g)
        });


        //定义空的dialog数组
        g.dialog = {};

        //绑定外部使用方法
        g = $.extend(g,{
            // 1 弹出dialog
            open:function(){
                g.removeClass("hidden");
                op.sysWH();
                $.cache["dialog"] = g;
            },
            // 2 关闭dialog
            close:function(){
                g.addClass("hidden");
                op.empty();
                delete $.cache["dialog"] ; //释放对象
            }
        });

        var op = {
            // 3 加载html片段
            load:function(htmlObj,callback){
                op.empty();
                op.removeEvent();
                if(typeof htmlObj === "string")
                {
                    g.content.load(htmlObj,function(){
                        var links = g.content[0].getElementsByTagName("link");
                        var count = links.length;
                        if(count)
                        {

                            for (var i = 0; i < links.length; i++) {
                                links[i].onerror = links[i].onload = function(){
                                    --count;
                                    if(!count) g.trigger("dialogContent");
                                }   
                            };
                        }
                        else
                        {
                            g.trigger("dialogContent");
                        } 
                    });
                }
                else
                {
                    g.content.append(htmlObj);
                    g.trigger("dialogContent");
                }
                callback();
            },
            // 4 绑定事件
            addEvent:function(){
                $.Elec.event.click.call(g.bg[0],function(){
                     //p.bgCallback && !p.bgCallback() ;
                    if(p.bgCallback != null) {
                        p.bgCallback.call(this, p.args);
                    }                     
                });
            },
            // 5 移除事件
            removeEvent:function(){
                $.Elec.event.unclick.call(g.bg[0]);
            },
            // 7 置空弹出框
            empty:function(){
                g.content.empty();
            },
            // 8 刷新弹出框内容
            // 9 同步dialog内容高宽
            sysWH:function(){
                g.content.width($(">div",g.content).width());
                g.content.height($(">div",g.content).height());

                $(">div",g.content).width(g.content.width());
                $(">div",g.content).height(g.content.height());
            }
        };
    
        g.bind("dialogContent",function(event,str){
            op.addEvent();
            g.open();
        })

        op.load(p.htmlObj,function(){
            if(document.getElementById("dialog_box_scroll")){
                new iScroll("dialog_box_scroll",{bounce:false, useTransition:true, vScrollbar: false});  
            }
        });
    }

    //加载初始化
    $.Elec.defaultParam.loading = {
        text:"请稍等，正在加载中。。。",    //文本域展示
        icon:"pic_loading",                 //图标样式
        time:null,                          //超时时间
        timeCallback:null                   //超时回调
    }

    // 加载主方法
    $.Elec.loading = function(options){
        //生成加载对象
        var g = $('<div class="loading_box"><div></div><span></span></div>');
        //合并用户传参
        var p = $.extend({},$.Elec.defaultParam.loading,options); 
        //超时临时变量
        var timeout = null;
        //对话框对象生成
        var dialog = $.Elec.dialog({htmlObj:g});
        //分离的公共变量
        g = $.extend(g,{
            icon:$(">div",g),
            text:$(">span",g)
        });

        //绑定外部使用方法
        g = $.extend(g,{
            //改变文本内容
            changeText:function(text){
                text && this.text.html(text);
            },
            //改变图标样式
            changeIcon:function(iconClass){
                if(iconClass)
                {
                    this.icon.removeAttr("class");
                    this.icon.addClass("icon " + iconClass);
                }
            },
            //关闭等待框
            close:function(){
                g = null;   //释放对象
                $.cache["dialog"].close();
                clearTimeout(timeout);
            }
        });

        //初始化设置
        g.changeText(p.text);
        g.changeIcon(p.icon);

        if(p.time)
        {
            timeout = setTimeout(p.timeCallback,p.time);
        }

        return g;
    }

   //提示框始化
   $.Elec.defaultParam.prompt = {
        text:"请确认删除联系人",     //提示框文本域
        buttons:[   //提示框按钮数组 class 单个按钮样式 id 按钮id text 按钮文本展示 callback 单个按钮回调
            {class:"simple",id:"prompt_cancel",text:"取消",callback:function(){}},
            {class:"simple",id:"prompt_ok",text:"确认",callback:function(){}}
        ]
    }
    // 主函数
    $.Elec.prompt = function(options){
        //生成提示框对象
        var g = $('<div class="prompt_box"><div class="content"></div><div class="button prompt"></div></div>');
        //合并用户传参
        var p = $.extend({},$.Elec.defaultParam.prompt,options); 
        //对话框对象生成
        var dialog = $.Elec.dialog({htmlObj:g});
        //分离的公共变量
        g = $.extend(g,{
            text:$(">.content",g),
            buttons:$(">.button",g)
        });

        //绑定外部使用方法
        g = $.extend(g,{
            //改变文本内容
            changeText:function(text){
                text && this.text.html(text);
            },
            //改变按钮组
            changeButtons:function(buttons){   
                //清空对象  
                g.buttons.empty();
                $.each(buttons,function(n,m){
                   var button = $("<div><span></span><div></div></div>");
                   button.addClass(m.class);
                   button.attr("id",m.id);
                   $(">span",button).html(m.text);
                   $.Elec.event.click.call(button[0],m.callback);
                   g.buttons.append(button);
                });
            },
            //关闭提示框
            close:function(){
                g = null;
                $.cache["dialog"].close();
            }
        });
        g.changeText(p.text);
        g.changeButtons(p.buttons);
        return g;
    }   

    //列表组件
    $.Elec.list = function(options){
        var g = $(this), p = options;
        return g;
    }

    //下拉框组件
    $.Elec.select = function(options){
        var g = $(this), p = options||{};
        //数据复写
        p = $.extend({},$.Elec.defaultParam.select,p);
        //增加组件识别样式
        g.addClass("select");
        //将模板导入页面形成对象
        g.append(p.template);
        //分离的公共变量
        g = $.extend(g,{
            bg:$(".backdrop",g),
            list:$(".list ul",g),
            listPanel:$(".list",g),
            contentPanel:$(".content",g),
            content:$(".content span",g)
        });

        //绑定外部使用方法
        g = $.extend(g,{
            changeList:function(list){
                g.refreshList(list);
            },
            changeBg:function(bgClass){
                g.bg.removeAttr("class");
                g.bg.addClass("backdrop " + iconClass);
            },
            getSelectObj:function(){
                return op.getSelectObj();
            }
        });
        //定义内部方法对象
        var op = {
            build:function(){
                //构建基础
                this.builContentText("");
                this.buildList([]);
            },
            buildList:function(list){
                g.list.empty();
                var listArray = [];
                $.each(list,function(n,m){
                    listArray.push("<li id="+m.id+" index="+n+"> "+m.text+"</li>")
                })
                g.list.append(listArray.join(""));
            },
            builContentText:function(text){
                g.content.html(text);
            },
            //增加事件监听
            addEvent:function(){
                $("li",g.list).each(function(m,n){
                    $.Elec.event.click.call(n,function(){
                        p.selectId = parseInt(n.id);
                        op.refreshContent(op.getSelectObj());
                        op.listSwitch(false,function(){
                            p.callback && p.callback({
                                selectobj:op.getObjById(p.selectId)
                            })
                        });
                    });
                });

                $.Elec.event.click.call(g.contentPanel[0],function(){
                    if(g.listPanel.css("display") === "none")
                    {
                        op.listSwitch(true);
                    }
                    else
                    {
                        op.listSwitch(false);
                    }
                });

                $.Elec.event.click.call(g.bg[0],function(){
                    op.listSwitch(false);
                });
            },
            //移除事件监听
            removeEvent:function(){
                $("li",g.list).each(function(m){
                    $.Elec.event.unclick.call(m);
                });
                $.Elec.event.unclick.call(g.contentPanel[0]);
                $.Elec.event.unclick.call(g.bg[0]);
            },
            //刷新列表
            refreshList:function(list){
                op.removeEvent();
                p.list = list || p.list;
                this.buildList(list);
                op.addEvent();
            },
            //刷新内容
            refreshContent:function(obj){
                p.selectId = obj.id;
                this.builContentText(obj.text);
            },
            //打开/隐藏列表
            listSwitch:function(flag,callback){
                if(!!flag)
                {
                	g.bg.show();
                    g.listPanel.show("fast",callback);
                }
                else
                {
                	g.bg.hide();
                    g.listPanel.hide("fast",callback);
                }
            },
            //根据选择的id 返回 选择对象
            getObjById:function(id){
                var obj = null;
                $.each(p.list,function(n,m){
                   if( m.id === id ) 
                   {
                        obj = m;
                   } 
                })
                return obj;
            },
            //获取选中值
            getSelectObj:function(){
                return op.getObjById(p.selectId)
            }
        };

        op.build();
        op.refreshList(p.list);
        op.refreshContent(op.getSelectObj());

        return g;
    }
})(jQuery)