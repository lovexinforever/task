var util = util || {};
util.moblie =  util.moblie || {};
 
 //导航全局变量
 var navbarBack = null ;    //导航返回
 var navbarAdd = null ;     //导航新增
 var navbarMenu = null ;    //导航首页

 //底部按钮组
 var leftButtonClick = null ;    //左按钮事件
 var centerButtonClick = null ;    //中间按钮事件
 var rightButtonClick = null ;    //右按钮事件
 


/**
 *navbar 工具类
 *
 **/

util.moblie.navbar = $.extend({
    title:"",                 //标题内容
    buttonList:[],            //按钮列表
    loadListener:null,        //加载完成监听事件
    changeTitle:null,          //刷新标题
    changeButton:null         //刷新按钮组
},util.moblie.navbar,{})

/**
 *样式表 工具类
 *
 **/
util.moblie.css = $.extend({
    getCssByName:function(obj,cssName){
        return window.getComputedStyle(obj).getPropertyValue(cssName) || ""; 
    }
},util.moblie.css,{})

/**
 * 01-授权申请人 , 02-授权人 
 */
var giveRightInfo = {
    debug: true,
    infos: [],                // 授权信息的集合
    dataDealCb: null,         // 处理数据的回调函数

    P_INFO : {    
        P_USER_NO: "",        // 授权人工号
        P_USER_NAME: "",      // 授权人名称
        P_DEPT_NO: "",        // 授权人部门编号
        P_DEPT_NANME: "",     // 授权人部门名称
        P_EMP_NO: "",         // 授权人编号
        AUTHORIZE_BEGIN: "",  // 授权开始时间
        AUTHORIZE_END: "",    // 授权结束时间
        AUTHORIZE_STATUS: ""  // 授权状态 
    },
    
    ACT_CODE: [ {KEY: "0210001", VALUE: "更名业务受理"},
                {KEY: "0210002", VALUE: "更名合同起草"},
                {KEY: "0210003", VALUE: "更名合同审核"},
                {KEY: "0210004", VALUE: "更名合同签订"},

                {KEY: "0306001", VALUE: "档案变更业务受理"},
                {KEY: "0306002", VALUE: "档案变更勘查派工"},
                {KEY: "0306003", VALUE: "档案变更现场勘查"},
                {KEY: "0306004", VALUE: "档案变更审批"},

                {KEY: "0000000", VALUE: "查询指定人员终端业务所有业务权限情况"}],
    
    modelList: {},              // 需要授权的模块列表

    timeList: {},               // 添加授权信息的模块列表

    index: 0,                   // 查询授权信息的ACT_CODE的索引

    //isForce: false,             // 是否强制刷新

    REQ_CODE: {NORMAL: "0", SYNC: "1", AUTO: "2"},  // 请求类型的枚举值

    reqType: "0",  // 请求类型
    
    /**
     * 通过待办事宜的code码得到授权用户的信息 
     */
    getPInfo: function(actCode) {
        console.log("getPInfo:" + actCode);
        for(var i = 0; i < giveRightInfo.infos.length; i++) {
            var tempInfo = giveRightInfo.infos[i];
            if(tempInfo.ACT_CODE == actCode && tempInfo.AUTHORIZE_STATUS == "01") {
            	
            	var startDate = new Date();
            	var endDate = new Date(tempInfo.AUTHORIZE_END);
            	var spaceTime = endDate.getTime() - startDate.getTime();
                var h = Math.ceil(spaceTime/(3600*1000));
                if(h <= 0){
                	return null;
                }/*modified by yuenhoa 20141216 : 增加判断，如果授权结束日期小于当前日期则判断为未授权返回空*/
            	
                giveRightInfo.P_INFO.P_USER_NO        = tempInfo.P_USER_NO;
                giveRightInfo.P_INFO.P_USER_NAME      = tempInfo.P_USER_NAME;
                giveRightInfo.P_INFO.P_DEPT_NO        = tempInfo.P_DEPT_NO;
                giveRightInfo.P_INFO.P_DEPT_NANME     = tempInfo.P_DEPT_NANME;
                giveRightInfo.P_INFO.P_EMP_NO         = tempInfo.P_EMP_NO;
                giveRightInfo.P_INFO.AUTHORIZE_BEGIN  = tempInfo.AUTHORIZE_BEGIN;
                giveRightInfo.P_INFO.AUTHORIZE_END    = tempInfo.AUTHORIZE_END;
                giveRightInfo.P_INFO.AUTHORIZE_STATUS = tempInfo.AUTHORIZE_STATUS;
                return giveRightInfo.P_INFO;
            }
        }
        return null;
    },

    /**
     * 查询所有授权环节的数据
     */
    select_all: function(select_data_deal_cb, type) {

        if(type == undefined) {
            type = giveRightInfo.REQ_CODE.NORMAL;
        }
        
        giveRightInfo.reqType = type;

        giveRightInfo.dataDealCb = select_data_deal_cb;

        if(giveRightInfo.reqType == giveRightInfo.REQ_CODE.NORMAL) {
            giveRightInfo.select_database();
        }
        else {
            giveRightInfo.select("0000000");
        }
    },

    /**
     * 授权管理授权信息查询(查询服务器)
     */
    select: function(actCode) {
        var data = {SYS_USER_NAME: localStorage.user_name,
                    USER_TYPE: "01",
                    ACT_CODE: actCode};
        PubFuns.addLoadingDialog();
        file_maint_req.giveright_selectinfo(giveRightInfo.select_cb, giveRightInfo.fail_cb, data);    
    },

    /**
     * 授权管理授权信息查询(查询数据库)
     */
    select_database: function() {
        var sql = "select * from GIVE_RIGHT where SYS_USER_NO='" + localStorage.user_name + "' order by ACT_CODE";
        db_execut_oneSQL("dawh.db", sql, [], giveRightInfo.select_database_cb, giveRightInfo.fail_cb);
    },

    /**
     * 授权管理授权信息查询(查询服务器)
     */
    select_cb: function(data) {
        console.log("data:" + data);
        data = JSON.parse(data);
        if(data.PKG != undefined && data.PKG.PKG != undefined && data.PKG.PKG.DATA != undefined && data.PKG.PKG.DATA.length > 0) {
            var result = data.PKG.PKG.DATA;
            giveRightInfo.infos = result;
            giveRightInfo.get_modelist();

            var sqls = giveRightInfo.get_sql_list(result);

            if(giveRightInfo.reqType == giveRightInfo.REQ_CODE.NORMAL) {
                db_batch_data("dawh.db", sqls, [], function() {
                    giveRightInfo.dataDealCb(result); 
                    PubFuns.removeLoadingDialog();    
                }, giveRightInfo.fail_cb);
            }
            else {
                giveRightInfo.delete_database(function() {
                    db_batch_data("dawh.db", sqls, [], function() {
                        if(giveRightInfo.reqType == giveRightInfo.REQ_CODE.AUTO) {
                            PubFuns.removeLoadingDialog();
                        }
                        giveRightInfo.dataDealCb(result);     
                    }, giveRightInfo.fail_cb);
                });
            } 
        }
        
    },

    select_database_cb: function(tx, results) {
        if(results.rows.length > 0) {
            var len = results.rows.length;
            giveRightInfo.infos = [];
            for (var i = 0; i < len; i++) {
                var tempData = results.rows.item(i);
                giveRightInfo.infos.push(tempData);                         
            }
            giveRightInfo.dataDealCb(giveRightInfo.infos);  
            giveRightInfo.get_modelist();     
        }
        else {
            giveRightInfo.select("0000000");
        }
    },
    
    fail_cb: function() {
        // 提示失败
        PubFuns.removeLoadingDialog();
    },

    get_sql_list: function(data) {
        var len = data.length;
        var sqls = [];
        for (var i = 0; i < len; i++) {
            var tempData = data[i];
            var sql = "insert into GIVE_RIGHT(SYS_USER_NO, ORG_NO, AUTHORIZE_STATUS, AUTHORIZE_TYPE, AUTHORIZE_END, AUTHORIZE_BEGIN, "
                    + "ACT_CODE, P_DEPT_NANME, P_DEPT_NO, P_USER_NAME, P_USER_NO, SYS_USER_NAME, P_EMP_NO) values("
                    + "'" + tempData.SYS_USER_NO + "','" + tempData.ORG_NO + "','" + tempData.AUTHORIZE_STATUS 
                    + "','" + tempData.AUTHORIZE_TYPE + "','" + tempData.AUTHORIZE_END + "','" + tempData.AUTHORIZE_BEGIN + "','" + tempData.ACT_CODE 
                    + "','" + tempData.P_DEPT_NANME + "','" + tempData.P_DEPT_NO + "','" + tempData.P_USER_NAME + "','" + tempData.P_USER_NO 
                    + "','" + tempData.SYS_USER_NAME + "','" + tempData.P_EMP_NO + "')"; 
            sqls[i] = sql;
        }
        return sqls;
    },

    update_database: function(data, succCb) {
        var sql = "update GIVE_RIGHT set AUTHORIZE_END='" + data.AUTHORIZE_END + "', AUTHORIZE_BEGIN='" + data.AUTHORIZE_BEGIN 
                + "', P_DEPT_NANME='" + data.DEPT_NAME + "', P_DEPT_NO='" + data.DEPT_NO + "', P_USER_NAME='" + data.USER_NAME 
                + "', P_USER_NO='" + data.SYS_USER_NAME + "', P_EMP_NO='" + data.EMP_NO + "', AUTHORIZE_STATUS='" + data.AUTHORIZE_STATUS
                + "' where SYS_USER_NO='" + localStorage.user_name + "' and ACT_CODE='" + data.ACT_CODE + "'"; 

        for (var i = 0; i < giveRightInfo.infos.length; i++) {
            var temp = giveRightInfo.infos[i];
            if(temp.SYS_USER_NO == localStorage.user_name && temp.ACT_CODE == data.ACT_CODE) {
                temp.AUTHORIZE_END    = data.AUTHORIZE_END;
                temp.AUTHORIZE_BEGIN  = data.AUTHORIZE_BEGIN;
                temp.P_DEPT_NANME     = data.DEPT_NAME;
                temp.P_DEPT_NO        = data.DEPT_NO;
                temp.P_USER_NAME      = data.USER_NAME;
                temp.P_USER_NO        = data.SYS_USER_NAME;
                temp.P_EMP_NO         = data.EMP_NO;
                temp.AUTHORIZE_STATUS = data.AUTHORIZE_STATUS;
            }
        }
        db_execut_oneSQL("dawh.db", sql, [], succCb, giveRightInfo.fail_cb);
    },

    delete_database: function(succCb) {
        var sql = "delete from GIVE_RIGHT where SYS_USER_NO='" + localStorage.user_name + "'";
        db_execut_oneSQL("dawh.db", sql, [], succCb, giveRightInfo.fail_cb);
    },

    get_modelist: function() {
        var len = giveRightInfo.infos.length;
        var n = 1;
        giveRightInfo.modelList = {};
        giveRightInfo.timeList = {};
        giveRightInfo.modelList.p0 = "请选择";
        giveRightInfo.timeList.p0 = "请选择";

        var startDate = new Date();

        for (var i = 0; i < len; i++) {
            var tempInfo = giveRightInfo.infos[i];
            var name = giveRightInfo.get_name_by_catcode(tempInfo.ACT_CODE);

            var m = i + 1;
            giveRightInfo.modelList["p" + m] = name;

            if(tempInfo.AUTHORIZE_STATUS == "01" || tempInfo.AUTHORIZE_STATUS == "02") {
                
                var timeName = name;                

                if(tempInfo.AUTHORIZE_STATUS == "01") {
                    var endDate = new Date(tempInfo.AUTHORIZE_END);
                    var spaceTime = endDate.getTime() - startDate.getTime();
                    var h = Math.ceil(spaceTime/(3600*1000)); 
                   
                    if(h < 100 && h > 0){
                    	timeName += "(已授权 小于" + h + "小时)";
                    }else if(h >= 100){
                    	timeName += "(已授权)";
                    }else if(h <= 0){
                    	timeName += "(未授权)";
                    }/*modified by yuenhoa 20141216 : 增加判断，如果授权结束日期小于当前日期则判断为未授权*/
                    
                }else{
                	timeName += "(未授权)";
                }
                //var timeInfo = h > 8 ? "" : (" 小于" + h + "小时");
                //timeName += (tempInfo.AUTHORIZE_STATUS == "01" ? ("(已授权" + timeInfo + ")") : "(未授权)");

                giveRightInfo.timeList["p" + n] = timeName;

                n++;
            } 
        }
    },

    get_name_by_catcode: function(actCode) {
        var len = giveRightInfo.ACT_CODE.length;
        for (var i = 0; i < len; i++) {
            var temp = giveRightInfo.ACT_CODE[i];
            if(temp.KEY == actCode) {
                return temp.VALUE;
            }
        }
    }
};




