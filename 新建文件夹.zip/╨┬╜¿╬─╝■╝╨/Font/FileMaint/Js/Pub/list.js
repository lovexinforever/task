/**
 * Copy Right Information   : STATE GRID
 * author                   : wangjun
 * Comments                 : 列表公共控件
 * Version                  : 0.0.1
 * Modification history     : 2014-07-15
 */

/**
 *  点击list的每一项的回调函数
 *  调用流程是：先关闭弹出款，再调用用户传来的回调函数
 */
function list_item_click(id) {    
    $.cache["dialog"].close();
    if(list_item_click_callback != undefined && list_item_click_callback != null) {
        list_item_click_callback(id, list_userdata);    
    }    
}

/**
 * 用户自己的点击回调 
 */
var list_item_click_callback;   
var list_userdata;

/**
 * 初始化list
 * @param {JSON} data     列表数据
 * @param {String} title  列表标题
 * @param {Function} item_click_callback 列表项的点击回调
 */
function private_list_init(data, title, item_click_callback, bg_color) {
    var bgStyle = "";
    if(bg_color != undefined) {
        bgStyle = " " + bg_color;
    }
    var html = '<div class="dialog_box' + bgStyle + '"><div class="head">' + title + '</div>'
             + '<div class="body" id="dialog_box_scroll"><div>';
    var lastStr;
    list_item_click_callback = item_click_callback;  


    if(typeof(data) == "string") {
        data = JSON.parse(data);
    } 
    var index = 0;
    for(node in data) {            
        lastStr = '<div class="item listitem line" id="' + node + '_list_' + index + '">' + data[node] + '</div>';
        html += lastStr;
        index++;
    }
    html += '</div></div></div>';
    var reStr = lastStr.replace("item line", "item");    
    return html.replace(lastStr, reStr);
}

/**
 * 弹出list选择对话框 
 * @param {JSON} data     列表参数
 * @param {Object} args   用户数据
 */
function list_show(data, args) {
    list_userdata = args;
    if(typeof(data.data) == "string") {
        data.data = JSON.parse(data.data);
    }
    var html = private_list_init(data.data, data.title, data.item_click_callback, data.bgColor);
    $.Elec.dialog({        
        htmlObj: $(html),
        bgCallback: data.bgCallback,
        args: args
    });
    var index = 0;
    for(node in data.data) { 
        EventUtil.addClickListener({id: (node + "_list_" + index), clk: list_item_click, args: node});
        index++;
    }
}


/*****************使用例子*********************/
/*
当列表项大于8时列表就以滚动条的形式显示，该list不支持下拉刷新等操作。
list_show({
    data: {p1: "qwe", p2: "sdf", p3: "234", p4: "王俊", p5: "sdf", p6: "asdf", p7: "sdf", p8: "ssdf", p9: "sdf", p10: "ssdf"},
    title:"晚上都符合", 
    item_click_callback: function(id) {alert(id); },
    bgCallback: function() {alert("df");},
    bgColor: "white"
}, 
"wangjun");
*/

