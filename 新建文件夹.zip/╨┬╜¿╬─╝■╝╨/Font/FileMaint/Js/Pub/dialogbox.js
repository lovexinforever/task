/**
 * Copy Right Information   : STATE GRID
 * author                  	: wangjun
 * Comments                	: 弹出框公共控件
 * Version                 	: 0.0.1
 * Modification history    	: 2014-07-15
 * 1. 将setTextValue改名为setValue；将左右点击事件放到setValue函数的参数中        20140716 16:28
 * 2. 增加对话框的主题和item项的主题配置，并将show方法可以在setItemData后连级调用 20140718 14:21
 */
 
(function($){
    $.Elec = $.Elec || {};  
    $.Elec.dialogTemplate = {

    	html: '<div class="${style}">'
        		+ '<div class="${head.style}">${head.txt}</div>'
		        + '<div class="${body.style}">'
		            + '{@each body.items as it,index}'
		                + '<div {@if it.id != undefined}id="${it.id}"{@/if} class="${it.style}">'
                            + '{@if it.type == "text"}'
                                + '<div class="text">${it.data}</div>'
                            + '{@else if it.type == "title"}'
                                + '<div class="title">${it.data}</div>'       
		                    + '{@else if it.type == "singleKV"}'                  
		                        + '<div class="first">${it.data.key}</div><div class="second">${it.data.value}</div>'   
                            + '{@else if it.type == "singleKVWithBorder"}'                  
                                + '<div class="first selectborder_bottom">${it.data.key}</div><div class="second selectborder_bottom">${it.data.value}</div>'                      
		                    + '{@else if it.type == "doubleKV"}'
		                        + '<div class="first_key">${it.data[0].key}</div><div class="first_value">${it.data[0].value}</div>'
		                        + '<div class="second_key">${it.data[1].key}</div><div class="second_value">${it.data[1].value}</div>'
		                    + '{@else if it.type == "editbox"}'
		                        + '<div class="input">'
		                            + '<input type="text" style="width:100%" placeholder="${it.placeholder}" value="${it.value}" />'
		                        + '</div>'
		                    + '{@else if it.type == "password"}'
		                        + '<div class="input">'
		                            + '<input type="password" style="width:100%" placeholder="${it.placeholder}" value="${it.value}" />'
		                        + '</div>'
		                    + '{@else if it.type == "listbox"}'
		                        + '<div class="input">'
		                            + '<input type="text" readonly="true" placeholder="${it.placeholder}" value="${it.value}" />'
		                            + '<div class="arrow">'
		                                + '<img src="../../../Res/Images/arrow.png">'
		                            + '</div>'
		                        + '</div>'
	                        + '{@else if it.type == "listboxWithKey"}'
	                        	+'<div class="inputKey">${it.key}</div>'
		                        + '<div class="input withKey" id="${it.inputId}">'
		                            + '<input type="text" readonly="true" placeholder="${it.placeholder}" value="${it.value}" />'
		                            + '<div class="arrow">'
		                                + '<img src="../../../Res/Images/arrow.png">'
		                            + '</div>'
		                        + '</div>'
		                    + '{@else if it.type == "editboxWithKey"}'
		                    	+'<div class="inputKey">${it.key}</div>'
		                        + '<div class="input withKey">'
		                            + '<input type="text" style="width:100%" placeholder="${it.placeholder}" value="${it.value}" />'
		                        + '</div>'    
		                    + '{@else}<div>none</div>'
		                    + '{@/if}'
		                + '</div>'
		            + '{@/each}'
		        + '</div>'
		        + '<div class="${bottom.style}">'
		            + '{@if bottom.type == "doubleBtn"}'
		                + '<div class="${bottom.btn.style}" id="dialog_left_btn">'
		                    + '<div class="${bottom.btn.left.style}">${bottom.btn.left.txt}</div>'
		                + '</div>'
		                + '<div class="${bottom.btn.style}" id="dialog_right_btn">'
		                    + '<div class="${bottom.btn.right.style}">${bottom.btn.right.txt}</div>'
		                + '</div>'
		            + '{@/if}'
                    + '{@if bottom.type == "singleBtn"}'
                        + '<div class="single_btn" id="dialog_single_btn">'
                            + '<div class="${bottom.btn.style}">${bottom.btn.txt}</div>'
                        + '</div>'
                    + '{@/if}'
		        + '</div>'
		    + '</div>',
        data: {},

        defaultData: {
        	style: "dialog_box",          // 全局样式的名字

		    head: {                       // 头部样式设置
		        txt: "对话框模板",
		        style: "head",            // 头部的样式名字
		    },
		    
		    body: {                       // 内容样式设置
		        style: "body dialogbody", // 内容样式的名字
		        items: []                 // type:singleKV, doubleKV, editbox, password, listbox, password, text
		    },

		    bottom: {                     // 底部样式设置
		        type: "doubleBtn",        // singleBtn, doubleBtn
		        style: "bar", 
		        btn: {  
		            style: "btn",                  
		            left: {
                        args: [],
		            	clickCB: function() {},
		                style: "left_button btn_grey", 
		                txt: "取消"
		            },
		            right: {
                        args: [],
		            	clickCB: function() {},
		                style: "right_button btn_blue", 
		                txt: "确认"
		            }
		        }
		    },
            bg: {
                clickCB: function(){},
                args:[]
            }
		},

        /** 对话框主题存储数据 */
        dialogThemeData: {},

        /** 当前主题的数据 */
        currentData: null,

        /** 数据项的主题数据 */
        itemThemeData:{ singleKV: "item", 
                        singleKVWithBorder: "selectborder_item item selectBorder", 
                        doubleKV: "item", 
                        editbox: "item", 
                        listbox: "item", 
                        password: "item", 
                        text: "item",
                        title: "item title",
                        listboxWithKey: "item",
                        editboxWithKey : "item"},

        /** 左按钮的点击回调 */
        leftClickCB: function() {},

        /** 右按钮的点击回调 */
        rightClickCB: function() {},

        /** 单个按钮的点击回调 */
        singleBtnClickCB: function() {},
        
        /**
         * 设置默认的样式
         */
        addDialogTheme: function(name, jsonDef) {
            this.dialogThemeData[name] = jsonDef;
        },

        /**
         * 设置当前的主题
         */
        setCurrentTheme: function(name) {
            this.currentData = this.dialogThemeData[name];
        },

        /**
         * 设置项的主题
         */
        addItemTheme: function(jsonDef) {
            for (node in jsonDef) {
                itemThemeData[node] = jsonDef[node];
            }            
        },

        /**
         * 设置弹出框中的内容
         */
        setItemsData: function(data) {
            for (var i = 0; i < data.length; i++) {
                data[i].style = this.itemThemeData[data[i].type];
            }
        	this.data.body.items = data;
            return this;
        },

        /**
         * 设置左边按钮的点击事件
         */
        setLeftBtnClickCB: function(clickCB, args) {
        	this.leftClickCB = function() {
        		clickCB.apply(this, args);      		
        	};        	
        },

        /**
         * 设置右边按钮的点击事件
         */
        setRightBtnClickCB: function(clickCB, args) {
        	this.rightClickCB = function() {
        		clickCB.apply(this, args);
        	};  
        },

        /**
         * 设置单个按钮的点击事件
         */ 
        setSingleBtnClickCB: function(clickCB, args) {
            this.singleBtnClickCB = function() {
                clickCB.apply(this, args);
            };  
        },

        /**
         * 设置文本值
         * @param {JSON} txt
         */
        setValue: function(data) { 
            if(this.currentData == null) {
                this.data = this.defaultData;
            }
            else {
                this.data = this.currentData;
            }

        	if(data.head != undefined) {
        		this.data.head.txt = data.head;
                if(this.data.bottom.type == "singleBtn") {
                    if(data.btn != undefined) {
                        this.data.bottom.btn.clickCB =  data.btn.clickCB.func;
                        this.data.bottom.btn.args =  data.btn.clickCB.args || []; 

                        if(data.btn.txt != undefined) {
                            this.data.bottom.btn.txt = data.btn.txt;
                        }

                        if(data.btn.color != undefined) {
                            this.data.bottom.btn.style = "single_btn btn_" + data.btn.color; 
                        }
                    }

                }                
        	}
        	if(data.left != undefined) {
                if(data.left.txt != undefined) {
                    this.data.bottom.btn.left.txt = data.left.txt;
                }
        		if(data.left.color != undefined) {
                    this.data.bottom.btn.left.style = "left_button btn_" + data.left.color;
                }
                if(data.left.clickCB != undefined) {
                    this.data.bottom.btn.left.clickCB = data.left.clickCB.func || function(){};
                    this.data.bottom.btn.left.args = data.left.clickCB.args || [];
                }
        	}
        	if(data.right != undefined) {
        		if(data.right.txt != undefined) {
                    this.data.bottom.btn.right.txt = data.right.txt;
                }
                if(data.right.color!= undefined) {
                    this.data.bottom.btn.right.style = "right_button btn_" + data.right.color;
                }
                if(data.right.clickCB != undefined) {
                    this.data.bottom.btn.right.clickCB = data.right.clickCB.func || function(){};
                    this.data.bottom.btn.right.args = data.right.clickCB.args || [];
                }
        	}

            if(data.bg != undefined) {
                this.data.bg.clickCB = data.bg.func || function(){};
                this.data.bg.args = data.bg.args || [];          
            }
        },
        
        addBodyClass: function(className) {
        	$.Elec.dialogTemplate.data.body.style += (" " + className);
        },

        /**
         * 展示对话框
         */
        show: function() {            
            var str = juicer(this.html, this.data);
            
            $.Elec.dialog({        
		        htmlObj: $(str),
                bgCallback: this.data.bg.clickCB,
                args: this.data.bg.args
		    });

            if(this.data.bottom.type == "singleBtn") {
                EventUtil.addClickListener({id: "dialog_single_btn", clk: this.data.bottom.btn.clickCB, args: this.data.bottom.btn.args});                
            }
            
            if(this.data.bottom.type == "doubleBtn") {
                EventUtil.addClickListener({id: "dialog_left_btn", clk: this.data.bottom.btn.left.clickCB, args: this.data.bottom.btn.left.args});
                EventUtil.addClickListener({id: "dialog_right_btn", clk: this.data.bottom.btn.right.clickCB, args: this.data.bottom.btn.right.args});
            }

            this.currentData = null;
        }
    };

})(jQuery);

/****************************************使用说明************************************************
// 添加主题
$.Elec.dialogTemplate.addTheme("dialog", {
    style: "dialog_box",          // 全局样式的名字

    head: {                       // 头部样式设置
        txt: "对话框模板",
        style: "head",            // 头部的样式名字
    },
    
    body: {                       // 内容样式设置
        style: "body dialogbody", // 内容样式的名字
        items: []                 // type:singleKV, singleKVWithBorder, doubleKV, editbox, listbox, password, text
    },

    bottom: {                     // 底部样式设置
        type: "doubleBtn",        // singleBtn, doubleBtn
        style: "bar", 
        btn: {  
            style: "btn",                  
            left: {
                args: [],
                clickCB: function() {},
                style: "left_button btn_grey", 
                txt: "取消"
            },
            right: {
                args: [],
                clickCB: function() {},
                style: "right_button btn_blue", 
                txt: "确认"
            }
        }
    },
    bg: {
        clickCB: function(){},
        args:[]
    }
});

// 设置当前的主题
$.Elec.dialogTemplate.setCurrentTheme("dialog");
// 设置自己的主题
$.Elec.dialogTemplate.addItemTheme({"singleKV": "item"});

// 设置数据和点击事件
1. 两个按钮
$.Elec.dialogTemplate.setValue({head: "请求/延长授权认证", 
                                left:  {txt:"取消", color: "blue", clickCB:{func: function() {$.cache["dialog"].close();}, args:[]} },
                                right: {txt:"授权", color: "grey", clickCB:{func: grUI.delay_giveright, args:[]}}    
                                bg: {func:grUI.delay_giveright, args:[]});
2. 一个按钮
$.Elec.dialogTemplate.setValue({head: "取消授权", btn: {clickCB:{func: function() {$.cache["dialog"].close();}}}});

$.Elec.dialogTemplate.setItemsData([
    {
        id: "key0",                               // 增加item的id，以便用户增加点击事件
        type: "singleKV",                         // singleKV, singleKVWithBorder, doubleKV, editbox, listbox, password, text
        //style: "item",                            // 样式的名字
        data: {key: "用户姓名", value: "宋剑峰"}
    },
    {
        type: "text",
        //style: "item",
        data: "rrrrr"
    },
    {
        id: "key1",
        type: "singleKVWithBorder",               
        //style: "selectborder_item item selectBorder",          
        data: {key: "用户姓名", value: "宋剑峰"}
    },
    {
        id: "key2",
        type: "doubleKV",   
        //style: "item",          
        data: [{key: "工号", value: "0000001"},{key: "结束时间", value: "2014-07-01"}]
    },
    {
        id: "key3",
        type: "listbox", 
        //style: "item", 
        placeholder: "请选择授权有效时间",
        value: "9"
    },
    {
        id: "key4",
        type: "editbox", 
        //style: "item", 
        placeholder: "请选择授权有效时间",
        value: "9"
    },
    {
        id: "key5",
        type: "password", 
        //style: "item", 
        placeholder: "请选择授权有效时间",
        value: "9"
    }
]).show();

// 设置自定义的左右按钮点击事件(不建议使用这种方式，请使用$.Elec.dialogTemplate.setValue函数)
$.Elec.dialogTemplate.setLeftBtnClickCB(function() {$.cache["dialog"].close();});
$.Elec.dialogTemplate.setRightBtnClickCB(grUI.delay_giveright);
// 展示对话框 该方法可以在setItemsData的方法后面连级调用
$.Elec.dialogTemplate.show();
***************************************************************************************/


