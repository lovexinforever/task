/*
 * Electric Mobile Framework 1.0
 *
 * Copyright 2014 (c) Electric Mobile Project
 * Author : XBB Start By 2014/02/11
 */
(function(w, $) {
    /**
     * 是否支持Touch事件
     */
    var supportTouch = "ontouchstart" in document ? true : false;//document.hasOwnProperty("ontouchstart");
    
    /**
     *  是否使用touch模拟单击
     */
    var useTouchForClick = false;
    
    /**
     * 模块管理对象
     */
    var module = {
        /**
         * 对模块进行输出，供页面调用
         *
         * @param id
         *            {String} 模块ID
         * @param expObj
         *            {Object} 模块对象
         */
        exports : function(id, expObj) {
            if(w[id] == null || w[id] == undefined || typeof w[id] != "object")
                w[id] = expObj;
        }
    };
    /**
     * Module:框架模块共用代码库
     */
    var Elec = {
        /**
         * 判断是否存在jQuery库
         *
         * @return {Boolean} true代表页面引用jQuery库  false表示不存在
         */
        hasJquery : function() {
            if(null != $ && undefined != $) {
                return true;
            }
            return false;
        },
        /**
         * 根据元素ID获取DOM对象
         *
         * @param id
         *            {String}  DOM元素ID
         * @return {HTMLElement}  DOM对象
         */
        getELeById : function(id) {
            return document.getElementById(id);
        },
        /**
         * 将 Undefined的替换为空字符
         *
         * @param str
         * @return {String}
         */
        setUndefined : function(str) {
            if(!str || str == "undefined" || str == "null") {
                return "";
            }
            return str;
        },
        canClick:true,
        /**
         * 判断变量是否已定义,是否为null
         *
         * @param pam
         * @return {Boolean}
         */
        isUndefined : function(pam) {
            if(pam == undefined || pam == null) {
                return true;
            }
            return false;
        },
        /**
          *  获取jq对象的id
          *  自动增加id
          *  @param obj 
          *  @return {String}
          */
        getIdByJqueryObj:function(obj){
            if(typeof obj !== "object") return ;
            var id = obj.attr("id") || (new Date().getTime());
            obj.attr("id",id);
            return id+"";
        }
    };
    module.exports("Elec", Elec);
    /**
     * 页面被唤醒时候进行回调 只需要在所在页面中定义onResume函数
     */
    document.addEventListener("resume", function() {
        if(window.onResume)
            onResume();
    }, false);
    /**
     * 页面被暂停时候进行回调 只需要在所在页面中定义onPause函数
     */
    document.addEventListener("pause", function() {
        if(window.onPause)
            onPause();
    }, false);
    /**
     * 初始化对页面中的Input,Select,TextArea取消默认滚动行为
     */
    document.ontouchmove = function(e) {
        var nodeName = e.srcElement.nodeName;
        if(nodeName != "INPUT" && nodeName != "SELECT" && nodeName != "TEXTAREA") {
            e.preventDefault();
        }
    };

    document.onmousedown = function(event){
        if(!Elec.canClick && event.target.nodeName === "INPUT")
        {
            event.stopPropagation();
            event.preventDefault();
            return false;
        }
    }
    /**
     * Module:EventUtil 页面上的点击,滑动等事件管理工具库
     */
    var EventUtil = {
        /**
         * 防止单击变双击标记
         */
        flag:true,
        /**
         * 使用TouchStart,TouchMove,TouchEnd实现的点击事件 默认的 Click点击事件 会有延迟
         */
        DISTANCE_XY : 15,
        MIN_MOVE_X : 20,
        MIN_MOVE_Y : 20,
        VERTICALDIS : 125,
        /**
         * 左右上下滑动事件标识
         * swipeLeft:左滑  swipeRight:右滑  swipeUp:上滑 swipeDown:下滑
         */
        SWIPE : {
            swipeLeft : "swipeLeft",
            swipeRight : "swipeRight",
            swipeUp : "swipeUp",
            swipeDown : "swipeDown"
        },
        /**
         * 添加Touch模式的点击事件
         * 
         * options
         *
         * @param options.id
         *            {String}  DOM元素ID / {Object}  DOM元素
         * @param  options.clk
         *            {Function}  回调函数
         * @param  options.actcls
         *            {String}  点击时候的样式
         * @param  options.args
         *            {Array}  事件触发传递的参数数组
         * @param  options.useTouch
         *            {Boolean}  是否使用touch模拟点击事件
         */
        addClickListener : function(options) {
            //对内容进行扩展 名称未变
            options.eventEle = typeof options.id === "object" ?  options.id : Elec.getELeById(options.id);
            if(!options.eventEle) throw "element is none";
            options.eventEle.eventName = ( supportTouch && options.useTouch ) ? "touchstart" : "click";
            options.eventEle.fun = function(op){
                if(op.eventEle.eventName == "click")
                {
                    return function(){
                        if(EventUtil.flag){
                            EventUtil.flag = false;
                            op.clk.call(op.eventEle,op.args);
                            setTimeout(function(){
                                EventUtil.flag = true;
                            },500)
                        }    
                    }
                }
                else
                {
                    return function() {
                        EventUtil.handleTSEvent(op.eventEle, op.clk, op.actcls, op.args);
                    };
                }
            }(options);
            options.eventEle.addEventListener(options.eventEle.eventName, options.eventEle.fun, false);
        }, 
        /**
         * 移除Touch模式的点击事件
         *
         * @param id
         *            {String}  DOM元素ID / {Object}  DOM元素
         */
        remveClickListener: function(id){
           var eventEle = typeof id === "object" ?  id : Elec.getELeById(id);
           if(!!!eventEle || eventEle === "") return ;
           eventEle.removeEventListener(eventEle.eventName,eventEle.fun,false);
           
           delete eventEle.eventName;
           delete eventEle.fun; 
        },

        /**
         * 避免真正的触发Click事件
         */
        handleOnClick : function() {
            event.stopPropagation();
        },
        /**
         * 事件重置,取消已经绑定的touch类型事件
         * @param target
         *            {HTMLElement}  DOM元素对象
         * @param activeCls
         *            {String}  点击时候的样式
         */
        reset : function(target, activeCls) {
            target.classList.remove(activeCls);
            target.removeEventListener("touchmove", target.handleTMEvent_Dep, false);
            target.removeEventListener("touchend", target.handleTEEvent_Dep, false);
            target.handleTMEvent_Dep = null;
            target.handleTEEvent_Dep = null;
        },
        /**
         * 元素触摸开始事件处理
         * @param target
         *           {HTMLElement} DOM元素对象
         * @param ck
         *           {Function} 回调函数
         * @param activeCls
         *           {String} 点击时候的样式
         * @param ags
         *           {Array} 事件触发传递的参数数组
         */
        handleTSEvent : function(target, ck, activeCls, ags) {
            if(event.targetTouches.length == 1) {
                var eventEle = target;
                event.stopPropagation();
                if(!Elec.isUndefined(activeCls)) {
                    eventEle.classList.add(activeCls);
                }
                var touch = event.targetTouches[0];
                var startX = touch.pageX;
                var startY = touch.pageY;
                //创建元素触摸移动事件的代理事件处理器
                var handleTMEvent_Dep = function(startX, startY, target, activeCls) {
                    return function() {
                        target.handleTMEvent_Dep = handleTMEvent_Dep;
                        EventUtil.handleTMEvent(startX, startY, target, activeCls);
                    };
                }(startX, startY, target, activeCls);
                //创建元素触摸结束事件的代理事件处理器
                var handleTEEvent_Dep = function(startX, startY, target, activeCls, ck, ags) {
                    return function() {
                        target.handleTEEvent_Dep = handleTEEvent_Dep;
                        EventUtil.handleTEEvent(startX, startY, target, activeCls, ck, ags);
                    };
                }(startX, startY, target, activeCls, ck, ags);
                eventEle.addEventListener("touchmove", handleTMEvent_Dep, false);
                eventEle.addEventListener("touchend", handleTEEvent_Dep, false);
            }
        },
        /**
         * 触摸移动事件处理函数
         * @param startX
         *            {Number} 触摸开始的X坐标
         * @param startY
         *            {Number} 触摸开始的Y坐标
         * @param target
         *            {HTMLElement} DOM元素对象
         * @param activeCls
         *            {String} 点击时候的样式
         */
        handleTMEvent : function(startX, startY, target, activeCls) {
            var mvtouch = event.targetTouches[0];
            if(Math.abs(mvtouch.pageX - startX) > EventUtil.DISTANCE_XY || Math.abs(mvtouch.pageY - startY) > EventUtil.DISTANCE_XY) {
                EventUtil.reset(target, activeCls);
            }
        },
        /**
         * 触摸结束事件处理函数
         * @param startX
         *            {Number} 触摸开始的X坐标
         * @param startY
         *            {Number} 触摸开始的Y坐标
         * @param target
         *            {HTMLElement} DOM元素对象
         * @param activeCls
         *            {String} 点击时候的样式
         * @param callback
         *            {Function} 回调函数
         * @param args
         *            {Array} 事件触发传递的参数数组
         */
        handleTEEvent : function(startX, startY, target, activeCls, callback, args) {
            var touched = event.changedTouches[0];
            var endX = touched.pageX;
            var endY = touched.pageY;
            if(Math.abs(endX - startX) < EventUtil.DISTANCE_XY && Math.abs(endY - startY) < EventUtil.DISTANCE_XY) {
                EventUtil.reset(target, activeCls);
                callback.apply(target, args);
                
                //开启单击事件阻塞
                Elec.canClick = false;
                setTimeout(function(){Elec.canClick = true},300);
            }
        },
        /**
         * 左右上下 滑动事件处理函数
         * @param id
         *            {String} DOM元素ID
         * @param clk
         *            {Object} 回调函数处理对象
         */
        touchSwipe : function(id, clk) {
            var ele = Elec.getELeById(id);
            if(supportTouch) {
                var touchswipestart_Dep = function(clk, ele) {
                    return function() {
                        EventUtil.touchswipestart(clk, ele);
                    };
                }(clk, ele);
                ele.addEventListener("touchstart", touchswipestart_Dep, false);
            }
        },
        /**
         * 滑动开始事件处理函数
         * @param clk
         *            {Object} 回调函数处理对象
         * @param ele
         *            {HTMLElement} DOM对象
         */
        touchswipestart : function(clk, ele) {
            if(event.targetTouches.length == 1) {
                var touch = event.targetTouches[0];
                var swipestartX = touch.pageX;
                var swipestartY = touch.pageY;
                var touchswipestart_Dep = function(swipestartX, swipestartY, clk) {
                    return function() {
                        ele.touchswipestart_Dep = touchswipestart_Dep;
                        EventUtil.touchswipeend(swipestartX, swipestartY, clk, ele);
                    };
                }(swipestartX, swipestartY, clk);
                ele.addEventListener("touchend", touchswipestart_Dep, false);
            }
        },
        /**
         * 滑动结束后根据滑动的方向调用相应的回调函数
         * @param swipetype
         *            {String} 触摸滑动的方向
         * @param fun_calls
         *            {Object} 回调函数处理对象
         */
        touchswipetrigger : function(swipetype, fun_calls) {
            if(fun_calls[EventUtil.SWIPE[swipetype]])
                fun_calls[EventUtil.SWIPE[swipetype]].call(this);
            EventUtil.swipestartX = EventUtil.swipestartY = undefined;
        },
        /**
         * 滑动结束事件处理函数
         * @param swipestartX
         *            {Number} 触摸开始的X坐标
         * @param swipestartY
         *            {Number} 触摸开始的Y坐标
         * @param fun_calls
         *            {Object} 回调函数处理对象
         * @param target
         *            {HTMLElement} 目标DOM对象
         */
        touchswipeend : function(swipestartX, swipestartY, fun_calls, target) {
            if(event.changedTouches.length == 1) {
                var touched = event.changedTouches[0];
                var endX = touched.pageX;
                var endY = touched.pageY;
                var p = endX - swipestartX;
                var n = endY - swipestartY;
                target.removeEventListener("touchend", target.touchswipestart_Dep, false);
                target.touchswipestart_Dep = null;
                if(Math.abs(p) >= EventUtil.MIN_MOVE_X && Math.abs(n) < EventUtil.VERTICALDIS) {
                    EventUtil.touchswipetrigger(p < 0 ? EventUtil.SWIPE.swipeLeft : EventUtil.SWIPE.swipeRight, fun_calls);
                } else {
                    if(Math.abs(n) >= EventUtil.MIN_MOVE_Y) {
                        EventUtil.touchswipetrigger(n < 0 ? EventUtil.SWIPE.swipeUp : EventUtil.SWIPE.swipeDown, fun_calls);
                    }
                }
            }
        }
    };
    module.exports("EventUtil", EventUtil);
    /**
     * Module:HTML应用层处理模块
     * @param pageOneId
     *                 {String} 主页面ID
     * @param pageTwoId
     *                 {String} 切换页面时页面存放容器ID
     */
    var pagechangescroll = true;
    var HtmlApplication = function(pageOneId, pageTwoId) {
        if(Elec.isUndefined(pageOneId))
            this.pageOneId = "dx-viewport-one";
        else
            this.pageOneId = pageOneId;
        if(Elec.isUndefined(pageTwoId))
            this.pageTwoId = "dx-viewport-two";
        else
            this.pageTwoId = pageTwoId;
    };
    /**
     * 根据页面的名称获取导航对象
     * @param pagename
     *            {String} 页面名称
     * @return {Object} 页面导航对象
     */
    HtmlApplication.prototype.getNavigationItem = function(pagename) {
        var len = window.AppConfig.navigation.length;
        var item = null;
        var i = 0;
        do {
            if(window.AppConfig.navigation[i].name == pagename) {
                item = window.AppConfig.navigation[i];
                break;
            }
            i++;
        } while(i<len)
        return item;
    };
    /**
     * 切换页面，Load子页面内容
     * @param parm
     *            {Object} 切换到下一个页面的配置参数
     */
    HtmlApplication.prototype.changepage = function(parm) {
        var pagename = null, loaded = null;
        if( typeof parm == "string")
            pagename = parm;
        if( typeof parm == "object")
            pagename = parm["name"], loaded = parm["loaded"]
        if(Elec.isUndefined(pagename)) {
            throw new Error("The PageName is Undefined");
            return;
        }
        if(pagechangescroll) {
            pagechangescroll = false;
            /**
             * hideELeID :HIDE Element ID
             * parendIdf :Load Element ID
             */
            var cleartime = 100, hideELeID, parendIdf, pageobj = this.getNavigationItem(pagename), dxshow = null, dxhide = null;

            if(Elec.isUndefined(pageobj)) {
                throw new Error("Not Find PageName:" + pagename + " in app.config.js");
                return;
            }
            var pageOneEle = Elec.getELeById(this.pageOneId);

            if(pageOneEle.classList.contains("dx-show")) {
                hideELeID = this.pageOneId;
                parendIdf = this.pageTwoId;
            } else {
                hideELeID = this.pageTwoId;
                parendIdf = this.pageOneId;
            }

            window.scrollTo(0, 0);
            if(Elec.isUndefined(pageobj.uri)) {
                throw new Error("Not Find PageUri " + "in app.config.js By PageName:" + pagename);
                return;
            }

            $("#" + parendIdf).load(pageobj.uri);

            var parendidfEle = Elec.getELeById(parendIdf);

            var hideELe = Elec.getELeById(hideELeID);

            /**
             * 改变CSS以及样式 实现动画效果
             */
            parendidfEle.classList.remove("dx-hide");
            parendidfEle.classList.add("dx-show");

            /**
             * 下一页面加载完成后回调
             */
            var animationEnd = function() {
                pagechangescroll = true;
                $("#" + hideELeID + " *").remove();

                hideELe.classList.remove(dxhide);
                parendidfEle.classList.remove(dxshow);
                parendidfEle.removeEventListener("webkitAnimationEnd", animationEnd, false);

                if(!Elec.isUndefined(loaded)) {
                    loaded.call(this);
                }
            }
            /**
             * 添加webkitAnimationEnd事件，监听动画结束
             */
            parendidfEle.removeEventListener("webkitAnimationEnd", animationEnd, false);
            parendidfEle.addEventListener("webkitAnimationEnd", animationEnd, false);

            pageobj.animation = pageobj.animation == undefined ? window.AppConfig.navigationType : pageobj.animation;
            var pageAnim = window.AppConfig.animations[pageobj.animation];
            /**
             * 实现加载页面的动画效果
             */
            if(!Elec.isUndefined(pageobj.animation) && !Elec.isUndefined(pageAnim)) {
                if(!Elec.isUndefined(pageAnim.dx_show))
                    dxshow = pageAnim.dx_show.dx_class;
                if(!Elec.isUndefined(pageAnim.dx_hide))
                    dxhide = pageAnim.dx_hide.dx_class;

                if(null != dxhide) {
                    parendidfEle.classList.remove(dxhide);
                    hideELe.classList.add(dxhide);
                }
                if(null != dxshow) {
                    hideELe.classList.remove(dxshow);
                    parendidfEle.classList.add(dxshow);
                }
            }
            setTimeout(function() {
                hideELe.classList.remove("dx-show");
                hideELe.classList.add("dx-hide");
            }, cleartime);
        }
    };
    module.exports("HtmlApplication", HtmlApplication);
})(window, jQuery);
