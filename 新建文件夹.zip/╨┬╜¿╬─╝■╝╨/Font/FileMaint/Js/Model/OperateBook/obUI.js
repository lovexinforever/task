/**
 * Copy Right Information  : STATE GRID
 * author                  	: yuenhoawong
 * Comments                	: 操作说明
 * Version                 	: 0.0.1
 * Modification history    	: 2014-05-04
 * Sr	Date        Modified By     Why & What is modified
 * 1.	2014-05-04  yuenhoawong    new file
 */

/**
 * 初始化页面
 */
var obUI = {
	/**
	 * 初始化页面
	 */
	init : function(){
		
		/*隐藏标题栏增加按钮，更改标题栏标题*/
		util.moblie.navbar.title = "操作说明";
        util.moblie.navbar.buttonList = ["back","menu"];// 可选参数：add back home
        
        /*navbarBack 和  navbarHome(nvabar.html) 指向自定义方法*/
		navbarBack = this.btn_back_click;
		//navbarMenu = this.btn_menu_click;
	},
	/**
	 * title返回按钮点击事件
	 */
	btn_back_click : function(){
		$("#dx-viewport-one").load("../Main/mainContent.html");
	},
	/**
	 * title菜单按钮点击事件
	 */
	btn_menu_click : function(){
		alert('btn_menu_click');
	}
}
obUI.init();