/**************
 * 合同审核
 */

var appno = sessionStorage.amAPP_NO;
var selectShjgData = {'01':'通过','02':'不通过'};//审核结果

var nmScroll=null;//滚动条
var nmScrDom = null;

/**
 * 初始化页面
 */
var nmBAUI = {
	/**
	 * 初始化页面
	 */
	init : function(){
		navbarBack = this.btn_back_click;
		navbarHome = this.btn_menu_click;
		nmBAUI.set_btn_clickfun();
		util.moblie.navbar.title = "更名-合同审核";
		util.moblie.navbar.buttonList = ["back","menu"];
		
		pubData.initdata(appno);
		nmQuery.queryDataFromTable('YK_210_CONTRACT_APPROVE',appno,nmBAUI.successQueryBargainAudit,pubData.failNmo);
		publicUIShow.nmScrools("nmScrollM");
	},
	/**
	 * 设置‘查看/收起更多信息’按钮点击事件
	 */
	set_btn_clickfun : function(){
		publicUIShow.btn_seemoreless_click("nmba_btn_seemoreless");//查看更多详情
		
		EventUtil.addClickListener({id:"nmBA_next",clk:function(){
			nmBAUI.btn_goto_barginsub();//任务传递
		}});
		EventUtil.addClickListener({id:"nmBA_save",clk:function(){
			nmBAUI.btn_save_barginaudit(function(){
				publicUIShow.amDialog("保存成功",1);
			});//保存
		}});
		EventUtil.addClickListener({id:"nmba_APPR_RSLT",clk:function(){
			nmBAUI.showSelectShjg();//审核结果
		}});
		EventUtil.addClickListener({
			id : "nmba_APPR_DATE",
			clk : function() {
				dateSelectFun.getDatetime({id:"nmba_APPR_DATE",type:"1"});//审核时间
			}
		});
		
	},
	/**
	 * 标题栏返回按钮
	 */
	btn_back_click : function(){
		$("#dx-viewport-one").load("../NameModify/index.html");
	},
	/***
	 * 合同审核数据库成功回调
	 */
	successQueryBargainAudit : function(tx, res){
		var len = res.rows.length;
		if(len > 0){
			var xs = res.rows.item(0);
			for(var key in xs){
				pubData.showInputOfJson('#nmba_',key,xs);
			}
			
			$("#nmba_APPR_RSLT").attr("nid",xs['APPR_RSLT']);
			if(xs['APPR_RSLT'] == '01')
				$("#nmba_APPR_RSLT").val("通过");
			else if(xs['APPR_RSLT'] == '02')
				$("#nmba_APPR_RSLT").val("不通过");
				
			$("#nmba_STATUS_CODE").val("待审");
			$("#nmba_STATUS_CODE").attr("nid","02");
				
			//供电单位转码
			nmQuery.queryOorgtoString('nmba_ORG_NO',xs['ORG_NO'],function(tx,res){
				var len = res.rows.length;
				if(len>0){
					$("#nmba_ORG_NO").val(res.rows.item(0)['ORG_NAME']);
					$("#nmba_ORG_NO").attr("nid",res.rows.item(0)['ORG_NO']);
				}
			},pubData.failNmo);
			
			//pcode数据转码
			nmQuery.showPcodeToValue(pubData.pcodeHtshArrayReturn(xs));
		}
	},
	showSelectShjg : function(){//审核结果弹出框
		list_show({data:selectShjgData, 
          title:'审核结果', 
          item_click_callback:function(id) {
          	$("#nmba_APPR_RSLT").val(selectShjgData[id]);
          	$("#nmba_APPR_RSLT").attr("nid",id);
          	}, 
          bgCallback:function() {$.cache["dialog"].close();}},"");
	},
	/****
	 * 合同审核任务传递
	 */
	btn_goto_barginsub:function(){
		
		nmBAUI.btn_save_barginaudit(function(){
			
			if(nmBAUI.checkNullOrType()){
				nmQuery.queryDataFromTable('YK_210_CONTRACT_APPROVE',appno, function(tx, res) {
						var len = res.rows.length;
						if (len != 0) {// 本地未查询
							var xs = res.rows.item(0);
							var htsh = "'APP_NO':'"+xs['APP_NO']+"', 'APPR_ID':'"+xs['APPR_ID']+"', 'ORG_NO':'"+xs['ORG_NO']+"', 'DEPT_NO':'"+xs['DEPT_NO']+"', 'APPROVER_NAME':'"+xs['APPROVER_NAME']+"','APPROVER_NAME_NAME':'"+xs['APPROVER_NAME_NAME']+"', 'APPR_DATE':'"+xs['APPR_DATE']+"', 'APPR_RSLT':'"+xs['APPR_RSLT']+"', 'APPR_OPINION':'"+xs['APPR_OPINION']+"'";
							var task = "'ORGNO':'"+sessionStorage.ORG_NO+"', 'SYS_USER_NAME':'"+sessionStorage.user_name+"', 'APP_NO':'"+sessionStorage.amAPP_NO+"', 'INSTANCE_ID':'"+sessionStorage.INSTANCE_ID+"', 'SQ_USER_NAME':'"+sessionStorage.shouquanUserNo+"'";
							
							netRequest.rwcdHtshMsg(htsh,task,netRequest.successHtshTaskCallBack, netRequest.faileCallBack);
						}
					}, pubData.failNmo);
			}
		});
		
	},
	/***
	 * 合同审核数据保存
	 */
	btn_save_barginaudit:function(callback){
		var htshsql = " ORG_NO='"+$("#nmba_ORG_NO").attr("nid")+"',APPROVER_NAME='"+$("#nmba_APPROVER_NAME").val()+"',APPROVER_NAME_NAME='"+$("#nmba_APPROVER_NAME_NAME").val()+"',DEPT_NAME='"+$("#nmba_DEPT_NAME").val()+"',STATUS_CODE='02',APPR_VERI_FLAG='"+$("#nmba_APPR_VERI_FLAG").attr("nid")+"',APPR_DATE='"+$("#nmba_APPR_DATE").val()+"',APPR_RSLT='"+$("#nmba_APPR_RSLT").attr("nid")+"',APPR_OPINION='"+$("#nmba_APPR_OPINION").val()+"' ";
		nmUpdate.updateDataFromTable('YK_210_CONTRACT_APPROVE',htshsql,appno, 
		function(){
			callback();
		}, 
		pubData.failNmo);
	},
	/***
	 * 界面数据检测 非空判断等
	 */
	checkNullOrType : function(){
		var tipStr = "";
		
		
		var APPR_DATE = document.getElementById("nmba_APPR_DATE").value;
		var APPR_OPINION = document.getElementById("nmba_APPR_OPINION").value;
		
		if(APPR_DATE == ""){
			tipStr = "审核时间不能为空";
		}else if(APPR_OPINION == "") {
			tipStr = "审核意见不能为空";
		}
		if(tipStr != "") {
			publicUIShow.amDialog(tipStr, 1);
			return false;
		}
		return true;
	}
	
}

nmBAUI.init();
