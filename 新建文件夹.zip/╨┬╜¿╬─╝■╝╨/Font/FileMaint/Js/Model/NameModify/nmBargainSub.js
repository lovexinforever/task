/*********
 * 合同签订
 */
var selectDffsData;//答复方式
var selectXqbzData = {'01' : '是','02':'否'};
var selectWbxsData = {'01' : '文本形式'};
var selectCzlxData;//操作类型
var selectHtflData;//合同分类
var selectHtlxData;//合同类型

var nmScroll=null;//滚动条
var nmScrDom = null;

var appno = sessionStorage.amAPP_NO;
/**
 * 初始化页面
 */
var nmBSUI = {
	/**
	 * 初始化页面
	 */
	init : function(){
		navbarBack = this.btn_back_click;
		navbarHome = this.btn_menu_click;
		
		nmBSUI.set_btn_clickfun();
		util.moblie.navbar.title = "更名-合同签订";
		util.moblie.navbar.buttonList = ["back","menu"];
		pubData.initdata(appno);
		nmQuery.queryDataFromTable('YK_210_CONTRACT_SIGN',appno,nmBSUI.successQueryBargainSub,pubData.failNmo);
		
		//答复方式pcode转码
		nmQuery.queryPcode("15001",function(tx,res){
			selectDffsData = JSON.parse(pubData.pcodeSuccess(tx,res));
		},pubData.failNmo);
		//操作类型pcode专门
		nmQuery.queryPcode("12004",function(tx,res){
			selectCzlxData = JSON.parse(pubData.pcodeSuccess(tx,res));
		},pubData.failNmo);
		//合同分类pcode转码
		nmQuery.queryPcode("12006",function(tx,res){
			selectHtflData = JSON.parse(pubData.pcodeSuccess(tx,res));
		},pubData.failNmo);
		//合同类型pcode转码
		nmQuery.queryPcode("12001",function(tx,res){
			selectHtlxData = JSON.parse(pubData.pcodeSuccess(tx,res));
		},pubData.failNmo);
		publicUIShow.nmScrools("nmScrollM");
	},
	/**
	 * 设置‘查看/收起更多信息’按钮点击事件
	 */
	set_btn_clickfun : function(){
		publicUIShow.btn_seemoreless_click("nmbs_btn_seemoreless");
		
		EventUtil.addClickListener({id:"nmBS_next",clk:function(){
			nmBSUI.btn_goto_index();//合同签订 任务传递
		}});
		EventUtil.addClickListener({id:"nmBS_save",clk:function(){
			nmBSUI.btn_save_bargainsub(function(){
				publicUIShow.amDialog("保存成功",1);
			});
		}});
		EventUtil.addClickListener({id:"nmbs_REPLY_MODE",clk:function(){
			nmBSUI.showSelectDffs();//答复方式
		}});
		EventUtil.addClickListener({id:"nmbs_REPLY_TYPE",clk:function(){
			nmBSUI.showSelectHffs();
		}});
		EventUtil.addClickListener({id:"nmbs_RENEW_FLAG",clk:function(){
			nmBSUI.showSelectXqbz();
		}});
		EventUtil.addClickListener({id:"nmbs_FORMAT_CODE",clk:function(){
			nmBSUI.showSelectWbxs();
		}});
		/*EventUtil.addClickListener({id:"nmbs_OPER_TYPE_CODE",clk:function(){
			nmBSUI.showSelectCzlx();//操作类型
		}});*/
		EventUtil.addClickListener({
			id : "nmbs_SIGN_DATE_CUST",
			clk : function() {
				dateSelectFun.getDatetime({id:"nmbs_SIGN_DATE_CUST",type:"1"});//客户签收时间
			}
		});
		EventUtil.addClickListener({
			id : "nmbs_REPLY_DATE",
			clk : function() {
				dateSelectFun.getDatetime({id:"nmbs_REPLY_DATE",type:"1"});//答复日期
			}
		});
		EventUtil.addClickListener({
			id : "nmbs_REPLY_TIME",
			clk : function() {
				dateSelectFun.getDatetime({id:"nmbs_REPLY_TIME",type:"1"});//客户回复时间
			}
		});
		
		EventUtil.addClickListener({
			id : "nmbs_END_DATE",
			clk : function() {
				dateSelectFun.getDatetime({id:"nmbs_END_DATE",type:"1"});//客户回复时间
			}
		});
	},
	/**
	 * 标题栏返回按钮
	 */
	btn_back_click : function(){
		$("#dx-viewport-one").load("../NameModify/index.html");
	},
	successQueryBargainSub : function(tx, res){
		var len = res.rows.length;
		if(len > 0){
			var xs = res.rows.item(0);
			for(var key in xs){
				pubData.showInputOfJson('#nmbs_',key,xs);
			}
			
			$("#nmbs_RENEW_FLAG").attr("nid",xs['RENEW_FLAG']);
			if(xs['RENEW_FLAG'] == '1'){
				$("#nmbs_RENEW_FLAG").val("是");
			}else if(xs['RENEW_FLAG'] == '2'){
				$("#nmbs_RENEW_FLAG").val("否");
			}
			$("#nmbs_FORMAT_CODE").val("标准化文本");
			$("#nmbs_FORMAT_CODE").attr("nid","01");
			nmQuery.showPcodeToValue(pubData.pcodeHtqdArrayReturn(xs));
			
		}
	},
	showSelectDffs : function(){
		list_show({data:selectDffsData, 
          title:'答复方式', 
          item_click_callback:function(id) {
          	$("#nmbs_REPLY_MODE").val(selectDffsData[id]);
          	$("#nmbs_REPLY_MODE").attr("nid",id);
          }, 
          bgCallback:function() {$.cache["dialog"].close();}},"");
	},
	showSelectHffs : function(){
		list_show({data:selectDffsData, 
          title:'回复方式', 
          item_click_callback:function(id) {
          	$("#nmbs_REPLY_TYPE").val(selectDffsData[id]);
          	$("#nmbs_REPLY_TYPE").attr("nid",id);
          }, 
          bgCallback:function() {$.cache["dialog"].close();}},"");
	},
	showSelectXqbz : function(){
		list_show({data:selectXqbzData, 
          title:'合同自动续签标志', 
          item_click_callback:function(id) {
          	$("#nmbs_RENEW_FLAG").val(selectXqbzData[id]);
          	$("#nmbs_RENEW_FLAG").attr("nid",id);
          }, 
          bgCallback:function() {$.cache["dialog"].close();}},"");
	},
	showSelectWbxs : function(){
		list_show({data:selectWbxsData, 
          title:'合同文本形式', 
          item_click_callback:function(id) {
          	$("#nmbs_FORMAT_CODE").val(selectWbxsData[id]);
          	$("#nmbs_FORMAT_CODE").attr("nid",id);
          }, 
          bgCallback:function() {$.cache["dialog"].close();}},"");
	},
	showSelectCzlx : function(){
		list_show({data:selectCzlxData, 
          title:'操作类型', 
          item_click_callback:function(id) {
          	$("#nmbs_OPER_TYPE_CODE").val(selectCzlxData[id]);
          	$("#nmbs_OPER_TYPE_CODE").attr("nid",id);
          }, 
          bgCallback:function() {$.cache["dialog"].close();}},"");
	},
	showSelectHtfl : function(){
		list_show({data:selectHtflData, 
          title:'合同协议分类', 
          item_click_callback:function(id) {
          	$("#nmbs_SORT_CODE").val(selectHtflData[id]);
          	$("#nmbs_SORT_CODE").attr("nid",id);
          }, 
          bgCallback:function() {$.cache["dialog"].close();}},"");
	},
	showSelectHtlx : function(){
		list_show({data:selectHtlxData, 
          title:'合同类型', 
          item_click_callback:function(id) {
          	$("#nmbs_CONTRACT_NO").val(selectHtlxData[id]);
          	$("#nmbs_CONTRACT_NO").attr("nid",id);
          }, 
          bgCallback:function() {$.cache["dialog"].close();}},"");
	},
	btn_save_bargainsub:function(callback){
		var htqdsql = " SIGN_CUST_NAME='"+$("#nmbs_SIGN_CUST_NAME").val()+"',REPLIER_NAME='"+$("#nmbs_REPLIER_NAME").val()+"',SIGN_DATE_CUST='"+$("#nmbs_SIGN_DATE_CUST").val()+"',REPLY_DATE='"+$("#nmbs_REPLY_DATE").val()+"',REPLY_TIME='"+$("#nmbs_REPLY_TIME").val()+"',REPLY_MODE='"+$("#nmbs_REPLY_MODE").attr("nid")+"',REPLY_TYPE='"+$("#nmbs_REPLY_TYPE").attr("nid")+"',CONS_OPINION='"+$("#nmbs_CONS_OPINION").val()+"',CONTRACT_NO='"+$("#nmbs_CONTRACT_NO").val()+"',OPER_TYPE_CODE='"+$("#nmbs_OPER_TYPE_CODE").attr("nid")+"',SORT_CODE='"+$("#nmbs_SORT_CODE").attr("nid")+"',SIGN_DATE='"+$("#nmbs_SIGN_DATE").val()+"',TYPE_CODE='"+$("#nmbs_TYPE_CODE").attr("nid")+"',PS_SIGNATORY='"+$("#nmbs_PS_SIGNATORY").val()+"',CONS_SIGNATORY='"+$("#nmbs_CONS_SIGNATORY").val()+"',SIGN_ADDR='"+$("#nmbs_SIGN_ADDR").val()+"',END_DATE='"+$("#nmbs_END_DATE").val()+"',RENEW_FLAG='"+$("#nmbs_RENEW_FLAG").attr("nid")+"',FORMAT_CODE='"+$("#nmbs_FORMAT_CODE").attr("nid")+"',ORGN_NO='"+$("#nmbs_ORGN_NO").val()+"',REMARK='"+$("#nmbs_REMARK").val()+"' ";
		nmUpdate.updateDataFromTable('YK_210_CONTRACT_SIGN',htqdsql,appno,
		function(){
			callback();
		}, pubData.failNmo);
	},
	/***
	 * 合同签订 任务传递
	 */
	btn_goto_index:function(){
		
		nmBSUI.btn_save_bargainsub(function(){
			if(nmBSUI.checkNullOrType()){
				nmQuery.queryDataFromTable('YK_210_CONTRACT_SIGN',appno, function(tx, res) {
							var len = res.rows.length;
							if (len > 0) {// 本地未查询
								var xs = res.rows.item(0);
								var htqd = "'APP_NO':'"+xs['APP_NO']+"', 'CONS_NO':'"+xs['CONS_NO']+"', 'CONTRACT_ID':'"+xs['CONTRACT_ID']+"', 'DRAFT_ID':'"+xs['DRAFT_ID']+"', 'AR_ID':'"+xs['AR_ID']+"', 'SIGN_DATE_CUST':'"+xs['SIGN_DATE_CUST']+"', 'SIGN_CUST_NAME':'"+xs['SIGN_CUST_NAME']+"', 'REPLY_DATE':'"+xs['REPLY_DATE']+"', 'REPLIER_NAME':'"+xs['REPLIER_NAME']+"', 'REPLY_MODE':'"+xs['REPLY_MODE']+"', 'REPLY_TYPE':'"+xs['REPLY_TYPE']+"', 'REPLY_TIME':'"+xs['REPLY_TIME']+"', 'CONS_OPINION':'"+xs['CONS_OPINION']+"', 'PS_SIGNATORY':'"+xs['PS_SIGNATORY']+"', 'CONS_SIGNATORY':'"+xs['CONS_SIGNATORY']+"', 'SIGN_ADDR':'"+xs['SIGN_ADDR']+"', 'END_DATE':'"+xs['END_DATE']+"', 'RENEW_FLAG':'"+xs['RENEW_FLAG']+"', 'FORMAT_CODE':'"+xs['FORMAT_CODE']+"', 'REMARK':'"+xs['REMARK']+"'";
								var task = "'ORGNO':'"+sessionStorage.ORG_NO+"', 'SYS_USER_NAME':'"+sessionStorage.user_name+"', 'APP_NO':'"+sessionStorage.amAPP_NO+"', 'INSTANCE_ID':'"+sessionStorage.INSTANCE_ID+"'";
								
								netRequest.rwcdHtqdMsg(htqd,task,netRequest.successHtqdTaskCallBack, netRequest.faileCallBack);
								
							}
						}, pubData.failNmo);
			}
			
		});
		
		//$("#dx-viewport-one").load("../NameModify/index.html");
	},
	/****
	 * 检索页面数据 非空判断
	 */
	checkNullOrType : function(){
		var checkArray = [{"id":"nmbs_SIGN_CUST_NAME","msg":"客户签收人"},
			{"id":"nmbs_REPLIER_NAME","msg":"答复人"},
			{"id":"nmbs_SIGN_DATE_CUST","msg":"客户签收时间"},
			{"id":"nmbs_REPLY_DATE","msg":"答复日期"},
			{"id":"nmbs_REPLY_TIME","msg":"客户回复时间"},
			{"id":"nmbs_REPLY_MODE","msg":"答复方式"},
			{"id":"nmbs_REPLY_TYPE","msg":"客户回复方式"},
			{"id":"nmbs_CONS_OPINION","msg":"客户意见"},
			{"id":"nmbs_PS_SIGNATORY","msg":"供电方签约人"},
			{"id":"nmbs_CONS_SIGNATORY","msg":"用电方签约人"},
			{"id":"nmbs_SIGN_ADDR","msg":"签订地点"},
			{"id":"nmbs_RENEW_FLAG","msg":"合同自动续签标志"},
			{"id":"nmbs_FORMAT_CODE","msg":"合同文本形式"}
		];
		for(var i=0;i<checkArray.length;i++){
			if($("#"+checkArray[i].id).val() == ""){
				publicUIShow.amDialog(checkArray[i].msg+"不能为空", 1);
				return false;
			}
		}
		return true;
		
	}
}

nmBSUI.init();
