/** ****参数定义********* */
var isFirst = true;// 是否第一次请求
var nowbuttonclick = '0210001';

var TITLETEXT = "更名-待办任务";
var listHtmlArr = ["", "", "", "",""]; // 各list HTML的list集合：业务受理 勘查派工 现场勘查 审批
var nmScroll = "";// 页面滚动和滑动对象
var nmTYPECODE = ["0210001", "0210002", "0210003", "0210004","0216666"];
var IDFLAG = "swipRightDel_";
var PLACEHOLDER = "输入申请编号或用户编号后4位";

var applisttype = true; //待办事宜状态 默认未完成

var dabgErrMsg = {
	"SELECT_DATABASE_FAIL" : "查询移动终端数据库失败",
	"JQUERYNODATA" : "未查询到数据",
	"PLESEDOWNLOAD" : "未查询到该工单的用户数据，请下载!",
	"DELETEDATAERR" : "批量删除移动终端数据失败",
	"MAKESQLERR" : "组装删除JS语法错误！"
}

/** ****初始化界面********* */
var initNm = {
	// Menu的4个子元素
	child : $("#optiongrouptitle").children(),
	scrollRefreshHtml : "<div id='pullDown'><div class='toprefresh'><span class='pullDownIcon'></span><span class='pullDownLabel'>下拉可以刷新...</span></div></div>",
	/**
	 * 查询档案维护工单列表数据
	 */
	queryWorkList : function(where) {
		nmQuery.queryWorkListData(where, initNm.initPageListCB,
						pubData.failNmo);
	},
	queryListFromNet : function(actcode,sysuser_name) {// 获取所有待办工单
		console.log("****---"+sysuser_name);
		netRequest.queryDbrwListmsg(actcode,sysuser_name,
				netRequest.successDbrwListCallBack, netRequest.faileCallBack);
	},
	querySqListFromNet : function(actcode,sysuser_name) {// 获取所有待办工单
		console.log("****---"+sysuser_name);
		netRequest.queryDbrwListmsg(actcode,sysuser_name,
				netRequest.successDbrwSQListCallBack, netRequest.faileCallBack);
	},

	/**
	 * 列表数据查询成功回调，初始化界面
	 * 
	 * @param {}
	 *            data 数据
	 */
	initPageListCB : function(tx, data) {
		try {
			data = data.rows;
			var len = data.length;
			$("#mainListid").html("");
			$(".numborder").html("0");
			listHtmlArr = ["", "", "", "",""];

			if (len == 0) {
				if (isFirst) {
					initNm.queryListFromNet('',sessionStorage.user_name);
				}else{
					//publicUIShow.amDialog("未查询到数据", 1);
				}
				isFirst = false;
				return;
			}
			isFirst = false;
			for (var i = 0; i < len; i++) {
				var tempHtml = returnListItemHtml(data.item(i));
				if (data.item(i).TYPE_CODE == nmTYPECODE[0])
					listHtmlArr[0] += tempHtml;// 业务受理
				else if (data.item(i).TYPE_CODE == nmTYPECODE[1])
					listHtmlArr[1] += tempHtml;// 合同起草
				else if (data.item(i).TYPE_CODE == nmTYPECODE[2])
					listHtmlArr[2] += tempHtml;// 合同审核
				else if (data.item(i).TYPE_CODE == nmTYPECODE[3])
					listHtmlArr[3] += tempHtml;// 合同签订
				else if(data.item(i).TYPE_CODE == nmTYPECODE[4])
					listHtmlArr[4] += tempHtml;
				tempHtml = "";
			}

			$("#ywslNumNm").html(listHtmlArr[0].split(IDFLAG).length - 1);
			$("#htqcNumNm").html(listHtmlArr[1].split(IDFLAG).length - 1);
			$("#htshNumNm").html(listHtmlArr[2].split(IDFLAG).length - 1);
			$("#htqdNumNm").html(listHtmlArr[3].split(IDFLAG).length - 1);

			// 默认初始化业务受理
			var indext = "";
			if (listHtmlArr[0] != "") {
				indext = 0;
			} else if (listHtmlArr[1] != "") {
				indext = 1;
			} else if (listHtmlArr[2] != "") {
				indext = 2;
			} else if (listHtmlArr[3] != "") {
				indext = 3;
			} else if(listHtmlArr[4] != ""){
				indext = 4;
			} else {
				indext = 0;
			}

			initNm.changeMenu(indext);// 初始化Menu的状态

		} catch (e) {
			console.log("err:" + e);
		}
	},
	
	/****
	 * 初始化按钮事件及数据
	 */
	initPageEvent : function() {
		// 头部
		util.moblie.navbar.title = TITLETEXT;
		util.moblie.navbar.buttonList = ["back", "add", "menu"];// 可选参数：add back

		var nmSearch = function(obj) {
			var selectType = obj.selectobj.text == "已完成"
					? " a.ACT_CODE='0216666'"
					: " (a.ACT_CODE in('0210001','0210002','0210003','0210004'))";// 已完成，未完成
			if (obj.selectobj.text == "已完成") {
				$("#optiongrouptitle").addClass("hidden");
				applisttype = false;
				
				
				
			} else {
				$("#optiongrouptitle").removeClass("hidden");
				applisttype = true;
			}

			var keyword = Elec.setUndefined(obj.searchText) == ""
					? $("#searchHeightId input").val()
					: obj.searchText;
			keyword = keyword.length == 0
					? " where  " + selectType
					: " where (a.APP_NO like '%" + keyword
							+ "'  or  b.CONS_NO like '%" + keyword + "') and "
							+ selectType;
			listHtmlArr = ["", "", "", "",""];
			initNm.queryWorkList(keyword);
		}
		// 搜索框绑定事件
		$(".search").elecSearch({
					changeTextCallback : nmSearch,
					select : {
						callback : nmSearch,
						list : [{
									id : 1,
									text : "未完成"
								}, {
									id : 2,
									text : "已完成"
								}]
					}
				});
		$("#searchHeightId input").attr("placeholder", PLACEHOLDER);
		$("#searchHeightId input").addClass("inputPlaceHolder");

		// 菜单绑定点击事件
		var childs = new Array();
		for (var i = 0; i < initNm.child.length; i++) {
			childs[i] = initNm.child[i];
			initNm.child[i].addEventListener("touchstart", function() {
						var index = childs.indexOf(this);
						initNm.changeMenu(index);

						switch (i) {
							case 1 :
								nowbuttonclick = '0210002';
								break;
							case 2 :
								nowbuttonclick = '0210003';
								break;
							case 3 :
								nowbuttonclick = '0210004';
								break;
							default :
								nowbuttonclick = '0210001';
								break;

						}

					}, false);
		}

		// 返回
		navbarBack = function() {
			listHtmlArr = ["", "", "", "",""];
			$("#dx-viewport-one").html("");
			$("#dx-viewport-one").load("mainContent.html"); // 固定死的规则
		}
		navbarAdd = function() {//任务发起
//			listHtmlArr = ["", "", "", "",""];
//			sessionStorage.fmWhichApply = "gm";
//			$("#dx-viewport-one").load("../../Pub/userInfoQuery.html");
			clickTaskQuery2 = function() {
				$("#dx-viewport-one").load("../NameModify/nmOperation.html");
				closePPDialog()
			};
			clickTaskBlue = function() {
				fm_bluetooth_connect(function(value) {
							$("#consOrAssetNo").val(value);
						});

			};
			clickTaskQuery1 = function(consOrAssetNo, contentIndex) {
				
				if(consOrAssetNo==""){
					publicUIShow.amDialog("请输入查询条件", 1);
					return;
				}
				
				
				closePPDialog();

				var taskmsg;
				if (contentIndex == 0) {
					taskmsg = "{'CONS_NO':'"
							+ consOrAssetNo
							+ "', 'ASSET_NO':'', 'APP_TYPE_CODE':'210', 'SYS_USER_NAME':'"
							+ sessionStorage.user_name + "','ACT_CODE':''}";
				} else {
					taskmsg = "{'CONS_NO':'', 'ASSET_NO':'" + consOrAssetNo
							+ "', 'APP_TYPE_CODE':'210', 'SYS_USER_NAME':'"
							+ sessionStorage.user_name + "','ACT_CODE':''}";
				}

				netRequest.addTaskFqmsg(taskmsg,
						netRequest.successYwslCallBack,
						netRequest.faileCallBack);
			};
			add_task("任务发起", function() {
						//closePPDialog();
					});
		}
	},

	/**
	 * Menu点击事件，样式切换
	 * 
	 * @param {}
	 *            index
	 */
	changeMenu : function(index) {

		var barWidth = $("#optiongrouptitle").width();
		$("#boxclip").css("margin-left", (barWidth / 4 * index) + "px");
		$(initNm.child).css("color", "#000000");
		$(initNm.child[index]).css("color", "#3cafdb");
		$("#mainListid").html(initNm.scrollRefreshHtml + listHtmlArr[index]);
		
		if(index != 4){
			nmScrollRefresh("scrollContent");// 添加滑动
			initNm.initListIDTouch();//给工单绑定点击事件
		}else{
			nmYwcScrollRefresh("scrollContent");
		}
		
	},
	returnHtmlIdArr : function(id) {//根据界面id获取所有元素信息
		return $(id).parent().children();
	},
	/**
	 * 给工单绑定点击事件
	 */
	initListIDTouch : function() {
		var scrllTouch = true;
		var workListID = initNm.returnHtmlIdArr("div[id*='swipRightDel_']");
		for (var i = 1; i < workListID.length; i++) {
			
			/*document.getElementById(workListID[i].id).addEventListener("touchend", function() {
				if(scrllTouch){
					initNm.gotoNextPage(this.id);
				}
			});
			document.getElementById(workListID[i].id).addEventListener("touchmove", function() {
				scrllTouch = false;
				setTimeout(function() {
					scrllTouch = true;
				}, 500);
			});*/
			
			EventUtil.addClickListener({
					id : workListID[i].id,
					clk :function(){
						initNm.gotoNextPage(this.id);
					}
					
				});
		}
	},
	
	/**
	 * 工单跳转到详情
	 * 
	 * @param {}
	 *            id
	 */
	gotoNextPage : function(id) {
		var typeCode = id.split("_")[2];
		sessionStorage.amAPP_NO = id.split("_")[1];
		sessionStorage.INSTANCE_ID = id.split("_")[3];// 活动实例标识

		queryOrNetGoPage(typeCode);
	}
}

/**
 * 拼接列表Item项的Html代码
 * 
 * @param {}
 *            data 数据
 * @return {} Html代码
 */
function returnListItemHtml(data) {
	var result = " <div class='displayflex margintopsublist'  id='swipRightDel_"
			+ data.APP_NO
			+ "_"
			+ data.TYPE_CODE
			+ "_"
			+ data.INSTANCE_ID
			+ "'  >"

			+ "    <div class='leftborder'></div>"
			+ "     	<div  class='sublist' >"

			+ "         <div  class='appcolor'><span>申请编号</span><span> "
			+ data.APP_NO
			+ "</span> </div>"

			+ "         <div class='displayflex textmagin'>"
			+ "              <div class='minwidth1'>接收时间</div><div> "
			+ data.RVC_TIME
			+ "</div>"
			+ "         </div>"
			+ "         <div class='displayflex textmagin'>"
			+ "               <div class='minwidth1'>到期时间</div><div> "
			+ data.DUE_TIME
			+ "</div>"
			+ "          </div>"
			+ "          <div class='displayflex textmagin'>"
			+ "               <div class='minwidth1'>说明栏</div><div> "
			+ data.NOTES + "</div>" + "          </div>   "

			+ "  		</div>   " + "   </div>";
	return result;
}

/**
 * 页面左右滑动切换菜单、下拉刷新
 * 
 * @param {}
 *            id1 需要滚动的DOM元素
 *            dirX为1时：向左滑动，为-1时想右滑动，0为onScrollStart。dirY为-1时：是向下滑动，为1时： 是向上滑动。
 */
function nmScrollRefresh(id1) {
	if (Elec.setUndefined(nmScroll) != "") {
		nmScroll.destroy();
		nmScroll = null;
	}
	if (!nmScroll || nmScroll == "undefined" || nmScroll == "null") {
		var pullDownEl = document.getElementById('pullDown');
		var pullDownOffset = pullDownEl.offsetHeight;
		var loading = false;
		nmScroll = new iScroll(id1, {
			hScrollbar : false,
			vScrollbar : false,
			useTransition : true,
			topOffset : pullDownOffset,
			onRefresh : function() {
				if (pullDownEl.className.match('reloading')) {
					pullDownEl.className = '';
					pullDownEl.querySelector('.pullDownLabel').innerHTML = '下拉可以刷新...';
					$("#pullDown").hide();
					loading = false;
				}
			},
			onScrollMove : function() {
				if (!loading && this.dirY == -1)
					$("#pullDown").show();
				if (this.y > 45 && !pullDownEl.className.match('flip')
						&& !loading) {
					pullDownEl.className = 'flip';
					pullDownEl.querySelector('.pullDownLabel').innerHTML = '松开开始刷新...';
					this.minScrollY = 0;
				} else if (this.y < 45 && pullDownEl.className.match('flip')
						&& !loading) {
					pullDownEl.className = '';
					pullDownEl.querySelector('.pullDownLabel').innerHTML = '下拉可以刷新...';
					this.minScrollY = -pullDownOffset;
				}
			},
			onScrollEnd : function() {
				if (pullDownEl.className.match('flip')) {
					loading = true;
					pullDownEl.className = 'reloading';
					pullDownEl.querySelector('.pullDownLabel').innerHTML = '正在刷新...';
					setTimeout(function() {
								nmScroll.refresh();
							}, 2000);
					if(applisttype){
						hasScrollref = true;
						initNm.queryListFromNet('',sessionStorage.user_name);
					}
				} else if (!loading) {
					$("#pullDown").hide();
				}
			}
		});
	}
	document.ontouchmove = function(e) {
		e.preventDefault();
	}// 禁止页面滚动
	nmScroll.refresh();
}


function nmYwcScrollRefresh(id1) {
	if (Elec.setUndefined(nmScroll) != "") {
		nmScroll.destroy();
		nmScroll = null;
	}
	if (!nmScroll || nmScroll == "undefined" || nmScroll == "null") {
		nmScroll = new iScroll(id1, {
			hScrollbar : false,
			vScrollbar : false,
			useTransition : true,
			onRefresh : function() {
			},
			onScrollMove : function() {
			
			},
			onScrollEnd : function() {}
		});
	}
	document.ontouchmove = function(e) {
		e.preventDefault();
	}// 禁止页面滚动
	nmScroll.refresh();
}

initNm.initPageEvent();// 初始页面点击事件
showGiveRightMsg();
initNm.queryWorkList(null);// 初始化工单列表项和列表上的点击事件

