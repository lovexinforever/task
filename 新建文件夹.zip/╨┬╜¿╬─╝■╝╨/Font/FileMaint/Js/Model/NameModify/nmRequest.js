/**===========档案变更报文FUN
 * 1申请   2021030601	var pkg1 = '{"SYS_USER_NAME":"' + sessionStorage.user_name + '","CONS_NO":"' +CONS_NO+ '","ASSET_NO":"' +ASSET_NO+ '"}';
 * 2业务受理   2021030602
 * 3勘查派工   2021030603		var pkg3 = '{"APP_NO":"' + APP_NO + '","INSTANCE_ID":"' +INSTANCE_ID+ '","EMP_NO":"' +EMP_NO+ '"}';
 * 4现场勘查   2021030604
 * 5审批   2021030605
 * 6查询工单用户信息  2021030606	var pkg6 = '{"CONS_NO":"' + CONS_NO + '","APP_NO":"' +APP_NO+ '","ACT_CODE":"' +ACT_CODE+ '"}';
 *============刷新
 * 空返回所有更名、档案变更的待办事宜@type
*	0210001:更名业务受理
*	0210002:更名合同起草
*	0210003:更名合同审核
*	0210004:更名合同签订
*	0306001:档案变更业务受理
*	0306002:档案变更勘查派工
*	0306003:档案变更现场勘查
*	0306004:档案变更审批
*	0306005:档案变更信息归档
*	0306666 档案变更已完成
*/
var nextUrl = "";
var degreenum = 0;//运行次数

function nmSendDataTool(fun, pkg, nmDoSome, faileMsg) {
	window.plugins.send_data.get_Tid(getTidSuc,null);
 	function getTidSuc(tid){
 		var basePkg = "{'MOD':'2021', 'FUN':'"+fun+"', 'ORG_NO':'"+sessionStorage.ORG_NO+"', 'SYS_USER_NAME':'"+sessionStorage.user_name+"', 'TERM_NUM':'"+tid+"', 'PKG':"+pkg+"}";
		console.log(basePkg);
	 	send_data(fun, "2021", basePkg, nmDoSome, faileMsg);
	}
}

function nmSendDataListTool(fun,sysuser_name, actcode, nmDoSome, faileMsg) {
	window.plugins.send_data.get_Tid(getTidSuc,null);
 	function getTidSuc(tid){
 		var basePkg = "{'MOD':'2021', 'FUN':'000002', 'SYS_USER_NAME':'"+sysuser_name+"', 'TERM_NUM':'"+tid+"', 'PKG':{'SYS_USER_NAME':'"+sysuser_name+"', 'ACT_CODE':'"+actcode+"', 'APP_NO':''}}";
		console.log(basePkg);
		send_data(fun, "2021", basePkg, nmDoSome, faileMsg);
	}
}

var netRequest = {
	queryLiuchengMsg : function(pkg,upload_success, upload_fail){
		addLoading();
		nmSendDataTool("021006",pkg,upload_success, upload_fail);
	},
	queryDbrwListmsg : function(actcode,sysuser_name,upload_success, upload_fail){
		addLoading();
		nmSendDataListTool("000002",sysuser_name,actcode,upload_success, upload_fail);
	},
	addTaskFqmsg : function(pkg,upload_success, upload_fail){//任务发起
		addLoading();
		nmSendDataTool("021001",pkg,upload_success, upload_fail);
	},
	rwcdYwslMsg : function(ywsl,task,upload_success, upload_fail){//业务受理任务发起
		addLoading();
		pkg = "{'APP_NO':'"+sessionStorage.amAPP_NO+"','ACT_CODE':'','SYS_USER_NAME':'"+sessionStorage.user_name+"', 'YWSL':{"+ywsl+"}, 'TASK':{"+task+"}}";
		console.log("--"+pkg);
		nmSendDataTool("021002",pkg,upload_success, upload_fail);
	},
	rwcdHtqcMsg : function(htqc,task,upload_success, upload_fail){//合同起草任务发起
		addLoading();
		pkg = "{'APP_NO':'"+sessionStorage.amAPP_NO+"','ACT_CODE':'','SYS_USER_NAME':'"+sessionStorage.user_name+"', 'HTQC':{"+htqc+"}, 'TASK':{"+task+"}}";
		console.log("--"+pkg);
		nmSendDataTool("021003",pkg,upload_success, upload_fail);
	},
	rwcdHtshMsg : function(htsh,task,upload_success, upload_fail){//合同审核任务发起
		addLoading();
		pkg = "{'APP_NO':'"+sessionStorage.amAPP_NO+"','ACT_CODE':'','SYS_USER_NAME':'"+sessionStorage.user_name+"', 'HTSH':{"+htsh+"}, 'TASK':{"+task+"}}";
		console.log("--"+pkg);
		nmSendDataTool("021004",pkg,upload_success, upload_fail);
	},
	rwcdHtqdMsg : function(htqd,task,upload_success, upload_fail){//合同签订任务发起
		addLoading();
		pkg = "{'HTQD':{"+htqd+"}, 'TASK':{"+task+"}}";
		console.log("--"+pkg);
		nmSendDataTool("021005",pkg,upload_success, upload_fail);
	},
	
	successYwslCallBack : function(msg) {//任务发起 申请接口 --- 业务受理查询接口
		console.log(msg);
		removeDialog();
		try{
			msg = JSON.parse(msg);
		}catch(e){
			console.log("----"+e);
			publicUIShow.amDialog("数据解析错误", 1);
		}
		if (msg.RET == "00") {// 请求成功
			var ret = msg.PKG.RET;
			if (ret == "10") {// 数据返回成功
				if(msg.PKG.PKG.FLAG == '-1'){
					publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1);
				}else if(msg.PKG.PKG.FLAG == '2'){
					nmUpdate.updateYkDoList('0210009',sessionStorage.amAPP_NO, function(){
						publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1,function(){},function(){
							publicUIShow.amDialogClose();
							nextUrl = "../NameModify/index.html";// 业务受理
							nmLoadPage(nextUrl);
						});
					}, pubData.failNmo);
				}else{
					netSqlcallBack(msg.PKG.PKG,{callbackType:"001"});
				}
			} else {// 数据返回失败
				publicUIShow.amDialog("未查询到数据", 1);
			}
		} else {
			publicUIShow.amDialog("未查询到数据", 1);
		}
	},
	successHtqcCallBack : function(msg) {//业务受理任务传递接口 --- 合同起草查询接口
		removeDialog();
		console.log("**==="+msg);
		msg = JSON.parse(msg);
		if (msg.RET == "00") {// 请求成功
			var ret = msg.PKG.RET;
			if (ret == "10") {// 数据返回成功
				if(msg.PKG.PKG.FLAG == '-1'){
					publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1);
				}else if(msg.PKG.PKG.FLAG == '2'){
					nmUpdate.updateYkDoList('0210009',sessionStorage.amAPP_NO, function(){
						publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1,function(){},function(){
							publicUIShow.amDialogClose();
							nextUrl = "../NameModify/index.html";// 业务受理
							nmLoadPage(nextUrl);
						});
					}, pubData.failNmo);
				}else{
					netSqlcallBack(msg.PKG.PKG,{callbackType:"002"});
				}
				
			} else {// 数据返回失败
				publicUIShow.amDialog("未查询到数据", 1);
			}
		} else {
			publicUIShow.amDialog("未查询到数据", 1);
		}
	},
	successHtshCallBack : function(msg) {//合同起草任务传递回调 --- 合同审核查询接口
		removeDialog()
		console.log(msg);
		msg = JSON.parse(msg);
		if (msg.RET == "00") {// 请求成功
			var ret = msg.PKG.RET;
			if (ret == "10") {// 数据返回成功
				
				if(msg.PKG.PKG.FLAG == '-1'){
					publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1);
				}else if(msg.PKG.PKG.FLAG == '2'){
					nmUpdate.updateYkDoList('0210009',sessionStorage.amAPP_NO, function(){
						publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1,function(){},function(){
							publicUIShow.amDialogClose();
							nextUrl = "../NameModify/index.html";// 业务受理
							nmLoadPage(nextUrl);
						});
					}, pubData.failNmo);
				}else{
					netSqlcallBack(msg.PKG.PKG,{callbackType:"003"});
				}
			} else {// 数据返回失败
				publicUIShow.amDialog("未查询到数据", 1);
			}
		} else {
			publicUIShow.amDialog("未查询到数据", 1);
		}
	},
	successHtqdCallBack : function(msg) {//合同签订查询接口回调(合同签订是最后一个流程，任务传递和查询回调处理不一样)
		removeDialog()
		console.log(msg);
		msg = JSON.parse(msg);
		if (msg.RET == "00") {// 请求成功
			var ret = msg.PKG.RET;
			if (ret == "10") {// 数据返回成功
				
				if(msg.PKG.PKG.FLAG == '-1'){
					publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1);
				}else if(msg.PKG.PKG.FLAG == '2'){
					nmUpdate.updateYkDoList('0210009',sessionStorage.amAPP_NO, function(){
						publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1,function(){},function(){
							publicUIShow.amDialogClose();
							nextUrl = "../NameModify/index.html";// 业务受理
							nmLoadPage(nextUrl);
						});
					}, pubData.failNmo);
				}else{
					netSqlcallBack(msg.PKG.PKG,{callbackType:"004"});
				}
				
			} else {// 数据返回失败
				publicUIShow.amDialog("未查询到数据", 1);
			}
		} else {
			publicUIShow.amDialog("未查询到数据", 1);
		}
	},
	successDbrwListCallBack : function(msg) {//查询工单列表
		console.log(msg);
		msg = JSON.parse(msg);
		if (msg.RET == "00") {// 请求成功
			var ret = msg.PKG.RET;
			if (ret == "10") {// 数据返回成功
				if(msg.PKG.PKG.FLAG == '-1'){
					publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1);
				}else if(msg.PKG.PKG.FLAG == '2'){
					nmUpdate.updateYkDoList('0210009',sessionStorage.amAPP_NO, function(){
						publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1,function(){},function(){
							publicUIShow.amDialogClose();
							nextUrl = "../NameModify/index.html";// 业务受理
							nmLoadPage(nextUrl);
						});
					}, pubData.failNmo);
				}else{
//					var sname = sessionStorage.user_name;
//					if(degreenum % 2 == 1){
//						sname = sessionStorage.shouquanUserNo;
//						if(sname == "" || sname == undefined){
//							return;
//						}
//					}else{
//						sname = sessionStorage.user_name;
//					}
//					++degreenum;
//					console.log("degreenum--=--"+degreenum);
					
					hasScrollref = true;
					netSqlcallBack(msg.PKG.PKG,{callbackType:"000",sysuser_name:sessionStorage.user_name});
				}
			} else {// 数据返回失败
				publicUIShow.amDialog("未查询到数据", 1);
			}
		} else {
			publicUIShow.amDialog("未查询到数据", 1);
		}
	},
	successDbrwSQListCallBack : function(msg) {//查询授权工单列表
		console.log(msg);
		msg = JSON.parse(msg);
		if (msg.RET == "00") {// 请求成功
			var ret = msg.PKG.RET;
			if (ret == "10") {// 数据返回成功
				if(msg.PKG.PKG.FLAG == '-1'){
					publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1);
				}else if(msg.PKG.PKG.FLAG == '2'){
					nmUpdate.updateYkDoList('0210009',sessionStorage.amAPP_NO, function(){
						publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1,function(){},function(){
							publicUIShow.amDialogClose();
							nextUrl = "../NameModify/index.html";// 业务受理
							nmLoadPage(nextUrl);
						});
					}, pubData.failNmo);
				}else{
					hasScrollref = true;
					netSqlcallBack(msg.PKG.PKG,{callbackType:"0000",sysuser_name:sessionStorage.shouquanUserNo});
				}
			} else {// 数据返回失败
				publicUIShow.amDialog("未查询到数据", 1);
			}
		} else {
			publicUIShow.amDialog("未查询到数据", 1);
		}
	},
	successHtshTaskCallBack : function(msg) {//合同审核 任务传递
		console.log(msg);
		removeDialog()
		msg = JSON.parse(msg);
		if (msg.RET == "00") {// 请求成功
			var ret = msg.PKG.RET;
			if (ret == "10") {// 数据返回成功
				
				if(msg.PKG.PKG.FLAG == '-1'){
					publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1);
				}else if(msg.PKG.PKG.FLAG == '2'){
					nmUpdate.updateYkDoList('0210009',sessionStorage.amAPP_NO, function(){
						publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1,function(){},function(){
							publicUIShow.amDialogClose();
							nextUrl = "../NameModify/index.html";// 业务受理
							nmLoadPage(nextUrl);
						});
					}, pubData.failNmo);
				}else{
					netSqlcallBack(msg.PKG.PKG,{callbackType:"004"});
				}
			} else {// 数据返回失败
				publicUIShow.amDialog("未查询到数据", 1);
			}
		} else {
			publicUIShow.amDialog("未查询到数据", 1);
		}
	},
	successHtqdTaskCallBack : function(msg) {//合同签订 任务传递
		console.log(msg);
		removeDialog()
		msg = JSON.parse(msg);
		if (msg.RET == "00") {// 请求成功
			var ret = msg.PKG.RET;
			if (ret == "10") {// 数据返回成功
				
				if(msg.PKG.PKG.FLAG == '-1'){
					publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1);
				}else if(msg.PKG.PKG.FLAG == '2'){
					nmUpdate.updateYkDoList('0210009',sessionStorage.amAPP_NO, function(){
						publicUIShow.amDialog(msg.PKG.PKG.ERR_MSG, 1,function(){},function(){
							publicUIShow.amDialogClose();
							nextUrl = "../NameModify/index.html";// 业务受理
							nmLoadPage(nextUrl);
						});
					}, pubData.failNmo);
				}else{
					nmUpdate.updateYkDoList('0216666',sessionStorage.amAPP_NO, function(){
						publicUIShow.amDialog('待办任务传递成功，终端操作全部完成', 1,function(){},function(){
							publicUIShow.amDialogClose();
							nextUrl = "../NameModify/index.html";// 业务受理
							nmLoadPage(nextUrl);
						});
					}, pubData.failNmo);
				}
			} else {// 数据返回失败
				publicUIShow.amDialog("未查询到数据", 1);
			}
		} else {
			publicUIShow.amDialog("未查询到数据", 1);
		}
	},
	faileCallBack : function(msg){
		console.log("error"+msg);
		removeDialog();
		publicUIShow.amDialog("数据请求失败", 1);
	}
}

var netSqlcallBack = function(data,jsonArgs) {
		try {
			var amDelSql = new Array();
			var amInsertSql = new Array();
			var reActCode = "";
			
			/*此处应对与查询接口，每个流程都会返回 YWSL（用电申请信息）*/
			var ywReData = data.YWSL;
			if (ywReData && ywReData.length>0) {
				ywReData[0].ORGN_CONS_NAME = ywReData[0].CONS_NAME;
				amDelSql = dataUpdate.deleteInfo({"YK_S_APP" : ywReData});
				amInsertSql = dataUpdate.insertInfo("YK_S_APP", ywReData);
			}
			
			/*此处应对为 任务传递接口  DBSY为待办事宜信息*/
			var dbrwData = data.DBSY;//待办事宜
			var appNos = new Array();
			if(dbrwData && dbrwData.length>0){
				
				reActCode = dbrwData[0].ACT_CODE;
				//任务发起时，将APP_NO和INSTANCE_ID保存
				sessionStorage.amAPP_NO = dbrwData[0].APP_NO;
				sessionStorage.INSTANCE_ID = dbrwData[0].INSTANCE_ID;
//				jsonArgs.sysuser_name = dbrwData[0].SYS_USER_NAME;
				
				for (var i = 0; i < dbrwData.length; i++) {
					if (dbrwData[i].APP_NO) appNos.push(dbrwData[i].APP_NO);
				}
				
				amDelSql = amDelSql.concat(dataUpdate.deleteInfo({"YK_S_DO_LIST_COMPLETION" : dbrwData}));
				amInsertSql = amInsertSql.concat(dataUpdate.insertInfo("YK_S_DO_LIST_COMPLETION", dbrwData));
				
			}else {
				appNos.push(" ");
			}
				
			if(hasScrollref){
				var appSqls = "select APP_NO from YK_S_DO_LIST_COMPLETION where APP_NO not in ("+appNos+") and ACT_CODE not in ('0216666','0306666')";
				amDelSql.push("delete from YK_S_DO_LIST_COMPLETION where SYS_USER_NAME in('"
					+ jsonArgs.sysuser_name + "') and ACT_CODE not in ('0216666','0306666') ");
				amDelSql.push("DELETE FROM YK_210_CONTRACT_DRAFT WHERE  APP_NO IN  ("+appSqls+")");
				amDelSql.push("DELETE FROM YK_210_CONTRACT_SIGN WHERE  APP_NO IN  ("+appSqls+")");
				amDelSql.push("DELETE FROM YK_210_CONTRACT_APPROVE WHERE  APP_NO IN  ("+appSqls+")");
			}
			
			/*此处是任务*/
			if(!reActCode || reActCode == ""){
				reActCode = jsonArgs.callbackType;
			}
			switch (reActCode) {
				case "002" : //合同起草查询
				case "0210002" : // 业务受理任务传递
					var reData = data.HTQC;
					if (reData) {
						amDelSql = amDelSql.concat(dataUpdate.deleteInfo({
									"YK_210_CONTRACT_DRAFT" : reData
								}));
						amInsertSql = amInsertSql.concat(dataUpdate.insertInfo(
								"YK_210_CONTRACT_DRAFT", reData));
					}
					break;
				case "003" : //合同审核 查询
				case "0210003" : // 合同审核 任务传递
					var reData = data.HTSH;
					if (reData) {
						amDelSql = amDelSql.concat(dataUpdate.deleteInfo({
									"YK_210_CONTRACT_APPROVE" : reData
								}));
						amInsertSql = amInsertSql.concat(dataUpdate.insertInfo(
								"YK_210_CONTRACT_APPROVE", reData));
					}
					break;
				case "004" : //合同签订 查询
				case "0210004" : // 合同签订 任务传递 
					var reData = data.HTQD;
					if (reData) {
						amDelSql = amDelSql.concat(dataUpdate.deleteInfo({
									"YK_210_CONTRACT_SIGN" : reData
								}));
						amInsertSql = amInsertSql.concat(dataUpdate.insertInfo(
								"YK_210_CONTRACT_SIGN", reData));
					}
					break;
				default :
					break;
			}
			amDelSql = amDelSql.concat(amInsertSql);// 拼接删除和插入数组
			
//			if(amDelSql.length == 0){ // 第一次进入待办事宜列表 如果返回数据为空
//				alert("没有数据");
//				removeDialog();
//				hasScrollref = false;
//				switch (jsonArgs.callbackType) {
//					case "000":
//					if(sessionStorage.shouquanUserNo != ""){
//						initNm.querySqListFromNet('0210003',sessionStorage.shouquanUserNo);
//					}else{
//						initNm.queryWorkList(null);
//					}
//					break;
//					case "0000":
//						initNm.queryWorkList(null);
//					break;
//				}
//				return;
//			}
			
			db_batch_data("dawh.db", amDelSql, [], function(tx, res) {
					removeDialog();
					hasScrollref = false;
					if(jsonArgs.callbackType && jsonArgs.callbackType == "000"){
						if(sessionStorage.shouquanUserNo != ""){
							initNm.querySqListFromNet('0210003',sessionStorage.shouquanUserNo);
						}else{
							initNm.queryWorkList(null);
						}
					}else if(jsonArgs.callbackType && jsonArgs.callbackType == "0000"){
						initNm.queryWorkList(null);
					}else {
						switch (reActCode) {
							case "001":
							case "0210001":
								nextUrl = "../NameModify/nmOperation.html";// 业务受理
								nmLoadPage(nextUrl);
								break;
							case "002" : //合同起草查询
							case "0210002":
								nextUrl = "../NameModify/nmBargainDO.html";// 合同起草
								nmLoadPage(nextUrl);
								break;
							case "003" : //合同审核查询
							case "0210003":
								nextUrl = "../NameModify/nmBargainAudit.html";// 合同审核
								nmLoadPage(nextUrl);
								break;
							case "004" : //合同签订查询	
							case "0210004":
								nextUrl = "../NameModify/nmBargainSub.html";//合同签订
								nmLoadPage(nextUrl);
								break;
							default:
								break;
						}
				}
			}, null);
					
		} catch (e) {
			hasScrollref = false;
			removeDialog();// 数据解析异常
			publicUIShow.amDialog("数据解析异常"+e, 1);
		}
	}

function queryOrNetGoPage(typeCode){
	if (typeCode == '0210002'){
		nextUrl = "../NameModify/nmBargainDO.html";// 合同起草
		nmQuery.queryDataFromTable('YK_210_CONTRACT_DRAFT',sessionStorage.amAPP_NO, function(tx,res){
			var len = res.rows.length;
			if (len <= 0) {
				netRequest.queryLiuchengMsg("{'APP_NO':'"+sessionStorage.amAPP_NO+"', 'ACT_CODE':'0210002','SYS_USER_NAME':'"+sessionStorage.user_name+"'}",netRequest.successHtqcCallBack,netRequest.faileCallBack);
			}else{
				nmLoadPage(nextUrl);
			}
		}, pubData.failNmo);
	}
	else if (typeCode == '0210003'){
		
		nextUrl = "../NameModify/nmBargainAudit.html";// 合同审核
		nmQuery.queryDataFromTable('YK_210_CONTRACT_APPROVE',sessionStorage.amAPP_NO,function(tx,res){
			var len = res.rows.length;
			if (len <= 0) {
				netRequest.queryLiuchengMsg("{'APP_NO':'"+sessionStorage.amAPP_NO+"', 'ACT_CODE':'0210003','SYS_USER_NAME':'"+sessionStorage.user_name+"','SQ_USER_NAME':'"+sessionStorage.shouquanUserNo+"'}",netRequest.successHtshCallBack,netRequest.faileCallBack);
			}else{
				nmLoadPage(nextUrl);
			}
		},pubData.failNmo);
	}
	else if (typeCode == '0210004'){
		nextUrl = "../NameModify/nmBargainSub.html";// 合同签订
		
		nmQuery.queryDataFromTable('YK_210_CONTRACT_SIGN',sessionStorage.amAPP_NO,function(tx,res){
				var len = res.rows.length;
				if (len <= 0) {
					netRequest.queryLiuchengMsg("{'APP_NO':'"+sessionStorage.amAPP_NO+"', 'ACT_CODE':'0210004','SYS_USER_NAME':'"+sessionStorage.user_name+"','SQ_USER_NAME':'"+sessionStorage.shouquanUserNo+"'}",netRequest.successHtqdCallBack,netRequest.faileCallBack);
				}else{
					nmLoadPage(nextUrl);
				}
			},pubData.failNmo);
	}
	else{
		nextUrl = "../NameModify/nmOperation.html";// 业务受理
		nmQuery.queryDataFromTable('YK_S_APP',sessionStorage.amAPP_NO, function(tx, res) {
			var len = res.rows.length;
			if (len <= 0) {
				netRequest.queryLiuchengMsg("{'APP_NO':'"+sessionStorage.amAPP_NO+"', 'ACT_CODE':'0210001'}",netRequest.successYwslCallBack,netRequest.faileCallBack);
			}else{
				nmLoadPage(nextUrl);
			}
		}, pubData.failNmo);
		
	}
	
}

function nmLoadPage(nextUrl){
	listHtmlArr = ["", "", "", "",""];
	$("#dx-viewport-one").html("");
	$("#dx-viewport-one").load(nextUrl);
}

