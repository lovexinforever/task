/*******************************************************************************
 * 合同起草
 */
var CONS_NO = "000000";// 用户编号
var appno = sessionStorage.amAPP_NO;
var bigImagePath; // 大图片地址
var smallImagePath; // 小图片地址

var nmScroll=null;//滚动条
var nmScrDom = null;

var selectCzlxData;//操作类型
var selectHtflData;//合同分类
var selectHtlxData;//合同类型
/**
 * 初始化页面
 */
var nmBDOUI = {
	/**
	 * 初始化页面
	 */
	init : function() {
		navbarBack = this.btn_back_click;
		navbarHome = this.btn_menu_click;

		nmBDOUI.set_btn_clickfun();
		nmBDOUI.initNavbar();
		pubData.initdata(appno);
		nmQuery.queryDataFromTable('YK_210_CONTRACT_DRAFT', appno,
				nmBDOUI.successQueryBargainDo, pubData.failNmo);

		// 合同协议分类
		nmQuery.queryPcode("12006", function(tx, res) {
					selectHtflData = JSON.parse(pubData.pcodeSuccess(tx, res));
				}, pubData.failNmo);
		// 合同类型
		nmQuery.queryPcode("12001", function(tx, res) {
					selectHtlxData = JSON.parse(pubData.pcodeSuccess(tx, res));
				}, pubData.failNmo);
		//操作类型
		nmQuery.queryPcode("12004", function(tx, res) {
					selectCzlxData = JSON.parse(pubData.pcodeSuccess(tx, res));
				}, pubData.failNmo);
		publicUIShow.nmScrools("nmScrollM");

	},
	initNavbar : function() {
		util.moblie.navbar.title = "更名-合同起草";
		util.moblie.navbar.buttonList = ["back", "menu"];// 可选参数：add back
	},
	/**
	 * 设置‘查看/收起更多信息’按钮点击事件
	 */
	set_btn_clickfun : function() {

		publicUIShow
				.btn_seemoreless_click("nmbdo_btn_seemoreless");// 查看更多详细信息

		EventUtil.addClickListener({
					id : "nmBDO_next",
					clk : function() {
						nmBDOUI.btn_goto_barginaudit();// 任务传递
					}
				});
		EventUtil.addClickListener({
					id : "nmBDO_save",
					clk : function() {
						nmBDOUI.btn_save_BarginDO(function(){
							publicUIShow.amDialog("确认保存", 1);
						});// 保存
					}
				});

		EventUtil.addClickListener({
					id : "nmbdtn_camera",
					clk : function() {
						nmBDOUI.btn_getCamera();// 拍摄合同
					}
				});
		EventUtil.addClickListener({
					id : "smallPicture",
					clk : function() {
						nmBDOUI.bigPictureShow();// 展示大图
					}
				});
		EventUtil.addClickListener({
					id : "deleteImg",
					clk : function() {
						nmBDOUI.deletePicture();// 删除图片
					}
				});

		/*EventUtil.addClickListener({
					id : "nmbd_OPER_TYPE_CODE",
					clk : function() {
						nmBDOUI.showSelectCzlx();// 操作类型
					}
				});
		EventUtil.addClickListener({
					id : "nmbd_SORT_CODE",
					clk : function() {
						nmBDOUI.showSelectHtfl();// 合同协议分类
					}
				});*/
		EventUtil.addClickListener({
					id : "nmbd_TYPE_CODE",
					clk : function() {
						nmBDOUI.showSelectHtlx();// 合同类型
					}
				});
				
		EventUtil.addClickListener({
					id : "nmbd_DRAFT_DATE",
					clk : function() {
						dateSelectFun.getDatetime({id:"nmbd_DRAFT_DATE",type:"1"});//起草时间
					}
				});
				
	},
	/**
	 * 标题栏返回按钮
	 */
	btn_back_click : function() {
		$("#dx-viewport-one").load("../NameModify/index.html");
	},
	/***************************************************************************
	 * 拍照
	 */
	btn_getCamera : function() {
		takephoto(appno, CONS_NO, function(path, res) {
					$("#nmbdtn_camera").addClass("hidden");
					$("#smallPicturediv").removeClass("hidden");
					$("#smallPicture").attr("src", path.small_name);
					bigImagePath = path.big_name;
					smallImagePath = path.small_name;
					if (path.small_name != "") {
						updateYkImage(['02', path.big_name, path.small_name,
										appno, 'YK_210_CONTRACT_DRAFT'], null,
								null);
					}
				}, function() {
				});
	},
	/***************************************************************************
	 * 查看大图
	 */
	bigPictureShow : function() {
		picture_show(bigImagePath, "图片预览", function() {
					closePPDialog();
				});
	},
	/***************************************************************************
	 * 删除图片
	 */
	deletePicture : function(event) {
		getPictureDelete({
					"bigpath" : bigImagePath,
					"smallpath" : smallImagePath
				}, function() {
					$("#nmbdtn_camera").removeClass("hidden");
					$("#smallPicturediv").addClass("hidden");
					updateYkImage(
							['01', '', '', appno, 'YK_210_CONTRACT_DRAFT'],
							null, null);
				}, null);
	},
	showSelectCzlx : function() {//操作类型弹出框
		list_show({
					data : selectCzlxData,
					title : '操作类型',
					item_click_callback : function(id) {
						$("#nmbd_OPER_TYPE_CODE").val(selectCzlxData[id]);
						$("#nmbd_OPER_TYPE_CODE").attr("nid", id);
					},
					bgCallback : function() {
						$.cache["dialog"].close();
					}
				}, "");
	},
	showSelectHtfl : function() {//合同协议分类弹出框
		list_show({
					data : selectHtflData,
					title : '合同协议分类',
					item_click_callback : function(id) {
						$("#nmbd_SORT_CODE").val(selectHtflData[id]);
						$("#nmbd_SORT_CODE").attr("nid", id);
					},
					bgCallback : function() {
						$.cache["dialog"].close();
					}
				}, "");
	},
	showSelectHtlx : function() {//合同类型弹出框
		list_show({
					data : selectHtlxData,
					title : '合同类型',
					item_click_callback : function(id) {
						$("#nmbd_TYPE_CODE").val(selectHtlxData[id]);
						$("#nmbd_TYPE_CODE").attr("nid", id);
					},
					bgCallback : function() {
						$.cache["dialog"].close();
					}
				}, "");
	},
	/***************************************************************************
	 * 合同起草查询成功回调
	 */
	successQueryBargainDo : function(tx, res) {
		var len = res.rows.length;
		if (len > 0) {
			var xs = res.rows.item(0);
			for (var key in xs) {
				pubData.showInputOfJson('#nmbd_', key, xs);
			}
			if (xs['CONS_NO'] != '') {
				CONS_NO = xs['CONS_NO'];
			}

			nmQuery.showPcodeToValue(pubData.pcodeHtqcArrayReturn(xs));

			if (xs['IMAGE_STATE'] == "02" || xs['IMAGE_STATE'] == '03') {
				$("#nmbdtn_camera").addClass("hidden");
				$("#smallPicturediv").removeClass("hidden");
				bigImagePath = xs['IMAGE_BIG'];
				smallImagePath = xs['IMAGE_SMALL'];
				$("#smallPicture").attr("src", xs['IMAGE_SMALL']);
			}
			
			if(xs['DRAFT_EMP_NAME'] == ""){
				$("#nmbd_DRAFT_EMP_NAME").val(sessionStorage.user_name_str);
			}

		}
	},
	/***************************************************************************
	 * 任务传递
	 */
	btn_goto_barginaudit : function() {
		showGiveRightMsg();//重新获取授权信息
		nmBDOUI.btn_save_BarginDO(function(){
			if(nmBDOUI.checkNullOrType()){
				nmQuery.queryDataFromTable('YK_210_CONTRACT_DRAFT', appno,
						function(tx, res) {
							var len = res.rows.length;
							if (len > 0) {// 本地未查询
								var xs = res.rows.item(0);
								var htqc = "'APP_NO':'" + xs['APP_NO']
										+ "', 'CONTRACT_NO':'"
										+ xs['CONTRACT_NO']
										+ "', 'CONS_NO':'" + xs['CONS_NO']
										+ "', 'SORT_CODE':'"
										+ xs['SORT_CODE']
										+ "', 'TYPE_CODE':'"
										+ xs['TYPE_CODE']
										+ "', 'OPER_TYPE_CODE':'"
										+ xs['OPER_TYPE_CODE']
										+ "', 'DRAFT_EMP_NAME':'"
										+ xs['DRAFT_EMP_NAME']
										+ "', 'DRAFT_DATE':'"
										+ xs['DRAFT_DATE']
										+ "', 'DRAFT_REMARK':'"
										+ xs['DRAFT_REMARK'] + "'";
								var task = "'ORGNO':'"
										+ sessionStorage.ORG_NO
										+ "', 'SYS_USER_NAME':'"
										+ sessionStorage.user_name
										+ "', 'APP_NO':'"
										+ sessionStorage.amAPP_NO
										+ "', 'INSTANCE_ID':'"
										+ sessionStorage.INSTANCE_ID
										+ "', 'SQ_USER_NAME':'"
										+ sessionStorage.shouquanUserNo + "'";
	
								netRequest.rwcdHtqcMsg(htqc, task,
										netRequest.successHtshCallBack,
										netRequest.faileCallBack);
	
							}
						}, pubData.failNmo);
			}
				
		});
		
	},
	/***************************************************************************
	 * 保存
	 */
	btn_save_BarginDO : function(callback) {
		var htqcsql = " APP_NO='" + $("#nmbd_APP_NO").val() + "',CONTRACT_NO='"
				+ $("#nmbd_CONTRACT_NO").val() + "',CONS_NO='"
				+ $("#nmbd_CONS_NO").val() + "',DRAFT_EMP_NAME='"
				+ $("#nmbd_DRAFT_EMP_NAME").val() + "',OPER_TYPE_CODE='"
				+ $("#nmbd_OPER_TYPE_CODE").attr("nid") + "',DRAFT_DATE='"
				+ $("#nmbd_DRAFT_DATE").val() + "',SORT_CODE='"
				+ $("#nmbd_SORT_CODE").attr("nid") + "',TYPE_CODE='"
				+ $("#nmbd_TYPE_CODE").attr("nid") + "',DRAFT_REMARK='"
				+ $("#nmbd_DRAFT_REMARK").val() + "' ";
		nmUpdate.updateDataFromTable('YK_210_CONTRACT_DRAFT', htqcsql, appno,
				function() {
					callback();
				}, pubData.failNmo);
	},
	/***
	 * 检测页面数据 非空等判断
	 */
	checkNullOrType : function(){
		var tipStr = "";
		var DRAFT_DATE = document.getElementById("nmbd_DRAFT_DATE").value;
		var SORT_CODE  = document.getElementById("nmbd_SORT_CODE").value;
		var TYPE_CODE  = document.getElementById("nmbd_TYPE_CODE").value;
		if(DRAFT_DATE == "") {
			tipStr = "起草时间不能为空";
		}
		else if(SORT_CODE == "") {
			tipStr = "合同协议分类不能为空";
		}else if(TYPE_CODE == "") {
			tipStr = "合同类型不能为空";
		}
		
		if(tipStr != "") {
			publicUIShow.amDialog(tipStr, 1);
			return false;
		}
		return true;
	}

}

nmBDOUI.init();
