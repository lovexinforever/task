var hasScrollref = false;//是否下拉刷新数据

var nmQuery = {
	/***************************************************************************
	 * 查询用户列表信息
	 */
	queryWorkListData : function(where, successCB, failCB) {
		
		var checksysuser =" and a.SYS_USER_NAME='"+sessionStorage.user_name+"' ";
		if(sessionStorage.shouquanUserNo != ""){
			checksysuser = " and a.SYS_USER_NAME in('"+sessionStorage.user_name+"','"+sessionStorage.shouquanUserNo+"') ";
		}
		var sql = "SELECT "
					+ "  a.APP_NO ,  "
					+ "  a.RVC_TIME ,  "
					+ "  a.DUE_TIME ,  "
					+ "  a.INSTANCE_ID ,  "
					+ "  a.ACT_CODE as TYPE_CODE,  "
					+ "  a.NOTES ,  "
					+ "  b.CONS_NO ,  "
					+ "  b.CONS_NAME ,  "
					+ "  b.ELEC_ADDR   "
					+ "  FROM  "
					+ "  YK_S_DO_LIST_COMPLETION a   "
					+ "  LEFT JOIN YK_S_APP b ON a.APP_NO = b.APP_NO  "
					+ (where != null ? where : " where (a.ACT_CODE in('0210001','0210002','0210003','0210004')) ") + checksysuser+" ORDER BY    "
					+ "a.ACT_CODE , a.RVC_TIME desc";
			db_execut_oneSQL("dawh.db", sql, [], successCB, failCB);
	},
	
	/***
	 * 查询表数据
	 * @param {} table 表名
	 * @param {} appno 
	 * @param {} successCB
	 * @param {} failCB
	 */
	queryDataFromTable : function(table,appno,successCB, failCB){
		var sql = "select * from "+table+" where APP_NO='" + appno + "'";
		db_execut_oneSQL("dawh.db", sql, [], successCB, failCB);
	},
	
	/***
	 * 查询pcode列表
	 * @param {} code_sort_id
	 * @param {} successCB
	 * @param {} failCB
	 */
	queryPcode : function(code_sort_id, successCB, failCB){
		var sql = "select VALUE,NAME from P_CODE where CODE_SORT_ID='" + code_sort_id + "'";
		db_execut_oneSQL("dawh.db", sql, [], successCB, failCB);
	},
	/***
	 * 查询单个pcode
	 * @param {} id
	 * @param {} num
	 * @param {} code_sort_id
	 * @param {} value
	 * @param {} successCB
	 * @param {} failCB
	 */
	queryPcodetoString : function(id,num,code_sort_id,value, successCB, failCB){
		var sql = "select "+num+" as id,VALUE,NAME from P_CODE where CODE_SORT_ID='" + code_sort_id + "' and VALUE='"+value+"'";
		db_execut_oneSQL("dawh.db", sql, [], successCB, failCB);
	},
	/***
	 * 查询供电单位
	 * @param {} id
	 * @param {} org_no
	 * @param {} successCB
	 * @param {} failCB
	 */
	queryOorgtoString : function(id,org_no, successCB, failCB){
		var sql = "select ORG_NO,ORG_NAME from O_ORG where ORG_NO='" + org_no + "'";
		db_execut_oneSQL("dawh.db", sql, [], successCB, failCB);
	},
	showPcodeToValue : function(pcodeArray){
		for(var p=0;p<pcodeArray.length;p++){
			nmQuery.queryPcodetoString(pcodeArray[p].id,p,pcodeArray[p].sortid,pcodeArray[p].value,function(tx,res){
				var len = res.rows.length;
				if(len>0){
					$("#"+pcodeArray[res.rows.item(0)['id']].id).val(res.rows.item(0)['NAME']);
					$("#"+pcodeArray[res.rows.item(0)['id']].id).attr("nid",res.rows.item(0)['VALUE']);
				}
			},pubData.failNmo);
		}
	}
}

var nmUpdate = {
	/****
	 * 更新表数据
	 * @param {} table 表名
	 * @param {} sqlval 拼接字段
	 * @param {} appno
	 * @param {} successCB
	 * @param {} failCB
	 */
	updateDataFromTable : function(table,sqlval,appno,successCB, failCB){
		var sql = "update "+table+" set "+sqlval+" where APP_NO = '" + appno + "'";
		db_execut_oneSQL("dawh.db", sql, [], successCB, failCB);
	},
	/***
	 * 修改更名流程状态
	 */
	updateYkDoList : function(actcode,appno, successCB, failCB){
		var sql = "update YK_S_DO_LIST_COMPLETION set ACT_CODE='"
				+ actcode + "' where APP_NO = '" + appno + "'";
		db_execut_oneSQL("dawh.db", sql, [], successCB, failCB);
	
	}
}


var pubData = {
	//查询页面上部份展示的 工单详情信息
	initdata : function(appno) {
		nmQuery.queryDataFromTable('YK_S_APP',appno, pubData.successNmo, pubData.failNmo);
	},
	//数据库成功回调
	successNmo : function(tx, res) {
		var len = res.rows.length;
		for (var i = 0; i < len; i++) {
			var xs = res.rows.item(i);
			for (var key in xs) {
				pubData.showValOfJson('#nmo_', key, xs);
			}
			
			
			var pcodeArray = pubData.pcodeArrayReturn(xs);
			for(var p=0;p<pcodeArray.length;p++){
				nmQuery.queryPcodetoString(pcodeArray[p].id,p,pcodeArray[p].sortid,pcodeArray[p].value,function(tx,res){
					var len = res.rows.length;
					if(len>0){
						$("#"+pcodeArray[res.rows.item(0)['id']].id).text(res.rows.item(0)['NAME']);
						$("#"+pcodeArray[res.rows.item(0)['id']].id).val(res.rows.item(0)['NAME']);
						$("#"+pcodeArray[res.rows.item(0)['id']].id).attr("nid",res.rows.item(0)['VALUE']);
					}
				},function(e){publicUIShow.amDialog("数据解析异常"+e, 1);});
			}
			
			//查询用电公司
			nmQuery.queryOorgtoString('nmo_ORG_NO',xs['ORG_NO'],function(tx,res){
					var len = res.rows.length;
					if(len>0){
						$("#nmo_ORG_NO").text(res.rows.item(0)['ORG_NAME']);
					}
				},function(e){publicUIShow.amDialog("数据解析异常"+e, 1);});
			

			$("#nmo_CONS_NAME").val(xs['CONS_NAME']);
			$("#nmo_REASON").val(xs['REASON']);
			
			$("#nmo_CERT_TYPE_CODE").val(xs['CERT_TYPE_CODE']);
			$("#nmo_CERT_TYPE_CODE").attr("nid",xs['CERT_TYPE_CODE']);
			$("#nmo_CERT_NO").val(xs['CERT_NO']);
			$("#nmo_CERT_NAME").val(xs['CERT_NAME']);
			$("#nmo_CONTACT_NAME").val(xs['CONTACT_NAME']);
			$("#nmo_POSTALCODE").val(xs['POSTALCODE']);
			$("#nmo_OFFICE_TEL").val(xs['OFFICE_TEL']);
			$("#nmo_ADDR").val(xs['ADDR']);
			$("#nmo_MOBILE").val(xs['MOBILE']);
			
			if ("" != xs['CONS_NAME']) {
				$("#nmo_REMARK").val(xs['ORGN_CONS_NAME']+"更名为"
						+ xs['CONS_NAME']);
			}
		}
	},
	//数据库操作失败回调
	failNmo : function(e) {
		publicUIShow.amDialog("数据库操作失败"+e, 1);
	},
	//pcode查询成功后回调
	pcodeSuccess : function(tx,res){
		var len = res.rows.length;
		var pcodelist='{';
		for (var i = 0; i < len; i++) {
			var xs = res.rows.item(i);
			if(i<len -1){
				pcodelist += '"'+xs['VALUE']+'"'+':"'+xs['NAME']+'",';
			}else{
				pcodelist += '"'+xs['VALUE']+'"'+':"'+xs['NAME']+'"';
			}
		}
		return pcodelist+'}';
	},
	pcodeStringSuccess : function(tx,res){
		var len = res.rows.length;
		var pcodelist="";
		var xs;
		if(len>0){
			xs = res.rows.item(0);
		}
		pcodelist = xs['NAME'];
		return pcodelist;
	},
	//根据key val解析json数据
	showValOfJson : function(phase_code, key, xs) {
		if (xs[key] == 'null' || xs[key] == null || xs[key] == undefined) {
			xs[key] = "";
		}
		key.indexOf(phase_code) > -1
				? $("#" + key.toUpperCase()).text(xs[key])
				: $(phase_code + key.toUpperCase()).text(xs[key]);
	},
	showInputOfJson : function(phase_code, key, xs) {
		if (xs[key] == 'null' || xs[key] == null || xs[key] == undefined) {
			xs[key] = "";
		}
		key.indexOf(phase_code) > -1
				? $("#" + key.toUpperCase()).val(xs[key])
				: $(phase_code + key.toUpperCase()).val(xs[key]);
	},
	pcodeArrayReturn : function(xs){
		var pcodeArray = [{"id":"nmo_ELEC_TYPE_CODE","sortid":29001,"value":xs['ELEC_TYPE_CODE']},
			{"id":"nmo_URBAN_RURAL_FLAG","sortid":17005,"value":xs['URBAN_RURAL_FLAG']},
				{"id":"nmo_TRADE_CODE","sortid":29005,"value":xs['TRADE_CODE']},
					{"id":"nmo_SETTLE_MODE","sortid":29015,"value":xs['SETTLE_MODE']},
						{"id":"nmo_NOTE_TYPE_CODE","sortid":15003,"value":xs['NOTE_TYPE_CODE']},
							{"id":"nmo_TRANSFER_CODE","sortid":29003,"value":xs['TRANSFER_CODE']},
								{"id":"nmo_PAY_MODE","sortid":15002,"value":xs['PAY_MODE']},
									{"id":"nmo_URBAN_RURAL_FLAG","sortid":17005,"value":xs['URBAN_RURAL_FLAG']},
									{"id":"nmo_CERT_TYPE_CODE","sortid":29012,"value":xs['CERT_TYPE_CODE']},
									{"id":"nmo_VOLT_CODE","sortid":10005,"value":xs['VOLT_CODE']},
									{"id":"nmo_NOTIFY_MODE","sortid":15001,"value":xs['NOTIFY_MODE']}];
		return pcodeArray;							
	},
	pcodeHtqcArrayReturn : function(xs){
		var pcodeArray = [{"id":"nmbd_SORT_CODE","sortid":12006,"value":xs['SORT_CODE']},
			{"id":"nmbd_OPER_TYPE_CODE","sortid":12004,"value":xs['OPER_TYPE_CODE']},
			{"id":"nmbd_TYPE_CODE","sortid":12001,"value":xs['TYPE_CODE']}];
			return pcodeArray;
	},
	pcodeHtshArrayReturn : function(xs){//
		var pcodeArray = [{"id":"nmba_APPR_VERI_FLAG","sortid":30005,"value":xs['APPR_VERI_FLAG']}];
		return pcodeArray;
	},
	pcodeHtqdArrayReturn : function(xs){
		var pcodeArray = [{"id":"nmbs_REPLY_MODE","sortid":15001,"value":xs['REPLY_MODE']},
			{"id":"nmbs_REPLY_TYPE","sortid":15001,"value":xs['REPLY_TYPE']},
			{"id":"nmbs_OPER_TYPE_CODE","sortid":15001,"value":xs['OPER_TYPE_CODE']},
			{"id":"nmbs_OPER_TYPE_CODE","sortid":12004,"value":xs['OPER_TYPE_CODE']},
			{"id":"nmbs_SORT_CODE","sortid":12006,"value":xs['SORT_CODE']},
			{"id":"nmbs_TYPE_CODE","sortid":12001,"value":xs['TYPE_CODE']}];
		return pcodeArray;
	}
}


var publicUIShow = {
	amDialog : function(text,type,cancelCB,okCB){
		var button = []; //提示框按钮数组 class 单个按钮样式 id 按钮id text 按钮文本展示 callback 单个按钮回调
		cancelCB = Elec.setUndefined(cancelCB)==""?publicUIShow.amDialogClose:cancelCB;
		okCB = Elec.setUndefined(okCB)==""?publicUIShow.amDialogClose:okCB;
		var bt1 = {class:"simple",id:"prompt_cancel",text:"取消",callback:cancelCB};
		var bt2 = {class:"simple",id:"prompt_ok",text:"确认",callback:okCB};
		if(type==1) button.push(bt2);//只有确定按钮
		else if(type==2){
			button.push(bt1);
			button.push(bt2);
		}
		$.Elec.prompt({
			text:text,     //提示框文本域
	        buttons:button
		});
	},
	
	/**
	 * 关闭弹出框
	 */
	amDialogClose : function(){
		$.cache["dialog"].close();
	},
	/**
	 * 查看更多按钮点击事件
	 */
	
	btn_seemoreless_click : function(ids) {
		
		EventUtil.addClickListener({
			id : ids,
			clk : function() {
				var _this = $("#"+ids);
				var list = $("#"+ids).parent().prev();
				var min_height = $("tr", list).height() * 4 + 20;
				var max_height = $("table", list).height();
				var status = $("#"+ids).hasClass("open") ? 1 : 0;
				$("#"+ids).toggleClass("open");
				var height = !!status ? min_height : max_height;
				list.animate({
					height : height
				}, 250, function() {
					$("div", $(_this)).toggleClass("icon_up");
					$("span", $(_this)).html(status == 1 ? "查看详细信息" : "收起详细信息");
				});
				setTimeout(function() {
					nmScroll.refresh();
				}, 500);
			}
		});
		
		
		/*document.getElementById(ids).addEventListener("touchstart", function() {
			var _this = $("#"+ids);
			var list = $("#"+ids).parent().prev();
			var min_height = $("tr", list).height() * 4 + 20;
			var max_height = $("table", list).height();
			var status = $("#"+ids).hasClass("open") ? 1 : 0;
			$("#"+ids).toggleClass("open");
			var height = !!status ? min_height : max_height;
			list.animate({
				height : height
			}, 250, function() {
				$("div", $(_this)).toggleClass("icon_up");
				$("span", $(_this)).html(status == 1 ? "查看详细信息" : "收起详细信息");
			});
			setTimeout(function() {
				nmScroll.refresh();
			}, 500);
		});*/
	},
	/**
	 * 
	 */
	nmScrools : function(id) {
		nmScroll?nmScroll.refresh():nmScroll = new iScroll(id,{
			onBeforeScrollStart : function(e) {
				var target = e.target;
				while(target.nodeType != 1)
				target = target.parentNode;
				if(target.tagName != 'SELECT' && target.tagName != 'INPUT' && target.tagName != 'TEXTAREA')
					e.preventDefault();
			},
			bounce:false,
			useTransition:true,
			vScrollbar: false
			}
		);
		window.onclick = function(e) {
			nmScrDom = e.target;
		}
		window.onresize = function() {
			setTimeout(function() {
				if (nmScroll) {
					nmScroll.refresh();
					nmScroll.scrollToElement(nmScrDom, 500);
				}
			}, 200)
		}
	}
}


var dateSelectFun = {
	/**
	 * jsonmsg
	 * jsonmsg.id 控件id
	 * jsonmsg.type 类型 1；
	 **/
	getDatetime : function(jsonmsg){
		dateTimePicker({"date":$("#"+jsonmsg.id).val(), "type":"1"},function(res) {
			if(res != "" && res != "null") {
				$("#"+jsonmsg.id).val(res);
			}else{
				$("#"+jsonmsg.id).val("");
			}
		}, null);
	}
}

var showGiveRightMsg = function(){//获取授权信息
		var giverightMsg = giveRightInfo.getPInfo("0210003");
		console.log("**********"+JSON.stringify(giverightMsg).toString());
		if(giverightMsg != null){
			sessionStorage.shouquanUserNo = giverightMsg.P_USER_NO;
		}else{
			sessionStorage.shouquanUserNo = "";
		}
}

var nmScrDom, nmScroll=null; //滚动条
