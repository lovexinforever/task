/*******************************************************************************
 * 业务受理
 * 
 * @type
 */

var bigImagePath; // 大图片路径
var smallImagePath; // 小图片路径
var idcardImagePath;// id卡路径

var CONS_NO = "000000"; // 用户编号
var appno = sessionStorage.amAPP_NO;
var selectZjlbData;//证件类别
var nmScroll=null;//滚动条
var nmScrDom = null;

/**
 * 初始化页面
 */
var nmOpUI = {
	/**
	 * 初始化页面
	 */
	init : function() {
		navbarBack = this.btn_back_click;
		navbarHome = this.btn_menu_click;

		nmOpUI.set_btn_clickfun();
		util.moblie.navbar.title = "更名-业务受理";
		util.moblie.navbar.buttonList = ["back", "menu"];

		nmQuery.queryDataFromTable('YK_S_APP', appno,
				nmOpUI.successQueryOperation, pubData.failNmo);
		pubData.initdata(appno);

		// 证件类别
		nmQuery.queryPcode("29012", function(tx, res) {
					selectZjlbData = JSON.parse(pubData.pcodeSuccess(tx, res));
				}, nmOpUI.failNmo);
		publicUIShow.nmScrools("nmScrollM");
	},
	/**
	 * 设置‘查看/收起更多信息’按钮点击事件
	 */
	set_btn_clickfun : function() {
		EventUtil.addClickListener({
					id : "nmOP_next",
					clk : function() {
						nmOpUI.btn_goto_bargindo();// 任务发起
					}
				});
		
		publicUIShow
				.btn_seemoreless_click('nmop_btn_seemoreless');// 查看更多

		EventUtil.addClickListener({
					id : "nmOP_save",
					clk : function() {
						nmOpUI.btn_save_Operation(function(){
							publicUIShow.amDialog("保存成功", 1);
						});// 保存
					}
				});

		EventUtil.addClickListener({
					id : "nmobtn_camera",
					clk : function() {
						nmOpUI.btn_getCamera();// 拍照
					}
				});
		EventUtil.addClickListener({
					id : "nmobtn_idcard",
					clk : function() {
						nmOpUI.btn_getIdcard();// 拍摄身份证
					}
				});

		EventUtil.addClickListener({
					id : "nmoSmallPicture",
					clk : function() {
						nmOpUI.bigPictureShow();// 预览大图
					}
				});
		EventUtil.addClickListener({
					id : "deleteImg",
					clk : function() {
						nmOpUI.deletePicture();// 删除图片
					}
				});
		EventUtil.addClickListener({
					id : "deleteIdcard",
					clk : function() {
						nmOpUI.deleteIdcardPicture();// 删除身份证图片
					}
				});

		$("#nmo_CONS_NAME").focusout(function() {// 自动改变备注信息
					$("#nmo_REMARK").val($("#nmo_ORGN_CONS_NAME").text()
							+ "更名为" + $("#nmo_CONS_NAME").val());
				});

		EventUtil.addClickListener({
					id : "nmo_CERT_TYPE_CODE",
					clk : function() {
						nmOpUI.showSelectZjlb();// 证件类别选择
					}
				});
		$("#nmo_CONTACT_NAME").focusin(function(){
				if($("#nmo_CONTACT_NAME").val() == ""){
					if($("#nmo_CONTACT_NAME").val($("#nmo_CONS_NAME").val()));
				}
			});
			
		$("#nmo_ADDR").focusin(function(){
			if($("#nmo_ADDR").val() == ""){
				if($("#nmo_ADDR").val($("#nmo_ELEC_ADDR").text()));
			}
		});
	},
	/**
	 * 数据查询成功回调
	 */
	successQueryOperation : function(tx, res) {
		var len = res.rows.length;
		if (len > 0) {
			var xs = res.rows.item(0);
			for (var key in xs) {
				pubData.showValOfJson('nmo_', key, xs);
			}
			if (xs['CONS_NO'] != '') {
				CONS_NO = xs['CONS_NO'];
			}
			if ("" != xs['CONS_NAME']) {
				$("#nmo_REMARK").val(xs['ORGN_CONS_NAME'] + "更名为"
						+ xs['CONS_NAME']);
			}
			
			if("" != xs['OFFICE_TEL']){
				var temptel = xs['OFFICE_TEL'].split("-");
			
				$("#office_tel_qh").val(temptel[0]);
				$("#office_tel_num").val(temptel[1]);
				$("#office_tel_fjh").val(temptel[2]);
			}
			
			if (xs['IMAGE_STATE'] == "02" || xs['IMAGE_STATE'] == '03') {
				bigImagePath = xs['IMAGE_BIG'];
				smallImagePath = xs['IMAGE_SMALL'];
				$("#nmobtn_camera").addClass("hidden");
				$("#nmoSmallPicturediv").removeClass("hidden");
				$("#nmoSmallPicture").attr("src", xs['IMAGE_SMALL']);
			}

			if (xs['IDIMAGE_STATE'] == "02" || xs['IDIMAGE_STATE'] == '03') {
				idcardImagePath = xs['IDIMAGE_NAME'];
				$("#nmobtn_idcard").addClass("hidden");
				$("#nmoSmallIdCarddiv").removeClass("hidden");
				$("#nmoSmallIdcard").attr("src", idcardImagePath);
			}
		} else {// 查询服务器
			// netRequest.queryLiuchengMsg("{'APP_NO':'"+sessionStorage.amAPP_NO+"',
			// 'ACT_CODE':'0210001'}",netRequest.successYwslCallBack,netRequest.faileCallBack);
		}
	},

	/**
	 * 标题栏返回按钮
	 */
	btn_back_click : function() {
		$("#dx-viewport-one").load("../NameModify/index.html");
	},
	/***************************************************************************
	 * 拍照展示
	 */
	btn_getCamera : function() {
		takephoto(sessionStorage.amAPP_NO, CONS_NO, function(path, res) {
					$("#nmobtn_camera").addClass("hidden");
					$("#nmoSmallPicturediv").removeClass("hidden");
					$("#nmoSmallPicture").attr("src", path.small_name);
					bigImagePath = path.big_name;
					smallImagePath = path.small_name;
					if (path.small_name != "") {
						updateYkImage(['02', path.big_name, path.small_name,
										appno, 'YK_S_APP'], null, null);
					}
				}, function() {
				});
	},
	btn_getIdcard : function() {
		ocrIdCard(function(path, res) {
					$("#nmobtn_idcard").addClass("hidden");
					$("#nmoSmallIdCarddiv").removeClass("hidden");
					$("#nmoSmallIdcard").attr("src", path.image_name);
					idcardImagePath = path.image_name;
					if (path.small_name != "") {
						updateYkIdcardImage(['02', path.image_name, appno,
										'YK_S_APP'], null, null);
					}
				}, function() {
				});
	},
	/***************************************************************************
	 * 查看大图
	 */
	bigPictureShow : function() {
		picture_show(bigImagePath, "图片预览", function() {
					closePPDialog();
				});
	},
	/***************************************************************************
	 * 删除图片
	 */
	deletePicture : function(event) {
		getPictureDelete({
					"bigpath" : bigImagePath,
					"smallpath" : smallImagePath
				}, function() {
					$("#nmobtn_camera").removeClass("hidden");
					$("#nmoSmallPicturediv").addClass("hidden");
					updateYkImage(['01', '', '', appno, 'YK_S_APP'], null, null);
				}, null);
	},
	/***************************************************************************
	 * 删除身份证图片
	 */
	deleteIdcardPicture : function(event) {

		getPictureDelete({
					"bigpath" : idcardImagePath,
					"smallpath" : ""
				}, function() {
					$("#nmobtn_idcard").removeClass("hidden");
					$("#nmoSmallIdCarddiv").addClass("hidden");
					updateYkIdcardImage(['01', '', appno, 'YK_S_APP'], null,
							null);
				}, null);

	},
	showSelectZjlb : function() {
		list_show({
					data : selectZjlbData,
					title : '证件类别',
					item_click_callback : function(id) {
						$("#nmo_CERT_TYPE_CODE").val(selectZjlbData[id]);
						$("#nmo_CERT_TYPE_CODE").attr("nid", id);
					},
					bgCallback : function() {
						$.cache["dialog"].close();
					}
				}, "");
	},
	/***************************************************************************
	 * 保存
	 */
	btn_save_Operation : function(callback) {
		var ywslsql = " CONS_NAME='" + $("#nmo_CONS_NAME").val()
				+ "',CERT_TYPE_CODE='" + $("#nmo_CERT_TYPE_CODE").attr("nid")
				+ "', CERT_NO='" + $("#nmo_CERT_NO").val() + "',CONTACT_NAME='"
				+ $("#nmo_CONTACT_NAME").val() + "', POSTALCODE='"
				+ $("#nmo_POSTALCODE").val() + "', OFFICE_TEL='"
				+ $("#nmo_OFFICE_TEL").val() + "', ADDR='"
				+ $("#nmo_ADDR").val() + "', MOBILE='" + $("#nmo_MOBILE").val()
				+ "', REASON='" + $("#nmo_REASON").val() + "', REMARK='"
				+ $("#nmo_REMARK").val() + "',CERT_NAME='"
				+ $("#nmo_CERT_NAME").val() + "' ";
		nmUpdate.updateDataFromTable('YK_S_APP', ywslsql, appno, function() {
					callback();
				}, pubData.failNmo);
	},
	/***************************************************************************
	 * 任务传递
	 */
	btn_goto_bargindo : function() {
		
		nmOpUI.btn_save_Operation(function(){
			
			if(nmOpUI.checkNullOrType()){
				nmQuery.queryDataFromTable('YK_S_APP', appno, function(tx,
								res) {
							var len = res.rows.length;
							if (len > 0) {// 本地未查询
								var xs = res.rows.item(0);
								var ywsl = "'APP_NO':'" + xs['APP_NO']
										+ "', 'CONS_NAME':'"
										+ xs['CONS_NAME']
										+ "', 'CERT_ID':'" + xs['CERT_ID']
										+ "', 'CERT_TYPE_CODE':'"
										+ xs['CERT_TYPE_CODE']
										+ "', 'CERT_NO':'" + xs['CERT_NO']
										+ "', 'CERT_NAME':'"
										+ xs['CERT_NAME']
										+ "', 'CONTACT_ID':'"
										+ xs['CONTACT_ID']
										+ "', 'CONTACT_NAME':'"
										+ xs['CONTACT_NAME']
										+ "', 'POSTALCODE':'"
										+ xs['POSTALCODE']
										+ "', 'OFFICE_TEL':'"
										+ xs['OFFICE_TEL'] + "', 'ADDR':'"
										+ xs['ADDR'] + "', 'MOBILE':'"
										+ xs['MOBILE'] + "', 'REASON':'"
										+ xs['REASON'] + "', 'REMARK':'"
										+ xs['REMARK'] + "'";
								var task = "'ORGNO':'"
										+ sessionStorage.ORG_NO
										+ "', 'SYS_USER_NAME':'"
										+ sessionStorage.user_name
										+ "', 'APP_NO':'"
										+ sessionStorage.amAPP_NO
										+ "', 'INSTANCE_ID':'"
										+ sessionStorage.INSTANCE_ID + "'";
	
								netRequest.rwcdYwslMsg(ywsl, task,
										netRequest.successHtqcCallBack,
										netRequest.faileCallBack);
	
							}
						}, pubData.failNmo);
			}
		});

	},
	/****
	 * 界面检索，非空等判断
	 */
	checkNullOrType : function(){
		var tipStr = "";
		var CONS_NAME = document.getElementById("nmo_CONS_NAME").value;
		if(CONS_NAME == "") {
			tipStr = "用户名称不能为空";
		}
		else if(PubFuns.isNum(CONS_NAME)) {
			tipStr = "用户名称不可以全是数字";
		}
		if(tipStr != "") {
			publicUIShow.amDialog(tipStr, 1);
			return false;
		}
		var CONTACT_NAME = document.getElementById("nmo_CONTACT_NAME").value;
		if(CONTACT_NAME == "") {
			tipStr = "联系人不能为空";
		}
		else if(PubFuns.isNum(CONTACT_NAME)) {
			tipStr = "联系人不可以全是数字";
		}
		if(tipStr != "") {
			publicUIShow.amDialog(tipStr, 1);
			return false;
		}
		var REASON = document.getElementById("nmo_REASON").value;
		if(REASON == "") {
			tipStr = "申请原因不能为空";
		}
		if(tipStr != "") {
			publicUIShow.amDialog(tipStr, 1);
			return false;
		}
		var MOBILE = document.getElementById("nmo_MOBILE").value;
		var OFFICE_TEL = document.getElementById("nmo_OFFICE_TEL").value;
		console.log("----**"+OFFICE_TEL);
		if(MOBILE == "" && OFFICE_TEL == "") {
			tipStr = "固定电话、移动电话必须填一个";
		}else if(MOBILE != "") {
			if(MOBILE.length != 11 || !PubFuns.isNum(MOBILE)) {
				tipStr = "移动电话必须为11位数字";
			}
		}else if(OFFICE_TEL != ""){
			if(OFFICE_TEL.indexOf("-") == -1) {
				tipStr = "固定电话必须格式是\"3或4位区号\"+\"-\"+\"8位电话号码\"或者\"3或4位区号\"+\"-\"+\"8位电话号码\"+\"-\"+\"分机号码1-4位\"";
			}else {
				var temp = OFFICE_TEL.split("-");
				if($("#office_tel_qh").val() == "" || $("#office_tel_num").val() == "") {
					tipStr = "固定电话必须格式是\"3或4位区号\"+\"-\"+\"8位电话号码\"或者\"3或4位区号\"+\"-\"+\"8位电话号码\"+\"-\"+\"分机号码1-4位\"";
				}else if(temp[0] == "" ||(temp[0] != "" && (temp[0].length<3 || temp[0].length>4))){
					tipStr = "固定电话必须格式是\"3或4位区号\"+\"-\"+\"8位电话号码\"或者\"3或4位区号\"+\"-\"+\"8位电话号码\"+\"-\"+\"分机号码1-4位\"";
				}else if(temp[1] == "" || (temp[1] != "" && temp[1].length != 8)){
					tipStr = "固定电话必须格式是\"3或4位区号\"+\"-\"+\"8位电话号码\"或者\"3或4位区号\"+\"-\"+\"8位电话号码\"+\"-\"+\"分机号码1-4位\"";
				}else if((temp[2] != "" && temp[2] != undefined )&& (temp[2].length<1 || temp[2].length>4)){
					tipStr = "固定电话必须格式是\"3或4位区号\"+\"-\"+\"8位电话号码\"或者\"3或4位区号\"+\"-\"+\"8位电话号码\"+\"-\"+\"分机号码1-4位\"";
				}
				else {
					
					/*for (var i = 0; i < temp.length; i++) {
						if(!PubFuns.isNum(temp[i])) {
							tipStr = "固定电话必须是数字";
							break;
						}
					}*/
				}
			}
		}
			
		if(tipStr != "") {
			publicUIShow.amDialog(tipStr, 1);
			return false;
		}
		
		return true;
	}
}

/****
 * 拼接电话号码
 */
function nmvaliOfficetel(type){
	var office_tel_qh = $("#office_tel_qh").val();
	var office_tel_num = $("#office_tel_num").val();
	var office_tel_fjh = $("#office_tel_fjh").val();
	if(office_tel_fjh != ""){
		$("#nmo_OFFICE_TEL").val(office_tel_qh+"-"+office_tel_num+"-"+office_tel_fjh);
	}else if(office_tel_qh !="" || office_tel_num != ""){
		$("#nmo_OFFICE_TEL").val(office_tel_qh+"-"+office_tel_num);
	}else{
		$("#nmo_OFFICE_TEL").val("");
	}
	console.log($("#nmo_OFFICE_TEL").val());
}



nmOpUI.init();
