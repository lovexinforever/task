console.log("btpair");
var BtPair = function() {

};

/**
 * 配对目标蓝牙设备
 */
BtPair.prototype.toPair = function(argument, successCallback) {
    return PhoneGap.exec(null, null, 'BtPairPlugin', "action_pair", [argument]);
};

/**
 * 扫描蓝牙设备
 */
BtPair.prototype.startSacn = function(argument) {
    return PhoneGap.exec(null, null, 'BtPairPlugin', "action_start_scan", [argument]);
};

/**
 * 扫描蓝牙设备
 */
BtPair.prototype.stopScan = function() {
    return PhoneGap.exec(null, null, 'BtPairPlugin', "action_stop_scan", []);
};


/**
 * 实例化插件
 */
cordova.addConstructor(function() {
	cordova.addPlugin("BtPair", new BtPair());
});


/**
 * 蓝牙配对
 * @param {Object} addr: 蓝牙的地址 
 */
function toPair(addr) {
    var data = {"addr": addr};
    window.plugins.BtPair.toPair(data);
}

/**
 * 开始扫描 
 * @param {Object} type:        
 *      Printer,         // 打印机
 *      CheckoutMeter,   // 校验仪
 *      InfraredEpm,     // 红外设备
 *      SecondDrangDrop, // 二次压降
 *      SecondChargeA,   // 二次负荷TA
 *      SecondChargeV    // 二次负荷TV
 */
function startSacn(type) {
    var data = {"type": type};
    window.plugins.BtPair.startSacn(data);
}

/**
 * 停止扫描 
 */
function stopScan() {
    window.plugins.BtPair.stopScan();
}
