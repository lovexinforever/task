/**
 * Copy Right Information  : STATE GRID
 * author                  	: zhangtianchang
 * Comments                	: 设置
 * Version                 	: 0.0.1
 * Modification history    	: 2014-05-04
 * Sr	Date        Modified By     Why & What is modified
 * 1.	2014-05-04  zhangtianchang    new file
 */


var setData = {
	default : function(){

	},
	/**
	 * 蓝牙数据保存
	 */
	btn_bluetooth_data_click : function(){
		Sharedpreference.put("filemaint",[{"k":"BluetoothMac","v":"08:09:e9:a1:d4:12"},{{"k":"ClearRate","v":"15"}],
			function(succ,res) {
			 	alert("succ=" + succ);

			}, function(err){
			  	alert("err"+err);
			} );
	},
	/**
	 * 清理数据
	 */
	btn_data_clear_data_click : function(){
		Sharedpreference.clear("filemaint",
				function(succ,res) {
				 	alert("succ=" + succ);

				}, function(err){
				  	alert("err"+err);
				} );
	}
}
