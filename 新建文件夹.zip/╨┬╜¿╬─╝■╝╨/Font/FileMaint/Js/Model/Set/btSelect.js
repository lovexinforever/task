var scan_state = 0;
var txt_state_paired  = "已配对";
var txt_state_pairing = "正在配对...";
var txt_state_none    = "可用设备";
var BT_STATE = {NONE:"None", PAIRING:"Pairing", PAIRED:"Paired"};
var sel_mac = "";

EventUtil.addClickListener({id:"cancel", clk: function() {$.cache["dialog"].close();}});

EventUtil.addClickListener({id:"start_scan", clk: function() {
    if(scan_state == 0) {
        var body = document.getElementById("body");
        body.innerHTML = "";
        startSacn("InfraredEpm");
        scan_state = 1;
    }
    else {
        stopScan();
        end_scan();
        scan_state = 0;
    }
}});

function start_scan() {
    document.getElementById("btn_start_scan").innerText = "停止";
    document.getElementById("loading").style.visibility = "visible";
}

function end_scan() {
    document.getElementById("btn_start_scan").innerText = "扫描";
    document.getElementById("loading").style.visibility = "hidden";
}

function item_click(id) {
    var state_txt = document.getElementById("bt_state" + id).innerHTML;
    sel_mac = id;
    if(state_txt == txt_state_paired) {
        // 得到mac地址，关闭弹出框
        stopScan();
        document.getElementById("txt_mac_addr").innerText = id;
        $.cache["dialog"].close();
    }
    else if(state_txt == txt_state_pairing) {
        // 提示正在配对中
        alert("配对中...");
    }
    else if(state_txt == txt_state_none) {
        // 发送配对请求
        stopScan();
        toPair(id);
    }
}

function bond_bonded() {
    set_state_txtandcolor(document.getElementById("bt_state" + sel_mac), BT_STATE.PAIRED);
}

function bond_bonding() {
    set_state_txtandcolor(document.getElementById("bt_state" + sel_mac), BT_STATE.PAIRING);
}

function bond_none() {
    set_state_txtandcolor(document.getElementById("bt_state" + sel_mac), BT_STATE.NONE);
}

function set_state_txtandcolor(obj, state) {
    var txt = "";
    if(state == BT_STATE.PAIRED) {
        txt = txt_state_paired;
        obj.style.color = "#00afed";
    }
    else if(state == BT_STATE.NONE) {
        txt = txt_state_none;
        obj.style.color = "#000000";
    }
    else if(state == BT_STATE.PAIRING) {
        txt = txt_state_pairing;
        obj.style.color = "#000000";
    }
   
    obj.innerHTML = txt;
}

function scan_find_newdevice(data) {
    var list = JSON.parse(data);
    var body = document.getElementById("body");
    body.innerHTML = "";
    for(var i = 0; i < list.length; i++) {
        var name  = list[i].name;
        var state = list[i].state;
        var addr = list[i].addr;
        
        body.innerHTML += '<div class="line" id="' + addr + '">'
                            + '<div class="left_icon">'
                                + '<img src="../../../Res/Images/icon_phone.png" />'
                            + '</div>'
                            + '<div class="right_txt">'
                                + '<div class="bt_name">' + name + '</div>'
                                + '<div class="bt_state" id="bt_state' + addr + '">' + state + '</div>'
                            + '</div>'
                        + '</div>';

        
        // 设置状态的文字和颜色
        var obj = document.getElementById("bt_state" + addr);
        set_state_txtandcolor(obj, state);
    }

    for(var i = 0; i < list.length; i++) {
        var addr = list[i].addr;
        EventUtil.addClickListener({id: addr, clk: item_click, args: addr});
    }
}