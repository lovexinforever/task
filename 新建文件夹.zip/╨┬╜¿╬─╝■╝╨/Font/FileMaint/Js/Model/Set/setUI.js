/**
 * Copy Right Information  : STATE GRID
 * author                  	: zhangtianchang
 * Comments                	: 设置
 * Version                 	: 0.0.1
 * Modification history    	: 2014-05-04
 * Sr	Date        Modified By     Why & What is modified
 * 1.	2014-05-04  zhangtianchang    new file
 */
/**
 * 初始化页面
 */
var setUI = {
	/**
	 * 初始化页面
	 */
	init: function() {	    
	    util.moblie.navbar.title = "设置";
        util.moblie.navbar.buttonList = ["back", "menu"];

        /* 得到配置文件中蓝牙的Mac地址和清除数据的天数 */
        Sharedpreference.get("config", ["bl_mac", "clear_rate"], setUI.getconfig_succ, setUI.getconfig_fail);
  
        /* 打开选择蓝牙界面 */
        EventUtil.addClickListener({id: "bluetooth", clk: setUI.choice_bluetooth});
        
        EventUtil.addClickListener({id: "clear_db", clk: setUI.clear_db});
        
        /* 保存页面的配置 */
        EventUtil.addClickListener({id: "btn_save", clk: setUI.btn_save_click});
	},
	
	/**
	 * 获取到配置信息的成功回调函数 
	 */
	getconfig_succ: function(tx) {
	    document.getElementById("txt_mac_addr").innerText = tx.bl_mac;
	    if(tx.clear_rate != "") {
	        document.getElementById("txt_clear_rate").innerText = tx.clear_rate;
	    }	  
	},
	
	/**
	 * 获取到配置信息的失败回调函数  
	 */
	getconfig_fail: function(tx) {
	    
	},
	
	/**
	 * 选择蓝牙 
	 */
	choice_bluetooth: function() {
	    console.log("choice_bluetooth");
	     $.Elec.dialog({
            htmlObj:"../../../Html/Model/Set/btIndex.html"
        });	   
	},
	
	clear_db: function() {	    
	    var data = {p1: "1天", p2: "2天", p3: "5天", p4: "10天", p5: "1个月", p6: "3个月"};
        list_show({data: data, title: "选择授权模块", item_click_callback: function(id) {
                var temp = data[id];
                var txt;
                if(temp.search("天") != -1) {
                    txt = temp.replace("天", "");
                }
                else if(temp.search("个月") != -1) {
                    txt = temp.replace("个月", "");
                    txt = txt*30;
                }
                document.getElementById("txt_clear_rate").innerText = txt;
            }, bgCallback: function() {$.cache["dialog"].close();}
        });
	},
	
	/**
	 * 保存按钮的点击事件(保存配置信息) 
	 */
	btn_save_click: function() {
	    /* 保存蓝牙的Mac地址和清除数据的天数到配置文件中 */
	    var txtMacAddr = document.getElementById("txt_mac_addr").innerText;
        var txtClearRate = document.getElementById("txt_clear_rate").innerText;
	   
	    Sharedpreference.put("config",[{"k":"bl_mac","v":txtMacAddr}, {"k":"clear_rate","v":txtClearRate}],
            function(succ, res) {
            	PubFuns.dialog_alert("保存成功");
            }, 
            function(err) {
            	PubFuns.dialog_alert(err);
            }
        );
        //navbarBack();
	}	
};

setUI.init();

/**
 * 返回按钮的点击事件（重写） 
 */
navbarBack = function() {
    $("#dx-viewport-one").load("../Main/mainContent.html");
}

