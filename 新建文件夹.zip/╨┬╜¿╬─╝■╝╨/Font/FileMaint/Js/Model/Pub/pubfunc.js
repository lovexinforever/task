var PubFuns = {

	loadingNode: null,
	tid: "", 
	/**
	 * 增加loading框
	 */
	addLoadingDialog: function() {
		PubFuns.loadingNode = $.Elec.loading({
		 	text:"请求数据中...",    		
	        icon:"pic_loading",  
	        time: 30*1000,
	        timeCallback: PubFuns.removeLoadingDialog
	    });
	},

	/**
	 * 取消loading框
	 */
	removeLoadingDialog: function() {
		if(PubFuns.loadingNode != null) {
			PubFuns.loadingNode.close();
			PubFuns.loadingNode = null;
		}
	},

	/**
	 * 初始化弹出框的主题
	 */
	initDialogTheme: function() {
		$.Elec.dialogTemplate.addDialogTheme("dialog", {
		    style: "dialog_box",          // 全局样式的名字

		    head: {                       // 头部样式设置
		        txt: "温馨提示",
		        style: "head",            // 头部的样式名字
		    },
		    
		    body: {                       // 内容样式设置
		        style: "body dialogbody", // 内容样式的名字
		        items: []                 // type:singleKV, singleKVWithBorder, doubleKV, editbox, listbox, password, text
		    },

		    bottom: {                     // 底部样式设置
		        type: "singleBtn",        // singleBtn, doubleBtn
		        style: "bar", 
		        btn: {                   
	                args: [],
	                clickCB:  function() {$.cache["dialog"].close();},
	                style: "btn_blue", 
	                txt: "确定"
		        }
		    },
		    bg: {
		        clickCB:  function() {$.cache["dialog"].close();},
		        args:[]
		    }
		});	
	},

	/**
	 * 弹出提示对话框
	 */
	dialog_alert: function(data, btnClick) {
		// 设置当前的主题
		$.Elec.dialogTemplate.setCurrentTheme("dialog");
		
		if(btnClick == undefined) {
			$.Elec.dialogTemplate.setValue({head: "温馨提示"});
		}
		else {
			$.Elec.dialogTemplate.setValue({head: "温馨提示", btn: {clickCB:{func: btnClick} }});
		}

		$.Elec.dialogTemplate.setItemsData([
		    {
		        type: "text",
		        data: data
		    }
		]).show();
	},

	/**
	 * 查询PCode码
	 */
	selectPCode: function(data, succCB, failCB) {
		var CODE_SORT_ID = data.CODE_SORT_ID;
		var VALUE = data.VALUE;
		var NAME  = data.NAME;
		if(CODE_SORT_ID == undefined) {
			return;
		}
		
		if(VALUE == undefined && NAME == undefined) {
			return;
		}

		var sql = "";
		if(VALUE != undefined) {
			sql = "select CODE_SORT_ID, VALUE, NAME from P_CODE where CODE_SORT_ID=" + CODE_SORT_ID + " and VALUE='" + VALUE + "'";
		}
		else if(NAME != undefined) {
			sql = "select CODE_SORT_ID, VALUE, NAME from P_CODE where CODE_SORT_ID=" + CODE_SORT_ID + " and NAME='" + NAME + "'";
		}
		db_execut_oneSQL("dawh.db", sql, [], succCB, failCB);
	},

	/**
	 * 是不是数字
	 */
	isNum: function(str) {
		var num = new Number(str);
		var str = new String(str);
		if(str.match("\\-0\\d|\\b^\\.?0\\d")) {
			return false;
		} else if (num.toString() == "NaN" && str != "-") {
			return false;
		} else {
			return true;
		}
	},

	getMyTid: function() {
		if(PubFuns.tid == "") {
			getTid(function(data) {
				PubFuns.tid = data;
				return PubFuns.tid;
			}, null);
		}
		else {
			return PubFuns.tid;
		}
	}
};
