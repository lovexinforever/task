
var consNoVal = "";
var assetNoVal = "";

util.moblie.navbar.buttonList = ["back", "menu"];
util.moblie.navbar.title = "任务发起";

// 返回
navbarBack = function() {
	
	$("#dx-viewport-one").html("");
	if(sessionStorage.fmWhichApply == "dabg"){	//档案变更
		$("#dx-viewport-one").load("../ArchivesModify/amWorkList.html");
	} else if (sessionStorage.fmWhichApply == "gm") { // 更名
		$("#dx-viewport-one").load("../NameModify/index.html");
	}
	sessionStorage.fmWhichApply = "";
}

// 任务发起
EventUtil.addClickListener({
	id : "sendApply",
	clk : function() {
		sendWhichApply();
	}
});

/**
 * 初始化搜索框
 */
$(".search").elecSearch({
			callback : function(obj) {
				var txtNo = obj.searchText;
				if (txtNo == "") {
					PubFuns.dialog_alert("请填写" + obj.selectobj.text);
				} else {
					consNoVal = "";
					assetNoVal = "";
					obj.selectobj.id == 1
							? consNoVal = txtNo
							: assetNoVal = txtNo;

					var pkg = {
						"CONS_NO" : consNoVal,
						"ASSET_NO" : assetNoVal
					};
					pkg = JSON.stringify(pkg);
					queryUserInfo("000001", pkg, showBaseInfo, sendErrorCB);
				}
			},
			select : {
				list : [{
							id : 1,
							text : "用户编号"
						}, {
							id : 2,
							text : "电表资产编号"
						}],
				callback : function(obj) {
					if (obj.selectobj.id == 2) {
						fm_bluetooth_connect(function(value) {
									$("input[type='search']").val(value);
								});
					}
				}
			}
		});

/**
 * 查询用户信息成功回调 初始化页面
 */
function showBaseInfo(data) {
	
	removeDialog();// 关闭Loading框
	if (Elec.setUndefined(data) == "" || data.length ==0) {
		Elec.getELeById("cm_head").setAttribute("class", "box hidden");
		PubFuns.dialog_alert("未查询到数据");
	} else {
		Elec.getELeById("cm_head").setAttribute("class", "box show");

		var tempArray = amPubUI.returnHtmlIdArr("[id*='am_']");
		amPubUI.initPageHtml(data, tempArray); // 初始化页面数据
		amQuery.tansformCode(amQuery.codeSortJson);// Pcode转码
		amQuery.queryOrgNo(data.ORG_NO,"am_ORG_NO");
	}
}

/**
 * 查询用户信息失败回调
 */
function sendErrorCB(obj) {
	removeDialog();// 关闭Loading框
	if (obj.flag == 1) {// 成功
	} else {
		amPubUI.amDialog(obj.msg, 1);
	}
}


/**
 * 查询用户基本信息  FUN：000001
 * @param {} fun
 * @param {} pkg
 * @param {} success
 * @param {} callback
 */
function queryUserInfo(fun, pkg, success, callback) {
	addLoading();
	var basePkg = '{"MOD":"2021","FUN":"' + fun + '","ORG_NO":"'
			+ sessionStorage.ORG_NO + '","PKG":' + pkg + '}';
	try {
		send_data(fun, "2021", basePkg, function(msg) {
					msg = JSON.parse(msg);
					if (msg.RET == "00") // 平台通讯成功
					{
						var ret = msg.PKG.RET;
						if (ret == "10") // 数据返回成功
						{
							var returnData = msg.PKG.PKG.CONSINFO[0];
							if (Elec.setUndefined(returnData.FLAG) =="-1"){ // 接口业务失败
								if (returnData.ERR_MSG)
									callback({"flag":"-1","msg":returnData.ERR_MSG});
								else
									callback({"flag":"-1","msg":amMsg.I});
							} else {
								success(returnData);
							}
						} else{
							var tpMsg = msg.PKG.PKG.ERR_MSG;
							tpMsg = tpMsg?tpMsg:amMsg.I;
							callback({"flag":"-1","msg":tpMsg});// 数据返回失败
						}
					} else
						callback({"flag":"-1","msg":amMsg.I});// 平台通讯异常

				}, function(msg) {
					callback({"flag":"-1","msg":amMsg.F});
				});
	} catch (e) {
		console.log("err->"+e);
		callback({"flag":"-1","msg":amMsg.W});
	}
}

/**
 * 选择发起哪项任务  dabg是档案变更  dm是更名
 */
function sendWhichApply(){
	if(sessionStorage.fmWhichApply == "dabg"){	//档案变更
		amSendApply({
			consNo : consNoVal,
			assetNo : assetNoVal,
			callback : function(obj) {
				reMsgDeal(obj, function() {
							sessionStorage.fmWhichApply = "";
							toNext("../ArchivesModify/amBusinessDeal.html");
						});
			}
		});
	} else if (sessionStorage.fmWhichApply == "gm") { // 更名

		var taskmsg = "{'CONS_NO':'" + consNoVal + "', 'ASSET_NO':'"
				+ assetNoVal + "', 'APP_TYPE_CODE':'210', 'SYS_USER_NAME':'"
				+ sessionStorage.user_name + "','ACT_CODE':''}";
		netRequest.addTaskFqmsg(taskmsg, netRequest.successYwslCallBack,
				netRequest.faileCallBack);
	}
}