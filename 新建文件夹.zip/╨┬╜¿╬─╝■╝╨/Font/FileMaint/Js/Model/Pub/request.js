/**
 * Copy Right Information   : STATE GRID
 * author                  	: yuenhoawong
 * Comments                	: 公共网络请求
 * Version                 	: 0.0.1
 * Modification history    	: 2014-04-28
 * Sr	Date        Modified By     Why & What is modified
 * 1.	2014-06-06  yuenhoa.wong    new file
 * 2. 	2014-06-06  yuenhoa.wong    define api
 */
var file_maint_req = {
    debug : true,

    /** 请求码 */
    REQ_CODE : {
    	/** 公共接口 */
        userBaseInfo:        {modNo: "2021", funcNo: "000001"},    // 用户基本信息的请求码
        actSelect:           {modNo: "2021", funcNo: "000002"},    // 待办事宜查询
        addrCode:      		 {modNo: "2021", funcNo: "000003"},    // 用电地址码查询
        /** 密码重置 */
        resetPassword:       {modNo: "2021", funcNo: "000301"},    // 密码重置的请求码
        /** 联系人信息 */
        linkmanSelect:       {modNo: "2021", funcNo: "000203"},    // 联系人信息查询
        linkmanDelete:       {modNo: "2021", funcNo: "000202"},    // 联系人信息删除
        linkmanSave:         {modNo: "2021", funcNo: "000201"},    // 联系人信息保存
        /** 授权 */
        giverightSelectNo:   {modNo: "2021", funcNo: "000101"},    // 授权管理查询环节处理工号
        giverightLaunch:     {modNo: "2021", funcNo: "000102"},    // 授权管理发起授权
        giverightSelectInfo: {modNo: "2021", funcNo: "000103"}     // 授权管理授权信息查询
    },

	/**
	 * 02010001/查询用户档案基本信息
	 * 适用于首页查询、联系人维护、密码重置、档案变更模块的用户基本信息查询
	 * @param 	{String}	type 			1:用户编号 2:用户资产编号
	 * @param 	{String} 	id				用户编号或用户资产编号
	 * @param	{function}	succCB		          成功回调
	 * @param   {function}  failCB          失败回调
	 */
	select_user_base_info : function(type, id, succCB, failCB) {
	    var obj = {};
	    if(type == 1) {
		    obj.CONS_NO = id;
	    }
	    if(type == 2) {
		    obj.ASSET_NO = id;
	    }
		var code = file_maint_req.REQ_CODE.userBaseInfo;   
		var pkg = pkg_data.get_pkg_data(code, obj);
	    	   
		send_data(code.funcNo, code.modNo, pkg, succCB, failCB);	   
	},
	
	/**
     * 待办事宜类型查询
     * @param {function}  succCB   成功回调
     * @param {function}  failCB   失败回调
     * @param {JSON}      data     需要的数据
     */
	act_select: function(succCB, failCB, data) {
		var code = file_maint_req.REQ_CODE.actSelect;
		var pkg = pkg_data.get_pkg_data(code, data);
                
        send_data(code.funcNo, code.modNo, pkg, succCB, failCB);
	},

	/** 
	 * 用电地址码查询
	 */
	addrcode_select: function() {

	},

	/**
	 * 密码重置
	 * @param {String}    cons_no  用户编号 
     * @param {function}  succCB   成功回调
     * @param {function}  failCB   失败回调
	 */
	reset_password: function(cons_no, succCB, failCB) {
	    var code = file_maint_req.REQ_CODE.resetPassword;
        var pkg = pkg_data.get_pkg_data(code, {CONS_NO: cons_no});
              
        send_data(code.funcNo, code.modNo, pkg, succCB, failCB);
	},
	
	/**
	 * 联系人信息查询 
	 * @param {String}    cons_no  用户编号 
     * @param {function}  succCB   成功回调
     * @param {function}  failCB   失败回调
	 */
	linkman_select_req: function(cons_no, succCB, failCB) {
		var code = file_maint_req.REQ_CODE.linkmanSelect;
	    var pkg = pkg_data.get_pkg_data(code, {CONS_NO: cons_no});

        send_data(code.funcNo, code.modNo, pkg, succCB, failCB);
	},
	
	/**
	 * 联系人信息删除
     * @param {function}  succCB     成功回调
     * @param {function}  failCB     失败回调
     * @param {String}    contact_id 联系人唯一标示
     * @param {String}    cons_id    用户ID
	 */
	linkman_delete_req: function(contact_id, cons_id, succCB, failCB) {	 
		var code = file_maint_req.REQ_CODE.linkmanDelete;   
	    var data = {CONTACT_ID: contact_id, CONS_ID: cons_id};
	    var pkg = pkg_data.get_pkg_data(code, data);
                
        send_data(code.funcNo, code.modNo, pkg, succCB, failCB);
	},
	
	/**
     * 联系人信息保存/更新
     * @param {function}  succCB   成功回调
     * @param {function}  failCB   失败回调
     * @param {JSON}      data     需要的数据
     */
    linkman_saveorupdate_req: function(succCB, failCB, data) {   
    	var code = file_maint_req.REQ_CODE.linkmanSave;     
        var pkg = pkg_data.get_pkg_data(code, data);

        send_data(code.funcNo, code.modNo, pkg, succCB, failCB);
    },
	
	/**
	 * 授权管理查询环节处理工号
	 * @param {String}   act_code_value 待办事宜类型
	 * @param {String}   sys_user_name  登录人员工号
	 * @param {function} succCB         成功回调
	 * @param {function} failCB         失败回调
	 */
	giveright_selectno_req: function(act_code, sys_user_name, succCB, failCB) {
		var code = file_maint_req.REQ_CODE.giverightSelectNo;
		var data = {ACT_CODE: act_code, SYS_USER_NAME: sys_user_name};
		var pkg = pkg_data.get_pkg_data(code, data);

        send_data(code.funcNo, code.modNo, pkg, succCB, failCB);
	},
	
	/**
     * 授权管理发起授权
     * @param {function}  succCB   成功回调
     * @param {function}  failCB   失败回调
     * @param {JSON}      data     需要的数据
     */
	giveright_launch: function(succCB, failCB, data) {
		var code = file_maint_req.REQ_CODE.giverightLaunch;
 		var pkg = pkg_data.get_pkg_data(code, data);
                
        send_data(code.funcNo, code.modNo, pkg, succCB, failCB);
	},

	/**
     * 授权管理授权信息查询
     * @param {function}  succCB   成功回调
     * @param {function}  failCB   失败回调
     * @param {JSON}      data     需要的数据
     */
	giveright_selectinfo: function(succCB, failCB, data) {
		var code = file_maint_req.REQ_CODE.giverightSelectInfo;
		var pkg = pkg_data.get_pkg_data(code, data);
                
        send_data(code.funcNo, code.modNo, pkg, succCB, failCB);
	},
	
	/**
	 * 03010001/业务申请
	 * 适用于更名、档案变更模块的业务申请请求
	 * @param	{String}	cons_no			用户户号
	 * @param	{String}	app_type_code	申请类型    201:更名  306:档案变更
	 * @return	{Object} 					json结果集
	 */
	app_req : function(cons_no, app_type_code){
		return 0;
	},
	/**
	 * 04000001/待办事宜查询
	 * 适用于更名、档案变更模块的业务申请请求
	 * @param	{String}	sys_user_name	登录用户名
	 * @param	{String}	type_code		待办事宜类型 
	 * 										null	: 所有更名、档案变更的待办事宜
	 * 										0210001 : 更名业务受理
	 * 										0210002 : 更名合同起草
	 * 										0210003 : 更名合同审核
	 * 										0210004 : 更名合同签订
	 * 										0306001 : 档案变更业务受理
	 * 										0306002 : 档案变更勘查派工
	 * 										0306003 : 档案变更现场勘查
	 * @return	{Object}					json结果集
	 */
	select_pending_app : function(sys_user_name, type_code){
		return 0;
	},
	/**
	 * 04000002/查询环节处理工号
	 * 适用于更名、档案变更模块的业务申请请求
	 * @param	{String}	app_no			申请编号	可为null
	 * @param	{String}	instance_id		活动实例标识
	 * @param	{String}	emp_no			登录工号唯一标识
	 * @return	{Object}					json结果集
	 */
	select_xxx : function(app_no, instance_id, emp_no){
		return 0;
	},
	/**
	 * 04000003/任务传递
	 * 适用于更名、档案变更模块的业务申请请求
	 * @param	{String}	orgno			供电单位
	 * @param	{String}	finishempno		完成人
	 * @param	{String}	app_no			申请编号
	 * @param	{String}	instance_id		活动实例标识
	 * @param	{String}	type_code		待办事宜类型
	 * 										0210001:更名业务受理
	 * 		 								0210002:更名合同起草
	 * 		  								0210003:更名合同审核
	 * 										0210004:更名合同签订
	 * 										0306001:档案变更业务受理
	 * 										0306002:档案变更勘查派工
	 * 										0306003:档案变更现场勘查
	 * @return	{Object}					json结果集
	 */
	mission_transfer: function(orgno, finishempno,app_no,instance_id,type_code){
		return 0;
	},
	select_addrcode : function(data, succCB, failCB){
		var code = file_maint_req.REQ_CODE.addrCode;
		var pkg = pkg_data.get_pkg_data(code, data);
		send_data(code.funcNo, code.modNo, pkg, succCB, failCB);
	}
};

/** 专门处理pkg数据 */
var pkg_data = {
    /**
     * 得到请求的数据包
     * @param {JSON} req_code  请求码
     * @param {JSON} data      需要的数据
     */
    get_pkg_data: function(req_code, data) {
        var modNo  = req_code.modNo;
        var funcNo = req_code.funcNo;
        var pkg = '{"MOD":"' + modNo + '","FUN":"' + funcNo 
                + '","SYS_USER_NAME":"' + localStorage.user_name + '", "ORG_NO":"' + localStorage.ORG_NO + '", "TERM_NUM":"' + '860275020934797'/*PubFuns.getMyTid()*/ + '","PKG":' + JSON.stringify(data) + '}';
        return pkg;        
    }  
    
};
