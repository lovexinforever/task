//参数目标元素

var clickTaskQuery1;
var clickTaskQuery2;
var clickTaskBlue;
var get_barcode;
var changeState;

var contentIndex = 0;

var tagScroll = function(scrollElement,element){
   scrollElement.style.left = element.offsetLeft +"px";
}    

/***
 * 任务发起 头部用户编号和电表资产编号切换
 */
$(".task_launch_box .tag .header").on("touchstart",function(event){
    var otherTarget = event.target.previousElementSibling || event.target.nextElementSibling;
    otherTarget.classList.remove("default");
    event.target.classList.add("default");    
    
    if($(event.target).attr("contentIndex") == 1){//电表资产编号
    	contentIndex = 1;
    	if($(event.target).attr("blue") != "blue"){
    		clickTaskBlue();
    	}
    	$(event.target).attr("blue","blue");
    }else{
    	contentIndex = 0;
    }
    
    var scrollElement = document.getElementsByClassName("scroll")[0];
    tagScroll(scrollElement,event.target);
})


/***
 * consOrAssetNo
 * contentIndex 类型 0用户编号 1电表资产编号
 */

EventUtil.addClickListener({//确定按钮 任务发起
	id : "tasklauch_ok",
	clk : function() {
		var consOrAssetNo = $("#consOrAssetNo").val();
		clickTaskQuery1(consOrAssetNo,contentIndex);
	}
});
EventUtil.addClickListener({//取消按钮 关闭dialog
	id : "tasklauch_cacle",
	clk : function() {
		$.cache.dialog.close();
	}
});
