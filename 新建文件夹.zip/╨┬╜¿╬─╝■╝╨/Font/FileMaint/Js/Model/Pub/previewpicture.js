
/**
 * 图片预览
 */


var prepic_path;
var prepic_header;

/***
 * 显示图片
 */
function showSystempic() {
	getPictureShow({
				"photopath" : $("#picviewImg").attr("src")
			}, null, null);
}

/***
 * 关闭弹出框
 */
function closePPDialog() {
	$.cache["dialog"].close();
}

/****
 * 更新业务受理拍照状态
 */
function updateYkImage(keyValueArr, successCB, failCB) {
	var sql = "update " + keyValueArr[4] + " set IMAGE_STATE='"
			+ keyValueArr[0] + "' ,IMAGE_BIG='" + keyValueArr[1]
			+ "' ,IMAGE_SMALL='" + keyValueArr[2] + "' where APP_NO = '"
			+ keyValueArr[3] + "'";
	db_execut_oneSQL("dawh.db", sql, [], successCB, failCB);
}

/***
 * 更新业务受理身份证照片状态
 */
function updateYkIdcardImage(keyValueArr, successCB, failCB) {
	var sql = "update " + keyValueArr[3] + " set IDIMAGE_STATE='"
			+ keyValueArr[0] + "' ,IDIMAGE_NAME='" + keyValueArr[1]
			+ "' where APP_NO = '" + keyValueArr[2] + "'";
	db_execut_oneSQL("dawh.db", sql, [], successCB, failCB);
}

/**
 * 弹出list选择对话框
 * 
 * @param {JSON}
 *            data 数据列表
 * @param {String}
 *            title 列表标题
 * @param {Function}
 *            item_click_callback 点击列表项的回调函数
 * @param {Object}
 *            bgCallback 点击背景区域的回调函数
 */
function picture_show(path, title, bgCallback) {
	prepic_path = path;
	prepic_header = title;
	$.Elec.dialog({
				htmlObj : "../../../Html/Pub/previewpicture.html",
				bgCallback : bgCallback
			});
}

/*******************************************************************************
 * 任务发起弹出框
 * 
 * @param {}
 *            title 标题
 * @param {}
 *            bgCallback 底部背景回调事件 并实现下列方法 clickTaskQuery2 = function(){
 *            alert("clickok2"); }; clickTaskBlue = function(){ alert("blue"); };
 *            clickTaskQuery1 = function(){ alert("clickok1"); };
 */
function add_task(title, bgCallback) {
	$.Elec.dialog({
				htmlObj : "../../../Html/Pub/task_launch.html",
				bgCallback : bgCallback
			});
}

var loadingNode = null;
/**
 * 增加loading框
 */
function addLoading() {
	if(loadingNode!=null){
		return;
	}
	loadingNode = $.Elec.loading({
				time : 90000,
				timeCallback : function() {
					//$.cache["dialog"].close();
					removeDialog();
				}
			});
}

/**
 * 取消loading框
 */
function removeDialog() {
	if (loadingNode != null) {
		loadingNode.close();
		loadingNode = null;
	}
}
