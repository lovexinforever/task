var PicturePlugin = function(){
	
}

PicturePlugin.prototype.getPPShow=function(argument,successCallBack,faileCallBack){
	
	return PhoneGap.exec(successCallBack,faileCallBack,'PicturePlugin','show',[argument]);
}

PicturePlugin.prototype.getPPPath=function(argument,successCallBack,faileCallBack){
	return PhoneGap.exec(successCallBack,faileCallBack,'PicturePlugin','path',[argument]);
}

PicturePlugin.prototype.getPPDelete=function(argument,successCallBack,faileCallBack){
	return PhoneGap.exec(successCallBack,faileCallBack,'PicturePlugin','delete',[argument]);
}

cordova.addConstructor(function() {
	cordova.addPlugin("Picture", new PicturePlugin());
	});
/***
 * 连接Picture 获取数据
 * @param {} argument
 * @param {} successCallBack
 * @param {} faileCallBack
 */
function getPictureShow(argument,successCallBack,faileCallBack){
	window.plugins.Picture.getPPShow(argument,successCallBack,faileCallBack);
}

function getPictureDelete(argument,successCallBack,faileCallBack){
	window.plugins.Picture.getPPDelete(argument,successCallBack,faileCallBack);
}

function getPicturePath(argument,successCallBack,faileCallBack){
	window.plugins.Picture.getPPPath(argument,successCallBack,faileCallBack);
}
