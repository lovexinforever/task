/**
 * Copy Right Information   : STATE GRID
 * author                  	: wangjun
 * Comments                	: 用户基本信息存储
 * Version                 	: 0.0.1
 * Modification history    	: 2014-06-25
 */
 
var user_base_info = {
    data : {
	    CONS_ID            : "", // 用户标识
	    CONS_NO            : "", // 用户编号
	    ORG_NO             : "", // 单位编号
	    CONS_NAME          : "", // 用户名称
	    CONS_SORT_CODE	   : "", // 用户分类
	    ELEC_ADDR	       : "", // 用电地址
	    CONTRACT_CAP       : "", // 合同容量
	    VOLT_CODE	       : "", // 供电电压
	    COUNTY_CODE        : "", // 区县
	    TRADE_CODE	       : "", // 行业分类
	    HEC_INDUSTRY_CODE  : "", // 高耗能产业类别
	    RUN_CAP	           : "", // 运行容量
	    PS_DATE	           : "", // 送电日期
	    STATUS_CODE	       : "", // 用户状态
	    ELEC_TYPE_CODE	   : "", // 用电类别
	    LODE_ATTR_CODE	   : "", // 负荷性质
	    RRIO_CODE	       : "", // 重要性等级
	    CHK_CYCLE	       : "", // 检查周期
	    CHECKER_NAME	   : "", // 检察人员
	    TRANSFER_CODE	   : "", // 转供标志
	    TMP_FLAG           : "", // 临时用电标志
	    DUE_DATE	       : "", // 临时用电约定到期日期
	    TMP_DATE           : "", // 临时用电到期日期
	    MR_SECT_NO	       : "", // 抄表段编号
	    LAST_CHK_DATE	   : "", // 上次检查日期
	    POWEROFF_CODE	   : "", // 停电标志
	    SETTLE_MODE	       : "" // 电费结算方式
	},
	/**
	 * 将从服务器返回的JSON值解析并赋值到用户基本信息类中
     * @param {Object} json
	 */
	set_value: function(json) {
	    //var list = JSON.parse(json);
	    for(var node in json) {
            var key = node + "";
            user_base_info.data[key] = json[key];
        }
	}
};



/**
 * Copy Right Information   : STATE GRID
 * author                  	: luocheng
 * Comments                	:用于服务器返回数据拼接成sql
 * Version                 	: 0.0.1
 * Modification history    	: 2014-8-26
 */
 
var dataUpdate = {
	/**
	 * 保存本地信息
	 * @param {} keyValueArr  {"tableName":"YK_S_APP",key1:123,key2:456}
	 * @param {} where {"cons_no":1111,"app_no":222}
	 * @param {} successCB 成功回调
	 * @param {} failCB 失败回调
	 */
	updateInfo :  function (keyValueArr,whereArr, successCB, failCB) {
			var sql = "update ";
			for(var i in keyValueArr){
				if(i == "tableName")
					sql+=keyValueArr[i]+" set ";
				else
					sql+= i+" = '"+keyValueArr[i]+"' ,"
			}
			sql = sql.substring(0,sql.length-1)+" where ";
			for(var i in whereArr){
					sql+= i+" = '"+whereArr[i]+"' ,"
			}
			sql = sql.substring(0,sql.length-1);
			db_execut_oneSQL("dawh.db", sql, [], successCB, failCB);
	},
	
	/**拼接删除SQL
	 * {pkg:{APPS:[{"CONS_NO":"123456","CONS_ID":"45667"},{"CONS_NO":"123456","CONS_ID":"45667"}],TODO_LIST:[{"CONS_NO":"123456","CONS_ID":"45667"},{"CONS_NO":"123456","CONS_ID":"45667"}]}}
	 */
	deleteInfo : function(pkg) {
		if(!pkg || pkg == ""|| pkg.length==0){
			return;
		}
		var deleteArr = new Array();
		for (var tbName in pkg) {
			var sql = "delete from " + tbName + " where APP_NO in ( ";
			for (var i = 0; i < pkg[tbName].length; i++) {
				var data = pkg[tbName][i];
				if(!data.APP_NO) continue;
				data.APP_NO = data.APP_NO.replace(/([']*)/g,"");
				sql += "'" + data.APP_NO + "',";
			}
			sql = sql.slice(0, sql.length - 1) + " ) "
			deleteArr.push(sql);
		}
		return deleteArr
	},
	
	/**拼接插入SQL
	 * tablename 表名
	 * str 数据 例：pkg.APPS
	 * {pkg:{APPS:[{"CONS_NO":"123456","CONS_ID":"45667"},{"CONS_NO":"123456","CONS_ID":"45667"}],TODO_LIST:[{"CONS_NO":"123456","CONS_ID":"45667"},{"CONS_NO":"123456","CONS_ID":"45667"}]}}
	 */
	insertInfo : function(tablename, str) {
		if (str == "" || str == null || str.length == 0)
			return "";

		var insert_sql = "INSERT INTO " + tablename + " ( ";
		if (str.length > 0) {
			for (var c in str[0]) {
				insert_sql += c + ",";
			}
			insert_sql = insert_sql.substring(0, insert_sql.length - 1) + " ) ";
			insert_sql += " VALUES (  ";
		}
		var insert_list = new Array();

		for (var p in str) {
			var insert_value = insert_sql;
			for (var f in str[p]) {
				str[p][f] = str[p][f].replace(/([']*)/g,"");
				insert_value += "'" + str[p][f] + "',";
			}
			insert_value = insert_value.substring(0, insert_value.length - 1)
					+ " ) ";
			insert_list.push(insert_value);
		}
		return insert_list;
	}
	
}

/**
 * 数据验证
 * @type 
 */
var dataValidate ={
	/**
	 * 验证必填项
	 * @param {} val
	 * @return {Boolean}
	 */	
	valiRequired : function(val){
		if(!val || val=="" || val=="null"){
			return false;
		}
		return true;
	},
	
	/**
	 * 固定电话校验正则
	 * @param {} id
	 * @param {} msg
	 * @return {Boolean}
	 */
	valiOffice : function(id,msg){
		var str = $("#"+id).val();
		if(str=='') return true;
		if(/^(0(\d{2}-|\d{3}-)(\d{8}))$/.test(str) || /^(0(\d{2}-|\d{3}-)(\d{8})-(\d{4}|\d{3}|\d{2}|\d{1}))$/.test(str)){
			return true;
		}else{
			var text = msg+"--应该以“3或4位区号-8位电话号码”形式保存，如“010-54201365”；<br/>有分机号的应以“3或4位区号-8位电话号码-1到4位分机号”形式保存，如“010-54201365-103”";
			var bt = [{class:"simple",id:"prompt_ok",text:"确认",callback:function(){$.cache["dialog"].close();}}];
			$.Elec.prompt({
				text:text,
		        buttons:bt
			});
			return false;
		}
	},
	
	/**
	 * 移动电话正则
	 * @param {} id
	 * @return {Boolean}
	 */
	 valiMobile : function(id){
		var str = $("#"+id).val();
		str = str.replace(/(^\s*)|(\s*$)/g,"");//剔除换行和空格
		if(str=='') return true;//空串不校验
//		mobile.value=str;
	    if(!/^1[3|4|5|8][0-9]\d{8}$/.test(str)){
			var text = "移动电话--应该以“1”开头第二位为3、4、5、8的11位数字！"
			var bt = [{class:"simple",id:"prompt_ok",text:"确认",callback:function(){$.cache["dialog"].close();}}];
			$.Elec.prompt({
				text:text,     //提示框文本域
		        buttons:bt
			});
	    	return false;
	    }
	    return true;
	}
	
	
}

