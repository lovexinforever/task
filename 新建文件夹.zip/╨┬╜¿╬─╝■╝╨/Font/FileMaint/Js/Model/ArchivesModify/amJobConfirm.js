// (function(){
var amScroll=null;//滚动条
var amScrDom = null;
var amJCInit = {
	// UI上INPUT里的数据
	amSaveData : {"tableName" : "YK_306_APPROVE"},
	// UI上所有元素的ID
	allInfoIdArr : amPubUI.returnHtmlIdArr("[id*='am_']"),
	// UI上INPUT元素的ID
	inputInfoIdArr : amPubUI.returnHtmlIdArr("input[id*='am_']"),
	// app_no的JSON
	whereApp : {"APP_NO" : sessionStorage.amAPP_NO},
	// 审核状态 List数据
	statusCode : {"01" : "待审","02" : "已审"},
	// 审批审核标志 List数据
	apprFlag : {"01" : "审批","02" : "审核"},
	// 审批结果 List数据
	apprResult : {"01" : "通过","02" : "不通过"},
	//审批意见
	apprOption : {"01" : "同意","02" : "不同意"},

	/**
	 * 初始化标题和点击事件
	 */
	initHeadClick : function() {
		amPubUI.amScrools("amScrollM");//添加滚动，调整键盘弹出高度变化
		// 标题
		util.moblie.navbar.title = "档案变更-审批";
		util.moblie.navbar.buttonList = ["back", "menu"];

		// 保存
		EventUtil.addClickListener({id : "amSave",clk : function() {
				amJCInit.saveLocalData(function() {
					amPubUI.amDialog("保存成功", 1);
				});
		}});

		// 任务传递
		EventUtil.addClickListener({id : "amWorkSend",clk : function() {
				amJCInit.saveLocalData(function() {
					amJCInit.upLoad();
				});	
		}});

		// 返回
		navbarBack = function() {
			toNext("../ArchivesModify/amWorkList.html");
		};
		// 更多信息
		amPubUI.amMoreInfoClick("moreInfo");

		//审批意见
		amPubUI.longClick("am_APPR_OPINION",amJCInit.apprOption,"审批意见");
		
		// 审批结果
		EventUtil.addClickListener({id : "am_APPR_RSLT",clk : function() {
				amPubUI.amListPop(amJCInit.apprResult, "审批结果","am_APPR_RSLT");
			}
		});

	},
	/**
	 * 查询用电申请信息
	 */
	initQueryData : function() {
		amQuery.queryFiledWorkData("YK_306_APPROVE", sessionStorage.amAPP_NO,
			function(tx, res) {
				var len = res.rows.length;
				if (len == 0) {// 本地未查询
					amPubUI.amDialog("未查询到数据", 1);
				} else {// 初始化页面数据
					amPubUI.initPageHtml(res.rows.item(0),amJCInit.allInfoIdArr); 
					var sc = res.rows.item(0).STATUS_CODE;//审核状态:01.02转换为中文
					var avf = res.rows.item(0).APPR_VERI_FLAG;//审批审核标志:01.02转换为中文
					var ar = res.rows.item(0).APPR_RSLT;//审批结果:01.02转换为中文
					$("#am_STATUS_CODE").val(amJCInit.statusCode[sc]);
					$("#am_STATUS_CODE").attr("name",sc);
					$("#am_APPR_VERI_FLAG").val(amJCInit.apprFlag[avf]);
					$("#am_APPR_VERI_FLAG").attr("name",avf);
					$("#am_APPR_RSLT").val(amJCInit.apprResult[ar]);
					$("#am_APPR_RSLT").attr("name",ar);
					amQuery.queryOrgNo(res.rows.item(0).ORG_NO,"am_ORG_NO");
					amQuery.tansformCode(amQuery.codeSortJson);//Pcode转码
				}
			}, null);
	},
	
	/**
	 * 保存
	 * @param callback 保存成功回调
	 */
	saveLocalData : function(callback) {
		
		if(!dataValidate.valiRequired($("#am_APPR_OPINION").val())){
			amPubUI.amDialog("审批意见不能为空",1);
			return;
		}
		
		var temp = {
			"APPR_RSLT" : $("#am_APPR_RSLT").attr("name"),
			"APPR_OPINION" : $("#am_APPR_OPINION").val()
		};
		// 将input里面的数据存入amSaveData
		amJCInit.amSaveData = $.extend(amJCInit.amSaveData, temp);
		dataUpdate.updateInfo(amJCInit.amSaveData, amJCInit.whereApp, callback,null);
	},
	
	/**
	 * 数据上装
	 */
	upLoad : function() {
		amQuery.queryFiledWorkData("YK_306_APPROVE", sessionStorage.amAPP_NO,
				function(tx, res) {
					var len = res.rows.length;
					if (len != 0) {
						var requestData = amJobConfirm(res.rows.item(0));// 任务传递需要的数据
						amSendTask({
							"flowKey" : "SHENPI",
							"flow" : requestData,
							"sqUserName" : amSqNosp,
							callback : function(obj) {
								reMsgDeal(obj, function() {

									var tempupdataJson = {
										"tableName" : "YK_S_DO_LIST_COMPLETION",
										"SYS_USER_NAME" : sessionStorage.user_name, // 将工单挂到登陆人员下
										"ACT_CODE" : "0306666"
									};
									dataUpdate.updateInfo(tempupdataJson,amJCInit.whereApp, null, null);//更新为已完成
									amPubUI.amDialog("待办任务传递成功，终端操作全部完成", 1,null,function(){
										amPubUI.amDialogClose();//关闭弹出框
										toNext("../ArchivesModify/amWorkList.html");
									});

								});
							}
						});
					}
			}, null);
	 }

}
amJCInit.initHeadClick();
amJCInit.initQueryData();
// })();
