	/** ****参数定义********* */
	var TITLETEXT = "档案变更-待办任务";
	var listHtmlArr = ["","","",""]; //各list HTML的list集合：业务受理 勘查派工 现场勘查 审批
	var amScroll="";//页面滚动和滑动对象
	var amTYPECODE = ["0306001","0306002","0306003","0306004","0306666"];
	var IDFLAG = "swipRightDel_";
	var PLACEHOLDER = "输入申请编号或用户编号后4位";
	
	/** ****初始化界面********* */
	var amInit = {
		firstWorkList:"first",
	    child : $("#optiongrouptitle").children(),//Menu的4个子元素
	    scrollRefreshHtml : "<div id='pullDown'><div class='toprefresh'><span class='pullDownIcon'></span><span class='pullDownLabel'>下拉可以刷新...</span></div></div>",
	    
		/**
		 * 查询档案维护工单列表数据
		 */
		 queryWorkList : function(where) {
			amQuery.queryWorkListData(where, function(tx, data) {
				removeDialog();//关闭Loading框
				var len = data.rows.length;
				if (len == 0 && amInit.firstWorkList =="first") {// 本地未查询到数据，向服务器请求数据
					
					amInit.SqOrLoginList();//查询登录人和授权的工单
					
				} else if(len == 0 && amInit.firstWorkList =="") {
					$("#mainListid").html("");
					$(".numborder").html("0");
					amPubUI.amDialog("未查询到数据", 1);
				} else {
					if(data.rows.item(0).ACT_CODE == "0306666"){
						amInit.initHavedDoneList(data.rows);
					}else{
						amInit.initPageListCB(data.rows);
					}
				}
			}, null);
		},
		
		/**
		 * 列表数据查询成功回调，初始化界面
		 * @param {} data 数据
		 */
		initPageListCB : function(data) {
			try {
				$("#mainListid").html("");
				$(".numborder").html("0");
				for(var i = 0;i<data.length;i++){
					var tempHtml = returnListItemHtml(data.item(i));
					if(data.item(i).ACT_CODE == amTYPECODE[0]) listHtmlArr[0]+=tempHtml;//业务受理
					else if(data.item(i).ACT_CODE == amTYPECODE[1]) listHtmlArr[1]+=tempHtml;//勘查派工
					else if(data.item(i).ACT_CODE == amTYPECODE[2]) listHtmlArr[2]+=tempHtml;//现场勘查
					else if(data.item(i).ACT_CODE == amTYPECODE[3]) listHtmlArr[3]+=tempHtml;//审批
					tempHtml = "";
				}
				$("#ywsltitleNum").html(listHtmlArr[0].split(IDFLAG).length-1);
				$("#kcpgltitleNum").html(listHtmlArr[1].split(IDFLAG).length-1);
				$("#xckcltitleNum").html(listHtmlArr[2].split(IDFLAG).length-1);
				$("#spltitleNum").html(listHtmlArr[3].split(IDFLAG).length-1);
				
				//默认初始化业务受理
				var indext = 0;
				if (listHtmlArr[0] != "") indext = 0;
				else if (listHtmlArr[1] != "") indext = 1;
				else if (listHtmlArr[2] != "") indext = 2;
				else if (listHtmlArr[3] != "") indext = 3;
				//初始化Menu的状态,并初始化列表
				amInit.changeMenu(indext);
				
			} catch (e) {
				console.log("err:"+e);
			}
		},
		
		/**
		 * 初始化已经完成的工单
		 * @param {} data
		 */
		initHavedDoneList : function(data){
		try {
				$("#mainListid").html("");
				var tempHtml = "";
				for(var i = 0;i<data.length;i++){
					 tempHtml += returnListItemHtml(data.item(i));
				}
				$("#mainListid").html(tempHtml);
				
				if(Elec.setUndefined(amScroll) != "") {
					amScroll.destroy();
				}
				amScroll = new iScroll("scrollContent", {useTransition : true,hScrollbar : false,vScrollbar : false});
				
			} catch (e) {
				console.log("err:"+e);
			}
		},
		
		initPageEvent : function() {
				//头部
	         	util.moblie.navbar.title = TITLETEXT;
          		util.moblie.navbar.buttonList =["back", "add", "menu"];// 可选参数：add back home
		
          		//搜索主方法
          		var amSearch = function(obj){
          			var selectType="";
        			if (obj.selectobj.text == "已完成") {
        				selectType = " a.ACT_CODE='0306666'";
						$("#optiongrouptitle").hide();
					} else {//未完成
						selectType = " a.ACT_CODE!='0306666'";
						$("#optiongrouptitle").show();
					}
      				var keyword = Elec.setUndefined(obj.searchText)==""?$("#searchHeightId input").val():obj.searchText;
      				if(keyword.length>0 && keyword.length<4) return;
  					keyword = keyword.length ==0?" and  "+selectType:" and (a.APP_NO like '%" + keyword + "'  or  b.CONS_NO like '%" + keyword + "') and "+selectType;
		            listHtmlArr = ["","","",""];
		            amInit.firstWorkList ="";//流程走 非第一次进入页面
	        		amInit.queryWorkList(keyword);
          		}
          		//搜索框绑定事件
          		$(".search").elecSearch({
          			changeTextCallback:amSearch,
				    select:{callback:amSearch,list:[{id:1,text:"未完成"},{id:2,text:"已完成"}]}
				});
				$("#searchHeightId input").attr("placeholder", PLACEHOLDER);
				$("#searchHeightId input").addClass("inputPlaceHolder");
          		
				
				//菜单绑定点击事件
				var childs=new Array();
				for(var i=0;i<amInit.child.length;i++){
					childs[i] = amInit.child[i];
					amInit.child[i].addEventListener("touchstart", function(){
						var index = childs.indexOf(this);
						amInit.changeMenu(index);
					},false);
				}
				
				//返回
		        navbarBack = function(){
		        	listHtmlArr = ["","","",""];
		        	$("#dx-viewport-one").html("");
			        $("#dx-viewport-one").load("mainContent.html"); //固定死的规则
		    	}
		    	
		    	//任务添加
    			navbarAdd = function(){
//    				sessionStorage.fmWhichApply = "dabg";
//    				listHtmlArr = ["", "", "", ""];
//    				toNext("../../Pub/userInfoQuery.html");
    				//点击资产编号
					clickTaskBlue = function() {
						fm_bluetooth_connect(function(value) {
                			$("#consOrAssetNo").val(value);
                		});
					};
					//查询
					clickTaskQuery1 = function(value,type){
						if(value==""){
							amPubUI.amDialog("请输入查询条件", 1);
							return;
						}
						var consNoVal = "";
						var assetNoVal = "";
						type == 0?consNoVal = value:assetNoVal =value;
						amSendApply({
							consNo : consNoVal,
							assetNo : assetNoVal,
							callback : function(obj) {
								reMsgDeal(obj, function() {
									listHtmlArr = ["", "", "", ""];
									toNext("../ArchivesModify/amBusinessDeal.html");
								});
						}});
					};
					//取消
					add_task("任务发起",function(){
						closePPDialog();
					});
			   }
		 },
		 
		 /**
		  * Menu点击事件，样式切换
		  * @param {} index
		  */
		 changeMenu : function(index){
				var barWidth = $("#optiongrouptitle").width();
				$("#boxclip").css("margin-left",(barWidth/4*index)+"px");
				$(amInit.child).css("color","#000000");
				$(amInit.child[index]).css("color","#3cafdb");
			    $("#mainListid").html(amInit.scrollRefreshHtml+listHtmlArr[index]);
			    amScrollRefresh("scrollContent");//添加滑动
		 },
		 
		 /**
		 * 工单跳转到详情
		 * @param {} id
		 */
		 gotoNextPage : function(id, title) {
			var typeCode = id.split("_")[2];
			if(typeCode ==amTYPECODE[4]) return;//如果是已完成不可点击
			sessionStorage.amAPP_NO = id.split("_")[1];
			sessionStorage.amINSTANCE_ID = title.split("_")[1];
			sessionStorage.amCONS_NO = title.split("_")[2];
			var LoginOrSqNo = title.split("_")[4];
			var downType = title.split("_")[3];//下载状态 1已下装 0未下载
			var nextUrl = "";
			var callbackType = "";
			if (typeCode == amTYPECODE[1]) {
				nextUrl = "../ArchivesModify/amCheckSend.html";// 勘查派工
				callbackType = "002";
			} else if (typeCode == amTYPECODE[2]) {
				nextUrl = "../ArchivesModify/amFieldWork.html";// 现场勘查
				callbackType = "003";
			} else if (typeCode == amTYPECODE[3]) {
				callbackType = "004";
				nextUrl = "../ArchivesModify/amJobConfirm.html";// 审批
			} else {
				callbackType = "001";
				nextUrl = "../ArchivesModify/amBusinessDeal.html";// 业务受理
			}
			if (downType == 0) {
					amSendConsInfo({
						appNo : sessionStorage.amAPP_NO,
						sysUserName : LoginOrSqNo,
						actCode : "0306" + callbackType,
						callbackType : callbackType,
						callback : function(obj) {
							reMsgDeal(obj, function() {
										listHtmlArr = ["", "", "", ""];
										toNext(nextUrl);
									});
						}});
			} else {
				listHtmlArr = ["", "", "", ""];
				toNext(nextUrl);
			}
		},
		
		/**
		 * 查询登录人和授权人的工单
		 */
		SqOrLoginList : function(){
			
			//查询勘查派工授权人的工单
			var sqFunPg = function(e){
				if(amSqNopg!="" && amSqNopg && amSqNopg!=sessionStorage.user_name){
					amSendWorkList({
						sysUserName : amSqNopg,
						actCode : "0306002",
						callback : function(obj) {
							sqFunSp(obj);
					}});
				}else{
					sqFunSp(e);
				}
			}
			
			//查询审批授权人的工单
			var sqFunSp = function(e){
				if(amSqNosp!="" && amSqNosp && amSqNosp!=sessionStorage.user_name){
					amSendWorkList({
						sysUserName : amSqNosp,
						actCode : "0306004",
						callback : function(obj) {
							listHtmlArr = ["","","",""];
							amInit.firstWorkList = "";
							reMsgDeal(obj,function(){amInit.queryWorkList(" and a.ACT_CODE!='0306666' ")});
							if(Elec.setUndefined(amScroll) != "") amScroll.refresh();
					}});
				}else{
					listHtmlArr = ["","","",""];
					amInit.firstWorkList = "";
					reMsgDeal(e,function(){amInit.queryWorkList(" and a.ACT_CODE!='0306666' ")});
					if(Elec.setUndefined(amScroll) != "") amScroll.refresh();
				}
			}
			
			//登录人的工单
			amSendWorkList({
				sysUserName : sessionStorage.user_name,
				actCode : "",
				callback : function(e) {
					sqFunPg(e);
			}});
			
		}
		
	}
	
	/**
	 * 拼接列表Item项的Html代码
	 * 
	 * @param {}
	 *            data 数据
	 * @return {} Html代码
	 */
	function returnListItemHtml(data) {
			var result ="<div class='displayflex margintopsublist' onclick='amInit.gotoNextPage(this.id,this.title)'  title='am_"+data.INSTANCE_ID+"_"+data.CONS_NO+"_"+data.DOWNLOAD+"_"+data.SYS_USER_NAME+"'  id='swipRightDel_"+data.APP_NO+"_"+data.ACT_CODE+"'  >"
						+ "    <div class='leftborder'></div>"
						+ "     	<div  class='sublist'>"
						+ "         <div class='displayflex textmagin'>"
						+ "         	    <div class='appcolor minwidth1'>申请编号</div><div> "+data.APP_NO+"</div>"
						+ "         </div>"
						+ "         <div class='displayflex textmagin'>"
						+ "              <div class='minwidth1'>接收时间</div><div> "+data.RVC_TIME+"</div>"
						+ "         </div>"
						+ "         <div class='displayflex textmagin'>"
						+ "               <div class='minwidth1'>到期时间</div><div> "+data.DUE_TIME+"</div>"
						+ "          </div>"
						+ "          <div class='displayflex textmagin'>"
						+ "               <div class='minwidth1'>说明栏</div><div class='boxflex_01'> "+data.NOTES+"</div>"
						+ "          </div>   " 
						+"  		</div>   "
						+"   </div>";
			 return result;
	}
	/**
	 * 页面左右滑动切换菜单、下拉刷新
	 * @param {} id1 需要滚动的DOM元素
	 * dirX为1时：向左滑动，为-1时想右滑动，0为onScrollStart。dirY为-1时：是向下滑动，为1时： 是向上滑动。
	 */
	function amScrollRefresh(id1) {
			if(Elec.setUndefined(amScroll) != "") {
				amScroll.destroy();
				amScroll = null;
			}
			if(!amScroll || amScroll=="undefined" || amScroll=="null"){
					var pullDownEl = document.getElementById('pullDown');
					var pullDownOffset = pullDownEl.offsetHeight;
					var loading = false;
					amScroll = new iScroll(id1, {
							hScrollbar : false,
							vScrollbar : false,
							useTransition : true,
							topOffset : pullDownOffset,
							onRefresh : function() {
								if (pullDownEl.className.match('reloading')) {
									pullDownEl.className = '';
									pullDownEl.querySelector('.pullDownLabel').innerHTML = '下拉可以刷新...';
									$("#pullDown").hide();
									loading = false;
								}
							},
							onScrollMove : function() {
								if(!loading && this.dirY == -1) $("#pullDown").show();
								if (this.dirY == -1 && this.y > 50 && !pullDownEl.className.match('flip') && !loading) {
									pullDownEl.className = 'flip';
									pullDownEl.querySelector('.pullDownLabel').innerHTML = '松开开始刷新...';
									this.minScrollY = 0;
								} else if (this.y < 50 && pullDownEl.className.match('flip') && !loading) {
									pullDownEl.className = '';
									pullDownEl.querySelector('.pullDownLabel').innerHTML = '下拉可以刷新...';
									this.minScrollY = -pullDownOffset;
								}
							},
							onScrollEnd : function() {
								if (pullDownEl.className.match('flip')) {
									loading = true;
									pullDownEl.className = 'reloading';
									pullDownEl.querySelector('.pullDownLabel').innerHTML = '正在刷新...';
									amInit.SqOrLoginList();//查询登录人和授权的工单
									
								}else if(!loading){
									$("#pullDown").hide();
								}
							}
					});
			}
			document.ontouchmove = function(e) {e.preventDefault();}// 禁止页面滚动
			amScroll.refresh();
	}
	
	/** * 页面被唤醒回调函数** */
	var onResume = function () {
	}
	
	/*** 页面被暂停回调函数***/
	var onPause = function () {
	}
	
	amInit.initPageEvent();//初始页面点击事件
	amInit.queryWorkList(" and a.ACT_CODE!='0306666' ");//初始化工单列表项和列表上的点击事件
	
	/** ****可删除工单滑动删除事件绑定********* */
//	EventUtil.touchSwipe("mainListid", {
////				listHtmlArr ="";置空listHtml集合  并刷新该list
//				swipeLeft : function() {
//					alert("swipeLeft");
//				},
//				swipeRight : function() {
//					alert("swipeRight");
//				}
//			});
