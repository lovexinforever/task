//业务受理档案变更信息
var amFileModifyInfo =function(data) {
		var tempData = {
			"APP_NO":data.APP_NO,							//申请编号	
			"CONS_NAME":data.CONS_NAME,						//用户名称
			"CERT_TYPE_CODE":data.CERT_TYPE_CODE,				//证件类别	01:居民身份证02:军人证03:护照04:营业执照05:户口本06:代码证07:产权证08:房卡证09:台胞证10:购房合同13:租赁凭证
			"CERT_NO":data.CERT_NO,							//证件号码	
			"CERT_NAME":data.CERT_NAME,						//证件名称	
			"CONTACT_NAME":data.CONTACT_NAME,				//联系人
			"POSTALCODE":data.POSTALCODE,					//邮编
			"OFFICE_TEL":data.OFFICE_TEL,						//固定电话
			"ADDR":data.ADDR,								//通信地址
			"MOBILE":data.MOBILE,								//移动电话
			"REASON":data.REASON,							//申请原因
			"ELEC_ADDR":data.ELEC_ADDR,						//用电地址
			"COUNTY_CODE":data.COUNTY_CODE,					//区县
			"URBAN_RURAL_FLAG":data.URBAN_RURAL_FLAG,			//城乡类别 01:城市02:农村
			"STREET_CODE":data.STREET_CODE,					//街道码（乡镇）
			"VILLAGE_CODE":data.VILLAGE_CODE,					//居委会（村）
			"ROAD_CODE":data.ROAD_CODE,						//道路码
			"COMMUNITY_CODE":data.COMMUNITY_CODE,			//小区码
			"PLATE_NO":data.PLATE_NO,							//门牌号
			"BUILDING":data.BUILDING							//地标
		}
		return tempData;
}

// 现场勘查实体信息
var amFieldWork = function(data) {
	var tempData = {
		"APP_NO" : data.APP_NO,// 申请编号 VARCHAR2(16) N
		"INS_ID" : sessionStorage.amINSTANCE_ID,// 流程实例唯一标识 NUMBER(16) N
		"CHK_ID" : data.CHK_ID,// 勘查记录唯一标识 NUMBER(16) Y 无新增，有变更
		"CHECKER_NAME" : data.CHECKER_NAME,// 勘查员 VARCHAR2(64) N
		"CHK_DATE" : data.CHK_DATE,// 勘查日期 DATE N
		"CHK_OPINION" : data.CHK_OPINION,// 勘查意见 VARCHAR2(256) N
		"CHK_REMARK" : data.CHK_REMARK// 勘查备注 VARCHAR2(4000) N
	}
	return tempData;
}
// 审批实体信息
var amJobConfirm = function(data) {
	var tempData = {
		"APP_NO" : data.APP_NO,// 申请编号 VARCHAR2(16) N
		"APPR_ID" : data.APPR_ID,// 审批的内部唯一标识 NUMBER(16) Y
		"ORG_NO" : data.ORG_NO,// 供电单位 VARCHAR2(16) N
		"DEPT_NO" : data.DEPT_NO,// 审批部门 VARCHAR2(16) N
		"APPROVER_NAME" : data.APPROVER_NAME,// 审批人 VARCHAR2(16) N
		"APPR_DATE" : data.APPR_DATE,// 审批时间 DATE N
		"APPR_RSLT" : data.APPR_RSLT, // 审批结果 VARCHAR2(8) N 01 通过、02 不通过
		"APPR_OPINION" : data.APPR_OPINION//	审批意见	VARCHAR2(256)	N
	}
	return tempData;
}

var amSqNosp ="";//审批授权人工号
var amSqNopg ="";//派工授权人工号
/**
 * 初始化授权信息
 */
var initGiveRightInfo = function (){
	var amSqInfo = giveRightInfo.getPInfo("0306004");//审批004 授权人信息P_USER_NO
	if(amSqInfo) amSqNosp = amSqInfo.P_USER_NO;
	
	amSqInfo = giveRightInfo.getPInfo("0306002");//勘查派工002 授权人信息P_USER_NO
	if(amSqInfo) amSqNopg = amSqInfo.P_USER_NO;
}
initGiveRightInfo();

var amQuery = {
	/**
	 * 查询档案变更工单列表数据
	 * @param where 查询条件
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	queryWorkListData : function (where, successCB, failCB) {
			addLoading();
			//审批环节授权人的工单
			var amTSql = "";
			if(amSqNosp) amTSql = " or  (a.SYS_USER_NAME='"+amSqNosp+"' and a.ACT_CODE ='0306004' ) ";
			//派工环节授权人的工单
			var amPgSql = "";
			if(amSqNopg) amPgSql = " or  (a.SYS_USER_NAME='"+amSqNopg+"' and a.ACT_CODE ='0306002' ) ";
			// 工单列表查询sql
			var sql = "SELECT "
					+ "  a.APP_NO ,  "
					+ "  a.RVC_TIME ,  "
					+ "  a.DUE_TIME ,  "
					+ "  a.INSTANCE_ID ,  "
					+ "  a.DOWNLOAD ,  "
					+ "  a.ACT_CODE ,  "
					+ "  a.SYS_USER_NAME ,  "
					+ "  a.NOTES ,  "
					+ "  b.CONS_NO ,  "
					+ "  b.CONS_NAME ,  "
					+ "  b.ELEC_ADDR   "
					+ "  FROM  "
					+ "  YK_S_DO_LIST_COMPLETION a   "
					+ "  LEFT JOIN YK_S_APP b ON a.APP_NO = b.APP_NO "
					+ " where (a.SYS_USER_NAME='"+sessionStorage.user_name+"'  " +amTSql +amPgSql +")"
					+	"  and a.ACT_CODE not in ('0210001','0210002','0210003','0210004','0216666') "
					+ (where != null ? where : " ") + "  ORDER BY    "
					+ " a.RVC_TIME  desc";
			db_execut_oneSQL("dawh.db", sql, [], successCB, failCB);
	},

	/**
	 * 用电申请信息查询sql--用于业务受理
	 * @param where 查询条件
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	queryUserSendInfo :  function (where, successCB, failCB) {
			// 用电申请信息查询sql--业务受理
			var sql = "select * from YK_S_APP where APP_NO=?";
			db_execut_oneSQL("dawh.db", sql, [where], successCB, failCB);
	},
	
	/**查询
	 *  1勘查派工（YK_306_INVESTIGATE_USER） 
	 * 	2现场勘查（YK_306_INVESTIGATE） 
	 * 	3审批（YK_306_APPROVE）信息和用电申请信息
	 * @param tableName 表名
	 * @param where 查询条件
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	queryFiledWorkData :  function (tableName,where, successCB, failCB) {
			var sql = "SELECT  *  FROM   YK_S_APP   A  LEFT JOIN  "+tableName+" B ON A.[APP_NO] = B.[APP_NO]  WHERE A.APP_NO = ? ";
			db_execut_oneSQL("dawh.db", sql, [where], successCB, failCB);
	},
	
	/**查询 供电公司
	 * @param tableName 表名
	 * @param where 查询条件
	 * @param successCB 成功回调
	 * @param ailCB 失败回调
	 */
	queryOrgNo :  function (ORG_NO,ID) {
	        var sql="select ORG_NAME from O_ORG where ORG_NO=?";
	        db_execut_oneSQL("dawh.db",sql,[ORG_NO],function(tx,res){
				if ($("#"+ID).is("input"))
					 $("#"+ID).val(res.rows.item(0).ORG_NAME);
				else
					$("#"+ID).html(res.rows.item(0).ORG_NAME);
	        },null);
	},
	
	/**
	 * CERT_TYPE_CODE	证件类别           29012
	 * ELEC_TYPE_CODE	用电类别			29001
	 * TRADE_CODE	行业分类			    29005
	 * NOTIFY_MODE  电费通知方式        15001
	 * SETTLE_MODE  电费结算方式         29015
	 * NOTE_TYPE_CODE	票据类型          15003
	 * TRANSFER_CODE	转供标志  			29003
	 * PAY_MODE	缴费方式					15002
	 * CONS_SORT_CODE	用户分类		29011
	 * VOLT_CODE	供电电压					10005不需要展示
	 * COUNTY_CODE	区县						10002
	 * URBAN_RURAL_FLAG	城乡类别		17005
	 * IS_LEVEL_PRC	是否执行阶梯电价  PrcCode 本地自定义
	 * BZ	是否合户									bzCode	  本地自定义
	 * @type 
	 */
	code_sort_ids : [
		{"A_PrcCode":"IS_LEVEL_PRC","codeId":"PrcCode"}, 
		{"A_bzCode":"BZ","codeId":"bzCode"}, 
		{"A_29012":"CERT_TYPE_CODE","codeId":29012}, 
		{"A_29001":"ELEC_TYPE_CODE","codeId":29001}, 
		{"A_29005":"TRADE_CODE","codeId":29005}, 
		{"A_15001":"NOTIFY_MODE","codeId":15001}, 
		{"A_29015":"SETTLE_MODE","codeId":29015}, 
		{"A_15003":"NOTE_TYPE_CODE","codeId":15003}, 
		{"A_29003":"TRANSFER_CODE","codeId":29003}, 
		{"A_15002":"PAY_MODE","codeId":15002}, 
		{"A_29011":"CONS_SORT_CODE","codeId":29011}, 
		{"A_10002":"COUNTY_CODE","codeId":10002}, //区县	
		{"A_17005":"URBAN_RURAL_FLAG","codeId":17005}], //城乡类别
		
	//Pcode的Json集合
	codeSortJson : {
	"A_PrcCode":[{"name":"否","value":"0"},{"name":"是","value":"1"}],
	"A_bzCode":[{"name":"否","value":"0"},{"name":"是","value":"1"}]},

	/**
	 * 处理P_CODE
	 * @param {} code_sort_ids
	 * @param {} callback
	 * 返回结果 json : {A_29012:[{"name":"name","value":"value"},{},{}],A_29001:[{"name":"name","value":"value"},{},{}]}
	 */
	getPcodeJson : function(code_sort_ids,callback) {
		var parmCodes = new Array(), json = {}, item = null;
		for (var i = 0; i < code_sort_ids.length; i++) {
			var codeId = code_sort_ids[i].codeId;
			parmCodes.push("'"+codeId+"'");
			json["A_" + codeId] = new Array();
		}
		db_execut_oneSQL("dawh.db",
				"select CODE_SORT_ID,NAME,VALUE from p_code where code_sort_id in("+ parmCodes + ")", [], function(tx, res) {
					if (res.rows.length > 0) {
						for (var j = 0; j < res.rows.length; j++) {
							item = res.rows.item(j);
							var vn = {
								"name" : item.NAME,
								"value" : item.VALUE
							};
							json["A_" + item.CODE_SORT_ID].push(vn);
						}
						item = null;
					}
					callback(json);
		}, null);
	},
	
	/**
	 * 将Pcode转码为name
	 * @param {} json->
	 * {A_29012:[{"name":"name","value":"value"},{},{}],A_29001:[{"name":"name","value":"value"},{},{}]}
	 */
	tansformCode : function(json) {
		
		var k =0;
		for (var code in json) {
			var domIds = amQuery.code_sort_ids[k][code];
			
			if(!document.getElementById("am_"+domIds)) {//不存在DOM元素
				k++;
				continue;
			}
			
			domIds = $("#am_" + domIds);
			var domVal = "";
			if (domIds.is("input")) domVal = domIds.val();
			else domVal = domIds.html();
			
			for (var i = 0; i < json[code].length; i++) {
				if (domVal == json[code][i].value) {
					if (domIds.is("input"))
						domIds.val(json[code][i].name);
					else
						domIds.html(json[code][i].name);

					domIds.attr("name", json[code][i].value);
					break;
				}
			}
			k++;
		}
	}
	
}

amQuery.getPcodeJson(amQuery.code_sort_ids,function(json){
	amQuery.codeSortJson = $.extend(json,amQuery.codeSortJson);
});

