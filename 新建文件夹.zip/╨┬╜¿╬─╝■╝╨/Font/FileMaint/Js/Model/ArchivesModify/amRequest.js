var amMsg = {
 	"F" : "数据请求失败",
	"I" : "未查询到数据",
	"W" : "数据解析异常"
}

var thisTid = "";//	移动终端编号
getTid(function(e){thisTid =e;},null);

/**===========档案变更报文FUN
 * 1申请 fun:  030601	var pkg1 = '{"SYS_USER_NAME":"' + sessionStorage.user_name + '","CONS_NO":"' +CONS_NO+ '","ASSET_NO":"' +ASSET_NO+ '"}';
 * 2业务受理   030602
 * 3勘查派工   030603		var pkg3 = '{"APP_NO":"' + APP_NO + '","INSTANCE_ID":"' +INSTANCE_ID+ '","EMP_NO":"' +EMP_NO+ '"}';
 * 4现场勘查   030604
 * 5审批   030605
 * 6查询工单用户信息  030606	var pkg6 = '{"CONS_NO":"' + CONS_NO + '","APP_NO":"' +APP_NO+ '","ACT_CODE":"' +ACT_CODE+ '"}';
 * 空返回所有更名、档案变更的待办事宜@type
 *	0306001:档案变更业务受理
 *	0306002:档案变更勘查派工
 *	0306003:档案变更现场勘查
 *	0306004:档案变更审批
 *	0306666 档案变更已完成 （本地自定义）
 *	0306665 档案变更某一环节已完成，后续环节无权限 （本地自定义）
*/
function amSendDataTool(fun, pkg, execData, callback) {
	addLoading();
	var basePkg = '{"MOD":"2021","FUN":"' + fun + '","SYS_USER_NAME":"'
			+ sessionStorage.user_name + '","TERM_NUM":"' + thisTid
			+ '","ORG_NO":"' + sessionStorage.ORG_NO + '","PKG":' + pkg + '}';
	try {
		send_data(fun, "2021", basePkg, function(msg) {
					msg = JSON.parse(msg);
					if (msg.RET == "00") // 平台通讯成功
					{
						var ret = msg.PKG.RET;
						if (ret == "10") // 数据返回成功
						{
							var returnData = msg.PKG.PKG;
							if (returnData.FLAG == 1){ // 接口业务成功
								execData(returnData,callback);
							}else if(returnData.FLAG == 2){//任务传递成功，授权失败
								callback({"flag":"2","msg":returnData.ERR_MSG});
							} else {
								if (returnData.ERR_MSG)
									callback({"flag":"-1","msg":returnData.ERR_MSG});
								else
									callback({"flag":"-1","msg":amMsg.I});
							}
						} else{
							var tpMsg = msg.PKG.PKG.ERR_MSG;
							tpMsg = tpMsg?tpMsg:amMsg.I;
							callback({"flag":"-1","msg":tpMsg});// 数据返回失败
						}
					} else
						callback({"flag":"-1","msg":amMsg.F});// 平台通讯异常

				}, function(msg) {
					callback({"flag":"-1","msg":amMsg.F});
				});
	} catch (e) {
		console.log("err->"+e);
		callback({"flag":"-1","msg":amMsg.W});
	}
}


/**
 * 待办事宜查询 接口 000002
 * @param {}  jsonArgs = {
 *  sysUserName:sysUserName,
 *  actCode:actCode,
 *  callback:callback} 
 *  //业务流程码 actCode :
 *  0306001:档案变更业务受理  0306002:档案变更勘查派工 
 *  0306003:档案变更现场勘查 0306004:档案变更审批 
 * @param {}  initCB
 */
function amSendWorkList(jsonArgs) {
	var pkg = {
		"APP_NO" : "",//不需要传值
		"SYS_USER_NAME" : jsonArgs.sysUserName,
		"ACT_CODE" : jsonArgs.actCode
	};

	pkg = JSON.stringify(pkg);
	var execData = function(data,callback) {// 回调
		try {
			var amDelSql = new Array();
			var amInsertSql = new Array();
			var reData = data.DBSY;
			var appNos = new Array();	//服务器返回的APP_NO
			if (reData && reData.length>0) {
				for (var i = 0; i < reData.length; i++) {
					if (reData[i].APP_NO) appNos.push(reData[i].APP_NO);
				}
				//先根据返回的app_no删除工单列表（因为无法删除在营销完成的工单，需要用SYS_USER_NAME删除）
				amDelSql = dataUpdate.deleteInfo({"YK_S_DO_LIST_COMPLETION" : reData});
				amInsertSql = dataUpdate.insertInfo("YK_S_DO_LIST_COMPLETION",reData);
			}else{
				appNos.push(" ");
			}
			var listWhere = "";
			if(jsonArgs.actCode ==""){//全部
				listWhere = " ACT_CODE!='0306666' ";
			}else{//勘查派工 审批
				listWhere = " ACT_CODE='"+jsonArgs.actCode+"' ";
			}
			//从数据库查出 服务器未返回  且 未完成 的APP_NO
			var appSqls = "select APP_NO from YK_S_DO_LIST_COMPLETION where APP_NO not in ("+appNos+") and" + listWhere +
					" and  SYS_USER_NAME ='" + jsonArgs.sysUserName + "'";
			//删除明细表
			amDelSql.push("DELETE FROM YK_S_APP WHERE  APP_NO IN  ("+appSqls+")");
			amDelSql.push("DELETE FROM YK_306_INVESTIGATE_USER WHERE  APP_NO IN  ("+appSqls+")");
			amDelSql.push("DELETE FROM YK_306_INVESTIGATE WHERE  APP_NO IN  ("+appSqls+")");
			amDelSql.push("DELETE FROM YK_306_APPROVE WHERE  APP_NO IN  ("+appSqls+")");
			
			//再根据SYS_USER_NAME删除工单 （如果未授权的，但是任务传递成功，中间状态的工单需要用app_no删除）
			amDelSql.push("delete from YK_S_DO_LIST_COMPLETION where SYS_USER_NAME ='"
					+ jsonArgs.sysUserName + "' and " +listWhere);
					
			amDelSql = amDelSql.concat(amInsertSql);// 拼接删除和插入数组

			console.log("批量执行SQL：" + amDelSql);
			
			if(amDelSql.length ==0){
				callback({"flag":"1","msg":amMsg.I});
				return;
			}
			db_batch_data("dawh.db", amDelSql, [], function(tx, res) {
					callback({"flag":"1","msg":""});
			}, null);

		} catch (e) {
			callback({"flag":"-1","msg":amMsg.W});
		}
	}
	amSendDataTool("000002", pkg, execData, jsonArgs.callback);
}



/**
 * 查询工单用户信息 接口 030606
 * @param {}  jsonArgs = { 
 *  appNo:appNo,
 *  actCode:actCode, 
 *  sysUserName:sysUserName,
 *  callbackType:callbackType,
 *  callback:callback} 
 *  //业务流程码 actCode :
 *  0306001:档案变更业务受理  0306002:档案变更勘查派工 
 *  0306003:档案变更现场勘查 0306004:档案变更审批 
 *  callback 1成功 -1失败
 * @param {}  initCB
 */
function amSendConsInfo(jsonArgs) {
	var pkg = {
		"APP_NO" : jsonArgs.appNo,
		"SYS_USER_NAME" : jsonArgs.sysUserName,
		"ACT_CODE" : jsonArgs.actCode
	};
	pkg = JSON.stringify(pkg);

	var execData = function(data,callback) {// 回调
		try {
			var amDelSql = new Array();
			var amInsertSql = new Array();
			// 业务受理
			var ywReData = data.QUERY_DANGAN_YEWU_SHOULI;
			if (ywReData) {
				amDelSql = dataUpdate.deleteInfo({
							"YK_S_APP" : ywReData
						});
				amInsertSql = dataUpdate.insertInfo("YK_S_APP", ywReData);
			}
			switch (jsonArgs.callbackType) {
				case "002" : // 勘查派工
					var reData = data.QUERY_DANGAN_KANCHA_PAIGONG;
					if (reData) {
						amDelSql = amDelSql.concat(dataUpdate.deleteInfo({
									"YK_306_INVESTIGATE_USER" : reData
								}));
						amInsertSql = amInsertSql.concat(dataUpdate.insertInfo(
								"YK_306_INVESTIGATE_USER", reData));
					}
					break;
				case "003" : // 现场勘查
					var reData = data.QUERY_DANGAN_XIANCHANG_KANCHA;
					if (reData) {
						amDelSql = amDelSql.concat(dataUpdate.deleteInfo({
									"YK_306_INVESTIGATE" : reData
								}));
						amInsertSql = amInsertSql.concat(dataUpdate.insertInfo(
								"YK_306_INVESTIGATE", reData));
					}
					break;
				case "004" : // 审批
					var reData = data.QUERY_DANGAN_SHENPI;
					if (reData) {
						amDelSql = amDelSql.concat(dataUpdate.deleteInfo({
									"YK_306_APPROVE" : reData
								}));
						amInsertSql = amInsertSql.concat(dataUpdate.insertInfo(
								"YK_306_APPROVE", reData));
					}
					break;
				default :
					break;
			}
			amDelSql = amDelSql.concat(amInsertSql);// 拼接删除和插入数组
			var upDownType = "update YK_S_DO_LIST_COMPLETION set DOWNLOAD =1   where APP_NO = '"+jsonArgs.appNo +"'";
			amDelSql.push(upDownType);
			
			console.log("批量执行SQL：" + amDelSql);
			
			db_batch_data("dawh.db", amDelSql, [], function(tx, res) {
					callback({"flag":"1","msg":""});
			}, null);

		} catch (e) {
			callback({"flag":"-1","msg":amMsg.W});
		}
	}
	amSendDataTool("030606", pkg, execData, jsonArgs.callback);
}

/**
 * 申请 接口  030601
 * @param {}  jsonArgs = { 
 *  consNo:consNo,
 *  assetNo:assetNo, 
 *  callback:callback} 
 *  callback 1成功 -1失败
 * @param {}  initCB
 */
function amSendApply(jsonArgs){
	var pkg = {
		"SYS_USER_NAME" : sessionStorage.user_name,
		"CONS_NO" : jsonArgs.consNo || "",
		"ASSET_NO" : jsonArgs.assetNo || ""
	};
	pkg = JSON.stringify(pkg);
	var execData = function(data,callback) {// 回调
		try {
			var amDelSql = new Array();
			var amInsertSql = new Array();
			var relistData = data.QUERY_DANGAN_DAIBAN_SHIYI;
			var reywslData = data.QUERY_DANGAN_YEWU_SHOULI;
			if (relistData) {
				
				sessionStorage.amAPP_NO = reywslData[0].APP_NO;//保存页面session
				sessionStorage.amCONS_NO = reywslData[0].CONS_NO;
				amDelSql = dataUpdate.deleteInfo({
							"YK_S_DO_LIST_COMPLETION" : relistData
						});
				amInsertSql = dataUpdate.insertInfo("YK_S_DO_LIST_COMPLETION", relistData);
			}
			if (reywslData) {
				
				sessionStorage.amINSTANCE_ID = relistData[0].INSTANCE_ID;//保存页面session
				amDelSql = amDelSql.concat(dataUpdate.deleteInfo({
							"YK_S_APP" : reywslData
						}));
				amInsertSql = amInsertSql.concat(dataUpdate.insertInfo("YK_S_APP", reywslData));
			}
			amDelSql = amDelSql.concat(amInsertSql);// 拼接删除和插入数组
			
			var upDownType = "update YK_S_DO_LIST_COMPLETION set DOWNLOAD =1   where APP_NO = '"+sessionStorage.amAPP_NO +"'";
			amDelSql.push(upDownType);
			
			console.log("批量执行SQL：" + amDelSql);
			
			if(amDelSql.length ==0){
				callback({"flag":"1","msg":amMsg.I});
				return;
			}
			db_batch_data("dawh.db", amDelSql, [], function(tx, res) {
					callback({"flag":"1","msg":""});
			}, null);

		} catch (e) {
			callback({"flag":"-1","msg":amMsg.W});
		}
	}
	amSendDataTool("030601", pkg, execData, jsonArgs.callback);
}

/**
 * 任务传递
 * fun{
 * 030601 业务受理 YEWU_SHOULI --TASK
 * 030602 勘查派工 KANCHA_PAIGONG  TASK
 * 030603 现场勘查 XIANCHANG_KANCHA TASK
 * 030604 审批 SHENPI TASK}
 * actCode{
 * 0306001:档案变更业务受理
 * 0306002:档案变更勘查派工
 * 0306003:档案变更现场勘查
 * 0306004:档案变更审批 }
 * @param {}  jsonArgs = { 
 *  flowKey:flowKey, 
 *  flow:flow, 
 *  sqUserName:sqUserName,
 *  callback:callback} 
 */
function amSendTask(jsonArgs) {
	var taskData = {
		"ORGNO" :sessionStorage.ORG_NO,
		"SYS_USER_NAME" : sessionStorage.user_name,
		"SQ_USER_NAME" : jsonArgs.sqUserName || "",
		"APP_NO" : sessionStorage.amAPP_NO,
		"INSTANCE_ID" : sessionStorage.amINSTANCE_ID
	}
	var funType = "";
	
	switch (jsonArgs.flowKey) {
			case "YEWU_SHOULI" : // 业务受理
				funType = "030602";
				break;
			case "KANCHA_PAIGONG" : // 勘查派工
				funType = "030603";
				taskData.NEXTHAND = sessionStorage.EMP_NO;
				break;
			case "XIANCHANG_KANCHA" : // 现场勘查
				funType = "030604";
				break;
			case "SHENPI" : // 审批
				funType = "030605";
				break;
			default :
				break;
	}
	var pkg = {
		"TASK" : taskData
	};
	pkg[jsonArgs.flowKey] = jsonArgs.flow;
	pkg = JSON.stringify(pkg);
	
	var execData = function(data,callback) {// 回调
		try {
			var amDelSql = new Array();
			var amInsertSql = new Array();
			var reActCode = "";
			//待办事宜数据
			var ywReData = data.QUERY_DANGAN_DAIBAN_SHIYI;
			
			if (ywReData && ywReData.length>0) {
				
				reActCode = ywReData[0].ACT_CODE;
				
				sessionStorage.amINSTANCE_ID = ywReData[0].INSTANCE_ID;//保存页面session
				amDelSql = dataUpdate.deleteInfo({"YK_S_DO_LIST_COMPLETION" : ywReData});
				amInsertSql = dataUpdate.insertInfo("YK_S_DO_LIST_COMPLETION", ywReData);
			
				switch (reActCode) {
					case "0306002" : // 返回流程： 勘查派工
						var reData = data.QUERY_DANGAN_KANCHA_PAIGONG;
						if (reData) {
							amDelSql = amDelSql.concat(dataUpdate.deleteInfo({
										"YK_306_INVESTIGATE_USER" : reData
									}));
							amInsertSql = amInsertSql.concat(dataUpdate.insertInfo(
									"YK_306_INVESTIGATE_USER", reData));
						}
						break;
					case "0306003" : // 返回流程： 现场勘查
						var reData = data.QUERY_DANGAN_XIANCHANG_KANCHA;
						if (reData) {
							amDelSql = amDelSql.concat(dataUpdate.deleteInfo({
										"YK_306_INVESTIGATE" : reData
									}));
							amInsertSql = amInsertSql.concat(dataUpdate.insertInfo(
									"YK_306_INVESTIGATE", reData));
						}
						break;
					case "0306004" : // 返回流程：审批
						var reData = data.QUERY_DANGAN_SHENPI;
						if (reData) {
							amDelSql = amDelSql.concat(dataUpdate.deleteInfo({
										"YK_306_APPROVE" : reData
									}));
							amInsertSql = amInsertSql.concat(dataUpdate.insertInfo(
									"YK_306_APPROVE", reData));
						}
						break;
					default :
						break;
				}
			}
			amDelSql = amDelSql.concat(amInsertSql);// 拼接删除和插入数组
			var upDownType = "update YK_S_DO_LIST_COMPLETION set DOWNLOAD =1   where APP_NO = '"+sessionStorage.amAPP_NO +"'";
			amDelSql.push(upDownType);
			
			console.log("批量执行SQL：" + amDelSql);
			
			db_batch_data("dawh.db", amDelSql, [], function(tx, res) {
					callback({"flag":"1","msg":reActCode});
			}, null);

		} catch (e) {
			console.log("err->"+e);
			callback({"flag":"-1","msg":amMsg.W});
		}
	}
	amSendDataTool(funType, pkg, execData, jsonArgs.callback);
}


/**
 * 处理返回信息
 * @param {} obj  {"flag":"-1","msg":"msg"}1成功 -1失败 2无授权
 * @param {} callbk
 */
function reMsgDeal(obj,callbk){
	removeDialog();//关闭Loading框
	if(obj.flag == -1){
		amPubUI.amDialog(obj.msg, 1);
	}else if(obj.flag == 2){//无授权信息，更新为中间状态
		var usql = "update YK_S_DO_LIST_COMPLETION set ACT_CODE ='0306665'   where APP_NO = '"+sessionStorage.amAPP_NO +"'";
		db_execut_oneSQL("dawh.db", usql, [], null, null);
		amPubUI.amDialog(obj.msg, 1, null, function(){
			amPubUI.amDialogClose();//关闭弹出框
			toNext("../ArchivesModify/amWorkList.html");
		});
	}else{
		callbk(obj.msg);
	}
}

/**
 * 页面跳转
 * @param {} nextUrl
 */
function toNext (nextUrl){
	$("#dx-viewport-one").html("");
	$("#dx-viewport-one").load(nextUrl);
}

/**
 * 任务传递 根据返回的待办事宜code跳转到哪一个环节
 * @param {} modelCode 业务类型
 */
function returnModelURL(modelCode){
//	alert("回调开始："+modelCode);
	var requestData = {"APP_NO":sessionStorage.amAPP_NO};
	var tempupdataJson = {
		"tableName" : "YK_S_DO_LIST_COMPLETION",
		"ACT_CODE" : modelCode
	};
	dataUpdate.updateInfo(tempupdataJson,requestData, null, null);// 更新工单类型
	
	switch (modelCode) {
		
		case "0306002" :  //勘查派工
			toNext("../ArchivesModify/amCheckSend.html");
			break;
			
		case "0306003" : //现场勘查
			toNext("../ArchivesModify/amFieldWork.html");
			break;
			
		case "0306004" : //审批
			toNext("../ArchivesModify/amJobConfirm.html");
			break;
		default :
			break;
	}
}
