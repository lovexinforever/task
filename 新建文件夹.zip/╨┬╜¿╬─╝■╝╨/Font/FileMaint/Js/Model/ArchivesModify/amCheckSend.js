// (function(){
var amScroll=null;//滚动条
var amScrDom = null;
var amCKSInit = {
	
	//UI上INPUT里的数据
	amSaveData : {"tableName":"YK_S_APP"},
	
	//UI上所有元素的ID
	allInfoIdArr : amPubUI.returnHtmlIdArr("[id*='am_']"),
	
	//UI上INPUT元素的ID
	inputInfoIdArr : amPubUI.returnHtmlIdArr("input[id*='am_']"),
	
	/**
	 * 初始化标题和点击事件
	 */
	initHeadClick : function() {
			amPubUI.amScrools("amScrollM");//添加滚动，调整键盘弹出高度变化
			//标题
			util.moblie.navbar.title = "档案变更-勘查派工";
			util.moblie.navbar.buttonList = ["back", "menu"];
			
			// 任务传递
			EventUtil.addClickListener({id:"amWorkSend", clk:function() {
					amCKSInit.upLoad();
			}});
			//返回
			navbarBack = function() {
				toNext("../ArchivesModify/amWorkList.html");
			};
	
			// 更多信息
			amPubUI.amMoreInfoClick("moreInfo");
	},
	
	/**
	 * 查询用电申请信息
	 */
	initQueryData : function() {
		amQuery.queryFiledWorkData("YK_306_INVESTIGATE_USER",
				sessionStorage.amAPP_NO, function(tx, res) {
					
					var len = res.rows.length;
					
					if (len == 0) {// 本地未查询
						amPubUI.amDialog("未查询到数据", 1);
					} else {
						amPubUI.initPageHtml(res.rows.item(0),amCKSInit.allInfoIdArr); // 初始化页面数据
						
						$("#am_USER_NAME").val(sessionStorage.user_name_str);// 登陆人员
						
						amQuery.tansformCode(amQuery.codeSortJson);// Pcode转码
					}
					
		}, null);
	},
	
	/**
	 * 	数据上装
	 */
	upLoad : function() {
		var requestData = {"APP_NO" : sessionStorage.amAPP_NO};
		amSendTask({
					"flowKey" : "KANCHA_PAIGONG",
					"flow" : requestData,
					"sqUserName" : amSqNopg,
					callback : function(obj) {
						reMsgDeal(obj, returnModelURL);
					}
		});
	}

}

amCKSInit.initHeadClick();
amCKSInit.initQueryData();

// })();
