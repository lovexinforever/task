/****LongClick 参数****/
var startX=0,startY=0,endX=0,endY=0;
var satrtTime=0,endTime=0;
var moveState = true;
/***LongClick 参数*****/

var amPubUI = {
	/**
	 * 更多信息点击
	 * @param {} id
	 */
	amMoreInfoClick : function(id){
//		document.getElementById(id).addEventListener("touchstart", function() {
		EventUtil.addClickListener({id :id,clk : function() {
			var _this = this;
			var list = $(this).parent().prev();
			var min_height = $("tr", list).height() * 4 + 12;
			var max_height = $("table", list).height();
			var status = $(this).hasClass("open") ? 1 : 0;
			$(this).toggleClass("open");
			var height = !!status ? min_height : max_height;
			list.animate({height : height}, 250, function() {
				$("div", $(_this)).toggleClass("icon_up");
				$("span", $(_this)).html(status == 1? "查看详细信息":"收起详细信息");
			});
			setTimeout(function() {
				amScroll.refresh();
			}, 500)
		}});
	},
	/**
	 * 文本框聚焦
	 * @param {} domElement 文本的dom元素 (固定结构)"amListEdit li input"
	 */
	amInputClick : function(domElement){
			$("#"+domElement).click(function(e) {
			var thisClass="";
			if($(this).attr("readonly") == "readonly")
				thisClass = "selectBorderFocus";
			else
				thisClass = "inputBorderFocus";
			$(this).parent().parent().addClass(thisClass);
			$(this).blur(function(e) {
				$(this).parent().parent().removeClass(thisClass);
			});
		})
	},
	   /**
	 * 返回htmlDom元素的ID
	 * 
	 * @param {}  obj -->类似 "td[id*='am_']"
	 * @return htmlIdArr -->ID数组
	 */
   returnHtmlIdArr : function(obj){
		var htmlDom = $(obj);	          //input html元素  D_PHASEANGLE_CHK_RECORD
		var htmlIdArr = new Array();  //input 的ID  D_PHASEANGLE_CHK_RECORD
		for(var i =0;i<htmlDom.length;i++){//初始化input ID数组
		    htmlIdArr.push(htmlDom[i].id);              
		}
		return htmlIdArr;
	},
	
	/**
	 * 向页面填充数据
	 * @param {} data 数据源
	 * @param {} arr 页面需填充ID数组
	 */
	initPageHtml : function(data,arr){
	     for(var i=0;i<arr.length;i++){
	     	var dataKey = arr[i].split("am_")[1];
	     	if($("#"+arr[i]).is("input")) $("#"+arr[i]).val(data[dataKey]);
	     	else  $("#"+arr[i]).html(data[dataKey]);
	     }
	},
	
	/**
	 * 将页面上的所有数据转换成Json
	 * @param {} temp 页面上元素的ID数组
	 * @return {} Json数据
	 */
	localJsonData : function(temp){
		var tempJson = {};
		for(var i=0;i<temp.length;i++){
			var tempKey = temp[i].split("am_")[1];
			if ($("#" + temp[i]).is("input"))
				tempJson[tempKey] = $("#"+temp[i]).val();
			else
				tempJson[tempKey] = $("#"+temp[i]).html();
		}
		return tempJson;
	},
	
	/**
	 * List弹出框
	 * @param {} data {p1: "qwe", p2: "sdf"}JSON数据
	 * @param {} title list弹出框标题
	 * @param {} htmlid 元素ID
	 */
	amListPop : function(data,title,htmlid){
		data = $.extend({"":""},data);
		list_show({
		    data: data,
		    title:title, 
          	item_click_callback:function(id) {
          		$("#"+htmlid).val(data[id]);
          		$("#"+htmlid).attr("name",id);
          	}, 
           	bgCallback:amPubUI.amDialogClose
		},"");

	},
	
	/**
	 * 弹出框
	 * @param {} text 提示信息
	 * @param {} cancelCB 取消按钮回调
	 * @param {} okCB 确定按钮回调
	 * @param {} type 按钮个数 1为一个 2为2个按钮 空无按钮
	 */
	amDialog : function(text,type,cancelCB,okCB){
		var button = []; //提示框按钮数组 class 单个按钮样式 id 按钮id text 按钮文本展示 callback 单个按钮回调
		cancelCB = Elec.setUndefined(cancelCB)==""?amPubUI.amDialogClose:cancelCB;
		okCB = Elec.setUndefined(okCB)==""?amPubUI.amDialogClose:okCB;
		var bt1 = {class:"simple",id:"prompt_cancel",text:"取消",callback:cancelCB};
		var bt2 = {class:"simple",id:"prompt_ok",text:"确认",callback:okCB};
		if(type==1) button.push(bt2);//只有确定按钮
		else if(type==2){
			button.push(bt1);
			button.push(bt2);
		}
		$.Elec.prompt({
			text:text,     //提示框文本域
	        buttons:button
		});
	},
	
	/**
	 * 关闭Loading框调用: removeDialog()
	 * Loading框: addLoading()
	 */
	amDialogClose : function(){
		$.cache["dialog"].close();
	},
	
	/**
	 * 
	 */
	amScrools : function(id) {
		amScroll ? amScroll.refresh() : amScroll = new iScroll(id, {
					bounce : false,
					useTransition : true,
					vScrollbar : false,
					onBeforeScrollStart : function(e) {
						var target = e.target;
						while (target.nodeType != 1)
							target = target.parentNode;
						if (target.tagName != 'SELECT'
								&& target.tagName != 'INPUT'
								&& target.tagName != 'TEXTAREA')
							e.preventDefault();
					}
				});
		window.onclick = function(e) {
			amScrDom = e.target;
		}
		window.onresize = function() {
			setTimeout(function() {
				if (amScroll) {
					amScroll.refresh();
					amScroll.scrollToElement(amScrDom, 0);
				}
			}, 200)
		}
	},
	
	/**
	 * 长按弹出框 Start
	 * @param {} id 长按Id
	 * @param {} data 弹出框数据
	 * @param {} title 弹出框标题
	 */
	longClick : function(id,data,title){
     	document.getElementById(id).addEventListener("touchstart",function(){
	        var e = event.touches[0];
	        satrtTime = new Date().getTime();
	        startX = e.pageX;
	        startY = e.pageY;
	        if(moveState){
	            moveState =false;
	            amPubUI.longClickMove(id,data,title)
	        }
	     });
	},
	/**
	 * 长按弹出框  Move
	 * @param {} id 长按Id
	 * @param {} data 弹出框数据
	 * @param {} title 弹出框标题
	 */
	longClickMove : function(id,data,title){
        document.getElementById(id).addEventListener("mousemove",function(){
		    var e = event;
		    endTime = new Date().getTime();
		    endX = e.pageX;
		    endY = e.pageY;
			if((Math.abs(endX-startX))<20 && (Math.abs(endY-startY))<20 && (endTime-satrtTime)>365){
				document.getElementById(id).removeEventListener("mousemove");
			    startX=0,startY=0,endX=0,endY=0,satrtTime=0,endTime=0;
				moveState = true;
			    amPubUI.amListPop(data, title,id);
			}
        });
	}
	
}

function show_foot(){}
function hide_foot(){}
