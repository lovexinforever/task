// (function(){
var idcardImagePath;//身份证图片路径
var bigImagePath;//普通图片  大图路径
var smallImagePath;//普通图片  小图路径
var amScroll=null;//滚动条
var amScrDom = null;
var amDealInit = {
	
	//UI上INPUT里的数据
	amSaveData : {"tableName":"YK_S_APP"},
	
	//UI上所有元素的ID
	allInfoIdArr : amPubUI.returnHtmlIdArr("[id*='am_']"),
	
	//UI上INPUT元素的ID
	inputInfoIdArr : amPubUI.returnHtmlIdArr("input[id*='am_']"),
	
	//app_no的JSON
	whereApp :  {"APP_NO":sessionStorage.amAPP_NO},
	
	/**
	 * 初始化标题和点击事件
	 */
	initHeadClick : function() {
			amPubUI.amScrools("amScrollM");//添加滚动，调整键盘弹出高度变化
			// 标题
			util.moblie.navbar.title = "档案变更-业务受理";
			util.moblie.navbar.buttonList = ["back", "menu"];
			
			// 返回
			navbarBack = function() {
				toNext("../ArchivesModify/amWorkList.html");
			};
			
			//用电地址
			EventUtil.addClickListener({id : "am_ELEC_ADDR",clk : function() {
				ae.show(sessionStorage.amAPP_NO,function(addressDetail) {
						$("#am_ELEC_ADDR").val(addressDetail);
				});
			}});
			
			//身份证拍照
			EventUtil.addClickListener({id:"amCardCamera",clk:function(){
				amDealInit.btn_getCamera("01");
			}});
			//身份证大图预览
			EventUtil.addClickListener({id:"smallCardPicture",clk:function(){
				amDealInit.bigPictureShow("01");
			}});
			//身份证删除图片
			EventUtil.addClickListener({id:"deleteCardImg",clk:function(){
				amDealInit.deletePicture("01");
			}});
			
			//房产证拍照
			EventUtil.addClickListener({id : "amHouseCamera",clk : function() {
				amDealInit.btn_getCamera("02");
			}});
			//房产证大图预览
			EventUtil.addClickListener({id : "smallHousePicture",clk : function() {
				amDealInit.bigPictureShow("02");
			}});
			// 房产证删除图片
			EventUtil.addClickListener({id : "deleteHouseImg",clk : function() {
				amDealInit.deletePicture("02");
			}});
			
			// 保存
			EventUtil.addClickListener({id:"amSave", clk:function() {
				amDealInit.saveLocalData(function(){
					amPubUI.amDialog("保存成功",1);
				});
			}});
			
			// 任务发起
			EventUtil.addClickListener({id:"amWorkSend", clk:function() {
				amDealInit.saveLocalData(function(){
					amDealInit.upLoad();//数据上装
				});
			}});
			
			// 通讯地址
			EventUtil.addClickListener({id:"am_ADDR", clk:function() {
				var elec_addrs = $("#am_ELEC_ADDR").val();
				$("#am_ADDR").val() == ""?$("#am_ADDR").val(elec_addrs):"";
			}});
			
			$("#am_CONTACT_NAME").focusin(function(){
				if($("#am_CONTACT_NAME").val() == ""){
					if($("#am_CONTACT_NAME").val($("#am_CONS_NAME").text()));
				}
			});
			
			// 更多信息
			amPubUI.amMoreInfoClick("moreInfo");
			
			//文本框聚焦
			amPubUI.amInputClick("amListEdit li input");
			
			// 证件类别
			EventUtil.addClickListener({id : "am_CERT_TYPE_CODE",clk : function() {
				var temp = amQuery.codeSortJson.A_29012, certType = {};
				for(var i = 0;i<temp.length;i++){
					certType[temp[i].value] = temp[i].name;
				}
				amPubUI.amListPop(certType, "证件类别","am_CERT_TYPE_CODE");
			}});
		
	},
	/**
	 * 查询用电申请信息
	 */
	initQueryData : function() {
		amQuery.queryUserSendInfo(sessionStorage.amAPP_NO, function(tx, res) {
			var len = res.rows.length;
			if (len == 0) {// 本地未查询
				amPubUI.amDialog("未查询到数据", 1);
			} else {
				amPubUI.initPageHtml(res.rows.item(0), amDealInit.allInfoIdArr); // 初始化页面数据
				
				amQuery.tansformCode(amQuery.codeSortJson);// Pcode转码
				
				valiOfficetel(1);//初始化固定电话
				
				if (res.rows.item(0).IDIMAGE_STATE == "02" || res.rows.item(0).IDIMAGE_STATE == '03') {// 身份证
					
					idcardImagePath = res.rows.item(0).IDIMAGE_NAME;
					$("#amCardCamera").addClass("hidden");
					$("#smallCardPicdiv").removeClass("hidden");
					$("#smallCardPicture").attr("src", idcardImagePath);
					
				}
			}
		}, null);
	},

	/**
	 * 身份证拍照
	 */
	btn_getCamera : function(type) {
		if(type == "01"){//身份证
			ocrIdCard(function(path, res) {
				idcardImagePath = path.image_name;
				$("#amCardCamera").addClass("hidden");
				$("#smallCardPicdiv").removeClass("hidden");
				$("#smallCardPicture").attr("src", idcardImagePath);
				if (idcardImagePath != "") {
					updateYkIdcardImage(['02', idcardImagePath,
									sessionStorage.amAPP_NO, 'YK_S_APP'],
							null, null);
				}
			}, null);
		}else{//普通拍照
				takephoto(sessionStorage.amAPP_NO, sessionStorage.amCONS_NO, function(path, res) {
					$("#amHouseCamera").addClass("hidden");
					$("#smallHousePicdiv").removeClass("hidden");
					$("#smallHousePicture").attr("src", path.small_name);
					bigImagePath = path.big_name;
					smallImagePath = path.small_name;
					if (bigImagePath != "") {
						updateYkImage(['02', bigImagePath, smallImagePath,
										sessionStorage.amAPP_NO, 'YK_S_APP'], null, null);
					}
				}, null);
		}
	},
	
	/***
	 * 查看大图
	 */
	bigPictureShow : function(type) {
		if(type == "01"){//身份证
			picture_show(idcardImagePath, "图片预览", function() {
					closePPDialog();
			});
		}else{
			picture_show(bigImagePath, "图片预览", function() {
					closePPDialog();
			});
		}
	},
	
	/***
	 * 删除图片
	 */
	deletePicture : function(type) {
		if (type == "01") {//身份证
			getPictureDelete({
						"bigpath" : idcardImagePath,
						"smallpath" : ""
					}, function() {
						$("#amCardCamera").removeClass("hidden");
						$("#smallCardPicdiv").addClass("hidden");
						updateYkIdcardImage(['01', '', sessionStorage.amAPP_NO,'YK_S_APP'], null, null);
					}, null);
					
		} else {
			getPictureDelete({
					"bigpath" : bigImagePath,
					"smallpath" : smallImagePath
				}, function() {
					$("#amHouseCamera").removeClass("hidden");
					$("#smallHousePicdiv").addClass("hidden");
					updateYkImage(['01', '', '', sessionStorage.amAPP_NO, 'YK_S_APP'], null,null);
				}, null);
		}
	},
	
	/**
	 * 保存
	 * @param {} callback 保存成功回调
	 */
	saveLocalData : function(callback) {
		
		if(!dataValidate.valiRequired($("#am_CONTACT_NAME").val())){
			amPubUI.amDialog("联系人不能为空",1);
			return;
		}
		
		if($("#am_CONTACT_NAME").val().replace(/\d+/g,'').length < 1){
			amPubUI.amDialog("联系人不能全为数字",1);
			return;
		}
		
		if ($("#am_T_CONTRACT_CAP").val() >= 12
				&& $("#am_CONS_SORT_CODE").html() == "低压非居民") {
			amPubUI.amDialog("移动电话不能为空", 1);
			return;
		}
		
		if ($("#am_T_CONTRACT_CAP").val() < 12
				&& $("#am_OFFICE_TEL").val() == ""
				&& $("#am_MOBILE").val() == "") {
			amPubUI.amDialog("固定电话、移动电话必须填一个", 1);
			return;
		}
		if(!dataValidate.valiMobile("am_MOBILE")) return;
		if(!dataValidate.valiOffice("am_OFFICE_TEL","固定电话")) return;
			
		if(!dataValidate.valiRequired($("#am_ELEC_ADDR").val())){
			amPubUI.amDialog("用电地址不能为空",1);
			return;
		}
		
		if(!dataValidate.valiRequired($("#am_REASON").val())){
			amPubUI.amDialog("申请原因不能为空",1);
			return;
		}
		
		var temp = amPubUI.localJsonData(amDealInit.inputInfoIdArr);
		var certType = {
			"CERT_TYPE_CODE" : $("#am_CERT_TYPE_CODE").attr("name")
		};
		// 将input里面的数据存入amSaveData
		amDealInit.amSaveData = $.extend(amDealInit.amSaveData, temp, certType);
		dataUpdate.updateInfo(amDealInit.amSaveData, amDealInit.whereApp,
				callback, null);
	},
	
	/**
	 * 	数据上装
	 */
	upLoad : function() {
		initGiveRightInfo();//重新获取授权人信息
		amQuery.queryUserSendInfo(sessionStorage.amAPP_NO, function(tx, res) {// 查询本地数据
					var len = res.rows.length;
					if (len != 0) {
						var requestData = amFileModifyInfo(res.rows.item(0));// 任务传递需要的数据
						amSendTask({
							"flowKey" : "YEWU_SHOULI",
							"flow" : requestData,
							"sqUserName" : amSqNopg,
							callback : function(obj) {
								reMsgDeal(obj, returnModelURL);
							}
						});
					}
			}, null);
	}
	
}

/**
 * 固定电话初始化 010 - 12345678 - 01
 * @param {} type 0为验证 1为初始化
 */
var valiOfficetel = function(type) {
	if(type ==0){
		$('#am_OFFICE_TEL').val($('#office_tel_qh').val()+ '-'+ $('#office_tel_num').val()
				+ ($('#office_tel_fjh').val() == '' ? '' : '-'+ $('#office_tel_fjh').val()));
		if ($('#am_OFFICE_TEL').val() == '-')
			$('#am_OFFICE_TEL').val('');
	}else{
	    var office_tel = $('#am_OFFICE_TEL').val();
	    if(office_tel){
		    var index = office_tel.indexOf("-");
		    var qh = office_tel.substring(0, index);
		    var num = office_tel.substring(index + 1);
		    var fjh = "";
		    index = num.indexOf("-");
		    if(index != -1) {
		        fjh = num.substring(index + 1);
		        num = num.substring(0, index);
		    }
		    $('#office_tel_qh').val(qh);
		    $('#office_tel_num').val(num);
		    $('#office_tel_fjh').val(fjh);
	    }
	}
}

amDealInit.initHeadClick();
amDealInit.initQueryData();

// })();
