// (function(){
var amScroll=null;//滚动条
var amScrDom = null;
var amFWInit = {
	// UI上INPUT里的数据
	amSaveData : {"tableName" : "YK_306_INVESTIGATE"},

	// UI上所有元素的ID
	allInfoIdArr : amPubUI.returnHtmlIdArr("[id*='am_']"),

	// UI上INPUT元素的ID
	inputInfoIdArr : amPubUI.returnHtmlIdArr("input[id*='am_']"),
	
	//勘查意见
	apprOption : {"01" : "同意","02" : "不同意"},

	// app_no的JSON
	whereApp : {"APP_NO" : sessionStorage.amAPP_NO},

	/**
	 * 初始化标题和点击事件
	 */
	initHeadClick : function() {
		amPubUI.amScrools("amScrollM");//添加滚动，调整键盘弹出高度变化
		// 标题
		util.moblie.navbar.title = "档案变更-现场勘查";
		util.moblie.navbar.buttonList = ["back", "menu"];

		// 勘查日期
		EventUtil.addClickListener({id : "am_CHK_DATE",clk : function() {
			dateTimePicker({"date":$("#am_CHK_DATE").val(), "type":"1"},function(res) {
				if(res != "" && res != "null") {
					$("#am_CHK_DATE").val(res);
				}
			});
		}});
		// 保存
		EventUtil.addClickListener({id : "amSave",clk : function() {
			amFWInit.saveLocalData(function() {
				amPubUI.amDialog("保存成功", 1);
			});
		}});

		// 任务传递
		EventUtil.addClickListener({id : "amWorkSend",clk : function() {
			amFWInit.saveLocalData(function() {
				amFWInit.upLoad();
			});
		}});

		// 返回
		navbarBack = function() {
			toNext("../ArchivesModify/amWorkList.html");
		};

		// 更多信息
		amPubUI.amMoreInfoClick("moreInfo");
		
		//勘查意见
		amPubUI.longClick("am_CHK_OPINION",amFWInit.apprOption,"勘查意见");
		
	},
	/**
	 * 查询用电申请信息
	 */
	initQueryData : function() {
		amQuery.queryFiledWorkData("YK_306_INVESTIGATE",
				sessionStorage.amAPP_NO, function(tx, res) {
					
					var len = res.rows.length;
					
					if (len == 0) {// 本地未查询
						amPubUI.amDialog("未查询到数据", 1);
					} else {
						
						// 初始化页面数据
						amPubUI.initPageHtml(res.rows.item(0),amFWInit.allInfoIdArr); 
						amQuery.tansformCode(amQuery.codeSortJson);// Pcode转码
					}
		}, null);
	},

	/**
	 * 保存
	 * @param callback 保存成功回调
	 */
	saveLocalData : function(callback) {
		
		if(!dataValidate.valiRequired($("#am_CHECKER_NAME").val())){
			amPubUI.amDialog("勘查员不能为空",1);
			return;
		}
		if(!dataValidate.valiRequired($("#am_CHK_DATE").val())){
			amPubUI.amDialog("勘查日期不能为空",1);
			return;
		}
		if(!dataValidate.valiRequired($("#am_CHK_OPINION").val())){
			amPubUI.amDialog("勘查意见不能为空",1);
			return;
		}
		// 将input里面的数据存入amSaveData
		var temp = amPubUI.localJsonData(amFWInit.inputInfoIdArr);
		amFWInit.amSaveData = $.extend(amFWInit.amSaveData, temp);
		dataUpdate.updateInfo(amFWInit.amSaveData, amFWInit.whereApp, callback,null);
	},

	/**
	 * 数据上装
	 */
	upLoad : function() {
		initGiveRightInfo();//重新获取授权人信息
		amQuery.queryFiledWorkData("YK_306_INVESTIGATE",
				sessionStorage.amAPP_NO, function(tx, res) {// 查询本地数据
					var len = res.rows.length;
					if (len != 0) {
						var requestData = amFieldWork(res.rows.item(0));// 任务传递需要的数据
						amSendTask({
							"flowKey" : "XIANCHANG_KANCHA",
							"flow" : requestData,
							"sqUserName" : amSqNosp,
							callback : function(obj) {
								reMsgDeal(obj, returnModelURL);
							}
						});
					}
			}, null);
		}

}

amFWInit.initHeadClick();
amFWInit.initQueryData();

// })();
