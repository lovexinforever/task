/**
 * Copy Right Information  : STATE GRID
 * author                  	:yuenhoawong
 * Comments                	: 通过网络调用营销接口，重置用户密码。
 * Version                 	: 0.0.1
 * Modification history    	: 2014-05-04
 * Sr	Date        Modified By     Why & What is modified
 * 1.	2014-05-04  yuenhoawong    new file
 */

var prRequest = {
    
	user_base_data: {
        CONS_NO            : "", // 用户编号
        CONS_NAME          : "", // 用户名称
        CONS_SORT_CODE     : "", // 用户分类
        ELEC_TYPE_CODE     : "", // 用电类别
        STATUS_CODE        : "", // 用户状态
        VOLT_CODE          : "", // 供电电压
        CONTRACT_CAP       : "", // 合同容量
        ELEC_ADDR          : "", // 用电地址
        /** 身份证验证信息 */
        CERT_NO            : "", // 证件号码
        CERT_NAME          : "", // 证件名称
        CONTACT_NAME       : "", // 联系人
        POSTALCODE         : "", // 邮编
        OFFICE_TEL         : "", // 固定电话
        ADDR               : "", // 通信地址
        MOBILE             : ""  // 移动电话
    },
	/**
	 * 查询用户的基本信息
	 */
    select_userinfo: function(type, id, successCB) {
        PubFuns.addLoadingDialog();
        file_maint_req.select_user_base_info(type, id, successCB, prRequest.fail_callback);     
    },
	/**
	 * 密码重置
	 */
	btn_password_reset_click : function(cons_no, succCB) {
        PubFuns.addLoadingDialog();
        file_maint_req.reset_password(cons_no, succCB, prRequest.fail_callback);
	},

    fail_callback: function(msg) {
        PubFuns.removeLoadingDialog();
        PubFuns.dialog_alert(msg);
    }
}
