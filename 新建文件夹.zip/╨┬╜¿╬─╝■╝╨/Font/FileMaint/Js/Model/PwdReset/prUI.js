/**
 * Copy Right Information  : STATE GRID
 * author                  	: yuenhoawong
 * Comments                	: 密码重置界面处理
 * Version                 	: 0.0.1
 * Modification history    	: 2014-05-04
 * Sr	Date        Modified By     Why & What is modified
 * 1.	2014-05-04  yuenhoawong    new file
 */

/**
 * 初始化页面
 */
var prUI = {
	CONS_NO: "",  // 用户编号

    baseIds: [  {ID:"CONS_NO",    TYPE:"value"},
	     	{ID:"CONS_NAME",      TYPE:"value"},
			{ID:"CONS_SORT_CODE", TYPE:"code"},
			{ID:"ELEC_TYPE_CODE", TYPE:"code"},
			{ID:"STATUS_CODE",    TYPE:"code"},
		    {ID:"VOLT_CODE",      TYPE:"code"},
			{ID:"CONTRACT_CAP",   TYPE:"value"},
			{ID:"ELEC_ADDR",      TYPE:"value"}],
    
	/**
	 * 初始化页面
	 */
	init: function() {
		/*隐藏标题栏增加按钮，更改标题栏标题*/
		util.moblie.navbar.title = "密码重置";
        util.moblie.navbar.buttonList = ["back","menu"];// 可选参数：add back home
		
		/*navbarBack 和  navbarHome(nvabar.html) 指向自定义方法*/
		navbarBack = this.btn_back_click;
		//navbarMenu = this.btn_menu_click;
		
		
		prUI.set_basic_info();		/*插入基本信息html+字段*/
		
		
        EventUtil.addClickListener({id: "pr_checkID", clk: prUI.btn_checkID_click});
        
        $(".search").elecSearch({
            callback:function(obj) {
                var txtNo = obj.searchText;	
		        if(txtNo == "") {
		        	PubFuns.dialog_alert("请填写" + obj.selectobj.text);
		        }	        
		        else {
		        	prRequest.select_userinfo(obj.selectobj.id, txtNo, prUI.select_userinfo_cb);
		        }                
            },
            select:{
                list:[{id:1,text:"用户编号"},{id:2,text:"电表资产编号"}],
                callback:function(obj){ 
                	if(obj.selectobj.id == 2) {
                		fm_bluetooth_connect(function(value) {
                			$("input[type='search']").val(value);
                		});
                	}
                }                
            }
        });

        //$("input[type='search']").val('0115835806');
	},

	/**
	 * 标题栏返回按钮
	 */
	btn_back_click : function(){
		$("#dx-viewport-one").load("../Main/mainContent.html");
	},
	/**
	 * 标题栏菜单按钮
	 */
	btn_menu_click : function(){
		alert('btn_menu_click');
	},
	/**
	 * 查询按钮点击事件
	 */
	btn_search_click: function() {

	},
	
	/**
	 * 验证身份
	 */
	btn_checkID_click: function() {
        /* 弹出身份验证的弹出框*/
        $.Elec.dialogTemplate.setValue({head: "身份证信息核对", left:  {txt:"通过核对", color: "blue", clickCB:{func: prUI.btn_checkover_click}},
                                                                right: {txt:"取消核对", color: "grey", clickCB:{func: prUI.btn_cancel_click}} });
        
        $.Elec.dialogTemplate.setItemsData([
            {
                type: "singleKV",            
                data: {key: "证件号码", value: prRequest.user_base_data.CERT_NO}
            },
            {
                type: "singleKV",            
                data: {key: "证件名称", value: prRequest.user_base_data.CERT_NAME}
            },
            {
                type: "singleKV",            
                data: {key: "联系人", value: prRequest.user_base_data.CONTACT_NAME}
            },
            {
                type: "singleKV",            
                data: {key: "邮编", value: prRequest.user_base_data.POSTALCODE}
            },
            {
            	type: "singleKV",            
                data: {key: "固定电话", value: prRequest.user_base_data.OFFICE_TEL}
            }, 
            {
                type: "singleKV",            
                data: {key: "通信地址", value: prRequest.user_base_data.ADDR}
            },
            {
            	type: "singleKV",            
                data: {key: "移动电话", value: prRequest.user_base_data.MOBILE}
            }
        ]).show(); 
	},

	/**
	 * 取消核对身份之后，关闭对话框
	 */ 
	btn_cancel_click: function() {
		$.cache["dialog"].close();
	},
	
	/**
	 * 核对完身份之后，刷新界面 
	 */
	btn_checkover_click: function() {
		$.cache["dialog"].close();

	    Elec.getELeById("text_check_id").innerText = "确定密码重置";
		
		EventUtil.remveClickListener("pr_checkID", prUI.btn_checkID_click);
		EventUtil.addClickListener({id: "pr_checkID", clk: prUI.btn_makesure_del_click});
	},
	
	btn_makesure_del_click: function() {
        $.Elec.dialogTemplate.setValue({head: "温馨提示", left:  {txt:"确定", color: "blue", clickCB:{func: prUI.btn_sure_click}},
                                                        right: {txt:"取消", color: "grey", clickCB:{func: function(){$.cache["dialog"].close();}}} });
        
        $.Elec.dialogTemplate.setItemsData([
            {
                type: "text",            
                data: "是否确定密码重置？"
            }
        ]).show();
    },
    
	/**
	 * 确定按钮
	 */
	btn_sure_click : function() {
		// 请求营销接口
		prRequest.btn_password_reset_click(prUI.CONS_NO, prUI.btn_sure_click_cb);
	},

	/**
     * 设置用户的基本信息
     * @param {int} type: 0--第一次设置  非0值--之后设置
     */
    set_basic_info : function(data) {
        
        var cons_no = '';
        var cons_name = '';
        var cons_sort_code = '';
        var elec_type_code = '';
        var status_code = '';
        var volt_code = '';
        var contract_cap = '';
        var elec_addr = '';
        
        if(data != undefined && data != null) {
            var cons_no = data.CONS_NO;
            var cons_name = data.CONS_NAME;
            var cons_sort_code = data.CONS_SORT_CODE;
            var elec_type_code = data.ELEC_TYPE_CODE;
            var status_code = data.STATUS_CODE;
            var volt_code = data.VOLT_CODE;
            var contract_cap = data.CONTRACT_CAP;
            var elec_addr = data.ELEC_ADDR;
        }
        if(Elec.getELeById('pr_basic_info').innerHTML == "") {    
 		    Elec.getELeById('pr_basic_info').innerHTML = '<table><tr><td >用户编号</td><td id="CONS_NO">' + cons_no + '</td><td >用户名称</td><td id="CONS_NAME">' + cons_name  + '</td></tr>'
													   + '<tr><td>用户分类</td><td id="CONS_SORT_CODE" pcode="29011" val="' + cons_sort_code + '"></td><td >用电类别</td><td id="ELEC_TYPE_CODE" pcode="29001" val="' + elec_type_code + '"></td></tr>'
													   + '<tr><td>用户状态</td><td id="STATUS_CODE" pcode="29002" val="' + status_code + '"></td><td >供电电压</td><td id="VOLT_CODE" pcode="10005" val="' + volt_code + '"></td></tr>'
													   + '<tr><td>合同容量</td><td colspan=3 id="CONTRACT_CAP">' + contract_cap + '</td></tr>'
													   + '<tr><td>用电地址</td><td colspan=3 id="ELEC_ADDR">' + elec_addr + '</td></tr></table>';
            
        }
        else {
            var ids = prUI.baseIds;
		    for(var i = 0; i < ids.length; i++) {
		    	var node = document.getElementById(ids[i].ID);
		    	if(node.hasAttribute("pcode")) {
		    		node.setAttribute("val", data[ids[i].ID]);
		    		var pcode = node.getAttribute("pcode");
		    		PubFuns.selectPCode({CODE_SORT_ID: pcode, VALUE: data[ids[i].ID]}, prUI.select_pcode_cb, null);
		    	}
		    	else {
		    		if(ids[i].ID == "CONTRACT_CAP") {
		    			node.innerText = data[ids[i].ID] + "kVA";
		    		}
		    		else {
		    			node.innerText = data[ids[i].ID];
		    		}
		    	}		        
		    }
		    document.getElementById("content").setAttribute("class", "content");
        }                                                
    },

    /**
	 * 查询PCODE码的回调函数
	 */
	select_pcode_cb: function(tx, results) {
		if(results.rows.length == 1) {
			var pcode = results.rows.item(0).CODE_SORT_ID;
			var value = results.rows.item(0).VALUE;
			var name = results.rows.item(0).NAME;

			var ids = cmUI.baseIds;
		    for(var i = 0; i < ids.length; i++) {
		    	var node = document.getElementById(ids[i].ID);
		    	if(node.hasAttribute("pcode")) {
		    		if(node.getAttribute("pcode") == pcode) {
		    			node.innerText = name;
		    			break;
		    		}
		    	}	        
		    }
		}
	},
	
	btn_sure_click_cb: function(data) {
	    console.log("btn_sure_click_cb:" + data + ",type=" + typeof(data));
	    PubFuns.removeLoadingDialog();
		data = JSON.parse(data);		
		if(data.PKG.PKG.FLAG == "1") {
			PubFuns.dialog_alert("密码重置成功");
		}
		else {
			PubFuns.dialog_alert("密码重置失败");
		}
	},

	/**
	 * 查询基本信息的成功回调
	 */
	select_userinfo_cb: function(data) {
		console.log("select_userinfo_cb:" + data);
		data = JSON.parse(data);
		PubFuns.removeLoadingDialog();
		if(data.PKG.PKG != undefined) {
			data = data.PKG.PKG.CONSINFO[0];
			prUI.CONS_NO = data.CONS_NO;
			console.log("prUI.CONS_NO=" + prUI.CONS_NO);
			for(node in data) {
		        prRequest.user_base_data[node] = data[node];
		    }
		    
		    prUI.set_basic_info(data);
		}
	}
};

prUI.init();
