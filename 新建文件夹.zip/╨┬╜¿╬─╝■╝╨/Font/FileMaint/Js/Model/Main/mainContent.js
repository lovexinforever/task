navbarBack = function(){
    console.log("click navbarBack");
    window.location.href = "../../../../../Platform/Plat/html/index.html";
} ;    
navbarAdd = function(){
  console.log("click navbarAdd");
} ;

// localStorage.SSN = "88333";
// localStorage.user_name = "010062";

(function($){
  /*命名空间*/
  $.Elec = $.Elec || {};

  $.Elec.homeMenu = {
      //模块初始化
      initModel:function(data,model,obj){
          var data = {list:data};
          var listStr = juicer(model,data);
          obj.innerHTML = "";
          obj.append(listStr);
          //右侧菜单栏跳转
          $(".v_list").on("click","li",function(){
              var t = $(this),url = t.data("url");
              if(url == "index.html"){
                  location.href = url;
              }else{
                  $("#dx-viewport-one").load(url,function(){
                     $(".viewContent").addClass("rightBarHide");
                     $(".toolbar").css("z-index","1");
                  });
              }
          })
      },
      //事件初始化
      initEvent:function(element){
        element.addListClickListener(function(){
          $("#dx-viewport-one").load($(this).attr("url")); //固定死的规则
        });
      },
      //初始化导航栏 利用延迟加载
      initNavbar:function(){
          util.moblie.navbar.title = "档案维护";
          util.moblie.navbar.buttonList = ["back"];// 可选参数：add back menu
      },
      //设置导航栏标题
      setNavbarTitle:function(title){
          util.moblie.navbar.changeTitle(title);
      },
      //设置导航栏按钮组
      setNavbarButton:function(list){
         util.moblie.navbar.changeButton(list);
      }
  }
})(jQuery)

/*模块列表*/
var modelList = [
  { 
      icon:"model_am_icon",             
      title:"档案变更",     
      url:"../ArchivesModify/amWorkList.html", 
      navigationName:"",
      id: "ArchivesModify",
      modeCode: "0306"
      // power:{
      //   code:1, //0  不需要授权 1 已经授权 -1未授权 01-已授权 02-未授权 03-无需授权
      //   text:"已授权",// 文本展示信息
      //   message:"剩余40分钟" //  提示信息
      // }
  },
  { 
      icon:"model_nm_icon",             
      title:"更名",         
      url:"../NameModify/index.html", 
      navigationName:"",
      id: "NameModify",
      modeCode: "0210"
      /*,
      power:{
        code:0, //0  不需要授权 1 已经授权 -1未授权
        text:"无需授权",// 文本展示信息
        message:"" //  提示信息
      }*/
  },
  { 
      icon:"model_cm_icon",    
      title:"联系人维护",   
      url:"../ContactMaint/contactInfo.html", 
      id: "ContactMaint",
      navigationName:""
  },
  { 
      icon:"model_pr_icon",                 
      title:"密码重置",     
      url:"../PwdReset/pwdIndex.html", 
      id: "PwdReset",
      navigationName:"" 
  },
  {
      icon:"model_em_icon",                 
      title:"授权管理",     
      url:"../GiveRight/grIndex.html", 
      id: "GiveRight",
      navigationName:"" 
  },
  { 
      icon:"model_set_icon",                 
      title:"设置",         
      url:"../Set/setIndex.html", 
      id: "Set",
      navigationName:"" 
  },
  { 
      icon:"model_ub_icon",                 
      title:"操作说明",     
      url:"../OperateBook/operateMenu.html", 
      id: "OperateBook",
      navigationName:"" 
  }
];

$.Elec.homeMenu.initModel(modelList,$("#modelListTemplate").html(),$(".modelList"));
$.Elec.homeMenu.initEvent($(".modelList a"));
$.Elec.homeMenu.initNavbar();

PubFuns.initDialogTheme();
PubFuns.getMyTid();

console.log("sessionStorage.USER_INFO=" + sessionStorage.USER_INFO);
var FM_NEED_REFRESH = false;
if(sessionStorage.FM_USER == undefined) {
    FM_NEED_REFRESH = true;    
} 
else {
    FM_NEED_REFRESH = (sessionStorage.FM_USER == sessionStorage.USER_INFO) ? false : true;
}
sessionStorage.FM_USER = sessionStorage.USER_INFO;
giveRightInfo.select_all(dealDataCb, FM_NEED_REFRESH ? giveRightInfo.REQ_CODE.AUTO : giveRightInfo.REQ_CODE.NORMAL);

function dealDataCb(result) {
    for (var i = 0; i < modelList.length; i++) {
        if(modelList[i].modeCode != undefined) {
            
            var modeActCode = modelList[i].modeCode;
            modelList[i].power = {};
            modelList[i].power.message = "";
            var html = "";
            var startDate = new Date();
            
            var hours = 0;
            var status = [];
            var style = "";

            for (var j = 0; j < result.length; j++) {
                
                var tempData = result[j];

                if(tempData.ACT_CODE.substr(0, 4) == modeActCode) {
                    status.push(tempData.AUTHORIZE_STATUS);
                    if(tempData.AUTHORIZE_STATUS == "01") {                             
                        // 计算授权的剩余时间
                        var endDate = new Date(tempData.AUTHORIZE_END);
                        var spaceTime = endDate.getTime() - startDate.getTime();
                        var h = Math.ceil(spaceTime/(3600*1000));

                        if(hours == 0) {
                            hours = h;
                        }
                        else {
                            if(hours > h) {
                                hours = h;
                            }
                        }
                    }
                    
                }
            }

            var b = true;
            if(status.toString().indexOf("02") != -1) {
                modelList[i].power.text = "未授权";
                style = "need";
            }
            else if(status.toString().indexOf("01") != -1) {
                modelList[i].power.text = "已授权";
                style = "pass";
                if(hours < 100 && hours > 0) {/*modified by yuenhoa 20141216 : hours变量的用法错误，将错就错在这里增加判断是不是过期*/
                    modelList[i].power.message = "小于" + hours + "小时";
                }else if(hours <= 0){
                	modelList[i].power.text = "未授权";
                	style = "need";
                }
            }
            else if(status.toString().indexOf("03") != -1) {
                modelList[i].power.text = "无需授权";
                style = "no";
            }
            else {
                b = false;
            }

            if(b) {
                html = '<div class="content">'
                        +'<div>'                                
                          +'<div class="power ' + style + '">' + modelList[i].power.text + '</div>'
                          +'<div class="notify">' + modelList[i].power.message + '</div>'
                        +'</div>'
                        +'</div>';
                document.getElementById(modelList[i].id).innerHTML = html;
                document.getElementById(modelList[i].id).setAttribute("class", "status"); 
                
                EventUtil.addClickListener({id: modelList[i].id, 
                	clk: function(url){
                		 $("#dx-viewport-one").load(url);
                	},
                	args:modelList[i].url
                });/*modified by yuenhoa 20141217 : 已授权未授权提示信息点击没有跳转页面*/
            }
        } 
    }
}

