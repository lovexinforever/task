/**
 * Copy Right Information  : STATE GRID
 * author                  	: wangjun
 * Comments                	: 通过网络调用营销接口，如：授权认证、取消授权、延长授权，查询环节处理工号
 * Version                 	: 0.0.1
 * Modification history    	: 2014-04-28
 * Sr	Date        Modified By     Why & What is modified
 * 1.	2014-04-28  yuenhoa.wong    new file
 */

var grRequest = {
    noList: [],                 // 授权人名单
    grList: [],                 // 被授权人名单

    data: {SYS_USER_NO: '',     // 被授权人工号
		   SYS_USER_NAME: '',   // 被授权人员名称
           P_USER_NO: '',       // 授权人工号
		   P_USER_NAME: '',     // 授权人名称
		   P_USER_PASSWORD: '', // 授权人密码
		   P_DEPT_NO: '',       // 授权人部门编号
		   P_DEPT_NANME: '',    // 授权人部门名称
		   P_EMP_NO: '',        // 授权人编号
		   ACT_CODE: '',        // 待办事宜类型
		   AUTHORIZE_TIME: '',  // 授权有效时间
		   OP_TYPE: '',         // 操作类型      0 取消授权     1 授权
		   AUTHORIZE_TYPE: '',  // 授权发起类型  01 申请方发起  02 授权方发起
		   IMEI: '',            // 终端编号
		   ORG_NO: ''},         // 供电公司

    /** 待办事宜类型 */
    ACT_CODE: [ {KEY: "0210001", VALUE: "更名业务受理"},
                {KEY: "0210002", VALUE: "更名合同起草"},
                {KEY: "0210003", VALUE: "更名合同审核"},
                {KEY: "0210004", VALUE: "更名合同签订"},
                {KEY: "0306001", VALUE: "档案变更业务受理"},
                {KEY: "0306002", VALUE: "档案变更勘查派工"},
                {KEY: "0306003", VALUE: "档案变更现场勘查"},
                {KEY: "0306004", VALUE: "档案变更审批"},
                {KEY: "0000000", VALUE: "查询指定人员终端业务所有业务权限情况"}],

	/**
	 * 发起、延长或者取消授权
	 * @param {function}  成功回调
	 */
    launch: function (flag_op, flag_role, successCB) {
    	if(flag_op == "launch" || flag_op == "delay") {
    		grRequest.data.OP_TYPE = "1";
    	} 
    	else if(flag_op == "canel") {
    		grRequest.data.OP_TYPE = "0";
    	}

    	if(flag_role == "apply") {
    		grRequest.data.AUTHORIZE_TYPE = "01";
    	}
    	else if(flag_role == "launch") {
    		grRequest.data.AUTHORIZE_TYPE = "02";
    	}
        PubFuns.addLoadingDialog();
    	file_maint_req.giveright_launch(successCB, grRequest.failCB, grRequest.data);
    },

    /**
     * 授权信息查询
     * @param {String} user_type  01-授权申请人  02-授权人
     * @param {function}  成功回调
     */
    select: function(sys_user_name, user_type, act_code, successCB) {
    	var select_data = {SYS_USER_NAME: sys_user_name, 
    		               USER_TYPE: user_type,
    		               ACT_CODE: act_code};
        PubFuns.addLoadingDialog();
    	file_maint_req.giveright_selectinfo(successCB, grRequest.failCB, select_data);
    },

    /**
     * 查询环节的处理工号
     */
    selectNo: function(act_code, sys_user_name, succCB) {
        PubFuns.addLoadingDialog();
        file_maint_req.giveright_selectno_req(act_code, sys_user_name, succCB, grRequest.failCB);
    },

    failCB: function(msg) {
        // 提示请求错误
        PubFuns.removeLoadingDialog();
        PubFuns.dialog_alert(msg);
    }	
}
