var amScroll=null;//滚动条
var amScrDom = null;
var grUI = {
    roleList: {p0: "请选择", p1: "授权申请人", p2: "授权人"},
    modelList: {p0: "请选择", p1: "更名合同审核", p2: "档案变更审批", p3: "档案变更勘查派工"},
    optIndex: -1,   // 操作对象的index
    args: [],

    init: function() {
        util.moblie.navbar.title = "授权管理";
        util.moblie.navbar.buttonList = ["back", "sync", "menu"];

        // 一进入页面默认是授权申请人
        grUI.modelList = giveRightInfo.timeList;
        document.getElementById("txt_role").innerHTML = grUI.roleList["p1"];

        document.getElementById("gr_info").style.display = "none";
        document.getElementById("grperson_list").style.display = "none";
        document.getElementById("op_info").style.display = "none";
        
        EventUtil.addClickListener({id: "txt_role", clk: grUI.choice_role});
        EventUtil.addClickListener({id: "txt_model", clk: grUI.choice_model});
        EventUtil.addClickListener({id: "delayGiveright", clk: grUI.apply_delay_giveright_btn_click, args: ["", "", ""]});
        EventUtil.addClickListener({id: "gr_search", clk: grUI.search});
    },

    search: function() {
        var txtRole = document.getElementById("txt_role").innerHTML;
        var txtSearch = document.getElementById("gr_search_input").value;
        
        if(txtRole == grUI.roleList.p1 && grRequest.noList.length > 0) {
            var len = grRequest.noList.length;
            
            // 如果输入的类容是空那么列表重新刷新一遍
            if(txtSearch == "") {
                grUI.set_grperson_list(grRequest.noList, true);
                return;
            }

            // 如果不为空列表则进行筛选
            for (var i = 0; i < len; i++) {
               
                if(grRequest.noList[i].SYS_USER_NAME == txtSearch) {
                    var list = [];
                    list.push(grRequest.noList[i]);                            
                    grUI.set_grperson_list(list, true);
                    return;
                }
            }

            // 如果没有找到相对应的值则列表不显示
            document.getElementById("grperson_list").style.display = "none";
        }
        if(txtRole == grUI.roleList.p2 && grRequest.grList.length > 0) {
            var len = grRequest.grList.length;
            
            // 如果输入的类容是空那么列表重新刷新一遍
            if(txtSearch == "") {
                grUI.set_op_info(grRequest.grList, true);
                return;
            }

            // 如果不为空列表则进行筛选
            for (var i = 0; i < len; i++) {
               
                if(grRequest.grList[i].SYS_USER_NO == txtSearch) {
                    var list = [];
                    list.push(grRequest.grList[i]);                            
                    grUI.set_op_info(list, true);
                    return;
                }
            }

            // 如果没有找到相对应的值则列表不显示
            document.getElementById("op_info").style.display = "none";
        }
    },

    choice_role: function() {
        list_show({data: grUI.roleList, title:"选择角色", item_click_callback: function(id) {
                document.getElementById("txt_role").innerHTML = grUI.roleList[id];
                var txtModel = document.getElementById("txt_model").innerHTML;
                var txtRole = document.getElementById("txt_role").innerHTML;

                if(grUI.roleList[id] == grUI.roleList.p1) {   
                    grUI.modelList = giveRightInfo.timeList;    


                    if(txtModel != grUI.modelList["p0"]) {
                        document.getElementById("op_info").style.display = "none";
                        document.getElementById("gr_info").style.display = "block";
                        document.getElementById("delayGiveright").style.display = "none";
                    }                    
                }
                else if(grUI.roleList[id] == grUI.roleList.p2) {
                    grUI.modelList = giveRightInfo.modelList;
                    
                    if(txtModel != grUI.modelList["p0"]) {
                        document.getElementById("gr_info").style.display = "none";
                        document.getElementById("grperson_list").style.display = "none";
                    }
                }

                if(txtModel != grUI.modelList["p0"] && txtRole != grUI.modelList["p0"]) {
                    grUI.select_action();
                }
                
            }, bgCallback:function() {$.cache["dialog"].close();}
        });
    }, 

    choice_model: function() {
        list_show({data:grUI.modelList, title:"选择授权模块", item_click_callback: function(id) {
                var value = grUI.modelList[id];
                var index = value.indexOf("(");
                if(index != -1) {
                    value = value.substring(0, index);
                }
                document.getElementById("txt_model").innerHTML = value; 
                var txtModel = grUI.modelList[id];
                var txtRole = document.getElementById("txt_role").innerHTML;

                if(txtModel != grUI.modelList["p0"] && txtRole != grUI.modelList["p0"]) {          
                    grUI.select_action();   
                }         
            }, bgCallback:function() {$.cache["dialog"].close();}
        });
    },

    select_action: function() {
        var user_type = "";
        if(document.getElementById("txt_role").innerHTML == grUI.roleList.p1) {
            user_type = "01";
        }
        else if(document.getElementById("txt_role").innerHTML == grUI.roleList.p2) {
            user_type = "02";
        }

        var sys_user_name = localStorage.user_name;
        var act_code = grUI.getActCode();

        // 如果是授权申请人，那么先查询是否有授权信息
        var pInfo = giveRightInfo.getPInfo(act_code);
        if(user_type == "01" ) {
            document.getElementById("gr_info").style.display = "block";
            document.getElementById("delayGiveright").style.display = (pInfo != null) ? "-webkit-box" : "none";
            if(pInfo != null) {          
                document.getElementById("P_USER_NAME").innerText     = pInfo.P_USER_NAME;
                document.getElementById("P_USER_NO").innerText       = pInfo.P_USER_NO;
                document.getElementById("AUTHORIZE_BEGIN").innerText = pInfo.AUTHORIZE_BEGIN;
                document.getElementById("AUTHORIZE_END").innerText   = pInfo.AUTHORIZE_END;
            }            
        }

        grRequest.select(sys_user_name, user_type, act_code, function(data) {
            if(user_type == "01") {
                grRequest.selectNo(act_code, sys_user_name, grUI.set_grperson_list);
            }
            else if(user_type == "02") {
                grRequest.select(sys_user_name, user_type, act_code, grUI.set_op_info);
            }
        });
    },

    /**
     * 设置操作人信息
     */
    set_op_info: function(data, flag) {
        if(flag == undefined) {
            PubFuns.removeLoadingDialog();
            console.log("set_op_info:" + data);
            data = JSON.parse(data);

            if(data.PKG != undefined && data.PKG.PKG != undefined && data.PKG.PKG.DATA != undefined) {
                 data = data.PKG.PKG.DATA;
            }
            else {
                PubFuns.dialog_alert("无授权信息"); 
                return;
            }
        }
        if(flag == undefined) {
            grRequest.grList = data;
        }

        document.getElementById("op_info").style.display = data.length > 0 ? "block" : "none";

        document.getElementById("op_info_content").innerHTML = "";
        for (var i = 0; i < data.length; i++) {
            var content = '<div class="message limiteWidth"><table class="add_padding"><tr><td>申请人名称</td><td>'+ data[i].SYS_USER_NAME+'</td>'
                        + '<td>申请人工号</td><td>' + data[i].SYS_USER_NO + '</td></tr>'
                        + '<tr><td>起始时间</td><td colspan="3" id="op_starttime_' + i + '">'+ data[i].AUTHORIZE_BEGIN +'</td></tr>'
                        + '<tr><td>结束时间</td><td colspan="3" id="op_endtime_' + i + '">'+ data[i].AUTHORIZE_END +'</td></tr></table></div>'
                        + '<div class="double_button line"><div class="button_left" id="opcancel_' + i + '">取消授权</div>'
                        + '<div class="button_right" id="oplaunch_' + i + '">延长授权</div></div>';

            document.getElementById("op_info_content").innerHTML += content;            
        } 
        // 添加点击事件
        for (var i = 0; i < data.length; i++) {
            EventUtil.addClickListener({id: "oplaunch_" + i, clk: grUI.delay_giveright_btn_click, args: ["", "oplaunch_" + i]});
            EventUtil.addClickListener({id: "opcancel_" + i, clk: grUI.cancel_giveright_btn_click, args: ["opcancel_" + i]});
        }
    },

    /**
     * 设置授权人名单信息
     */
    set_grperson_list: function(data, flag) {
        if(flag == undefined) {
            PubFuns.removeLoadingDialog();
            console.log("set_grperson_list:" + data);
            data = JSON.parse(data);
        }
        
        if(flag == undefined) {
            if(data.PKG != undefined && data.PKG.PKG != undefined && data.PKG.PKG.SYSUSER != undefined) {
                data = data.PKG.PKG.SYSUSER;
                if(flag == undefined) {
                    grRequest.noList = data;
                }
            }
            else {
                PubFuns.dialog_alert("无授权名单");
                return;
            }
        }
          
        var len = data.length;

        if(len > 0) {
            document.getElementById("grperson_list").style.display = "block";
        }
        else {
            document.getElementById("grperson_list").style.display = "none";
        }

        document.getElementById("grperson_list_content").innerHTML = "";
        for (var i = 0; i < len; i++) {
            var content = '<tr>'
                              +'<td class="one_key">用户姓名</td>'
                              +'<td class="one_value">' + data[i].USER_NAME + '</td>'
                              +'<td class="two_key">工号</td>'
                              +'<td class="two_value">' + data[i].SYS_USER_NAME + '</td>'
                              +'<td rowspan="2"><div class="btn" id="gp_' + i + '">请求授权</div></td>'
                         +'</tr>'
                         +'<tr>'
                              +'<td class="key">部门名称</td>'
                              +'<td class="value" colspan="4">' + data[i].DEPT_NAME + '</td>'
                         +'</tr>'
                         +'<tr>'
                              +'<td colspan="5" class="line"></td>'
                         +'</tr>'; 

            document.getElementById("grperson_list_content").innerHTML += content;         
        }
        
        if(len > 0) {
            var h = document.body.clientHeight - document.getElementById("main_head").clientHeight - document.getElementById("gr_head").clientHeight - document.getElementById("cm_search").clientHeight - document.getElementById("gr_info").clientHeight - document.getElementById("grperson_head").clientHeight;
            document.getElementById("rightScroll").style.height = h + "px";
        }
	grUI.amScrools("rightScroll");
        for (var i = 0; i < len; i++) {
            EventUtil.addClickListener({id: "gp_" + i, clk: grUI.apply_delay_giveright_btn_click, args: ["", "", "gp_" + i]});
        }  
    },
    
    amScrools : function(id) {
        amScroll = new iScroll(id, {useTransition : true, hScrollbar : false, vScrollbar : false});
    },

    /**
     * 点击取消授权后弹出取消授权的提示框
     */
    cancel_giveright_btn_click: function(args) {
        var indexId = args[0];
        $.Elec.dialogTemplate.setValue({head: "取消授权", left:  {txt:"取消", color: "grey", clickCB:{func: function() {$.cache["dialog"].close();}}},
                                                          right: {txt:"确认", color: "blue", clickCB:{func: grUI.delay_giveright, args:[indexId, "cancel"]}}     });
        var tempIndex = indexId.split("_")[1]; 
        var data = grRequest.grList;
        $.Elec.dialogTemplate.setItemsData([
            {
                type: "doubleKV",   // singleKV, doubleKV, editbox, listbox
                data: [{key: "申请人名称", value: data[tempIndex].SYS_USER_NAME}, {key: "申请人工号", value: data[tempIndex].SYS_USER_NO}]
            },
            {
                type: "singleKV",   
                data: {key: "起始时间", value: data[tempIndex].AUTHORIZE_BEGIN}
            },
            {
                type: "singleKV",   
                data: {key: "结束时间", value: data[tempIndex].AUTHORIZE_END}
            }
        ]).show();
    },

    /**
     * 授权人延长授权按钮的点击事件
     */
    delay_giveright_btn_click: function(args) {
        var value = args[0];
        var indexId = args[1];
        grUI.args = args;
        $.Elec.dialogTemplate.setValue({head: "延长授权", left:  {txt:"取消", color: "grey", clickCB:{func: function() {$.cache["dialog"].close();}}},
                                                          right: {txt:"授权", color: "blue", clickCB:{func: grUI.delay_giveright, args:[grUI.args[1], "delay_2"]}}     });
        var tempIndex = (indexId+"").split("_")[1]; 
        value =  (value == null ? "" : value);
        var data = grRequest.grList;
        $.Elec.dialogTemplate.setItemsData([
            {
                type: "doubleKV",   // singleKV, doubleKV, editbox, listbox
                data: [{key: "申请人名称", value: data[tempIndex].SYS_USER_NAME}, {key: "申请人工号", value: data[tempIndex].SYS_USER_NO}]
            },
            {
                type: "singleKV",   
                data: {key: "起始时间", value: data[tempIndex].AUTHORIZE_BEGIN}
            },
            {
                type: "singleKV",   
                data: {key: "结束时间", value: data[tempIndex].AUTHORIZE_END}
            },
            {
                id: "select",
                type: "listbox", 
                placeholder: "请选择授权有效时间",
                value: value
            }

        ]).show();

        EventUtil.addClickListener({id: "select", clk: function() {
                $.cache["dialog"].close();
                var data = {p1: "1天", p2: "3天", p3: "5天", p4: "7天", p5: "15天", p6: "30天"};
                list_show({data:data, title:"请选择授权有效时间", item_click_callback: function(id) {
                        grUI.args[0] = data[id];
                        grUI.delay_giveright_btn_click(grUI.args);
                    }
                });
            }
        });     
    },

    /**
     * 申请人延长或者请求授权
     */
    apply_delay_giveright_btn_click: function(args) {

        console.log("apply_delay_giveright_btn_click:" + args.toString());

        var lValue =  args[0];
        var pValue =  args[1];
        var indexId = args[2];

        grUI.args = args;

        $.Elec.dialogTemplate.setValue({head: "请求/延长授权认证", left:  {txt:"取消", color: "grey", clickCB:{func: function() {grUI.args = []; $.cache["dialog"].close();}}},
                                                                   right: {txt:"授权", color: "blue", clickCB:{func: grUI.delay_giveright, args:[grUI.args[2], "delay_1"]}}    });

        $.Elec.dialogTemplate.setItemsData([           
            {
                id: "select",
                type: "listbox", 
                placeholder: "请选择授权有效时间",
                value: lValue
            },
            {
                type: "password", 
                placeholder: "请输入密码",
                value: pValue
            }
        ]).show();

        EventUtil.addClickListener({id: "select", clk: function() {
                var pwd = $(".dialog_box input[type^='password']")[0].value;
                $.cache["dialog"].close();
                var data = {p1: "1天", p2: "3天", p3: "5天", p4: "7天", p5: "15天", p6: "30天"};
                list_show({data:data, title:"请选择授权有效时间", item_click_callback: function(id) {
                        grUI.args[0] = data[id];
                        grUI.args[1] = pwd;
                        grUI.apply_delay_giveright_btn_click(grUI.args);
                    }
                });
            }
        });  
    },

    delay_giveright: function(args) {
        grUI.args = [];
        var indexId = args[0];
        var type = args[1];

        // 授权人的密码为空
        var pwd = "";
        if(type == "delay_1") {
            pwd = $(".dialog_box input[type^='password']")[0].value;
        }

        var time = "";
        if(type != "cancel") {
            time = $("#select input[type^='text']")[0].value;
            time = time.substr(0, time.length - 1);
        }        

        var index = "";
        if(indexId != "") {
            index = (indexId+"").split("_")[1];         
        }
        else {
            // 根据工号查询
            var len = grRequest.noList.length;
            var curNo = document.getElementById("P_USER_NO").innerText;
            var index = "";
            for (var i = 0; i < len; i++) {
                if(grRequest.noList[i].SYS_USER_NO == curNo) {
                    index = i;
                    break;
                }
            }
        }

        var role = "";
        var txtRole = document.getElementById("txt_role").innerText;
        if(txtRole == grUI.roleList.p1) {
            role = "apply";
        }
        else if(txtRole == grUI.roleList.p2) {
            role = "launch";
        }

        var data = {};

        if(role == "apply") {
            data = grRequest.noList[index];
        }
        else if(role == "launch") {
            data = grRequest.grList[index];
        }

        grUI.optIndex = index;

        if(type == "cancel") {
            grRequest.data.SYS_USER_NO = data.SYS_USER_NO;
            grRequest.data.SYS_USER_NAME = data.SYS_USER_NAME;
        }
        else {
            grRequest.data.SYS_USER_NO = localStorage.user_name;
            grRequest.data.SYS_USER_NAME = sessionStorage.user_name_str;
        }

        if(index != "") { 
            if(type == "cancel") {
                grRequest.data.P_USER_NO = localStorage.user_name;
                grRequest.data.P_USER_NAME = sessionStorage.user_name_str;
            }
            else {
                grRequest.data.P_USER_NO = data.SYS_USER_NAME;
                grRequest.data.P_USER_NAME = data.USER_NAME;                 
            }       
            grRequest.data.P_DEPT_NO = data.DEPT_NO;
            grRequest.data.P_DEPT_NANME = data.DEPT_NAME;
            grRequest.data.P_EMP_NO = data.EMP_NO; 
            grRequest.data.ORG_NO = data.ORG_NO;
        }

        grRequest.data.P_USER_PASSWORD = pwd;
        grRequest.data.ACT_CODE = grUI.getActCode();
        grRequest.data.AUTHORIZE_TIME = time*24;
        grRequest.data.IMEI = PubFuns.getMyTid();
        
        $.cache["dialog"].close();

        if(type.indexOf("delay") != -1) {
            grRequest.launch("delay", role, grUI.launch_giveright_succ_cb);
        }
        else if(type == "cancel") {
            grRequest.launch("canel", role, grUI.cancel_giveright_succ_cb);
        }
    },

    /**
     * 取消授权的成功回调
     */
    cancel_giveright_succ_cb: function(data) {
        console.log("cancel_giveright_succ_cb:" + data);
        data = JSON.parse(data);
        PubFuns.removeLoadingDialog();

        if(data.PKG != undefined && data.PKG.PKG != undefined && data.PKG.PKG.RESULT != undefined) {
            data = data.PKG.PKG;
            PubFuns.dialog_alert(data.RESULT_TEXT);
            if(data.RESULT == "1") {
                var tempGrList = [];
                for (var i = 0; i < grRequest.grList.length; i++) {
                    if(grUI.optIndex != i) {
                        tempGrList.push(grRequest.grList[i]);
                    }
                }
                grRequest.grList = tempGrList;        
                grUI.set_op_info(grRequest.grList, true);
            }
        }
        else {
            PubFuns.dialog_alert("取消授权失败");    
        }        
    },

    /**
     * 授权或延长授权的成功回调
     */
    launch_giveright_succ_cb: function(data) {
        console.log("launch_giveright_succ_cb:" + data);
        data = JSON.parse(data);
        PubFuns.removeLoadingDialog();

        if(data.PKG != undefined && data.PKG.PKG != undefined && data.PKG.PKG.RESULT != undefined) {
            data = data.PKG.PKG;
            PubFuns.dialog_alert(data.RESULT_TEXT);
            if(data.RESULT == "1") {                
                // 重新设置时间
                var txtRole = document.getElementById("txt_role").innerHTML;
                if(txtRole == grUI.roleList.p1) {                    

                    grRequest.noList[grUI.optIndex].AUTHORIZE_BEGIN = data.AUTHORIZE_BEGIN;
                    grRequest.noList[grUI.optIndex].AUTHORIZE_END   = data.AUTHORIZE_END;
                    grRequest.noList[grUI.optIndex].ACT_CODE        = grUI.getActCode();
                    grRequest.noList[grUI.optIndex].AUTHORIZE_STATUS = "01";

                    document.getElementById("delayGiveright").style.display = "-webkit-box";
                    document.getElementById("P_USER_NAME").innerText     = grRequest.noList[grUI.optIndex].USER_NAME;
                    document.getElementById("P_USER_NO").innerText       = grRequest.noList[grUI.optIndex].SYS_USER_NAME;
                    document.getElementById("AUTHORIZE_BEGIN").innerText = grRequest.noList[grUI.optIndex].AUTHORIZE_BEGIN;
                    document.getElementById("AUTHORIZE_END").innerText   = grRequest.noList[grUI.optIndex].AUTHORIZE_END; 

                    giveRightInfo.update_database(grRequest.noList[grUI.optIndex], function() {
                        giveRightInfo.get_modelist();
                        grUI.modelList = giveRightInfo.timeList; 
                    });
                }
                else if(txtRole == grUI.roleList.p2) {
                    document.getElementById("op_starttime_" + grUI.optIndex).innerText = data.AUTHORIZE_BEGIN;
                    document.getElementById("op_endtime_" + grUI.optIndex).innerText = data.AUTHORIZE_END;
                    grRequest.grList[grUI.optIndex].AUTHORIZE_BEGIN = data.AUTHORIZE_BEGIN;
                    grRequest.grList[grUI.optIndex].AUTHORIZE_END = data.AUTHORIZE_END;
                    grRequest.noList[grUI.optIndex].AUTHORIZE_STATUS = "01";
                    giveRightInfo.update_database(grRequest.grList[grUI.optIndex], function() {
                        giveRightInfo.get_modelist();
                        grUI.modelList = giveRightInfo.modelList;
                    });
                }                
            } 
            return;          
        }
        PubFuns.dialog_alert("授权失败");        
    },

    getActCode: function() {
        var act_code = "";

        var value = document.getElementById("txt_model").innerHTML;
        var index = value.indexOf("(");
        if(index != -1) {
            value = value.substring(0, index);
        }
        for (var i = 0; i < grRequest.ACT_CODE.length; i++) {
            var tempCode = grRequest.ACT_CODE[i];
            if(tempCode.VALUE == value) {
                act_code = tempCode.KEY;
            }
        }
        return act_code;
    }
};

grUI.init();

navbarBack = function() {
    $("#dx-viewport-one").load("../Main/mainContent.html");
}

navbarSync = function() {
    giveRightInfo.select_all(function(data) {
        var txtRole = document.getElementById("txt_role").innerHTML;
        var txtModel = document.getElementById("txt_model").innerHTML;
        if(txtRole == grUI.roleList.p1) {
            grUI.modelList = giveRightInfo.timeList;
        }
        else if(txtRole == grUI.roleList.p2) {
            grUI.modelList = giveRightInfo.modelList;
        } 

        if(txtModel != grUI.modelList["p0"] && txtRole != grUI.modelList["p0"]) {
            grUI.select_action();
        }       
    }, true);
}