/**
 * Copy Right Information  : STATE GRID
 * author                  	: yuenhoawong
 * Comments                	: 联系人信息维护界面
 * Version                 	: 0.0.1
 * Modification history    	: 2014-04-28
 * Sr	Date        Modified By     Why & What is modified
 * 1.	2014-04-28  yuenhoa.wong    new file
 */


/*****************************************************************************************************
 * 详细信息的html需要动态添加
 *     所有9527代表编号，用于辨识用户点击按钮操作的是哪一个联系人详细信息
 * 字段要求：
 *     1.联系人姓名不可以全是数字、不可有全角字符、不可为空。
 *     2.固定电话必须是以“3或4位区号”+“-”+“8位电话号码”或者“3或4位区号”+“-”+“8位电话号码”+“-”+“分机号码1-4位”形式保存, 以中划线作为分隔符，其余全部为数字。
 *     3.移动电话只允许为11位长度全数字且参照运营商号码对前3位作校验。
 *     4.固定电话或移动电话两者必填一个。
 *****************************************************************************************************/

/**
 * 初始化页面
 */

var cmUI = {
    /** 联系类型 */
    CONTACT_MODE:   {"01": "电气联系人", "02": "帐务联系人",    "03": "停送电联系人", 
                     "04": "法人联系人", "05": "委托代理联系人", "06": "有序用电联系人"},
    /** 联系信息来源 */
    CONTACT_SOURCE: {"01": "业扩申请",   "02": "95598",      "03": "合同约定",    "04": "市场调查",
                     "05": "客户关系",   "06": "现场收集",     "07": "营业厅登记",   "08": "手机登记",
                     "09": "银行登记",   "10": "微信",        "11": "短信",       "99": "其他"},
    /** 联系优先级  */
    CONTACT_PRIO:   {"1": "高", "2": "中", "3": "低"},
    /** 性别 */
    GENDER:         {"01": "男", "02": "女"},
    /** 职务/职称  */
    TITLE:          {"001": "教授级高工",    "002": "高级工程师（高级计师）", "003": "工程师",
                     "004": "助理工程师",    "005": "技术员",             "006": "会计师",
                     "007": "经济师",       "101": "高级技师",            "102": "技师", 
                     "103": "高级工",       "104": "中级工",             "105": "初级工", 
                     "201": "一级注册计量师", "202": "二级注册计量师"},
    opId: "",

    baseIds: [  {ID:"CONS_NO",        TYPE:"value"},
		     	{ID:"CONS_NAME",      TYPE:"value"},
				{ID:"CONS_SORT_CODE", TYPE:"code"},
				{ID:"ELEC_TYPE_CODE", TYPE:"code"},
				{ID:"STATUS_CODE",    TYPE:"code"},
			    {ID:"VOLT_CODE",      TYPE:"code"},
				{ID:"CONTRACT_CAP",   TYPE:"value"},
				{ID:"ELEC_ADDR",      TYPE:"value"}],

    ids: [{ID:"CONTACT_NAME", TYPE:"value"}, {ID:"CONTACT_MODE", TYPE:"code"}, {ID:"GENDER", TYPE:"code"},
	      {ID:"POSTALCODE", TYPE:"value"}, {ID:"MOBILE", TYPE:"value"}, {ID:"DEPT_NO", TYPE:"value"},
		  {ID:"CONTACT_SOURCE", TYPE:"code"}, {ID:"TITLE", TYPE:"code"}, {ID:"HOMEPHONE", TYPE:"value"},
		  {ID:"OFFICE_TEL", TYPE:"value"}, {ID:"FAX_NO", TYPE:"value"}, {ID:"ADDR", TYPE:"value"},
		  {ID:"EMAIL", TYPE:"value"}, {ID:"FAMILY_ADDR", TYPE:"value"}, {ID:"INTEREST", TYPE:"value"},
		  {ID:"BIRTHDAY", TYPE:"value"}, {ID:"WORK", TYPE:"value"}, {ID:"CONTACT_REMARK", TYPE:"value"},
		  {ID:"CONTACT_PRIO", TYPE: "code"}],

	CONS_NO: "",       // 用户编号
	CONS_ID: "",       // 用户编号
	isCkecked: false,  // 是否核验过联系人身份信息
	amScroll: null,
    amScrDom: null,
    content: null,

	/**
	 * 初始化页面
	 */
	init : function(){
		/*隐藏标题栏增加按钮，更改标题栏标题*/
		util.moblie.navbar.title = "联系人信息维护";
        util.moblie.navbar.buttonList = ["back","menu"];// 可选参数：add back home
		
		navbarBack = this.btn_back_click;		
		
		cmUI.set_basic_info();		/*插入基本信息html+字段*/
		
		EventUtil.addClickListener({id:"cm_checkID", clk: cmUI.btn_checkID_click});
		
		$("#cm_addedit .inputBorder input").live("focus blur", function() {
			if(event.type == "focus") {
				cmUI.set_addedit_input_focus();
			}
			else {
				cmUI.set_addedit_input_blur();
			}
		});
		
		$(".search").elecSearch({
		    callback: function(obj) {
		        //alert(obj.selectobj.id + " : " + obj.selectobj.text + " : " + obj.searchText);
		        var txtNo = obj.searchText;	
		        if(txtNo == "") {
		        	PubFuns.dialog_alert("请填写" + obj.selectobj.text);
		        }	        
		        else {
		        	cmRequest.select_userinfo(obj.selectobj.id, txtNo, cmUI.select_userinfo_cb);
		        }
		    },
		    select: {
		    	list: [{id: 1, text: "用户编号"},{id: 2, text: "电表资产编号"}],
		    	callback: function(obj) {
		    		if(obj.selectobj.id == 2) {
		    		    fm_bluetooth_connect(function(value) {
                			$("input[type='search']").val(value);
                		});
		    		}
		    	}		    	
		    }
		});

		//$("input[type='search']").val('0107340254');
	},

	/**
	 * 设置用户的基本信息
	 * @param {int} type: 0--第一次设置  非0值--之后设置
	 */
	set_basic_info : function(data) {
		
		var cons_no = '';
		var cons_name = '';
		var cons_sort_code = '';
		var elec_type_code = '';
		var status_code = '';
		var volt_code = '';
		var contract_cap = '';
		var elec_addr = '';
		
		if(data != undefined && data != null) {
		    cons_no = data.CONS_NO;
            cons_name = data.CONS_NAME;
            cons_sort_code = data.CONS_SORT_CODE;
            elec_type_code = data.ELEC_TYPE_CODE;
            status_code = data.STATUS_CODE;
            volt_code = data.VOLT_CODE;
            contract_cap = data.CONTRACT_CAP;
            elec_addr = data.ELEC_ADDR;
		}
		if(Elec.getELeById('cm_basic_info').innerHTML == "") {		
		    Elec.getELeById('cm_basic_info').innerHTML = '<table><tr><td >用户编号</td><td id="CONS_NO">' + cons_no + '</td><td >用户名称</td><td id="CONS_NAME">' + cons_name  + '</td></tr>'
													   + '<tr><td>用户分类</td><td id="CONS_SORT_CODE" pcode="29011" val="' + cons_sort_code + '"></td><td >用电类别</td><td id="ELEC_TYPE_CODE" pcode="29001" val="' + elec_type_code + '"></td></tr>'
													   + '<tr><td>用户状态</td><td id="STATUS_CODE" pcode="29002" val="' + status_code + '"></td><td >供电电压</td><td id="VOLT_CODE" pcode="10005" val="' + volt_code + '"></td></tr>'
													   + '<tr><td>合同容量</td><td colspan=3 id="CONTRACT_CAP">' + contract_cap + '</td></tr>'
													   + '<tr><td>用电地址</td><td colspan=3 id="ELEC_ADDR">' + elec_addr + '</td></tr></table>';
		}
		else {
			var ids = cmUI.baseIds;
		    for(var i = 0; i < ids.length; i++) {
		    	var node = document.getElementById(ids[i].ID);
		    	if(data == undefined || data == null) {
		    	    node.innerText = "";
		    	}
		    	else if(node.hasAttribute("pcode")) {
		    		node.setAttribute("val", data[ids[i].ID]);
		    		var pcode = node.getAttribute("pcode");
		    		PubFuns.selectPCode({CODE_SORT_ID: pcode, VALUE: data[ids[i].ID]}, cmUI.select_pcode_cb, null);
		    	}
		    	else {
		    		if(ids[i].ID == "CONTRACT_CAP") {
		    			node.innerText = data[ids[i].ID] + "kVA";
		    		}
		    		else {
		    			node.innerText = data[ids[i].ID];
		    		}
		    	}		        
		    }
		    document.getElementById("cm_base").children[0].setAttribute("class", "box");
		}													
	},

	/**
	 * 查询PCODE码的回调函数
	 */
	select_pcode_cb: function(tx, results) {
		if(results.rows.length == 1) {
			var pcode = results.rows.item(0).CODE_SORT_ID;
			var value = results.rows.item(0).VALUE;
			var name = results.rows.item(0).NAME;

			var ids = cmUI.baseIds;
		    for(var i = 0; i < ids.length; i++) {
		    	var node = document.getElementById(ids[i].ID);
		    	if(node.hasAttribute("pcode")) {
		    		if(node.getAttribute("pcode") == pcode) {
		    			node.innerText = name;
		    			break;
		    		}
		    	}	        
		    }
		}
	},

	/**
	 * 插入联系人item项html
	 */
	set_contact_info : function(data) {
		
		var dis = (cmUI.isCkecked ? "display: -webkit-box;" : "display: none;");

		for(var i = 0; i < data.length; i++) {
			var tempId = data[i].CONS_ID + '_' + data[i].CONTACT_ID;
			if(Elec.getELeById('line_' + tempId) == undefined) {		
				var birth = data[i].BIRTHDAY;
				data[i].BIRTHDAY = birth.split(" ")[0]; 	
				Elec.getELeById('cm_contact_info').innerHTML += '<div class="line_grey" id="line_' + tempId + '"><div class="content"><div id="cm_contact_' + data[i].CONS_ID + '"><div class="message limiteWidth" style="height: 74px;"><table>'
														+ '<tr><td>联系人</td><td id="CONTACT_NAME_' + tempId + '">' + data[i].CONTACT_NAME +'</td><td >联系类型</td><td id="CONTACT_MODE_' + tempId + '">' + data[i].CONTACT_MODE + '</td></tr>'
														+ '<tr><td>移动电话</td><td id="MOBILE_' + tempId + '">' + data[i].MOBILE + '</td><td >联系优先级</td><td id="CONTACT_PRIO_' + tempId + '">' + data[i].CONTACT_PRIO + '</td></tr>'
														+ '<tr><td>性别</td><td id="GENDER_' + tempId + '">' + Elec.setUndefined(data[i].GENDER) + '</td><td >邮编</td><td id="POSTALCODE_' + tempId + '">' + data[i].POSTALCODE + '</td></tr>'
														+ '<tr><td>部门编号</td><td id="DEPT_NO_' + tempId + '">' + data[i].DEPT_NO + '</td><td >信息来源</td><td id="CONTACT_SOURCE_' + tempId + '">' + Elec.setUndefined(data[i].CONTACT_SOURCE) + '</td></tr>'
														+ '<tr><td>职务/职称</td><td colspan="3" id="TITLE_' + tempId + '">' + Elec.setUndefined(data[i].TITLE) + '</td></tr>'
														+ '<tr><td>住宅电话</td><td colspan="3" id="HOMEPHONE_' + tempId + '">' + data[i].HOMEPHONE + '</td></tr>'
														+ '<tr><td>办公电话</td><td colspan="3" id="OFFICE_TEL_' + tempId + '">' + data[i].OFFICE_TEL + '</td></tr>'
														+ '<tr><td>传真电话</td><td colspan="3" id="FAX_NO_' + tempId + '">' + data[i].FAX_NO + '</td></tr>'
														+ '<tr><td>电子邮箱</td><td colspan="3" id="EMAIL_' + tempId + '">' + data[i].EMAIL + '</td></tr>'
														+ '<tr><td>联系地址</td><td colspan="3" id="ADDR_' + tempId + '">' + data[i].ADDR + '</td></tr>'
														+ '<tr><td>家庭住址</td><td colspan="3" id="FAMILY_ADDR_' + tempId + '">' + data[i].FAMILY_ADDR + '</td></tr>'
														+ '<tr><td>兴趣爱好</td><td colspan="3" id="INTEREST_' + tempId + '">' + data[i].INTEREST + '</td></tr>'
														+ '<tr><td>出生日期</td><td colspan="3" id="BIRTHDAY_' + tempId + '">' + data[i].BIRTHDAY + '</td></tr>'
														+ '<tr><td>工作经历</td><td colspan="3" id="WORK_' + tempId + '">' + data[i].WORK + '</td></tr>'
														+ '<tr><td>联系备注</td><td colspan="3" id="CONTACT_REMARK_' + tempId + '">' + data[i].CONTACT_REMARK + '</td></tr></table></div>'
														+ '<div class="button" id="cm_btn_cls_' + data[i].CONS_ID + '"><div class="detail" id="cm_btn_seemoreless_' + data[i].CONS_ID + '_' + data[i].CONTACT_ID + '"><span>查看详细信息</span><div class="icon"></div></div>'
														+ '<div class="del" id="cm_btn_del_' + data[i].CONS_ID + '_' + data[i].CONTACT_ID + '" style="' + dis +'"><div class="icon"></div><span>删除</span></div>'
														+ '<div class="edit" id="cm_btn_edit_' + data[i].CONS_ID + '_' + data[i].CONTACT_ID + '" style="' + dis +'"><div class="icon"></div><span >编辑</span></div></div></div></div></div>';

				cmUI.getValueByCode('CONTACT_MODE_' + tempId, cmUI.CONTACT_MODE, data[i].CONTACT_MODE);
				cmUI.getValueByCode('CONTACT_SOURCE_' + tempId, cmUI.CONTACT_SOURCE, data[i].CONTACT_SOURCE);
				cmUI.getValueByCode('CONTACT_PRIO_' + tempId, cmUI.CONTACT_PRIO, data[i].CONTACT_PRIO);
				cmUI.getValueByCode('GENDER_' + tempId, cmUI.GENDER, data[i].GENDER);
				cmUI.getValueByCode('TITLE_' + tempId, cmUI.TITLE, data[i].TITLE);
			}
		}

		/*设置‘查看/收起更多信息’、‘编辑’、‘删除’按钮点击事件*/
		for(var i = 0; i < data.length; i++) {
			var tempId = data[i].CONS_ID + '_' + data[i].CONTACT_ID;
			if(Elec.getELeById('line_' + tempId) != undefined || Elec.getELeById('line_' + tempId) != null) {		
				var id_seemoreless = "cm_btn_seemoreless_" + data[i].CONS_ID + "_" + data[i].CONTACT_ID;
				var id_edit = "cm_btn_edit_" + data[i].CONS_ID + "_" + data[i].CONTACT_ID;
				var id_del = "cm_btn_del_" + data[i].CONS_ID + "_" + data[i].CONTACT_ID;
				EventUtil.addClickListener({id: id_seemoreless, clk: cmUI.btn_seemoreless_click, args: id_seemoreless});
				EventUtil.addClickListener({id: id_edit, clk: cmUI.btn_edit_click, args: id_edit});
				EventUtil.addClickListener({id: id_del, clk: cmUI.btn_makesure_del_click, args: id_del});
			}
		}
		
		document.getElementById("cm_base").children[1].setAttribute("class", "box");
		
		cmUI.amScrools("cm_contact_info_case");
	},
	
    amScrools : function(id) {
        if(cmUI.amScroll != null) {
            setTimeout(function(){
                cmUI.amScroll.refresh();
                //cmUI.amScroll.scrollToElement(cmUI.amScrDom, 0);
            }, 500);
            return;   
        }
        
        var h = document.body.clientHeight - document.getElementById("page_head").clientHeight - document.getElementById("cm_search").clientHeight - document.getElementById("cm_head").clientHeight - document.getElementById("cm_contact_info_head").clientHeight-45;
        document.getElementById(id).style.height = h + "px";
        
        cmUI.amScroll = new iScroll(id, {useTransition : true, hScrollbar : false, vScrollbar : false});
        
        window.onresize = function(){
        	var h = document.body.clientHeight - document.getElementById("page_head").clientHeight - document.getElementById("cm_search").clientHeight - document.getElementById("cm_head").clientHeight - document.getElementById("cm_contact_info_head").clientHeight - 45;
       		document.getElementById("cm_contact_info_case").style.height = h + "px";
       		cmUI.amScroll.refresh();
        } ;
    },
    
	getValueByCode: function(id, json, code) {
	    if(code == "null") {
	        document.getElementById(id).innerText = "";
	        return;
	    }
		for (node in json) {
			if(code == (node+"")) {
				document.getElementById(id).innerText = json[node+""];
			} 
		}
	},

	/**
	 * 核对身份按钮点击事件
	 */
	btn_checkID_click : function() {
		$.Elec.dialogTemplate.setValue({head: "身份证信息核对", left:  {txt:"通过核对", color: "blue", clickCB:{func: cmUI.btn_checkover_click}},
                                                                right: {txt:"取消核对", color: "grey", clickCB:{func: function(){$.cache["dialog"].close();}}} });
        
        $.Elec.dialogTemplate.setItemsData([
            {
                type: "singleKV",            
                data: {key: "证件号码", value: cmRequest.user_base_data.CERT_NO}
            },
            {
                type: "singleKV",            
                data: {key: "证件名称", value: cmRequest.user_base_data.CERT_NAME}
            },
            {
                type: "singleKV",            
                data: {key: "联系人", value: cmRequest.user_base_data.CONTACT_NAME}
            },
            {
                type: "singleKV",            
                data: {key: "邮编", value: cmRequest.user_base_data.POSTALCODE}
            },
            {
            	type: "singleKV",            
                data: {key: "固定电话", value: cmRequest.user_base_data.OFFICE_TEL}
            }, 
            {
                type: "singleKV",            
                data: {key: "通信地址", value: cmRequest.user_base_data.ADDR}
            },
            {
            	type: "singleKV",            
                data: {key: "移动电话", value: cmRequest.user_base_data.MOBILE}
            }
        ]).show();
	},

	/**
	 * 核对通过的点击事件
	 */
	btn_checkover_click: function() {
		$.cache["dialog"].close();
		cmUI.isCkecked = true;
		Elec.getELeById("text_check_id").innerText = "新增联系人";
		
		EventUtil.remveClickListener("cm_checkID", cmUI.btn_checkID_click);
		EventUtil.addClickListener({id: "cm_checkID", clk: cmUI.btn_add_click});
		
		$("#cm_contact_info div[id^='cm_btn_edit_']").css("display","-webkit-box");	
		$("#cm_contact_info div[id^='cm_btn_del_']").css("display","-webkit-box");
	},

	/**
	 * 标题栏返回按钮
	 */
	btn_back_click : function(){
		$("#dx-viewport-one").load("../Main/mainContent.html");
	},

	/**
	 * 新增和编辑页面的返回按钮点击事件
	 */
	btn_addedit_back_click : function() {
		cmUI.to_base_page();
		
		util.moblie.navbar.changeTitle("联系人信息维护");
		util.moblie.navbar.changeButton(["back","menu"]);
		navbarBack = cmUI.btn_back_click;
		
		EventUtil.remveClickListener("cm_addedit_btn_ok", cmUI.btn_add_done_click);
		EventUtil.remveClickListener("cm_addedit_btn_ok", cmUI.btn_edit_done_click);

		Elec.getELeById('cm_contact_info').innerHTML = "";
		cmUI.set_contact_info(cmRequest.contact_datalist);
	},
	/**
	 * 标题栏菜单按钮
	 */
	btn_menu_click : function(){
		alert('btn_menu_click');
	},
	/**
	 * 查询按钮点击事件
	 */
	btn_search_click : function(){
		
	},
	/**
	 * 查看更多按钮点击事件
	 */
	btn_seemoreless_click : function(id){

		var list = $("#" + id).parent().prev();
		var min_height = $("tr",list).height() * 2 + 12;
		var max_height = $("table",list).height();
		var status = $("#" + id).hasClass("open") ? 1 : 0 ;
		$("#" + id).toggleClass("open");
		var height = !!status ? min_height : max_height;
		list.animate({height:height},250,function(){
			$("div",$("#" + id)).toggleClass("icon_up");
			$("span",$("#" + id)).html(status == 1 ? "查看详细信息" : "收起详细信息");
		});	
		
		setTimeout(function() {
            cmUI.amScroll.refresh();
        }, 500);
	},
	/**
	 * 修改按钮点击事件
	 */
	btn_edit_click : function(id) {
		
		cmUI.to_addedit_page();

		util.moblie.navbar.changeTitle("联系人信息维护-编辑");       
		util.moblie.navbar.changeButton(["back","menu"]);
		navbarBack = cmUI.btn_addedit_back_click;

		EventUtil.addClickListener({id: "cm_addedit_btn_ok", clk: cmUI.btn_edit_done_click});

		cmUI.opId = id;	
		var data = cmRequest.contact_datalist;
		for(var i = 0; i < data.length; i++) {
			var temp = 'cm_btn_edit_' + data[i].CONS_ID + '_' + data[i].CONTACT_ID;
			if(id == temp) {
				console.log("data[i]=" + JSON.stringify(data[i]));
				for (var j = 0; j < cmUI.ids.length; j++) {
					var node = document.getElementById(cmUI.ids[j].ID);
					if(cmUI.ids[j].TYPE == "code") {
						node.setAttribute("val", data[i][cmUI.ids[j].ID]);
					}
					else {
						if(node.tagName == "INPUT") {
							node.value = data[i][cmUI.ids[j].ID];
						}
						else {
							node.innerText = data[i][cmUI.ids[j].ID];
						}
					}
				}
				// 转换PCODE码
				cmUI.getValueByCode('CONTACT_MODE', cmUI.CONTACT_MODE, data[i].CONTACT_MODE);
				cmUI.getValueByCode('CONTACT_SOURCE', cmUI.CONTACT_SOURCE, data[i].CONTACT_SOURCE);
				cmUI.getValueByCode('CONTACT_PRIO', cmUI.CONTACT_PRIO, data[i].CONTACT_PRIO);
				cmUI.getValueByCode('GENDER', cmUI.GENDER, data[i].GENDER);
				cmUI.getValueByCode('TITLE', cmUI.TITLE, data[i].TITLE);
				break;
			}
		}
	},
	
	btn_makesure_del_click: function(id) {
	    $.Elec.dialogTemplate.setValue({head: "温馨提示", left:  {txt:"确定", color: "blue", clickCB:{func: cmUI.btn_del_click, args:[id]}},
                                                        right: {txt:"取消", color: "grey", clickCB:{func: function(){$.cache["dialog"].close();}}} });
        
        $.Elec.dialogTemplate.setItemsData([
            {
                type: "text",            
                data: "是否确定删除此联系人？"
            }
        ]).show();
	},

	/**
	 * 删除按钮点击事件
	 */
	btn_del_click: function(args) {	
	    cmUI.opId = args[0];	
		var data = cmRequest.contact_datalist;
		for(var i = 0; i < data.length; i++) {
			var temp = 'cm_btn_del_' + data[i].CONS_ID + '_' + data[i].CONTACT_ID;
			if(args[0] == temp) {
				cmRequest.delete_contact(data[i].CONTACT_ID, data[i].CONS_ID, cmUI.btn_del_click_cb);
				break;
			}
		}		
	},

	/**
	 * 查询基本信息的成功回调
	 */
	select_userinfo_cb: function(data) {
		console.log("select_userinfo_cb:" + data);
		data = JSON.parse(data);
		PubFuns.removeLoadingDialog();
		if(data.PKG.PKG != undefined) {
			data = data.PKG.PKG.CONSINFO[0];
			if(data.FLAG != undefined) {
			    cmUI.set_basic_info();
			    PubFuns.dialog_alert(data.ERR_MSG);
			    // 清空联系人列表
			    Elec.getELeById('cm_contact_info').innerHTML = "";
			    document.getElementById("cm_base").children[1].setAttribute("class", "box hidden");
			    cmRequest.contact_datalist = [];
			    document.getElementById("cm_checkID").setAttribute("class", "simple hidden");
			}
			else {
			    cmUI.CONS_NO = data.CONS_NO;
                cmUI.CONS_ID = data.CONS_ID;
                for(node in data) {
                    cmRequest.user_base_data[node] = data[node];
                }
                document.getElementById("cm_checkID").setAttribute("class", "simple");
                cmUI.set_basic_info(data);
                if(cmUI.CONS_NO != "") {                    
                    cmRequest.select_contact(cmUI.CONS_NO, cmUI.select_contact_cb);
                }   
			}				    
		}
	},

	/**
	 * 查询联系人信息的成功回调
	 */
	select_contact_cb: function(data) {
		console.log("select_contact_cb:" + data);
		PubFuns.removeLoadingDialog();
		data = JSON.parse(data);
		if(data.PKG != undefined && data.PKG.PKG != undefined && data.PKG.PKG.DATA != undefined) {
		    rst = data.PKG.PKG.DATA;
            cmRequest.contact_datalist = rst;
            Elec.getELeById('cm_contact_info').innerHTML = "";
            cmUI.set_contact_info(cmRequest.contact_datalist);
		}
		else {
		    cmRequest.contact_datalist = [];
            // TODO: 清空联系人列表
            Elec.getELeById('cm_contact_info').innerHTML = "";
		}		
	},

	btn_del_click_cb: function(data) {
		PubFuns.removeLoadingDialog();
		console.log("btn_del_click_cb:" + data);
		data = JSON.parse(data);
		if(data.PKG.PKG.FLAG == "1") {
			PubFuns.dialog_alert("删除成功");
			var id = cmUI.opId;
			var data = cmRequest.contact_datalist;
			var newDataList = [];
			var j = 0;
			for(var i = 0; i < data.length; i++) {
				var temp = 'cm_btn_del_' + data[i].CONS_ID + '_' + data[i].CONTACT_ID;
				if(id != temp) {
					newDataList[j] = data[i];
					j++;
				}
			}
			cmRequest.contact_datalist = newDataList;
			var newId = id.replace("cm_btn_del", "line");
			$("#cm_contact_info div").remove("#" + newId);
			/*modified by yuenhoa.wong 20141105 : 
			 * 删除item后需要刷新iscroll
			 * 避免删除的item大于展示区域时删除后其它item项在展示区外无法操作*/
			cmUI.amScroll.refresh();
			if(cmRequest.contact_datalist.length == 0) {
				document.getElementById("cm_base").children[1].setAttribute("class", "box hidden");
			}
		}
		else {
			PubFuns.dialog_alert("删除失败");
		}
	},

	btn_add_done_click_cb: function(data) {
		PubFuns.removeLoadingDialog();
		console.log("btn_add_done_click_cb:" + data);
		data = JSON.parse(data);
		if(data.PKG.PKG.FLAG == 1) {
			PubFuns.dialog_alert("新增成功");
			cmRequest.contact_data.CONTACT_ID = data.PKG.PKG.CONTACT_ID;
			cmRequest.contact_datalist.push(cmRequest.contact_data);
		}
		else {
			PubFuns.dialog_alert(data.PKG.PKG.ERR_MSG);
		}
	},

	btn_edit_done_click_cb: function(data) {
		PubFuns.removeLoadingDialog();
		console.log("btn_edit_done_click_cb:" + data);
		data = JSON.parse(data);
		if(data.PKG.PKG.FLAG == 1) {
			// 修改联系人列表中的数据
			var data = cmRequest.contact_datalist;
			var newDataList = [];
			for(var i = 0; i < data.length; i++) {
				var temp = 'cm_btn_edit_' + data[i].CONS_ID + '_' + data[i].CONTACT_ID;
				if(cmUI.opId != temp) {
					newDataList[i] = data[i];
				}
				else {
					newDataList[i] = cmRequest.contact_data;
				}
			}
			cmRequest.contact_datalist = newDataList;

			PubFuns.dialog_alert("保存成功");
		}
		else {
			PubFuns.dialog_alert(data.PKG.PKG.ERR_MSG);
		}
	},

	/**
	 * 新增按钮点击事件
	 */
	btn_add_click : function() {
		
		cmUI.to_addedit_page();
		
		util.moblie.navbar.changeTitle("联系人信息维护-新增");
		util.moblie.navbar.changeButton(["back","menu"]);
		navbarBack = cmUI.btn_addedit_back_click;

		// 清空页面
		var len = cmUI.ids.length;
		for (var i = 0; i < len; i++) {
			var node = document.getElementById(cmUI.ids[i].ID);
			if(node.tagName == "INPUT") {
				node.value = "";
			}
			else {
				node.innerText = "";
			}
			if(node.hasAttribute("val")) {
				node.setAttribute("val", "");
			}
		}
		
		EventUtil.addClickListener({id: "cm_addedit_btn_ok", clk: cmUI.btn_add_done_click});		
	},
	/**
	 * 转到展示页面
	 */
	to_base_page:function(){
		Elec.getELeById("cm_search").setAttribute("class", "search normal show");
		Elec.getELeById("cm_base").setAttribute("class", "content show");
		Elec.getELeById("cm_addedit").setAttribute("class", "content hidden");
		Elec.getELeById("cm_floor").setAttribute("class", "floor");
		Elec.getELeById("cm_addedit_btn").setAttribute("class", "button hidden");
		
		if(cmUI.content != null) {
		    cmUI.content.destroy();
		}
	},
	/**
	 * 转到新增和编辑页面
	 */
	to_addedit_page : function(){
		Elec.getELeById("cm_search").setAttribute("class", "search normal hidden");
		Elec.getELeById("cm_base").setAttribute("class", "content hidden");
		Elec.getELeById("cm_addedit").setAttribute("class", "content show");
		Elec.getELeById("cm_floor").setAttribute("class", "footerButton show");
		Elec.getELeById("cm_addedit_btn").setAttribute("class", "button show");

		cmUI.addEditPageEvent();

		//解决原生滚动条造成动画错位问题
		if(Elec.setUndefined(cmUI.content) != "") {
			cmUI.content.destroy();
			cmUI.content = null;
		}
		if(cmUI.content == null) {
            cmUI.content = new iScroll("cm_addedit", {
                    bounce:false, 
                    useTransition:true, 
                    vScrollbar: false,
                    onBeforeScrollStart : function(e) {
                        var target = e.target;
                        while(target.nodeType != 1)
                        target = target.parentNode;
                        if(target.tagName != 'SELECT' && target.tagName != 'INPUT' && target.tagName != 'TEXTAREA')
                            e.preventDefault();
                    }
                }
            );
            
    		//解决在虚拟键盘出现时，滚动不全以及输入框不出现在视野的问题
    		var dom;
    		window.onclick = function(e){
    			dom = e.target;
    		};
    		window.onresize = function(){
    			setTimeout(function(){
    				if(cmUI.content){
    					cmUI.content.refresh();
    					cmUI.content.scrollToElement(dom, 300);
    				}
    			},500)
    		};
		}
	},

	/**
	 * 修改完成按钮点击事件
	 */
	btn_edit_done_click : function() {
		if(!cmUI.validate()) {
			return;
		}
		var data = cmRequest.contact_datalist;
		console.log("data:" + JSON.stringify(data));
		for(var i = 0; i < data.length; i++) {
			var temp = 'cm_btn_edit_' + data[i].CONS_ID + '_' + data[i].CONTACT_ID;
			if(cmUI.opId == temp) {
				cmRequest.contact_data = JSON.parse(JSON.stringify(data[i]));
				cmUI.savePageValue(cmRequest.contact_data); 		
				cmRequest.contact_data.CONS_NO = cmUI.CONS_NO;
				cmRequest.contact_data.CONS_ID = cmUI.CONS_ID;
				break;
			}
		}

		// 验证必填选项
		cmRequest.updateorinsert_contact(cmUI.btn_edit_done_click_cb);
	},

	/**
	 * 新增完成按钮点击事件
	 */
	btn_add_done_click : function() {
		if(!cmUI.validate()) {
			return;
		}
		cmRequest.contact_data = {};
		var newData = cmRequest.contact_data;
		cmUI.savePageValue(newData);
		newData.CONS_ID = cmUI.CONS_ID;
		newData.CONS_NO = cmUI.CONS_NO;
		newData.CONTACT_ID = "";
		cmRequest.updateorinsert_contact(cmUI.btn_add_done_click_cb);
	},

	savePageValue: function(data) {
		for (var j = 0; j < cmUI.ids.length; j++) {
			var node = Elec.getELeById(cmUI.ids[j].ID);
			if(cmUI.ids[j].TYPE == "code") {
				data[cmUI.ids[j].ID] = node.getAttribute("val");
			}
			else {
				if(node.tagName == "INPUT") {
					data[cmUI.ids[j].ID] = node.value;
				}
				else {
					data[cmUI.ids[j].ID] = node.innerText;
				}
			}
		}
	},

	validate: function() {
		// 1.联系人姓名不可以全是数字、不可有全角字符、不可为空。联系类型不能为空，邮编为6位数字，联系优先级不能为空。
		var tipStr = "";
		var CONTACT_NAME = document.getElementById("CONTACT_NAME").value;
		if(CONTACT_NAME == "") {
			tipStr = "联系人姓名不能为空";
		}
		else if(PubFuns.isNum(CONTACT_NAME)) {
			tipStr = "联系人姓名不可以全是数字";
		}
		if(tipStr != "") {
			PubFuns.dialog_alert(tipStr);
			return false;
		}
		
		var CONTACT_MODE = document.getElementById("CONTACT_MODE").innerText;
		if(CONTACT_MODE == "") {
			tipStr = "联系类型不能为空";
		}
		if(tipStr != "") {
			PubFuns.dialog_alert(tipStr);
			return false;
		}

		var CONTACT_PRIO = document.getElementById("CONTACT_PRIO").innerText;
		if(CONTACT_PRIO == "") {
			tipStr = "联系优先级不能为空";
		}
		if(tipStr != "") {
			PubFuns.dialog_alert(tipStr);
			return false;
		}

		var POSTALCODE = document.getElementById("POSTALCODE").value;
		if(POSTALCODE.length == "") {
			tipStr = "邮编不能为空";
		}
		else if(POSTALCODE.length != 6 || !PubFuns.isNum(POSTALCODE)) {
			tipStr = "邮编为6位数字";
		}
		if(tipStr != "") {
			PubFuns.dialog_alert(tipStr);
			return false;
		}

		// 2.固定电话必须是以“3或4位区号”+“-”+“8位电话号码”或者“3或4位区号”+“-”+“8位电话号码”+“-”+“分机号码1-4位”形式保存, 以中划线作为分隔符，其余全部为数字。
		// 3.移动电话只允许为11位长度全数字且参照运营商号码对前3位作校验。
		// 4.固定电话或移动电话两者必填一个。
		var MOBILE = document.getElementById("MOBILE").value;
		var HOMEPHONE = document.getElementById("HOMEPHONE").value;
		var OFFICE_TEL = document.getElementById("OFFICE_TEL").value;
		
		if(MOBILE == "" && OFFICE_TEL == "") {
			tipStr = "办公电话或移动电话两者必填一个";
			PubFuns.dialog_alert(tipStr);
			return false;
		}
		else {
			
			if(!dataValidate.valiMobile("MOBILE")) return false;
			if(!dataValidate.valiOffice("HOMEPHONE","住宅电话")) return false;
			if(!dataValidate.valiOffice("OFFICE_TEL","办公电话")) return false;
		}

		return true;
	},

	initSearch: function(){
		var selectObj = [
		  {
		    id:1,
		    title:"用户编号"
		  },
		  {
		    id:2,
		    title:"用户资产编号"
		  }
		]

		$.Elec.select($(".select"),selectObj,function(obj,id){
		});
	},
	
	set_addedit_input_focus : function(){
		$(this).parent().parent().addClass("inputBorderFocus");
	},
	set_addedit_input_blur : function(){
		$(this).parent().parent().removeClass("inputBorderFocus");
	},
	set_addedit_select_focus : function(){
		$(this).parent().parent().addClass("selectBorderFocus");
	},
	set_addedit_select_blur : function(){
		$(this).parent().parent().removeClass("selectBorderFocus");
	},

	addEditPageEvent: function() {
		console.log("addEditPageEvent");
		// 出生日期
		document.getElementById("BIRTHDAY_LI").onclick = function() {
			var value = document.getElementById("BIRTHDAY").innerText;			
			dateTimePicker({"date":value, "type":"1"}, function(res) {
				if(res != "" && res != "null") {
					document.getElementById("BIRTHDAY").innerText = res;
				}
			});
		};

		// 联系人类型
		document.getElementById("CONTACT_MODE_LI").onclick = function() {
			list_show({
			    data: cmUI.CONTACT_MODE,
			    title:"请选择联系人类型", 
			    item_click_callback: function(id) {
			    	document.getElementById("CONTACT_MODE").innerText = cmUI.CONTACT_MODE[id];
			    	document.getElementById("CONTACT_MODE").setAttribute("val", id);
				},
			    bgCallback: function() {$.cache["dialog"].close();},
			    bgColor: "white"
			});
		};
		// 性别
		document.getElementById("GENDER_LI").onclick = function() {
			list_show({
			    data: cmUI.GENDER,
			    title:"请选择性别", 
			    item_click_callback: function(id) {
			    	document.getElementById("GENDER").innerText = cmUI.GENDER[id]; 
			    	document.getElementById("GENDER").setAttribute("val", id); 
			    },
			    bgCallback: function() {$.cache["dialog"].close();},
			    bgColor: "white"
			});
		};
		// 联系优先级
		document.getElementById("CONTACT_PRIO_LI").onclick = function() {
			list_show({
			    data: cmUI.CONTACT_PRIO,
			    title:"请选择联系优先级", 
			    item_click_callback: function(id) {
			    	document.getElementById("CONTACT_PRIO").innerText = cmUI.CONTACT_PRIO[id];
			    	document.getElementById("CONTACT_PRIO").setAttribute("val", id); 
			    },
			    bgCallback: function() {$.cache["dialog"].close();},
			    bgColor: "white"
			});
		};
		// 信息来源
		document.getElementById("CONTACT_SOURCE_LI").onclick = function() {
			list_show({
			    data: cmUI.CONTACT_SOURCE,
			    title:"请选择信息来源", 
			    item_click_callback: function(id) {
			    	document.getElementById("CONTACT_SOURCE").innerText = cmUI.CONTACT_SOURCE[id];
			    	document.getElementById("CONTACT_SOURCE").setAttribute("val", id); 
			    },
			    bgCallback: function() {$.cache["dialog"].close();},
			    bgColor: "white"
			});
		};
		// 职务/职称
		document.getElementById("TITLE_LI").onclick = function() {
			list_show({
			    data: cmUI.TITLE,
			    title:"请选择职务/职称", 
			    item_click_callback: function(id) {
			    	document.getElementById("TITLE").innerText = cmUI.TITLE[id];
			    	document.getElementById("TITLE").setAttribute("val", id); 
			    },
			    bgCallback: function() {$.cache["dialog"].close();},
			    bgColor: "white"
			});
		};
	}	
}

cmUI.init();
cmUI.initSearch();
