/**
 * Copy Right Information  : STATE GRID
 * author                  	: yuenhoawong
 * Comments                	: 通过网络调用营销接口，如：新增、删除、修改联系人信息等。
 * Version                 	: 0.0.1
 * Modification history    	: 2014-04-28
 * Sr	Date        Modified By     Why & What is modified
 * 1.	2014-04-28  yuenhoa.wong    new file
 */

var cmRequest = {

	contact_datalist: [],
    
	contact_data : {	
		/** 必填选项 */    	    
		CONS_ID: '',		    // 用户id
		CONTACT_MODE: '',       // 联系类型
		CONTACT_SOURCE: '',     // 联系信息来源
		CONTACT_PRIO: '',       // 联系优先级
		CONTACT_NAME: '',       // 联系人
		OFFICE_TEL: '',         // 办公电话		
		MOBILE: '',             // 移动电话		
		ADDR: '',               // 联系地址
		POSTALCODE: '',         // 邮编
		/** 可不填选项 */
		CONTACT_ID: '',         // 联系人信息标识    
	    GENDER: '',             // 性别
        DEPT_NO: '',            // 部门编号
        TITLE: '',              // 职务/职称
        HOMEPHONE: '',          // 住宅电话
        FAX_NO: '',             // 传真号码
        EMAIL: '',              // 电子信箱
        FAMILY_ADDR: '',        // 家庭住址
        INTEREST: '',           // 兴趣爱好
        BIRTHDAY: '',           // 出生日期
        WORK: '',               // 工作经历
        CONTACT_REMARK: ''      // 联系备注 
	},
	
	user_base_data: {
	    CONS_NO            : "", // 用户编号
	    CONS_NAME          : "", // 用户名称
	    CONS_SORT_CODE     : "", // 用户分类
	    ELEC_TYPE_CODE     : "", // 用电类别
	    STATUS_CODE        : "", // 用户状态
	    VOLT_CODE          : "", // 供电电压
	    CONTRACT_CAP       : "", // 合同容量
	    ELEC_ADDR          : "", // 用电地址
	    /** 身份证验证信息 */
	    CERT_NO	           : "", // 证件号码
		CERT_NAME	       : "", // 证件名称
		CONTACT_NAME	   : "", // 联系人
		POSTALCODE	       : "", // 邮编
		OFFICE_TEL	       : "", // 固定电话
		ADDR	           : "", // 通信地址
		MOBILE	           : ""  // 移动电话
	},

	
	select_userinfo: function(type, id, successCB) {
		PubFuns.addLoadingDialog();
		file_maint_req.select_user_base_info(type, id, successCB, cmRequest.fail_callback);		
	},

	select_contact : function(cons_no, successCB) {
		PubFuns.addLoadingDialog();
		file_maint_req.linkman_select_req(cons_no, successCB, cmRequest.fail_callback);
	},

	updateorinsert_contact: function(successCB) {
		PubFuns.addLoadingDialog();			
		file_maint_req.linkman_saveorupdate_req(successCB, cmRequest.fail_callback, cmRequest.contact_data);
	},

	delete_contact : function(contact_id, cons_id, succCB) {
		PubFuns.addLoadingDialog();
		file_maint_req.linkman_delete_req(contact_id, cons_id, succCB, cmRequest.fail_callback);
	},
	
	fail_callback: function(msg) {
		PubFuns.removeLoadingDialog();
		PubFuns.dialog_alert(msg);
	}
}
