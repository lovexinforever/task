/**
 * Copy Right Information   : STATE GRID
 * author                  	: Wang.yuxing
 * Comments                	: 页面右侧菜单栏相关效果
 * Version                 	: 0.0.1
 * Modification history    	: 2014-08-04
 * Sr	Date        Modified By     Why & What is modified
 * 1.	2014-08-04  Wang.yuxing     new file
 */
/**
 * 1. 此插件依赖jQuer.js、elec.mobile-1.0.js
 * 2. 调用方式：(在原有html结构的基础上)
 * $("#menu").rightToolBar();
 */
!function($){
	$.fn.extend({
		rightToolBar:function(){
			var t = $(this),
				id = t.attr("id"),
				toolbar = $(".toolbar")
				left = $(".left",toolbar),
				view = $(".viewContent"),
				flag = true,
				ani_callback = function(){
					setTimeout(function(){
						toolbar.css("z-index","2");
						},500);
					};
			EventUtil.remveClickListener(id);
			EventUtil.remveClickListener(left[0]);
			EventUtil.addClickListener({
		        id:id,
		        clk:function(arg){
		        	if(flag){
		        		flag = false;
		        		view.toggleClass(function(){
		                    if($(this).hasClass("rightBarShow")){
		                    	ani_callback();
		                        return "rightBarHide";
		                    }
		                    else{
								ani_callback();
		                        return "rightBarShow";
		                    }
                		});
		        	}
		        	setTimeout(function(){
		        		flag = true;
		        	},500)
		            
		        },
		        useTouch:false
		    });
			EventUtil.addClickListener({
				id:left[0],
				clk:function(arg){
					view.addClass("rightBarHide");
					toolbar.css("z-index","1");
				},
				useTouch:false
			})
		return t;
		}
	})
}(jQuery);