/**
 * Copy Right Information  : STATE GRID
 * author                  	: zhangtianchang
 * Comments                	: 配置信息本地化文件存储
 * Version                 	: 0.0.1
 * Modification history    	: 2014-05-04
 * Sr	Date        Modified By     Why & What is modified
 * 1.	2014-05-04  zhangtianchang    new file
 */

var PreferencePlugin = function() {

};

PreferencePlugin.prototype.put = function(filename, argument, successCallback,
		errorCallback) {
	return PhoneGap.exec(successCallback, errorCallback, 'PreferencePlugin',
			"put", [ filename, argument ]);
};

PreferencePlugin.prototype.get = function(filename, argument, successCallback,
		errorCallback) {
	return PhoneGap.exec(successCallback, errorCallback, 'PreferencePlugin',
			"get", [ filename, argument ]);
};

PreferencePlugin.prototype.clear = function(filename, argument,
		successCallback, errorCallback) {
	return PhoneGap.exec(successCallback, errorCallback, 'PreferencePlugin',
			"clear", [ filename, argument ]);
};

/**
 * 实例化插件
 */
cordova.addConstructor(function() {
	cordova.addPlugin("PreferencePlugin", new PreferencePlugin());
});

/**
 * 对插件的方法进行接口封装
 */
var Sharedpreference = {
	put : function(filename, argument, successCallback, errorCallback) {
		window.plugins.PreferencePlugin.put(filename, argument,
				successCallback, errorCallback);
	},
	get : function get(filename, argument, successCallback, errorCallback) {
		window.plugins.PreferencePlugin.get(filename, argument,
				successCallback, errorCallback);
	},
	clear : function(filename, successCallback, errorCallback) {
		window.plugins.PreferencePlugin.clear(filename, argument,
				successCallback, errorCallback);
	}
};

/**
 * 以下为接口使用说明及使用demmo
 */

/**
 * ***************** 接口:Sharedpreference.put ******************
 * 接口:Sharedpreference.put(<filename>,<argument>, <successCallback>,<errorCallback>)
 * 参数：filename 欲存数据的文件名 argument 存入数据的键值对数组
 * 格式：[{"k":"BluetoothMac","v":"08:09:e9:a1:d4:12"},{{"k":"ClearRate","v":"15"}]
 * 其中k 表示key，v表示value
 *
 * 返回值:successCallback 成功回调 errorCallback 失败回调
 *
 * DEMO：
 * Sharedpreference.put("filemaint",[{"k":"BluetoothMac","v":"08:09:e9:a1:d4:12"},{{"k":"ClearRate","v":"15"}],
 * function(succ,res) {
 * 		 alert("succ=" + succ);
 *
 * }, function(err){
 * 		 alert("err"+err);
 * } );
 *
 */

/**
 * ****************** 接口:Sharedpreference.get ******************
 * 接口:Sharedpreference.get(<filename>,<argument>, <successCallback>,<errorCallback>)
 * 参数:filename 欲存数据的文件名 argument 存入数据的键值对数组
 * 格式：[{"k":"BluetoothMac","v":"08:09:e9:a1:d4:12"},{{"k":"ClearRate","v":"15"}]
 * 其中k 表示欲记录的key，v表示欲记录的value
 *
 * 返回值：successCallback 成功回调 errorCallback 失败回调
 *
 * DEMO：
 * Sharedpreference.get("filemaint",["BluetoothMac","ClearRate"],
 * function(succ,res) {
 * 		alert("BluetoothMac=" +
 *	 	succ.BluetoothMac+"ClearRate="+succ.ClearRate);
 * },
 * function(err){
 * 		alert("err"+err);
 * } );
 *
 */

/**
 * *********************** 接口:clear **************************
 * 接口:Sharedpreference.clear(<filename>,<successCallback>,<errorCallback>)
 * 参数：filename 欲存数据的文件名
 *
 * 返回值：successCallback 成功回调 errorCallback 失败回调
 *
 * DEMO：
 * Sharedpreference.clear(
 * function(succ,res) {
 * 		 alert("succ=" + succ);
 * }, function(err){
 * 		alert("err"+err);
 *
 * } );
 *
 */
