var ae = {
	city_kv_data:[{k:'32401',v:	'南京市'},
					{k:'32402',v:'无锡市'},
					{k:'32403',v:'徐州市'},
					{k:'32404',v:'常州市'},
					{k:'32405',v:'苏州市'},
					{k:'32406',v:'南通市'},
					{k:'32407',v:'连云港市'},
					{k:'32408',v:'淮安市'},
					{k:'32409',v:'盐城市'},
					{k:'32410',v:'扬州市'},
					{k:'32411',v:'镇江市'},
					{k:'32412',v:'泰州市'},
					{k:'32413',v:'宿迁市'}],
	loadingNode:null,
	/*city:'',
	area:'',
	detail:'',
	area_id:'',*/
	
	more_callback:null,
	app_no:null,
	reqJson:null,
	data_count:{street:0,road:0,estate:0,village:0},
	data_more:{street:true,road:true,estate:true,village:true},
	data_choice:{street_code:null,road_code:null,estate_code:null,village_code:null,street_name:null,road_name:null,estate_name:null,village_name:null,URBAN_RURAL_FLAG:null,elec_addr:'-1'},
	data_street:null,		/*请求到的街道/乡镇数据*/
	data_road:null,			/*请求到的道路数据*/
	data_estate:null,		/*请求到的小区数据*/
	data_village:null,		/*请求到的居委会/村数据*/
	focus_id:'',
	sucess_cb:null,
	fali_cb:null,
	req_dataSign:null,
	show : function(appNo,sucessCB){
		
		ae.loadingNode = $.Elec.loading({
		 	text:"正在加载数据，请稍后。",
		    icon:"pic_loading",
		    time:1000*60*2,
		    timeCallback:function(){
		    	ae.loadingNode.close();
		    } 
		});
		ae.data_choice={street_code:null,road_code:null,estate_code:null,village_code:null,street_name:null,road_name:null,estate_name:null,village_name:null,URBAN_RURAL_FLAG:null,elec_addr:'-1'};	
		if(ae.app_no != appNo){
			ae.reqJson = null;
			ae.data_count={street:0,road:0,estate:0,village:0};
			ae.data_more={street:true,road:true,estate:true,village:true};
			ae.data_street=null;
			ae.data_road=null;
			ae.data_estate=null;
			ae.data_village=null;
			ae.focus_id='';
			ae.app_no = appNo;
		}
		ae.sucess_cb = sucessCB;
		ae.get_local_data();
		
		//ae.data_count = {street:0,road:0,estate:0,village:0};
		//ae.get_local_data();
		//ae.addrEdit_base_dialog();
	},
	get_local_data : function(){
		var sqlStr = 'SELECT URBAN_RURAL_FLAG,'
						 //+ 'CITY_CODE as city_code,'
						 + 'CONS_SORT_CODE AS cons_sort_code,'
						 + 'ORG_NO AS org_no,'
						 + 'COUNTY_CODE as county_code,'
						 + '(select NAME from P_CODE where CODE_SORT_ID = "10002" and VALUE = county_code) AS county_name,'
						 + 'STREET_CODE as street_code,'
						 + 'VILLAGE_CODE as village_code,'
						 + 'ROAD_CODE as road_code,'
						 + 'COMMUNITY_CODE as estate_code,'
						 + 'ELEC_ADDR as elec_addr '
						 + 'FROM YK_S_APP WHERE APP_NO = "' + ae.app_no +'"';
		
		db_execut_oneSQL("dawh.db",sqlStr,[],
			function(a,b){
				var tmpList = [];
				if(b.rows.length > 0) {
					for(var i = 0; i < b.rows.length; i++) {
						var item = b.rows.item(i);
						tmpList.push(item);
					}
					ae.data_choice = tmpList[0];
					//for(o in ae.data_choice){alert('111 -- ' + o + ' : ' + ae.data_choice[o]);}
				}
				for(var i = 0; i< ae.city_kv_data.length; i++){
					if(ae.data_choice.org_no.substr(0,5) == ae.city_kv_data[i].k){
						ae.data_choice.org_no = ae.data_choice.org_no.substr(0,5);
						ae.data_choice.org_name = ae.city_kv_data[i].v;
						break;
					}
				}
				
				ae.req_local_data();
			},function(e){
				PubFuns.dialog_alert(e);
			});
	},
	req_local_data:function(){
		var valuelist = [];
		var valueStr = '';
		if(ae.data_choice.street_code != ''){
			valuelist.push(['street_code',ae.data_choice.street_code]);
		}
		if(ae.data_choice.road_code != ''){
			valuelist.push(['road_code',ae.data_choice.road_code]);
		}
		if(ae.data_choice.estate_code != ''){
			valuelist.push(['estate_code',ae.data_choice.estate_code]);
		}
		if(ae.data_choice.village_code != ''){
			valuelist.push(['village_code',ae.data_choice.village_code]);
		}
		ae.req_dataSign = valuelist;
		for(var i = 0; i < valuelist.length; i++){
			valueStr += valuelist[i][1];
			if(i < valuelist.length - 1){
				valueStr += ',';
			}
		}
		var reqJ = {CODE_TYPE: '',
					COUNTY_CODE: ae.data_choice.county_code,
					NAME: '',
					P_CODE_TYPE: '',
					START: '0',
					VALUE: valueStr,
					P_CODE: ''};
		
		file_maint_req.select_addrcode(reqJ,
			function(d){
				var tempJson = JSON.parse(d);
				if(tempJson.PKG.PKG.FLAG == '-1'){
					ae.loadingNode.close();
					PubFuns.dialog_alert(tempJson.PKG.PKG.ERR_MSG);
					return;
				}
				for(var i = 0; i < ae.req_dataSign.length; i++){
					if(ae.req_dataSign[i][0] == 'street_code'){
						ae.data_choice.street_name = tempJson.PKG.PKG.ADDCODE[i].NAME;
					}else if(ae.req_dataSign[i][0] == 'road_code'){
						ae.data_choice.road_name = tempJson.PKG.PKG.ADDCODE[i].NAME;
					}else if(ae.req_dataSign[i][0] == 'estate_code'){
						ae.data_choice.estate_name = tempJson.PKG.PKG.ADDCODE[i].NAME;
					}else if(ae.req_dataSign[i][0] == 'village_code'){
						ae.data_choice.village_name = tempJson.PKG.PKG.ADDCODE[i].NAME;
					}
				}
				/*ae.data_choice.street_name = tempJson.PKG.PKG.ADDCODE[0].NAME;
			  	ae.data_choice.road_name = tempJson.PKG.PKG.ADDCODE[1].NAME;
			  	ae.data_choice.estate_name = tempJson.PKG.PKG.ADDCODE[2].NAME;
			  	ae.data_choice.village_name = tempJson.PKG.PKG.ADDCODE[3].NAME;*/
			  	ae.loadingNode.close();
				ae.addrEdit_base_dialog();
			},function(d){
				PubFuns.dialog_alert(d);
			});
	},
	req_street : function(){

		ae.reqJson = {P_CODE:'0',P_CODE_TYPE:'03',CODE_TYPE:'04',COUNTY_CODE:ae.data_choice.county_code,NAME:'',START:ae.data_count.street.toString()};
		file_maint_req.select_addrcode(ae.reqJson ,
			function(d){
				var tempJson = JSON.parse(d);
				var listData = '{';
				/*这里后面要加上错误判断*/
				if(tempJson.PKG.PKG.FLAG == '-1'){
					ae.more_callback(null,'-1');
					return;
				}
				if(null == ae.data_street){
					ae.data_street = tempJson.PKG.PKG.ADDCODE;
				}else{
					for(var i = 0; i < tempJson.PKG.PKG.ADDCODE.length; i++){
						ae.data_street.push(tempJson.PKG.PKG.ADDCODE[i]);
					}
				}
				for(var i = 0; i < tempJson.PKG.PKG.ADDCODE.length; i++){
					listData +='"' + tempJson.PKG.PKG.ADDCODE[i].VALUE + '":"' + tempJson.PKG.PKG.ADDCODE[i].NAME + '"';
					if(i < tempJson.PKG.PKG.ADDCODE.length-1)
						listData +=',';
					else
						listData += '}';
				}
				
				ae.data_count.street = ae.data_street.length;
				if(listData == null || tempJson.PKG.PKG.ADDCODE.length < 50){
					ae.data_more.street = false;
					ae.more_callback(listData,'-1');
				}else{
					ae.data_more.street = true;
					ae.more_callback(listData,'1');
				}
			},function(d){
				PubFuns.dialog_alert('请求街道/乡镇数据时：' + d);
			});
	},
	req_road : function(){
		ae.reqJson = {P_CODE:'0',P_CODE_TYPE:'03',CODE_TYPE:'06',COUNTY_CODE:ae.data_choice.county_code,NAME:'',START:ae.data_count.road.toString()};
		file_maint_req.select_addrcode(ae.reqJson ,
			function(d){
				var tempJson = JSON.parse(d);
				var listData = '{';
				/*这里后面要加上错误判断*/
				if(tempJson.PKG.PKG.FLAG == '-1'){
					ae.more_callback(null,'-1');
					return;
				}
				if(null == ae.data_road){
					ae.data_road = tempJson.PKG.PKG.ADDCODE;
				}else{
					for(var i = 0; i < tempJson.PKG.PKG.ADDCODE.length; i++){
						ae.data_road.push(tempJson.PKG.PKG.ADDCODE[i]);
					}
				}
				for(var i = 0; i < tempJson.PKG.PKG.ADDCODE.length; i++){
					listData +='"' + tempJson.PKG.PKG.ADDCODE[i].VALUE + '":"' + tempJson.PKG.PKG.ADDCODE[i].NAME + '"';
					if(i < tempJson.PKG.PKG.ADDCODE.length-1)
						listData +=',';
					else
						listData += '}';
				}
				ae.data_count.road = ae.data_road.length;
				if(listData == null || tempJson.PKG.PKG.ADDCODE.length < 50){
					ae.data_more.road = false;
					ae.more_callback(listData,'-1');
				}else{
					ae.data_more.road = true;
					ae.more_callback(listData,'1');
				}
			},function(d){
				PubFuns.dialog_alert('请求道路数据时：' + d);
			});
	},
	req_estate : function(){
		ae.reqJson = {P_CODE:'0',P_CODE_TYPE:'03',CODE_TYPE:'07',COUNTY_CODE:ae.data_choice.county_code,NAME:'',START:ae.data_count.estate.toString()};
		file_maint_req.select_addrcode(ae.reqJson ,
			function(d){
				var tempJson = JSON.parse(d);
				var listData = '{';
				/*这里后面要加上错误判断*/
				if(tempJson.PKG.PKG.FLAG == '-1'){
					ae.more_callback(null,'-1');
					return;
				}
				if(null == ae.data_estate){
					ae.data_estate = tempJson.PKG.PKG.ADDCODE;
				}else{
					for(var i = 0; i < tempJson.PKG.PKG.ADDCODE.length; i++){
						ae.data_estate.push(tempJson.PKG.PKG.ADDCODE[i]);
					}
				}
				for(var i = 0; i < tempJson.PKG.PKG.ADDCODE.length; i++){
					listData +='"' + tempJson.PKG.PKG.ADDCODE[i].VALUE + '":"' + tempJson.PKG.PKG.ADDCODE[i].NAME + '"';
					if(i < tempJson.PKG.PKG.ADDCODE.length-1)
						listData +=',';
					else
						listData += '}';
				}
				
				ae.data_count.estate = ae.data_estate.length;
				if(listData == null || tempJson.PKG.PKG.ADDCODE.length < 50){
					ae.data_more.estate = false;
					ae.more_callback(listData,'-1');
				}else{
					ae.data_more.estate = true;
					ae.more_callback(listData,'1');
				}
			},function(d){
				PubFuns.dialog_alert('请求小区数据时：' + d);
			});
	},
	req_village : function(){
		
		ae.reqJson = {P_CODE:ae.data_choice.street_code,P_CODE_TYPE:'04',CODE_TYPE:'05',COUNTY_CODE:ae.data_choice.county_code,NAME:'',START:ae.data_count.village.toString()};
		file_maint_req.select_addrcode(ae.reqJson ,
			function(d){
				var tempJson = JSON.parse(d);
				var listData = '{';
				/*这里后面要加上错误判断*/
				if(tempJson.PKG.PKG.FLAG == '-1'){
					ae.more_callback(null,'-1');
					return;
				}
				if(null == ae.data_village){
					ae.data_village = tempJson.PKG.PKG.ADDCODE;
				}else{
					for(var i = 0; i < tempJson.PKG.PKG.ADDCODE.length; i++){
						ae.data_village.push(tempJson.PKG.PKG.ADDCODE[i]);
					}
				}
				for(var i = 0; i < tempJson.PKG.PKG.ADDCODE.length; i++){
					listData +='"' + tempJson.PKG.PKG.ADDCODE[i].VALUE + '":"' + tempJson.PKG.PKG.ADDCODE[i].NAME + '"';
					if(i < tempJson.PKG.PKG.ADDCODE.length-1)
						listData +=',';
					else
						listData += '}';
				}
				ae.data_count.village = ae.data_village.length;
				if(listData == null || tempJson.PKG.PKG.ADDCODE.length < 50){
					ae.data_more.village = false;
					ae.more_callback(listData,'-1');
				}else{
					ae.more_callback(listData,'1');
					ae.data_more.village = true;
				}
			},function(d){
				PubFuns.dialog_alert('请求居委会/村数据时：' + d);
			});
	},
	addrEdit_base_dialog : function(){
		$.Elec.dialog({
				htmlObj : "../../../Html/Pub/addressEdit.html",
				bgCallback : function(){/*$.cache["dialog"].close();*/}
			});
	},
	add_click_event : function(){
		EventUtil.addClickListener({
	        id:"addrEdit_tab_city",
	        clk:ae.tab_click,
	        args:"addrEdit_tab_city"
	    });
		EventUtil.addClickListener({
	        id:"addrEdit_tab_village",
	        clk:ae.tab_click,
	        args:"addrEdit_tab_village"
	    });
		EventUtil.addClickListener({
	        id:"addrEdit_street",
	        clk:ae.addrEdit_child_click,
	        args:"addrEdit_street"
	    });
		EventUtil.addClickListener({
	        id:"addrEdit_village",
	        clk:ae.addrEdit_child_click,
	        args:"addrEdit_village"
	    });
		EventUtil.addClickListener({
	        id:"addrEdit_road",
	        clk:ae.addrEdit_child_click,
	        args:"addrEdit_road"
	    });
		EventUtil.addClickListener({
	        id:"addrEdit_estate",
	        clk:ae.addrEdit_child_click,
	        args:"addrEdit_estate"
	    });
		EventUtil.addClickListener({
	        id:"addrEdit_ok",
	        clk:ae.ok_click,
	        args:"addrEdit_ok"
	    });
		EventUtil.addClickListener({
	        id:"addrEdit_cancel",
	        clk:function(){$.cache["dialog"].close();}
	    });
	},
	init_data : function(){
		$('#addrEdit_city').children('input').attr('value',ae.data_choice.org_name);
		$('#addrEdit_area').children('input').attr('value',ae.data_choice.county_name);
		
		$('#addrEdit_street').children('input').attr('value',ae.data_choice.street_name);
		$('#addrEdit_road').children('input').attr('value',ae.data_choice.road_name);
		$('#addrEdit_estate').children('input').attr('value',ae.data_choice.estate_name);
		$('#addrEdit_village').children('input').attr('value',ae.data_choice.village_name);
		
		$('#addrEdit_detail').children('input').attr('value',ae.data_choice.elec_addr);
		
		var tabSignId = 'addrEdit_tab_city';
		if(ae.data_choice.URBAN_RURAL_FLAG == '02'){
			tabSignId = 'addrEdit_tab_village';
		}
		setTimeout(function(){
			ae.tab_click(tabSignId);
		},350);
	},
	tab_click : function(id){
		if($('#'+id).attr('class') == 'default'){
    		return;
    	}
    	if(id == 'addrEdit_tab_city'){
    		ae.data_choice.URBAN_RURAL_FLAG = '01';
    	}else{
    		ae.data_choice.URBAN_RURAL_FLAG = '02';
    	}
    	id == 'addrEdit_tab_city' ? $('#addrEdit_tab_village').removeClass('default') : $('#addrEdit_tab_city').removeClass('default'); 
    	$('#' + id).addClass('default');
    	document.getElementsByClassName("scroll")[0].style.left = (document.getElementById(id).offsetLeft) + 'px';
	},
	data_save : function(sql){
		db_execut_oneSQL("dawh.db",sql,[],
			function(a,b){
				var detail = $('#addrEdit_detail').children('input').attr('value');
				$.cache["dialog"].close();
				ae.sucess_cb(detail);
			},function(e){
				PubFuns.dialog_alert(e,function(){
					ae.addrEdit_base_dialog();
				});
			});
	},
	ok_click : function(){
		var detail = $('#addrEdit_detail').children('input').attr('value');
		if(detail == undefined ||detail == null ||detail == ''){
			$.cache["dialog"].close();
			PubFuns.dialog_alert('请填写详细信息。',function(){
				ae.addrEdit_base_dialog();
			});
			return;
		}
		if(detail.length < detail.replace('$','**').length){
			PubFuns.dialog_alert('详细地址中不能包含"$"符号。',function(){
				ae.addrEdit_base_dialog();
			});
			return;
		}
		if(detail.replace(/\d+/g,'').length < 1){
			PubFuns.dialog_alert('详细地址中不能为纯数字。',function(){
				ae.addrEdit_base_dialog();
			});
			return;
		}
		if(detail.length < 6){
			PubFuns.dialog_alert('详细地址不能少于六个字符。',function(){
				ae.addrEdit_base_dialog();
			});
			return;
		}
		
		var street_code = ae.data_choice.street_code;
		var road_code = ae.data_choice.road_code;
		var estate_code = ae.data_choice.estate_code;
		var village_code = ae.data_choice.village_code;
		
		if(ae.data_choice.URBAN_RURAL_FLAG == '01'){/*10.	城市用户居民道路F、小区G必填；非居民道路F必填*/
			if(road_code == null || road_code == undefined || road_code == '-1'|| road_code == ''){
				/*城市用户道路必填。*/
				PubFuns.dialog_alert('城市用户道路必填。',function(){
					ae.addrEdit_base_dialog();
				});
				return;
			}
			if(ae.data_choice.cons_sort_code == '03'){
				if(estate_code == null || estate_code == undefined || estate_code == '-1'|| estate_code == ''){
					PubFuns.dialog_alert('城市用户居民小区必填。',function(){
						ae.addrEdit_base_dialog();
					});
					return;
				}
			}
			
		}else{/*11.	农村用户：省、市、区县、街道（乡镇）ABCD必填；居委、道路、小区EFG至少一项不为空*/
			if(street_code == null || street_code == undefined || street_code == '-1'|| street_code == ''){
				PubFuns.dialog_alert('农村用户街道（乡镇）必填。',function(){
					ae.addrEdit_base_dialog();
				});
				return;
			}
			if((road_code == null || road_code == undefined || road_code == '-1'|| road_code == '')
			 && (estate_code == null || estate_code == undefined || estate_code == '-1'|| estate_code == '')
			 &&	(village_code == null || village_code == undefined || village_code == '-1'|| village_code == '')){
			 	
			 	PubFuns.dialog_alert('农村用户居委会、道路、小区至少一项不为空。',function(){
					ae.addrEdit_base_dialog();
				});
				return;
			 }
		}
		if(street_code == undefined || street_code == '-1'|| street_code == ''){
			street_code = null;
		}
		if(road_code == undefined || road_code == '-1'|| road_code == ''){
			road_code = null;
		}
		if(estate_code == undefined || estate_code == '-1'|| estate_code == ''){
			estate_code = null;
		}
		if(village_code == undefined || village_code == '-1'|| village_code == ''){
			village_code = null;
		}
		var saveSql = 'UPDATE YK_S_APP SET '
					+ (street_code != null ? ('STREET_CODE = "' + street_code + '",') : ('STREET_CODE = "",'))
					+ (road_code != null ? ('ROAD_CODE = "' + road_code + '",') : ('ROAD_CODE = "",'))
					+ (estate_code != null ? ('COMMUNITY_CODE = "' + estate_code + '",') : ('COMMUNITY_CODE = "",'))
					+ (village_code != null ? ('VILLAGE_CODE = "' + village_code + '",') : ('VILLAGE_CODE = "",'))
					+ 'URBAN_RURAL_FLAG = "' + ae.data_choice.URBAN_RURAL_FLAG + '",'
					+ 'ELEC_ADDR = "' + detail +'" '
					+ 'WHERE APP_NO = "' + ae.app_no +'"';
		ae.data_save(saveSql);
	},
	get_listData_by_dataReq : function(data){
		var listData = '{';
		for(var i = 0; i < data.length; i++){
			listData +='"' + data[i].VALUE + '":"' + data[i].NAME + '"';
			if(i < data.length-1)
				listData +=',';
			else
				listData += '}';
		}
		return listData;
	},
	addrEdit_child_click : function(id){
		ae.focus_id = id;
		var listData = null;
		var moreFlag = true;
		var title = '';
		
		ae.data_choice.elec_addr = $('#addrEdit_detail').children('input').attr('value');
		
		if(ae.focus_id == "addrEdit_street"){/*04  街道/乡镇*/
			title = '请选择街道/乡镇';
			if(ae.data_street == null || ae.data_street.length < 1){
				listData = {};
			}else{
				moreFlag = ae.data_more.street;
				listData = ae.get_listData_by_dataReq(ae.data_street);
			}
		}else if(ae.focus_id == "addrEdit_road"){/*06  道路*/
			title = '请选择道路';
			if(ae.data_road == null || ae.data_road.length < 1){
				listData = {};
			}else{
				moreFlag = ae.data_more.road;
				listData = ae.get_listData_by_dataReq(ae.data_road);
			}
		}else if(ae.focus_id == "addrEdit_estate"){/*07  小区*/
			title = '请选择小区';
			if(ae.data_estate == null || ae.data_estate.length < 1){
				listData = {};
			}else{
				moreFlag = ae.data_more.estate;
				listData = ae.get_listData_by_dataReq(ae.data_estate);
			}
		}else if(ae.focus_id == "addrEdit_village"){/*05  居委会*/
			title = '请选择居委会';
			if(ae.data_village == null || ae.data_village.length < 1){
				listData = {};
			}else{
				moreFlag = ae.data_more.village;
				listData = ae.get_listData_by_dataReq(ae.data_village);
			}
		}else{
			listData = {};
		}
		list_ex.show({
		    data : listData,
		    title :title, 
		    hasMore : moreFlag,
		    item_click_callback: function(id) {
				if(ae.focus_id == "addrEdit_street"){/*04  街道/乡镇*/
					if(id == 'list_ex_empty'){
						ae.data_choice.street_code = '-1';
						ae.data_choice.street_name = '请选择';
					}else{
						ae.data_choice.street_code = id;
						for(var i = 0; i < ae.data_street.length; i++){
							if(id == ae.data_street[i].VALUE){
								ae.data_choice.street_name = ae.data_street[i].NAME;
							}
						}
					}
				}else if(ae.focus_id == "addrEdit_road"){/*06  道路*/
					if(id == 'list_ex_empty'){
						ae.data_choice.road_code = '-1';
						ae.data_choice.road_name = '请选择';
					}else{
						ae.data_choice.road_code = id;
						for(var i = 0; i < ae.data_road.length; i++){
							if(id == ae.data_road[i].VALUE){
								ae.data_choice.road_name = ae.data_road[i].NAME;
							}
						}
					}
				}else if(ae.focus_id == "addrEdit_estate"){/*07  小区*/
					if(id == 'list_ex_empty'){
						ae.data_choice.estate_code = '-1';
						ae.data_choice.estate_name = '请选择';
					}else{
						ae.data_choice.estate_code = id;
						for(var i = 0; i < ae.data_estate.length; i++){
							if(id == ae.data_estate[i].VALUE){
								ae.data_choice.estate_name = ae.data_estate[i].NAME;
							}
						}
					}
				}else if(ae.focus_id == "addrEdit_village"){/*05  居委会*/
					if(id == 'list_ex_empty'){
						ae.data_choice.village_code = '-1';
						ae.data_choice.village_name = '请选择';
					}else{
						ae.data_choice.village_code = id;
						for(var i = 0; i < ae.data_village.length; i++){
							if(id == ae.data_village[i].VALUE){
								ae.data_choice.village_name = ae.data_village[i].NAME;
							}
						}
					}
				}
				ae.addrEdit_base_dialog();
		    },
		    bgCallback: function() {
				//$.cache["dialog"].close();
				$.cache["dialog"].close();
				ae.addrEdit_base_dialog();
			},
			more_callback : function(cb){
				ae.more_callback = cb;
				if(ae.focus_id == "addrEdit_street"){/*04  街道/乡镇*/
					ae.req_street();
				}else if(ae.focus_id == "addrEdit_road"){/*06  道路*/
					ae.req_road();
				}else if(ae.focus_id == "addrEdit_estate"){/*07  小区*/
					ae.req_estate();
				}else if(ae.focus_id == "addrEdit_village"){/*05  居委会*/
					ae.req_village();
				}
			}
		});
		
		if(ae.focus_id == "addrEdit_street"){/*04  街道/乡镇*/
			if(ae.data_street == null || ae.data_street.length < 1){
				list_ex.more();
			}
		}else if(ae.focus_id == "addrEdit_road"){/*06  道路*/
			if(ae.data_road== null || ae.data_road.length < 1){
				list_ex.more();
			}
		}else if(ae.focus_id == "addrEdit_estate"){/*07  小区*/
			if(ae.data_estate== null || ae.data_estate.length < 1){
				list_ex.more();
			}
		}else if(ae.focus_id == "addrEdit_village"){/*07  小区*/
			if(ae.data_village== null || ae.data_village.length < 1){
				list_ex.more();
			}
		}
	}
}
