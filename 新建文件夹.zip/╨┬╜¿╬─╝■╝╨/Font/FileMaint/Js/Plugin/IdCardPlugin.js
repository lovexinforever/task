var IdCardPlugin = function() {

};

IdCardPlugin.prototype.ocr = function(str, argument, successCallBack, faileCallBack) {
	return PhoneGap.exec(successCallBack, faileCallBack, 'GetIdCardNum', str, [argument]);
};

IdCardPlugin.prototype.takephoto = function(str, argument, successCallBack, faileCallBack) {
    return PhoneGap.exec(successCallBack, faileCallBack, 'GetIdCardNum', str, [argument]);
};

cordova.addConstructor(function() {
	cordova.addPlugin("IdCard", new IdCardPlugin());
});


function ocrIdCard(successCallBack, faileCallBack) {    
    window.plugins.IdCard.ocr("action_ocr_idcard", {}, successCallBack, faileCallBack);
}

function takephoto(field_userno, model_name, successCallBack, faileCallBack) {   
    var data = {
        field_userno: field_userno,
        model_name: model_name
    };
    window.plugins.IdCard.takephoto("action_takephoto", data, successCallBack, faileCallBack);
}

