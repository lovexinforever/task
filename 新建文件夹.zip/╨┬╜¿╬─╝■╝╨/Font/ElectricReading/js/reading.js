$(function() {
	window.testJs = {};
	business_com.loadToolKit();
	$("header p:eq(1)").html(localStorage.area + "-" + localStorage.user_name_str + "-" + localStorage.user_name);
	var sql = 'select a.content,a.order07,a.order97,a.remark,b.type from content a, category b where a.cid = b.id;',
		tabWidth = document.body.offsetWidth,
		localInfoAll = {},
		order07_elecReading = '',
		order97_elecReading = '',
		meter_addr = '',
		returnFlag = 0,
		clickFlag = true,
		forExaminationObj = {},
		endFlag = false, //标记是否抄读结束
		isReading = false, //判断是否抄读中
		readScroller = {}, //水平滚动对象
		page_zero_scroller = {},
		page_one_scroller = {},
		page_two_scroller = {},
		page_three_scroller = {},
		page_four_scroller = {},
		page_five_scroller = {},
		readListScroll = {};

	$('#readInfo_List').height(plat_common.getHeight() - 313).css('position', 'relative');
	$('#tabScroll').width(tabWidth).css('position', 'relative');
	var tabScroll = new iScroll('tabScroll', {
		snap: true,
		momentum: false,
		vScroll: false,
		hScroll: true,
		hScrollbar: false,
		hideScrollbar: true
	});
	tabScroll.refresh();
	document.addEventListener('deviceready', function() {
		db_execut_oneSQL('elecreading.db', sql, [], function(tx, res) {
				var resObj = res.rows,
					str0 = str1 = str2 = str3 = str4 = str5 = '<ul class="list" style="padding-bottom: 15px;">',
					sumStr = '',
					m0 = m1 = m2 = m3 = m4 = m5 = 0,
					res_type = '',
					res_content = '',
					res_order07 = '',
					res_order97 = '',
					propertyObj = {
						snap: false,
						momentum: true,
						vScroll: true,
						hScroll: false,
						hScrollbar: false,
						vScrollbar: true,
						hideScrollbar: true,
						lockDirection: true
					};
				$.each(resObj, function(index) {
					var curr_result = resObj.item(index);
					res_type = curr_result.type;
					res_content = curr_result.content;
					res_order07 = curr_result.order07;
					res_order97 = curr_result.order97;
					switch (res_type) {
						case '常用':
							m0++;
							str0 += addValue(m0, res_content, res_order07, res_order97);
							break;
						case '正向数据':
							m1++;
							str1 += addValue(m1, res_content, res_order07, res_order97);
							break;
						case '反向数据':
							m2++;
							str2 += addValue(m2, res_content, res_order07, res_order97);
							break;
						case '变量/负荷数据':
							m3++;
							str3 += addValue(m3, res_content, res_order07, res_order97);
							break;
						case '基本数据':
							m4++;
							str4 += addValue(m4, res_content, res_order07, res_order97);
							break;
						case '其他':
							m5++;
							str5 += addValue(m5, res_content, res_order07, res_order97);
							break;
					};
				});
				sumStr = '<li id="page_zero">' + str0 + '</ul></li><li id="page_one">' + str1 + '</ul></li><li id="page_two">' + str2 + '</ul></li><li id="page_three">' + str3 + '</ul></li><li id="page_four">' + str4 + '</ul></li><li id="page_five">' + str5 + '</ul></li>';
				$('#readInfo_List >ul').html(sumStr);
				$('#readInfo_List >ul').width(tabWidth * 6).css('position', 'relative');
				$('#readInfo_List >ul >li').width(tabWidth - 30).css('position', 'relative');
				$('#readInfo_List >ul >li').height(plat_common.getHeight() - 328).css('position', 'relative');
				//垂直滚动
				page_zero_scroller = new iScroll('page_zero', propertyObj);
				page_one_scroller = new iScroll('page_one', propertyObj);
				page_two_scroller = new iScroll('page_two', propertyObj);
				page_three_scroller = new iScroll('page_three', propertyObj);
				page_four_scroller = new iScroll('page_four', propertyObj);
				page_five_scroller = new iScroll('page_five', propertyObj);

				//水平滑动
				readScroller = new iScroll('readInfo_List', {
					snap: true,
					momentum: false,
					vScroll: true,
					hScroll: true,
					hScrollbar: false,
					vScrollbar: false,
					lockDirection: true,
					onScrollStart: function() {
						tabScroll.disable();
					},
					onScrollEnd: function() {
						tabScroll.enable();
						var tar_page_index = Math.abs(this.x / tabWidth);
						$('#tabScroll .active').removeClass('active');
						$('#tabScroll li:eq(' + tar_page_index + ')').addClass('active');
						tar_page_index === 2 ? tabScroll.scrollToElement($('#tabScroll li:eq(0)')[0], 300) :
							tar_page_index === 3 ? tabScroll.scrollToElement($('#tabScroll li:eq(3)')[0], 300) : true;
					}
				});
				//tab的点击
				$('#tabScroll li').on('click', function() {
					if (preventDClick()) {
						var tar_page_index = Math.floor($(this).index() / 2),
							tar_page = $('#readInfo_List >ul >li:eq(' + tar_page_index + ')');
						readScroller.scrollToElement(tar_page[0], 500);
					};
				});

				//抄读命令的点选
				$('#readInfo_List').on('click', 'li li', function() {
					if (preventDClick()) {
						$(this).find('.infoselect').toggleClass('infoselected');
					};
				});

				//全选与取消
				$('#selectAll').on('click', function() {
					var curr_page_index = $('#tabScroll').find('.active').index() / 2;
					$('#readInfo_List >ul>li:eq(' + curr_page_index + ')').find(".infoselect").addClass("infoselected");
				});
				$('#cancelAll').on('click', function() {
					var curr_page_index = $('#tabScroll').find('.active').index() / 2;
					$('#readInfo_List >ul>li:eq(' + curr_page_index + ')').find(".infoselect").removeClass("infoselected");
				});

				//填充命令html
				function addValue() {
					return '<li class="float">' +
						'<div class="readInfoNum">' + arguments[0] + '</div>' +
						'<div class="flex info infoselect">' + arguments[1] + '<span>' + arguments[2] + '$' + arguments[3] + '</span></div>' +
						'</li>';
				};
			},
			function(err) {
				console.log('数据库查询失败！原因：' + err);
			});
		blue_connectss();
	}, false);

	//返回或主页按钮
	$('header >span').on('click', function() {
		if (preventDClick()) {
			if (returnFlag === 0) {
				closeTools(forExaminationObj);
				delete window.testJs;
			} else {
				if (!endFlag) {
					navigator.notification.confirm("数据抄读未结束，是否中断退出？", confirm_callback_back, "提示", "确定,取消");

					function confirm_callback_back(button) {
						if (button == 1) {
							returnToHome();
							window.send_Bt_Instruct_New_All('{"nameSpace":"testJs","code07":"","code97":"","address":""}', null, null);
						}
					}
				} else {
					returnToHome();
				};
			};
		};
	});

	//开始抄读
	$('#startReading').on('click', readAmmeter);

	//抄读方法
	function readAmmeter() {
		if (preventDClick()) {
			var asset_no = meter_addr,
				asset_no_len = asset_no.length,
				content = $('.infoselected span'),
				content_len = content.length,
				order07 = order07_elecReading,
				order97 = order97_elecReading,
				localInfo = localInfoAll;
			if (asset_no == '') {
				blue_connectss();
				return false;
			};
			//将电表地址中字母换成数字0
			asset_no = asset_no.replace(/[a-z|A-Z]/g, "0");
			asset_no = asset_no_len == 9 ? '0' + asset_no : asset_no;
			//清空命令
			order07 = '';
			order97 = '';
			if (content_len == 0) {
				showmsg('请选择电表抄读项！', 2000);
				return false;
			} else {
				for (var i = 0; i < content_len; i++) {
					var tempstr = content[i].innerHTML,
						order_list = tempstr.split('$'),
						currentOrder07 = order_list[0],
						currentOrder97 = order_list[1];
					//本地存储所有选中信息
					localInfo[currentOrder07] = $('.infoselected')[i].innerHTML.split('<')[0];
					if (currentOrder97 !== '') {
						localInfoAll[currentOrder97] = $('.infoselected')[i].innerHTML.split('<')[0];
					};
					order07 += i == content_len - 1 ? currentOrder07 : currentOrder07 + ',';
					order97 += i == content_len - 1 ? currentOrder97 : currentOrder97 + ',';
				};
				var paramObj = {
					"nameSpace": "testJs",
					"code07": order07,
					"code97": order97,
					"address": "00" + asset_no
				};
				window.send_Bt_Instruct_New_All(JSON.stringify(paramObj), null, null);

				//删除前一次页面
				if ($('#container').is(':hidden')) {
					$('#container').next().remove();
				};
				$('#container').css('display', 'none').after('<div></div>');
				//跳转到列表页面
				$('#container').next().load('./readingList.html', function() {
					$('#read_List').height(plat_common.getHeight() - 227).css('position', 'relative');
					//返回按钮替换主页按钮
					$('header span img:first-child').css('display', 'none');
					$('header span img:last-child').css('display', 'inline-block');
					returnFlag = 1; //标记按钮为返回，即在list页面
					$('#readCourseTotal').html(content_len);
					$('#read_asset_no').html(meter_addr);
					//传递给营销稽查
					forExaminationObj.assetno = meter_addr;
					forExaminationObj.value = [];
					readListScroll = plat_common.iScrollInit('read_List'),
					j = 0,
					str = '';

					//开始抄读
					isReading = true;
					/**
					 * 扫描返回方法
					 * code：当前命令
					 * data：数据信息
					 * flag：是否扫描结束（end时本次扫描结束）
					 * next：下一个即将扫描的命令
					 * errCode：错误码（-1：无错误，
					 *                0:请检查电能表是否通电或表以损坏,
					 *                1:未抄到数据，请对准红外接口,
					 *                2:为测试电表型号时使用,
					 *                3:命令错误,
					 *                4:未得到数据(可能是红外传输异常导致)
					 *                5:未抄到数据，无此命令）
					 *                6:数据接收片段过程中造成丢失引起的红外异常
					 *                7:电表不支持命令
					 * type:97表示1997表，07表示2007表
					 */
					window.testJs.returnSendDataFun = function(code, data, flag, next, errCode, type) {
						console.log('78787878data: ' + data + ' errCode: ' + errCode + ' type: ' + type + ' next: ' + next + ' flag: ' + flag + ' code: ' + code);
						if (returnFlag == 1) {
							if (code == '' && data == '') {
								if (errCode == 6) {
									showmsg('红外连接异常，请重新抄表！', 3000);
									endFlag = true;
									isReading = false;
									return false;
								}
							} else {
								if (errCode == 0) {
									showmsg(data, 3000);
									endFlag = true;
									isReading = false;
									return false;
								} else if (errCode == 4) {
									console.log('errCode=2,data: ' + data);
								} else if (errCode == 2) {
									console.log('errCode=2,data: ' + data);
								} else if (errCode == 7) {
									showmsg(data, 3000);
								} else {
									$('#readCourseContent').html(checkCode(code));
									if (errCode == -1) {
										str = '<li>' + checkCode(code) + '：' + changeUnit(code, data) + '</li>';
									} else if (errCode == 5) {
										str = '<li>' + checkCode(code) + '：电表返回异常</li>';
									} else if (errCode == 1 || errCode == 3 || errCode == 8) {
										str = '<li>' + checkCode(code) + '：' + data + '</li>';
										showmsg(data, 3000);
									}
									j++;
									console.log('命令返回: ' + str);
									$('#read_List ul').append(str);
									forExaminationObj.value.push(str.substring(4, str.length - 5));
									setTimeout(function() {
										var ulHeight = $('#read_List ul').height(),
											wrapper = plat_common.getHeight() - 227,
											lastLi = $('#read_List ul li:last')[0];
										if (ulHeight > wrapper) {
											readListScroll.scrollToElement(lastLi, 250);
										}
									}, 300);
									$('#readCourseNum').html(j);
									var num = $("#read_List .list li").length;
									$(".readCourseing").width(num / content_len * 100 + "%");
									readListScroll.refresh();
								};
							};
							if (flag == 'end') {
								if (errCode != 6) {
									setTimeout(function() {
										$('#readCourseContent').html('');
										$('#readCourseContent').html('抄读结束');
										showmsg('抄读结束', 3000);
										endFlag = true;
										isReading = false;
									}, 1000);
									return false;
								}
							};
						} else {
							return false;
						};

						//检测当前返回命令是否为选中的命令，如果是则返回中文
						function checkCode(code) {
							if (code in localInfo) {
								return localInfo[code];
							} else {
								console.log('code: ' + code + ' data: ' + data + ' flag: ' + flag + ' next: ' + next + ' errCode: ' + errCode + ' type: ' + type);
							}
						};

						//改变单位（目前只改变电压电流，在此写死）
						function changeUnit(code, data) {
							var str = '';
							switch (code) {
								case '02010100':
								case '02010200':
								case '02010300':
								case 'B611':
								case 'B612':
								case 'B613':
									str = data + 'V';
									break;
								case '02020100':
								case '02020200':
								case '02020300':
								case 'B621':
								case 'B622':
								case 'B623':
									str = data + 'A';
									break;
								default:
									str = data;
							};
							return str;
						};
					};
				});
			};
		};
	};

	//扫描获取barcode
	window.get_barcode = function(barcode) {
		try {
			meter_addr = business_com.dealWithAssetNO(barcode);
		} catch (e) {
			showmsg('获取表地址异常: ' + e, 1000);
		}
	};

	//检查蓝牙连接
	window.blue_connectss = function() {
		bluetooth_conn(function(e) {
			if (e.msg == 1) {
				showToast("设备已连接!");
				showmsg('请扫描电表条码!', 1500);
			} else if (e.msg == 3) {
				showToast("扫描设备未设置!");
			} else {
				showToast("连接失败!");
				showmsg("扫描设备连接失败,请重新连接扫描设备!", 1500);
			}
		});
	};

	//更改蓝牙连接状态
	window.changeState = function(status) {
		if (status == 0) {
			showToast("扫描设备连接已断开!");
			showmsg('扫描设备连接已断开,请重新连接扫描设备!', 1500);
		}
	};

	//按"红外"按钮发送请求开始读表
	window.prepare_readAmmeter = function() {
		if (clickFlag) {
			if (!isReading) {
				if ($('#container').is(':hidden')) {
					clickFlag = false;
					refreshReadingList(readAmmeter);
				} else {
					readAmmeter();
				}
			} else {
				showmsg('数据抄读中...', 1500);
			};
		};
	};

	//重复读取
	function refreshReadingList(func) {
		navigator.notification.confirm("是否重新抄读？", confirm_callback_s, "提示", "确定,取消");

		function confirm_callback_s(button) {
			clickFlag = true;
			if (button == 1) {
				endFlag = false;
				$('#read_List ul').html('');
				$('#readCourseNum').html(0);
				$(".readCourseing").width(0);
				$('#readCourseContent').html('');
				func();
			};
		};
	};

	//自定义信息显示框
	function showmsg(content, time) {
		plat_common.loadDialog(content, '0');
		setTimeout(function() {
			plat_common.closeDialog();
		}, time);
	};

	//防止双击
	function preventDClick() {
		if (clickFlag) {
			clickFlag = false;
			setTimeout(function() {
				clickFlag = true;
			}, 500);
			return true;
		};
		return false;
	};

	//回到首页
	function returnToHome() {
		$('#container').next().remove();
		$('#container').css('display', 'block');
		returnFlag = 0;
		//清空缓存
		localInfoAll = {};
		order07_elecReading = '';
		order97_elecReading = '';
		meter_addr = '';
		endFlag = false;
		isReading = false;
		$('header span img:first-child').css('display', 'inline-block');
		$('header span img:last-child').css('display', 'none');
		window.onresize();
	};
	//for HW
	window.onresize = function() {
		if ($('#container').is(':hidden')) {
			changeListHeightForHW();
		} else {
			changeHeightForHW();
		};
	};

	function changeListHeightForHW() {
		$('#read_List').height(plat_common.getHeight() - 227).css('position', 'relative');
		readListScroll.refresh();
	};

	function changeHeightForHW() {
		$('#readInfo_List >ul >li').height(plat_common.getHeight() - 328).css('position', 'relative');
		$('#readInfo_List').height(plat_common.getHeight() - 313).css('position', 'relative');
		page_zero_scroller.refresh();
		page_one_scroller.refresh();
		page_two_scroller.refresh();
		page_three_scroller.refresh();
		page_four_scroller.refresh();
		page_five_scroller.refresh();
		readScroller.refresh();
	};
});