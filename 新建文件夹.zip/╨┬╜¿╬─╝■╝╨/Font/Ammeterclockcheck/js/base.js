// JavaScript Document
var printHeight= document.body.offsetHeight - 270;
var click_flag=true;
var myScroll1;
var chechFlage=true;

//初始化列表选择框
var toggleFlage=true;

//0编程模式未勾上,1为勾上
var check_tap_flag = 0;


$(document).ready(function(e) {
	//加载平台工具箱页面
	business_com.loadToolKit();
	
    $(".listcontenta").css({height:(printHeight+128)+"px", position:"relative"});
	$("#show_footer").css("display","none")
	
	//刚进入时电表资产编号、历史时间偏差、当前时间偏差等为空
	$(".checkfont span").text('');
	//刚进入时隐藏"上拉刷新提示"
	$("#pullUp").hide();
	
	//如果是从别的模块进入的,则直接将电表资产号填入输入框
	var assetNo = window.location.search.trim();
	if(assetNo.indexOf('assetNo')!=-1 || assetNo.indexOf('assetno')!=-1){
		assetNo = assetNo.slice(assetNo.lastIndexOf('=')+1);
		//填充资产编号
		$("#szjd_asset_input").html(assetNo);
	}
	
	//编程模式点击
	$(".checkTap").click(function(){
		//获取资产编号
		var my_asset_no = $("#szjd_asset_input").html();
		if(check_tap_flag==0){
			check_tap_flag=1;
			$(this).css("background-image","url(../../../Util/Images/sz_checkboxon.png)")
			if(my_asset_no!=''){
				$(".checkcontent").html('<b>请打开电表编程模式</b>,然后摁"红外"按钮校时!');
			}else{
				$(".checkcontent").html('<b>请打开电表编程模式</b>,然后扫描电表条码!');
			}
			
		}else{
			check_tap_flag=0;
			$(this).css("background-image","url(../../../Util/Images/sz_checkboxun.png)")
			if(my_asset_no!=''){
				$(".checkcontent").html('蓝牙终端对准红外接口,按"红外"按钮校时');
			}else{
				$(".checkcontent").html('请扫描电表条码');
			}
		}
	});
});

//上拉结束后刷新列表
function pullUpAction(){
	//判断是分时表还是智能表
	var objs = $("#contentscroll2");
	//分时表
	if(objs.find('li:first').hasClass('active')){
		//如果总页数大于当前页数,重新获取下一页的数据
		if(g_pageCount_fs>g_currPage_fs){
			//每次请求时当前页数+1
			g_currPage_fs++;
			requestFsData(g_pageSize,g_currPage_fs,min_check,max_check,'01');
		}
	}else{
		//如果总页数大于当前页数,重新获取下一页的数据
		if(g_pageCount_zn>g_currPage_zn){
			//每次请求时当前页数+1
			g_currPage_zn++;
			requestZnData(g_pageSize,g_currPage_zn,min_check,max_check,'02');
		}
	}
}


function scrollStart(){
	 var pullUpEl = document.getElementById('pullUp');
	 var pullUpOffset = pullUpEl.offsetHeight;
	 myScroll1 = new iScroll('contentscroll', {
	 	useTransition: true,
		hScrollbar: false,
		vScrollbar: true,
		onRefresh: function () {
			if ($("#pullUp").hasClass("loading")) {
				$("#pullUp").removeClass();
				$(".pullUpLabel").text('向上拉动加载新的列表，试试看!');
			}
		},
		onScrollMove: function () {
			if (this.y < (this.maxScrollY - 70) && !($("#pullUp").hasClass("flip"))) {
				$("#pullUp").removeClass();
				$("#pullUp").addClass("flip");
				$(".pullUpLabel").text('松开开始加载新的列表...');
				this.maxScrollY = this.maxScrollY;
			} else if (this.y > (this.maxScrollY + 70) && ($("#pullUp").hasClass("flip"))) {
				$("#pullUp").removeClass();
				$(".pullUpEl").text('向上拉动加载新的列表，试试看!');
				this.maxScrollY = pullUpOffset;
			} 
		},
		onScrollEnd: function () {
			if ($("#pullUp").hasClass("flip")) {
				$("#pullUp").removeClass();
				$("#pullUp").addClass("loading");
				$(".pullUpLabel").text('加载中...')	
				pullUpAction();
			}
		}
	 });
}



//页面加载完成再加载滑动
document.addEventListener('DOMContentLoaded', function () { setTimeout(scrollStart, 200); }, false);
document.ontouchmove = function(e){
	e.preventDefault();
}


document.addEventListener("deviceready",function(){
	//进行蓝牙连接
	blue_connectss();
},false);



//扫描设备返回资产编号
function get_barcode(barcode) {
	try{
		barcode = business_com.dealWithAssetNO(barcode);
	}
	catch(e){
		alert("处理资产编号时发生异常: "+e);
	}
	
	//填充资产编号
	$("#szjd_asset_input").html(barcode);
	//重新扫描时清空其余项的数据
    $("#cur_span").text('');
	$("#meter_time").text('');
	$("#ter_time").text('');
	$("#check_result").html('');
    clearHis();
	
	//设置提示框内容	
	$(".checkcontent").html('蓝牙小终端对准电表红外接口,按"红外"按钮校时!');
	
	//扫描到一个资产编号后,去后台查询其历史校时时间
	query_history_check(barcode);
}


//查询历史校时记录
function query_history_check(barcode){
	$("#login_msg").text('上次校时记录查询中...');
	$("#waitlogin").fadeIn();
	
	var pkg='{"MOD":"03","FUN":"04","ORG_NO":"'+localStorage.ORG_NO+'","USR":"'+localStorage.user_name+'","PKG_TYPE":"0","PKG":{"ASSET_NO":"'+barcode+'"}}';
	send_data("0000","2019",pkg,function(successData){
		try{
			successData = JSON.parse(successData);
			console.log("通过资产编号查询上次校时记录,返回: "+JSON.stringify(successData));
			if(successData.PKG.RET=='01'){
				var metInfo =successData.PKG.PKG.METINFO;
				
				if(null!=metInfo){
					//填充obj_check_id隐藏span
					$("#obj_check_id").text(metInfo.OBJ_CHECK_ID);
					//设置上次校时时间(暂时用系统时间)
					$("#last_check_time").text(metInfo.SYSTEM_DATE);
					//设置偏差值(单位从秒转为分钟)
					$("#last_offset").text((Number(metInfo.TIME_DIFF)/60).toFixed(2)+"分钟");
				}else{
					$("#login_msg").text('无相关记录!');
				    clearHis();
				}
			}else if(successData.PKG.RET=='14'){
				$("#login_msg").text(successData.PKG.PKG.MSG);
				clearHis();
			}else{
				$("#login_msg").text('数据获取失败!');
				clearHis();
			}
		}
		catch(e){
			$("#login_msg").text('服务端返回数据错误!');
			clearHis();
		}
		
		setTimeout(function(){
			$("#waitlogin").fadeOut();
		},1000)
	},function(e){
		$("#login_msg").text(e);
		setTimeout(function(){
			$("#waitlogin").fadeOut();
		},1000)
		clearHis();
	});
}


//清除"上次校时时间"和"偏差"
function clearHis(){
   $("#last_check_time").text('');
   $("#last_offset").text('');
   $("#obj_check_id").text('');
}

//检查蓝牙连接
function blue_connectss(){
	$(".checkcontent").html('扫描设备连接中...');
	bluetooth_conn(function(e){
		if(e.msg == 1){
			showToast("设备已连接!");
			//设置提示框内容	
			$(".checkcontent").html('请扫描电表条码!');
		}else if(e.msg==3){
			showToast("扫描设备未设置!");
			//设置提示框内容	
			$(".checkcontent").html('&nbsp;&nbsp;&nbsp;&nbsp;请先点击左上角按钮回到平台或通过左下角工具箱按钮,进入"设置模块",滑动到最底部后,'+
			  '点击"扫描"下的输入框,选择你要连接的蓝牙设备,选好点击"确定"按钮保存设置,重新进入时钟校时模块!');
		}else{
			showToast("连接失败!");
			//设置提示框内容	
			$(".checkcontent").html('扫描设备连接失败,请重新连接扫描设备!');
		}

	});
}


//更改蓝牙连接状态
function changeState(status){
	if(status==0){
		showToast("扫描设备连接已断开!");
		//设置提示框内容	
		$(".checkcontent").html('扫描设备连接已断开,请重新连接扫描设备!');
	}
}
