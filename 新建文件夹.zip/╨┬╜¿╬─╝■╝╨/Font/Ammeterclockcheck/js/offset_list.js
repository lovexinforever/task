//对应偏差范围数据的列表相关js
//最小偏差范围及最大偏差范围
var min_check=0,max_check=0;
//当前页数(分时表)
var g_currPage_fs=1;
//当前页数(智能表)
var g_currPage_zn=1;
//每页显示条数
var g_pageSize=30;
//总页数(分时表)
var g_pageCount_fs=0;
//总页数(智能表)
var g_pageCount_zn=0;
//总记录数(分时表)
var g_totalCount_fs=0;
//总记录数(智能表)
var g_totalCount_zn=0;
//存放当前请求的分时表信息(每次拉动刷新时往里加入),每次选择偏差范围重新查询时清空(二维数组)
var fenshiData = [];
//存放当前请求的智能表信息
var zhinengData = [];
//发送请求处理完的个数(当达到此个数时才能关闭进度条)
var requestFlag = 2;
//每次选择偏差范围时时当分时表和智能表信息都请求完成后才能关掉进度条
var checkRequestOver = [];

function requestOffsetList(listIndex){
	switch(listIndex){
	   //快3~5分钟
	   case 0:
	     min_check=-300;
	     max_check=-181;
	     break;
	   //快5~15分钟
	   case 1:
	     min_check=-900;
	     max_check=-301;
	     break;
	   //慢5~3分钟
	   case 2:
	     min_check=181;
	     max_check=300;
	     break;
	   //慢15~5分钟
	   case 3:
	     min_check=301;
	     max_check=900;
	     break;
	   //慢1天以上
	   case 4:
	     min_check=85501;
	     max_check=0;
	     break;
	   //慢1天~1小时
	   case 5:
	     min_check=3601;
	     max_check=85500;
	     break;
	   //慢1小时~15分钟
	   case 6:
	     min_check=901;
	     max_check=3600;
	     break;
	   //快1天以上
	   case 7:
	     min_check=0;
	     max_check=-85501;
	     break;
	   //快1小时到1天
	   case 8:
	     min_check=-85500;
	     max_check=-3601;
	     break;
	   //快15分钟到1小时
	   case 9:
	     min_check=-3600;
	     max_check=-901;
	     break;
	}
	
	//此方式获取数据时,每次将g_currPage置为1,并将tab页默认置为分时表
	//这种方式请求时分时表和智能表都请求30条,METER_TYPE:字段不传时即为请求所有
	g_currPage_fs=1;
	g_currPage_zn=1;
	fenshiData = [];
	zhinengData = [];
	$("#contentscroll2").find('li:first').addClass('active').siblings().removeClass('active');
	$("#contentscroll2 li span").text('0');
	//请求分时表和智能表信息(各请求30条)
	//挂进度条
	plat_common.loadDialog("数据获取中...");
	requestFlag = 2;
	requestFirstFs(g_pageSize,g_currPage_fs,min_check,max_check,'01');
	requestFirstZn(g_pageSize,g_currPage_zn,min_check,max_check,'02');
}

//组装json请求参数信息
function _getJSONData(temp_pageSize,temp_currPage,t_min_check,t_max_check,meter_type){
	//组装参数,发送请求获取数据
	var tid = business_com.tid;
	var innerPkg = {"PAGE_SIZE":temp_pageSize,"CURR_PAGE":temp_currPage,"METER_TYPE":meter_type};
	if(t_min_check==0){
		innerPkg["MAX_CHECK"] = t_max_check;
	}else if(t_max_check==0){
		innerPkg["MIN_CHECK"] = t_min_check;
	}else{
		innerPkg["MIN_CHECK"] = t_min_check;
		innerPkg["MAX_CHECK"] = t_max_check;
	}
	var outterPkg = {"MOD":"03","FUN":"01","PKG_TYPE":"0","USR":localStorage.user_name,"ORG_NO":localStorage.ORG_NO,"PKG":innerPkg};
	var jsonData = {"FUN":"0000","LEN":plat_common.getLenOfChinese(outterPkg),"MOD":"2019","PKG":outterPkg,"REQ":"0","SSN":localStorage.SSN,"USR":localStorage.user_name,"TID":tid};
	return jsonData;
}

//当两个请求都返回后才能关掉进度条
function checkFinish(){
	if(checkRequestOver.length==requestFlag){
		setTimeout(function(){
			plat_common.closeDialog();
		},2000);
		checkRequestOver = [];
	}
}

//每次重新选择偏差范围后查询分时表信息
function requestFirstFs(temp_pageSize,temp_currPage,t_min_check,t_max_check,meter_type){
	plat_common.ajax_req(business_com.requestUrl,"data",_getJSONData(temp_pageSize,temp_currPage,t_min_check,t_max_check,meter_type),function(successData){
		try{
			console.log("服务端返回数据为fs: "+JSON.stringify(successData));
			checkRequestOver.push('01');
			handleFirstFs(successData);
		}
		catch(e){
			checkRequestOver.push('00');
			plat_common.loadDialog('服务器返回数据异常',0);
			g_pageCount_fs=0;
		    g_totalCount_fs=0;
			$(".content_listbottn").html('');
			$("#contentscroll2").find('li:first span').text(0);
			$("#show_footer").css("display","none")
			myScroll1.refresh();
		}
		checkFinish();
	},function(e){
		console.log("获取服务端端数据失败!");
		plat_common.loadDialog('网络连接错误',0);
		checkRequestOver.push('00');
		checkFinish();
		g_pageCount_fs=0;
	    g_totalCount_fs=0;
		$(".content_listbottn").html('');
		$("#contentscroll2").find('li:first span').text(0);
		$("#show_footer").css("display","none")
		myScroll1.refresh();
	},60*1000);
}

//每次重新选择偏差范围后解析分时表信息
function handleFirstFs(successData){
	console.log("开始处理分时表数据");
	//总页数和总记录数
	g_totalCount_fs = successData.PKG.PKG.TOTAL_COUNT;
	g_pageCount_fs = successData.PKG.PKG.PAGE_COUNT;
	
	var fsbObjs = $("#contentscroll2");
	//无记录
	if(0==g_totalCount_fs){
		$("#login_msg").text("数据为空!");
		$(".content_listbottn").html('');
		fsbObjs.find('li:first span').text(0);
		$("#show_footer").css("display","none")
		fenshiData = [];
	}else{
		$("#show_footer").css("display","block")
		fsbObjs.find('li:first span').text(g_totalCount_fs);
		var metInfo = successData.PKG.PKG.METINFO;
		fenshiData.push(metInfo);
		parseFirstFs(metInfo);
	}
	
	//更改当前条数
	if(g_currPage_fs>=g_pageCount_fs){
		//如果是最后一页
		$(".green").text(g_totalCount_fs);
		//最后一页,则隐藏"上拉加载列表"提示
		$("#pullUp").hide();
	}else{
		$(".green").text(g_currPage_fs*g_pageSize);
		$("#pullUp").show();
	}
	$(".yellow").text(g_totalCount_fs);
	
	myScroll1.refresh();
}

//每次重新选择偏差范围后填充分时表信息
function parseFirstFs(dataList){
	console.log("开始解析分时表数据");
	var str ='';
	for(var i=0,i_len=dataList.length;i<i_len;i++){
		var temp_i = dataList[i];
		//时间偏差如果是正数则加上"慢"字,如果是负数则加上"快"字
		//时间偏差的单位是秒，需要转成分钟
		var temp_diff = temp_i.TIME_DIFF;
		temp_diff = (Number(temp_diff)/60).toFixed(2)+"分钟";
		if(temp_diff.indexOf("-")!=-1){
			temp_diff = "快"+temp_diff.replace("-","");
		}else{
			temp_diff = "慢"+temp_diff;
		}
		
		str+='<div class="list float">'+
		'<div class="num">'+((g_currPage_fs-1)*g_pageSize+i+1)+'</div>'+
		'<div class="detail flex">'+
	    '电表资产编号：<span class="mter_ast_no">'+temp_i.METER_ASSET_NO+'</span><span style="display:none" class="obj_check_cls">'+temp_i.OBJ_CHECK_ID+'</span><span style="display:none" class="obj_check_time">'+temp_i.SYSTEM_DATE+'</span><span class="red">&nbsp;&nbsp;&nbsp;&nbsp;偏差：<span class="meter_fiff">'+temp_diff+'</span></span><br />'+
	 　　       '用户地址：'+temp_i.ELEC_ADDR+
	    '</div>'+
	    '</div>';
	}
	
    //填充页面
	$(".content_listbottn").html(str+'<div id="pullUp">'+
    '<span class="pullUpIcon"></span><span class="pullUpLabel">向上拉动加载新的列表</span></div>');
    $("#show_footer").show();		
}

//每次重新选择偏差范围后查询智能表信息
function requestFirstZn(temp_pageSize,temp_currPage,t_min_check,t_max_check,meter_type){
	plat_common.ajax_req(business_com.requestUrl,"data",_getJSONData(temp_pageSize,temp_currPage,t_min_check,t_max_check,meter_type),function(successData){
		try{
			console.log("服务端返回数据为zn: "+JSON.stringify(successData));
			checkRequestOver.push('11');
			handleFirstZn(successData);
		}
		catch(e){
			checkRequestOver.push('10');
			console.log('获取智能表信息,服务器返回数据错误!');
			$("#contentscroll2").find('li:last span').text(0);
		}
		checkFinish();
	},function(e){
		checkRequestOver.push('10');
		console.log("获取服务端端数据失败,网络连接错误!");
		checkFinish();
		$("#contentscroll2").find('li:last span').text(0);
	},60*1000);
}

//tab切换时如果智能表信息为空,则重新发送请求获取数据
function requestFirstZn2(temp_pageSize,temp_currPage,t_min_check,t_max_check,meter_type){
	plat_common.ajax_req(business_com.requestUrl,"data",_getJSONData(temp_pageSize,temp_currPage,t_min_check,t_max_check,meter_type),function(successData){
		try{
			console.log("服务端返回数据为: "+JSON.stringify(successData));
			checkRequestOver.push('31');
			handleFirstZn2(successData);
		}
		catch(e){
			plat_common.loadDialog('服务器返回数据异常',0);
			checkRequestOver.push('30');
			console.log('获取智能表信息,服务器返回数据错误!');
			$(".content_listbottn").html('');
			$("#show_footer").css("display","none")
			myScroll1.refresh();
		}
		checkFinish();
	},function(e){
		plat_common.loadDialog('网络连接错误',0);
		checkRequestOver.push('30');
		console.log("获取服务端端数据失败,网络连接错误!");
		$(".content_listbottn").html('');
		$("#show_footer").css("display","none")
		myScroll1.refresh();
		checkFinish();
	},60*1000);
}

//每次重新选择偏差范围后解析智能表信息
function handleFirstZn(successData){
	console.log("开始处理智能表数据");
	//总页数和总记录数
	g_totalCount_zn = successData.PKG.PKG.TOTAL_COUNT;
	g_pageCount_zn = successData.PKG.PKG.PAGE_COUNT;
	
	var fsbObjs = $("#contentscroll2");
	//无记录
	if(0==g_totalCount_zn){
		fsbObjs.find('li:last span').text(0);
		zhinengData = [];
	}else{
		fsbObjs.find('li:last span').text(g_totalCount_zn);
		var metInfo = successData.PKG.PKG.METINFO;
		zhinengData.push(metInfo);
	}
	myScroll1.refresh();
}

//tab切换时如果智能表信息为空,则重新发送请求获取数据时解析数据
function handleFirstZn2(successData){
	//总页数和总记录数
	g_totalCount_zn = successData.PKG.PKG.TOTAL_COUNT;
	g_pageCount_zn = successData.PKG.PKG.PAGE_COUNT;
	
	var fsbObjs = $("#contentscroll2");
	//无记录
	if(0==g_totalCount_zn){
		$("#login_msg").text("数据为空!");
		fsbObjs.find('li:last span').text(0);
		zhinengData = [];
		$("#show_footer").css("display","none")
		$(".content_listbottn").html('');
	}else{
		$("#show_footer").css("display","block")
		var metInfo = successData.PKG.PKG.METINFO;
		zhinengData.push(metInfo);
		fsbObjs.find('li:last span').text(g_totalCount_zn);
		parseFirstZn2(metInfo);
	}
	
	//更改当前条数
	if(g_currPage_zn>=g_pageCount_zn){
		//如果是最后一页
		$(".green").text(g_totalCount_zn);
		//最后一页,则隐藏"上拉加载列表"提示
		$("#pullUp").hide();
	}else{
		$(".green").text(g_currPage_zn*g_pageSize);
		$("#pullUp").show();
	}
	$(".yellow").text(g_totalCount_zn);
	myScroll1.refresh();
}

//解析智能表数据
function parseFirstZn2(dataList){
	var str ='';
	for(var i=0,i_len=dataList.length;i<i_len;i++){
		var temp_i = dataList[i];
		//时间偏差如果是正数则加上"慢"字,如果是负数则加上"快"字
		//时间偏差的单位是秒，需要转成分钟
		var temp_diff = temp_i.TIME_DIFF;
		temp_diff = (Number(temp_diff)/60).toFixed(2)+"分钟";
		if(temp_diff.indexOf("-")!=-1){
			temp_diff = "快"+temp_diff.replace("-","");
		}else{
			temp_diff = "慢"+temp_diff;
		}
		
		str+='<div class="list float">'+
		'<div class="num">'+((g_currPage_zn-1)*g_pageSize+i+1)+'</div>'+
		'<div class="detail flex">'+
	    '电表资产编号：<span class="mter_ast_no">'+temp_i.METER_ASSET_NO+'</span><span style="display:none" class="obj_check_cls">'+temp_i.OBJ_CHECK_ID+'</span><span style="display:none" class="obj_check_time">'+temp_i.SYSTEM_DATE+'</span><span class="red">&nbsp;&nbsp;&nbsp;&nbsp;偏差：<span class="meter_fiff">'+temp_diff+'</span></span><br />'+
	 　　       '用户地址：'+temp_i.ELEC_ADDR+
	    '</div>'+
	    '</div>';
	}
    
    //填充页面
	$(".content_listbottn").html(str+'<div id="pullUp">'+
    '<span class="pullUpIcon"></span><span class="pullUpLabel">向上拉动加载新的列表</span></div>');
    $("#show_footer").show();		
}

//拉动刷新时请求分时表数据
function requestFsData(temp_pageSize,temp_currPage,t_min_check,t_max_check,meter_type){
	//挂进度条
	plat_common.loadDialog("数据获取中...");
	plat_common.ajax_req(business_com.requestUrl,"data",_getJSONData(temp_pageSize,temp_currPage,t_min_check,t_max_check,meter_type),function(successData){
		try{
			console.log("服务端返回数据为: "+JSON.stringify(successData));
			handleFsData(successData);
		}
		catch(e){
			plat_common.loadDialog('服务器返回数据异常',0);
			g_currPage_fs--;
			myScroll1.refresh();
		}
		setTimeout(function(){
			plat_common.closeDialog();
		},2000);
	},function(e){
		plat_common.loadDialog('网络连接错误',0);
		console.log("获取服务端端数据失败,网络连接错误!");
		g_currPage_fs--;
		myScroll1.refresh();
		setTimeout(function(){
			plat_common.closeDialog();
		},2000);
	},60*1000);
}

//拉动刷新时解析分时表数据
function handleFsData(successData){
	//总页数和总记录数
	g_totalCount_fs = successData.PKG.PKG.TOTAL_COUNT;
	g_pageCount_fs = successData.PKG.PKG.PAGE_COUNT;
	
	var fsbObjs = $("#contentscroll2");
	//无记录
	if(0==g_totalCount_fs){
		$("#login_msg").text("数据为空!");
	}else{
		var metInfo = successData.PKG.PKG.METINFO;
		fenshiData.push(metInfo);
		parseFsData(metInfo);
		fsbObjs.find('li:first span').text(g_totalCount_fs);
	}
	
	//更改当前条数
	if(g_currPage_fs>=g_pageCount_fs){
		//如果是最后一页
		$(".green").text(g_totalCount_fs);
		//最后一页,则隐藏"上拉加载列表"提示
		$("#pullUp").hide();
	}else{
		$(".green").text(g_currPage_fs*g_pageSize);
		$("#pullUp").show();
	}
	$(".yellow").text(g_totalCount_fs);
	
	myScroll1.refresh();
}

//拉动刷新时填充分时表数据
function parseFsData(dataList){
	var str = '';
	for(var i=0,i_len=dataList.length;i<i_len;i++){
		var temp_i = dataList[i];
		//时间偏差如果是正数则加上"慢"字,如果是负数则加上"快"字
		//时间偏差的单位是秒，需要转成分钟
		var temp_diff = temp_i.TIME_DIFF;
		temp_diff = (Number(temp_diff)/60).toFixed(2)+"分钟";
		if(temp_diff.indexOf("-")!=-1){
			temp_diff = "快"+temp_diff.replace("-","");
		}else{
			temp_diff = "慢"+temp_diff;
		}
		
		str+='<div class="list float">'+
		'<div class="num">'+((g_currPage_fs-1)*g_pageSize+i+1)+'</div>'+
		'<div class="detail flex">'+
	    '电表资产编号：<span class="mter_ast_no">'+temp_i.METER_ASSET_NO+'</span><span style="display:none" class="obj_check_cls">'+temp_i.OBJ_CHECK_ID+'</span><span style="display:none" class="obj_check_time">'+temp_i.SYSTEM_DATE+'</span><span class="red">&nbsp;&nbsp;&nbsp;&nbsp;偏差：<span class="meter_fiff">'+temp_diff+'</span></span><br />'+
	 　　       '用户地址：'+temp_i.ELEC_ADDR+
	    '</div>'+
	    '</div>';
	}
    
    //填充页面
	$("#pullUp").before(str);		
}

//拉动刷新时请求智能表数据
function requestZnData(temp_pageSize,temp_currPage,t_min_check,t_max_check,meter_type){
	//挂进度条
	plat_common.loadDialog("数据获取中...");
	plat_common.ajax_req(business_com.requestUrl,"data",_getJSONData(temp_pageSize,temp_currPage,t_min_check,t_max_check,meter_type),function(successData){
		try{
			console.log("服务端返回数据为: "+JSON.stringify(successData));
			handleZnData(successData);
		}
		catch(e){
			plat_common.loadDialog('服务器返回数据异常',0);
			g_currPage_zn--;
			myScroll1.refresh();
		}
		setTimeout(function(){
			plat_common.closeDialog();
		},2000);
	},function(e){
		plat_common.loadDialog('网络连接错误',0);
		console.log("获取服务端端数据失败,网络连接错误!");
		g_currPage_zn--;
		myScroll1.refresh();
		setTimeout(function(){
			plat_common.closeDialog();
		},2000);
	},60*1000);
}

//拉动刷新时解析智能表信息
function handleZnData(successData){
	//总页数和总记录数
	g_totalCount_zn = successData.PKG.PKG.TOTAL_COUNT;
	g_pageCount_zn = successData.PKG.PKG.PAGE_COUNT;
	
	var fsbObjs = $("#contentscroll2");
	//无记录
	if(0==g_totalCount_zn){
		$("#login_msg").text("数据为空!");
	}else{
		var metInfo = successData.PKG.PKG.METINFO;
		zhinengData.push(metInfo);
		parseZnData(metInfo);
		fsbObjs.find('li:last span').text(g_totalCount_zn);
	}
	
	//更改当前条数
	if(g_currPage_zn>=g_pageCount_zn){
		//如果是最后一页
		$(".green").text(g_totalCount_zn);
		//最后一页,则隐藏"上拉加载列表"提示
		$("#pullUp").hide();
	}else{
		$(".green").text(g_currPage_zn*g_pageSize);
		$("#pullUp").show();
	}
	$(".yellow").text(g_totalCount_zn);
	
	myScroll1.refresh();
}

//拉动刷新时填充智能表数据
function parseZnData(dataList){
	var str ='';
	for(var i=0,i_len=dataList.length;i<i_len;i++){
		var temp_i = dataList[i];
		//时间偏差如果是正数则加上"慢"字,如果是负数则加上"快"字
		//时间偏差的单位是秒，需要转成分钟
		var temp_diff = temp_i.TIME_DIFF;
		temp_diff = (Number(temp_diff)/60).toFixed(2)+"分钟";
		if(temp_diff.indexOf("-")!=-1){
			temp_diff = "快"+temp_diff.replace("-","");
		}else{
			temp_diff = "慢"+temp_diff;
		}
		
		str+='<div class="list float">'+
		'<div class="num">'+((g_currPage_zn-1)*g_pageSize+i+1)+'</div>'+
		'<div class="detail flex">'+
	    '电表资产编号：<span class="mter_ast_no">'+temp_i.METER_ASSET_NO+'</span><span style="display:none" class="obj_check_cls">'+temp_i.OBJ_CHECK_ID+'</span><span style="display:none" class="obj_check_time">'+temp_i.SYSTEM_DATE+'</span><span class="red">&nbsp;&nbsp;&nbsp;&nbsp;偏差：<span class="meter_fiff">'+temp_diff+'</span></span><br />'+
	 　　       '用户地址：'+temp_i.ELEC_ADDR+
	    '</div>'+
	    '</div>';
	}
    
    //填充页面
	$("#pullUp").before(str);		
}

//分时表和智能表tab页点击切换效果
$("#contentscroll2 .tab li").click(function(){
	var index = $("#contentscroll2 .tab li").index(this);
	$(this).addClass('active').siblings().removeClass('active');
	//分时表
	if(index==0){
		//解析分时表数据
		fillHtmlByClickTab(fenshiData,'01');
	}else{
		//解析智能表数据
		fillHtmlByClickTab(zhinengData,'02');
	}
});

//切换tab页时填充页面数据
function fillHtmlByClickTab(data,meter_type){
	var len = data.length;
	if(len==0){
		requestFlag = 1;
		$(".content_listbottn").html('');
		$("#show_footer").css("display","none")
		myScroll1.refresh();
		//分时表
		if(meter_type=='01'){
			//挂进度条
			plat_common.loadDialog("分时表数据获取中...");
			//发送请求获取分时表数据
			requestFirstFs(g_pageSize,g_currPage_fs,min_check,max_check,'01')
		}else{
			//挂进度条
			plat_common.loadDialog("智能表数据获取中...");
			//发送请求获取智能表数据
			requestFirstZn2(g_pageSize,g_currPage_zn,min_check,max_check,'02')
		}
	}else{
		var str ='';
		for(var i=0,count=0;i<len;i++){
			var temp = data[i];
			for(var j=0,j_len=temp.length;j<j_len;j++){
				var temp_j = temp[j];
				//时间偏差如果是正数则加上"慢"字,如果是负数则加上"快"字
				//时间偏差的单位是秒，需要转成分钟
				var temp_diff = temp_j.TIME_DIFF;
				temp_diff = (Number(temp_diff)/60).toFixed(2)+"分钟";
				if(temp_diff.indexOf("-")!=-1){
					temp_diff = "快"+temp_diff.replace("-","");
				}else{
					temp_diff = "慢"+temp_diff;
				}
				
				count++;
				str+='<div class="list float">'+
				'<div class="num">'+count+'</div>'+
				'<div class="detail flex">'+
			    '电表资产编号：<span class="mter_ast_no">'+temp_j.METER_ASSET_NO+'</span><span style="display:none" class="obj_check_cls">'+temp_j.OBJ_CHECK_ID+'</span><span style="display:none" class="obj_check_time">'+temp_j.SYSTEM_DATE+'</span><span class="red">&nbsp;&nbsp;&nbsp;&nbsp;偏差：<span class="meter_fiff">'+temp_diff+'</span></span><br />'+
			 　　       '用户地址：'+temp_j.ELEC_ADDR+
			    '</div>'+
			    '</div>';
			}
		}
		 //填充页面
		$(".content_listbottn").html(str+'<div id="pullUp">'+
	    '<span class="pullUpIcon"></span><span class="pullUpLabel">向上拉动加载新的列表</span></div>');
	    $("#show_footer").show();
	    //更改当前条数
	    if(meter_type=='01'){
	    	if(g_currPage_fs>=g_pageCount_fs){
				//如果是最后一页
				$(".green").text(g_totalCount_fs);
				//最后一页,则隐藏"上拉加载列表"提示
				$("#pullUp").hide();
			}else{
				$(".green").text(g_currPage_fs*g_pageSize);
				$("#pullUp").show();
			}
			$(".yellow").text(g_totalCount_fs);
	    }else{
	    	if(g_currPage_zn>=g_pageCount_zn){
				//如果是最后一页
				$(".green").text(g_totalCount_zn);
				//最后一页,则隐藏"上拉加载列表"提示
				$("#pullUp").hide();
			}else{
				$(".green").text(g_currPage_zn*g_pageSize);
				$("#pullUp").show();
			}
			$(".yellow").text(g_totalCount_zn);
	    }
		myScroll1.refresh();	
	}
}

//点击电表列表,将资产编号和偏差值带到首页
$(".content_listbottn .list.float").live('click',function(){
	var list_index = $(".content_listbottn .list.float").index(this);
	var current_obj = document.getElementsByClassName("detail").item(list_index);
	//资产编号
	var asset_no = current_obj.querySelector(".mter_ast_no").innerHTML;
	//历史偏差
	var his_diff = current_obj.querySelector(".meter_fiff").innerHTML;
	if(his_diff.indexOf("快")!=-1){
		his_diff = his_diff.replace("快","-");
	}else if(his_diff.indexOf("慢")!=-1){
		his_diff = his_diff.replace("慢","");
	}
	
	//obj_check_id,用于更新历史偏差接口
	var obj_check_id = current_obj.querySelector(".obj_check_cls").innerHTML;
	//填充隐藏span的值
	$("#obj_check_id").text(obj_check_id);
	//填充上次校时时间
	var obj_check_time = current_obj.querySelector(".obj_check_time").innerHTML;
	$("#last_check_time").text(obj_check_time);
	
	$(".contentlist:first-child").css("display","block")
	$(".contentlist:last-child").css("display","none")
	$(".listcontenta").css("height",(printHeight+128)+"px");
	//填充资产编号
	$("#szjd_asset_input").html(asset_no);
	//填充历史偏差
	$("#last_offset").text(his_diff.replace('M',''));
	//清除当前时间偏差、电能表时间、终端时间和校时结果
	$("#cur_span").text('');
	$("#meter_time").text('');
	$("#ter_time").text('');
	$("#check_result").html('');
	$("#show_footer").css("display","none")
	chechFlage=true;
	
    //设置提示框内容	
    $(".checkcontent").html('蓝牙小终端对准电表红外接口,按"红外"按钮校时!');
});

$("#mapNavi").click(function(){
	mapNavigation();
});

//地图模式
function mapNavigation(){
    //获取当前tab页已请求的数据组装成地图需求的格式
    var arr = [];
    var objs = $("#contentscroll2");
    //分时表
    if(objs.find('li:first').hasClass('active')){
    	arr = fenshiData;
    }else{
    	//智能表
    	arr = zhinengData;
    }
    if(arr.length==0){
    	showToast('当前数据为空!');
    	return;
    }
    
    //组装数据
    var mapArr = [];
    for(var i=0,k=-1,len=arr.length;i<len;i++){
    	var temp_i = arr[i];
    	for(var j=0,j_len=temp_i.length;j<j_len;j++){
    		k++;
    		var temp = temp_i[j];
    		mapArr.push({"index":k,"name":temp.CONS_NAME,"address":temp.ELEC_ADDR,"no":temp.CONS_NO,"x":temp.LONGITUDE,"y":temp.LATITUDE});
    	}
    }
    console.log("mapArr: "+JSON.stringify(mapArr));
    var mapJson = {"content":mapArr};
    showHno(function(suc){},mapJson);
}
