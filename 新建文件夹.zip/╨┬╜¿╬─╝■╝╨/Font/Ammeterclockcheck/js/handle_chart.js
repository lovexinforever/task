//处理饼图相关的js
$(function(){
	//滚动
	var scontent2Scroll = new iScroll('scontent2Scroll',{hideScrollbar:true});
	
	//隐藏15分钟以上的偏差
	$("#scontent2Scroll").find('li:gt(3):not(:last)').hide();
	//"更多"点击事件
	$("#scontent2Scroll li:last").click(function(){
		var obj = $('#scontent2Scroll');
		var display = obj.find('li:eq(4)').css('display');
		if(display=='none'){
			obj.find('li').show();
			obj.find('li:last').text('收　起');
		}else{
			obj.find('li:gt(3):not(:last)').hide().end().find('li:last').text('更　多');
		}
		scontent2Scroll.refresh();
	});
	
	//偏差范围点击事件
	$(".scontent2 ul li:lt(10)").click(function(){
		$(".selectedpopup").hide();
		showComponent2();
		
		var listIndex = $(".scontent2 ul li").index(this);
		//发送请求获取偏差列表
		$(".select_list .flex").html('偏差：'+$(".scontent2 ul li:eq("+listIndex+") div:first").html());
		$(".content_listbottn").html('');
		$("#show_footer").hide();
		requestOffsetList(listIndex);
	});
	
	//chart"返回"按钮点击事件
	$("#return_back").click(function(){
		$(".selectedpopup").hide();
	});
	
	//第二个页面"返回"按钮点击事件
	$("#go_first_btn").click(function(){
		showComponent1();
	});
	
	//"列表"按钮点击事件
	$(".list_chart_btn:not(:eq(1))").click(function(){
		if(click_flag){
			click_flag = false;
			setTimeout(function(){
				click_flag = true;
			},1000);
			
			//每次画图表前,清空原有图表和数据
			$("#canvasDiv").html('');
			$(".scontent2 ul div:odd").html('');
			$(".selectedpopup").show();
		
			//发送请求获取图表比例数据
			$("#login_msg").text('数据获取中...');
			$("#waitlogin").fadeIn();
			getChartData();
		}
	});
})


//从后台获取偏差百分比数据并绘制饼图
function getChartData(){
	var pkg='{"MOD":"03","FUN":"05","ORG_NO":"'+localStorage.ORG_NO+'","USR":"'+localStorage.user_name+'","PKG_TYPE":"0","PKG":{}}';
	send_data("0000","2019",pkg,function(returnData){
		try{
			var successData = JSON.parse(returnData);
			if(successData.PKG.RET=='01'){
				var metDiff = successData.PKG.PKG.METDIFF;
				if(metDiff==null){
					$("#login_msg").text("数据为空!");
					$("#canvasDiv").html('');
				}else{
					drawMyChart(metDiff);
					$('#scontent2Scroll,#scontent2Scroll *').css("-webkit-transform","perspective(1200px) rotateY(60deg)");
					$('#scontent2Scroll,#scontent2Scroll *').css("-webkit-transform","perspective(0px) rotateY(0deg)");
				}
			}else{
				$("#login_msg").text('获取数据失败!');
				$("#canvasDiv").html('');
			}
		}
		catch(e){
		   $("#login_msg").text("服务端返回数据错误!");
		   $("#canvasDiv").html('');
		}
		setTimeout(function(){
			$("#waitlogin").fadeOut();
		},1000);
	},function(e){
		$("#login_msg").text(e);
		$("#canvasDiv").html('');
		setTimeout(function(){
			$("#waitlogin").fadeOut();
		},1000);
	});
}


//绘制图表
function drawMyChart(jsonData){
	//如果所有的数据都为0(则不画饼图,否则iChartjs组件会出错)
	if(jsonData.k1_COUNT==0 && jsonData.k2_COUNT==0 && jsonData.k3_COUNT==0 && jsonData.k4_COUNT==0 && jsonData.k5_COUNT==0 && jsonData.m1_COUNT==0 && jsonData.m2_COUNT==0 && jsonData.m3_COUNT==0 && jsonData.m4_COUNT==0 && jsonData.m5_COUNT==0){
		$("#canvasDiv").html('');
		$("#login_msg").text('数据为空!');
		return;
	}
	
	var array = new Array();
	array.push({name:'快3~5分钟',value:jsonData.k1_COUNT,color:'#be7156'});
	array.push({name:'快5~15分钟',value:jsonData.k2_COUNT,color:'#cea841'});
	array.push({name:'慢5~3分钟',value:jsonData.m1_COUNT,color:'#b66093'});
	array.push({name:'慢15~5分钟',value:jsonData.m2_COUNT,color:'#bb8442'});
	array.push({name:'慢1天以上',value:jsonData.m5_COUNT,color:'#bb8442'});
	array.push({name:'慢1天～1小时',value:jsonData.m4_COUNT,color:'#5da392'});
	array.push({name:'慢1小时~15分钟',value:jsonData.m3_COUNT,color:'#5a87a4'});
	array.push({name:'快1天以上',value:jsonData.k5_COUNT,color:'#5a87a4'});
	array.push({name:'快1小时～1天',value:jsonData.k4_COUNT,color:'#7bb037'});
	array.push({name:'快15分钟~1小时',value:jsonData.k3_COUNT,color:'#bcc73e'});
	
	//设置个数
	for(var i=0;i<array.length;i++){
		$(".scontent2 ul li:eq("+i+") div:last").html(array[i].value);
	}
	
    new iChart.Pie2D({
		render : 'canvasDiv',
	    data: array,
		background_color : 'rgba(0,0,0,0)',
		title : '',
		bound_event: function(){},
		border:{
			enable:false
		},
		legend : {
			enable : false
		},
		showpercent:true,
		decimalsnum:2,
		width :600,
		height :360,
		radius:'90%'
   }).draw();
}


//显示界面第一部分
function showComponent1(){
	$("#show_footer").css("display","none")
	$(".contentlist:first-child").css("display","block")
	$(".contentlist:last-child").css("display","none")
	$(".listcontenta").css("height",(printHeight+128)+"px");
}

//显示界面第二部分
function showComponent2(){
	$("#show_footer").css("display","block")
    $(".contentlist:first-child").css("display","none")
	$(".contentlist:last-child").css("display","block")
	$(".listcontenta").css("height",(printHeight+8-80)+"px");
}
