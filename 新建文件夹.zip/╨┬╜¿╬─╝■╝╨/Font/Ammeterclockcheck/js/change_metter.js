//校时相关js
var user_flag=0;
//电能表日期和时间字符串(校时前)
var meter_date_time="";
//(校时后)
var meter_date_time2="";
//编程模式校时后时间
var meter_date_time3="";
//校时前时间偏差(单位秒)
var meter_time_offset='';
//校时后时间偏差
var meter_time_offset2='';
//编程模式校时后偏差
var meter_time_offset3='';

var testJs = {};
var myJs = {};

//置空全局变量
function clearData(){
	meter_date_time="";
	meter_date_time2="";
	meter_date_time3="";
	meter_time_offset='';
	meter_time_offset2='';
	meter_time_offset3='';
}

//按"红外"按钮发送请求获取电表时间
function prepare_readAmmeter(){
	user_flag=0;
	//每次点"红外的时候"将之前的数据清空掉
	clearData();
	sendReqToGetTime();
}

//发送红外获取电表时间
function sendReqToGetTime(){
	//当前资产编号
	var input_assetNo = $("#szjd_asset_input").html().trim();
	if(input_assetNo==''){
		showToast("请扫描电表条形码!");
		//设置提示框内容	
		$(".checkcontent").html('请扫描电表条形码!');
		return;
	}
	
	if(click_flag){
		click_flag = false;
		setTimeout(function(){
			click_flag = true;
		},3000);
		
		//挂起进度条
		$("#login_msg").text('获取电表时间...');
		$("#waitlogin").fadeIn();
		//设置提示框内容	
		$(".checkcontent").html('获取电能表时间中...,请将蓝牙终端对准红外接口!');
		
		//将电表地址中字母换成数字0
		var meter_addr = input_assetNo.replace(/[a-z|A-Z]/g, "0");
		if(meter_addr.length==9){
			meter_addr='0'+meter_addr;
		}
		
		//发送请求(红外方式)获取电表日期和时间
		send_Bt_Instruct_New('{"nameSpace":"testJs","code07":"04000101,04000102","code97":"C010,C011","address":"00'+meter_addr+'"}',null,null);
	}
}


//校时完成后重新获取电表时间以判定是成功还是失败
function sendReqToGetTime2(){
	var input_assetNo = $("#szjd_asset_input").html().trim();
	var meter_addr = input_assetNo.replace(/[a-z|A-Z]/g, "0");
	if(meter_addr.length==9){
		meter_addr='0'+meter_addr;
	}
	//发送请求(红外方式)获取电表日期和时间
	send_Bt_Instruct_New('{"nameSpace":"testJs","code07":"04000101,04000102","code97":"C010,C011","address":"00'+meter_addr+'"}',null,null);
}


//获取电表的日期和时间的回调函数
/**
 * 扫描返回方法
 * code：当前命令
 * data：数据信息
 * flag：是否扫描结束（end时本次扫描结束）
 * next：下一个即将扫描的命令
 * errCode：错误码（-1：无错误，
 *                0:请检查电能表是否通电或表以损坏,
 *                1:未抄到数据，请对准红外接口,
 *                2:为测试电表型号时使用,
 *                3:命令错误,
 *                4:未得到数据(可能是红外传输异常导致)） 
 * type:97表示1997表，07表示2007表
 */
testJs.returnSendDataFun = function(code,data,flag,next,errCode,type){
	console.log("code: "+code+",data: "+data+",errCode: "+errCode+",flag="+flag+",errCode="+errCode+",type="+type);
	//alert("code: "+code+",data: "+data+",errCode: "+errCode);
	var error_msg="电表时间获取中...";
    if(code=="04000101" || code=="C010"){
	    //电表日期(2014/01/26 19:34:27)
	    if(user_flag==0){
	    	meter_date_time='20'+data.replace(/[:]/g,'/');
	    }else if(user_flag==2){
	    	meter_date_time2='20'+data.replace(/[:]/g,'/');
	    }else if(user_flag==3){
	    	meter_date_time3='20'+data.replace(/[:]/g,'/');
	    }
    }else if(code=="04000102" || code=="C011"){
    	var regExp = /^\d{2}[:]{1}\d{2}[:]{1}\d{2}$/;
    	//异常情况处理,如果data不是dd:dd:dd这种格式,则清空数据
    	if(!data.match(regExp)){
    		//设置当前时间偏差
	        $("#cur_span").text("");
	        //设置电表时间
	        $("#meter_time").text('');
	        $("#ter_time").text('');
	        $("#check_result").html('');
    	}else{
    		if(user_flag==0){
	    		meter_date_time+=" "+data;
			    var meter_date = new Date(meter_date_time);
			    
			    //时间偏差从毫秒数转为分钟(手机时间减去电表时间)
			    var date = new Date();
			    var time_offset = date.getTime()-meter_date.getTime();
			    //设置当前时间偏差
			    var set_cr_time = time_offset/(1000*60);
			    $("#cur_span").text(isNaN(set_cr_time)?'':(set_cr_time.subStr(2)+"分钟"));
			    meter_time_offset = time_offset/1000;
			    
			    //设置电表时间
			    $("#meter_time").text(isNaN(set_cr_time)?'':meter_date_time);
			    //设置终端时间
			    var date_str = date.getFullYear()+"/"+add_zero(date.getMonth()+1)+"/"+add_zero(date.getDate())+" "+add_zero(date.getHours())
			       +":"+add_zero(date.getMinutes())+":"+add_zero(date.getSeconds());
			    $("#ter_time").text(isNaN(set_cr_time)?'':date_str);
    		}else if(user_flag==2){
    			meter_date_time2+=" "+data;
			    var meter_date2 = new Date(meter_date_time2);
			    
			    var date2 = new Date();
			    var time_offset2 = date2.getTime()-meter_date2.getTime();
			    meter_time_offset2 = time_offset2/1000;
    		}else if(user_flag==3){
    			meter_date_time3+=" "+data;
    			var meter_date3 = new Date(meter_date_time3);
    			
    			var date3 = new Date();
			    var time_offset3 = date3.getTime()-meter_date3.getTime();
			    meter_time_offset3 = time_offset3/1000;
    		}
    	}
     }else if(code==""){
      	//如果返回失败
      	error_msg = getErrorMsg(data);
     }
	
	if(flag=="end"){
		//获取电表时间
		if(user_flag==0){
		   if(error_msg!='电表时间获取中...'){
			   $("#login_msg").text(error_msg);
			   $("#cur_span").text('');
			   $("#meter_time").text('');
			   $("#ter_time").text('');
			   
			   //设置提示框内容	
	           $(".checkcontent").html('读取电能表时间失败!'+error_msg);
	           //清除校时结果
	           $("#check_result").html('');
	           
	           setTimeout(function(){
			      $("#waitlogin").fadeOut();
		       },1000);
		   }else{
		   	  if(isNaN(meter_time_offset)){
		   	  	 //如果电表时间包含字母,则读取电表时间出错了
		   	  	 $("#login_msg").text('读取电表时间错误,不是一个有效的时间!');
		   	  	 $(".checkcontent").html('读取电表时间错误,不是一个有效的时间!');
		   	  	 $("#cur_span").text('');
			     $("#meter_time").text('');
			     $("#ter_time").text('');
			     $("#check_result").html('');
			     setTimeout(function(){$("#waitlogin").fadeOut();},1000);
		   	  }else if(meter_time_offset==''|| $("#meter_time").text()=='' ||$("#ter_time").text()==''){
			     $("#login_msg").text('未抄到数据,无此命令!');
		   	  	 $(".checkcontent").html('未抄到数据,无此命令!');
		   	  	 setTimeout(function(){$("#waitlogin").fadeOut();},1000);
		   	  }
		   	  else{
		   	  	 //开始校时操作
		   	     change_meter_time(meter_date_time,meter_time_offset);
		   	  }
		   }
		}else if(user_flag==1){
			if(error_msg.indexOf('校时失败')!=-1){
				$("#login_msg").text(error_msg);
		   	  	$(".checkcontent").html(error_msg);
		   	  	setTimeout(function(){
    			   $("#waitlogin").fadeOut();
    		    },800)
			}
			else if(error_msg!='电表时间获取中...'){
			   //校时完成重新获取电表时间以判断是成功还是失败!
			   user_flag = 2;
			   sendReqToGetTime2();
		    }
		}else if(user_flag==2){
			var c_msg = getErrorMsg(data);
			if(c_msg!='电表时间获取中...'){
				$("#login_msg").text("校时失败!"+c_msg);
		   	  	$(".checkcontent").html("校时失败!"+c_msg);
		   	  	$("#check_result").html("校时失败!");
		   	  	setTimeout(function(){$("#waitlogin").fadeOut();},1000);
		   	  	return;
			}
			
			var my_offset = Math.abs(meter_time_offset2-meter_time_offset);
			//如果两次偏差的差值小于10秒钟则认为其校时失败了
			if(my_offset<=10){
				 var currentOffset = (meter_time_offset2/60).subStr(2);
				 $("#login_msg").text('校时失败');
				 $("#check_result").html('校时失败,偏差:'+currentOffset+'分钟');
				 //设置提示框内容	
	             $(".checkcontent").html('校时失败!');
				 setTimeout(function(){
				 	 handleFailed(currentOffset,2);
				 },1000);
			}else{
				 $("#login_msg").text('校时成功!');
				 $("#check_result").html('校时成功,偏差:'+((meter_time_offset2/60).subStr(2))+'分钟');
				  //设置提示框内容	
	             $(".checkcontent").html('校时成功!');
				 //获取obj_check_id的值
				 var obj_check_id = $("#obj_check_id").text();
				 //开始上装数据
				 addClockDiff(obj_check_id,meter_date_time2.replace(/[/]/g,"-"),meter_time_offset2);
			}
		}else if(user_flag==3){
			var my_offset = Math.abs(meter_time_offset3-meter_time_offset);
			//如果两次偏差的差值小于10秒钟则认为其校时失败了
			if(my_offset<=10){
				 var currentOffset = (meter_time_offset3/60).subStr(2);
				 $("#login_msg").text('校时失败');
				 $("#check_result").html('校时失败,偏差:'+currentOffset+'分钟');
				 //设置提示框内容	
	             $(".checkcontent").html('校时失败!');
				 setTimeout(function(){
				 	 handleFailed(currentOffset,3);
				 },1000);
			}else{
				 $("#login_msg").text('校时成功!');
				 $("#check_result").html('校时成功,偏差:'+((meter_time_offset3/60).subStr(2))+'分钟');
				  //设置提示框内容	
	             $(".checkcontent").html('校时成功!');
				 //获取obj_check_id的值
				 var obj_check_id = $("#obj_check_id").text();
				 //开始上装数据
				 addClockDiff(obj_check_id,meter_date_time3.replace(/[/]/g,"-"),meter_time_offset3);
			}
		}
	}
}


//解析并处理错误信息
function getErrorMsg(data){
	var error_msg ='电表时间获取中...';
	if(data.indexOf("未得到数据")!=-1){
  	   error_msg="未得到数据!";
  	}else if(data.indexOf("请检查电能表")!=-1){
  	   error_msg="请检查电能表是否通电或表已损坏!";
  	}else if(data.indexOf("未抄到数据")!=-1){
  	   error_msg="未抄到数据，请对准红外接口!";
  	}else if(data.indexOf("为测试电表")!=-1){
  	   error_msg="为测试电表型号时使用!";
  	}else if(data.indexOf("命令错误")!=-1){
  	   error_msg="命令错误!";
  	}else if(data.indexOf("校时完成")!=-1){
  		error_msg="校时完成!";
  	}else if(data.indexOf("校时失败")!=-1){
  		error_msg="校时失败,请对准红外接口!";
  	}
  	return error_msg;
}


//编程校时回调
myJs.returnSendDataFun = function(code,data,flag,next,errCode,type){
    if(flag=="end"){
    	if(data=="校时完成"){
    		user_flag = 3;
	        sendReqToGetTime2();
    	}else{
    		 $("#login_msg").text(data);
    		 $("#check_result").html(data);
    		 $(".checkcontent").html(data);
    		setTimeout(function(){
    			$("#waitlogin").fadeOut();
    		},500)
    	}
    }
}


//校时失败时,如果发现其偏差范围与上次偏差相比超过2分钟,则更新记录
function handleFailed(currentOffset,type){
	 //获取obj_check_id的值
	 var obj_check_id = $("#obj_check_id").text();
	 if(obj_check_id!=''){
	 	//获取上次偏差值
	 	var lastOffset = $("#last_offset").text().replace('分钟','');
	 	if(lastOffset=='' || Math.abs(Number(currentOffset)-Number(lastOffset))>2){
	 		$("#login_msg").text('更新上次校时偏差...');
	 		//电表时间
	 		var ss_meter_t = '';
	 		if(type==2){
	 			ss_meter_t = meter_date_time2.replace(/[/]/g,"-");
	 		}else if(type==3){
	 			ss_meter_t = meter_date_time3.replace(/[/]/g,"-");
	 		}
	 		addClockDiff(obj_check_id,ss_meter_t,Number(currentOffset)*60);
	 	}else{
	 		$("#waitlogin").fadeOut();
	 	}
	 }else{
	 	$("#waitlogin").fadeOut();
	 }
}


//更改电表时间
//meter_date_time:当前电表时间
//offset:时间偏差
function change_meter_time(meter_date_time,offset){
	//编程模式校时
	if(check_tap_flag==1){
		//偏差单位为秒,换成小时
		offset = Number(offset)/(60*60);
		
		if(offset>=-1 && offset<=1){
			//电表资产编号
			var t_address = ($("#szjd_asset_input").html()).replace(/[a-z|A-Z]/g, "0");
			if(t_address.length==9){
			   t_address='0'+t_address;
		    }
		    
		    //处理用户id
		    var user_name = localStorage.user_name;
		    var regExpp = /\d/g;
		    if(new RegExp(regExpp).test(user_name)){
		    	user_name="00"+user_name;
		    }else{
		    	user_name="00000000";
		    }
		    
		    //拼凑时间时间字符串参数(格式yymmddhhmmss)
		    var systemDate = new Date();
		    var param_times = (systemDate.getFullYear()+"").substring(2)+add_zero(systemDate.getMonth()+1)+add_zero(systemDate.getDate())+add_zero(systemDate.getDay())+","
		                 +add_zero(systemDate.getHours())+add_zero(systemDate.getMinutes())+add_zero(systemDate.getSeconds());
		    //设置提示框内容	
		    $(".checkcontent").html('编程校时中...,请保持蓝牙设备对准红外接口!');
		    $("#login_msg").text('编程校时中...');
		    
			changeTime_code('{"nameSpace":"myJs","code07":"04000101,04000102","code97":"C010,C011","address":"00'+t_address+'","operator":"'+user_name+'","value":"'+param_times+'"}',null,null);
		}else{
			alert("时间偏差超过1个小时,无法校时!");
			$(".checkcontent").html('时间偏差超过1个小时,无法校时!');
			$("#check_result").html("无法校时");
			$("#waitlogin").fadeOut();
		}
	}else{
		//红外校时
		var meterDate = new Date(meter_date_time);
		if(offset>=-10 && offset<=10){
			//10秒之内不用校时
			$(".checkcontent").html('偏差少于10秒钟无需校时!');
			$("#check_result").html('无需校时');
			$("#login_msg").text('无需校时!');
		    $("#waitlogin").fadeOut();
			return;
		}else if(offset>=-300 && offset<=300){
			//-5到5分钟之内的使用系统时间
			meterDate = new Date();
		}else if(offset>300 && offset<1020){
			//5--17分钟
			meterDate.setMinutes(meterDate.getMinutes()+5);
		}else if(offset>-1020 && offset<-300){
			//-5到-17分钟
			meterDate.setMinutes(meterDate.getMinutes()-4);
		}else{
			$("#login_msg").text("电表时间偏差较大,无法校对!");
			//设置提示框内容	
		    $(".checkcontent").html('&nbsp;&nbsp;&nbsp;&nbsp;电表时间偏差较大,无法校对!请调整系统时间使偏差范围在5分钟之内,再进行校时操作!');
		    $("#check_result").html('无法校对');
		    $("#waitlogin").fadeOut();
		    return;
		}
		
		user_flag=1;
		//拼凑时间时间字符串参数(格式yymmddhhmmss)
		var param_time = (meterDate.getFullYear()+"").substring(2)+add_zero(meterDate.getMonth()+1)+add_zero(meterDate.getDate())
		                 +add_zero(meterDate.getHours())+add_zero(meterDate.getMinutes())+add_zero(meterDate.getSeconds());
		//电表资产编号
		var t_address = ($("#szjd_asset_input").html()).replace(/[a-z|A-Z]/g, "0");
		if(t_address.length==9){
		   t_address='0'+t_address;
	    }
	    //设置提示框内容	
		$(".checkcontent").html('校时中...,请保持蓝牙设备对准红外接口!');
		$("#login_msg").text('校时中...');
		changeTime('{"date":"'+param_time+'","address":"00'+t_address+'"}',null,null);
	}
}


//向采集系统上传电表偏差记录(新增和修改)
function addClockDiff(obj_check_id,meter_time,timeOffset){
	//获取电表资产号
	var asset_no = $("#szjd_asset_input").html();
    //系统时间
    var date  = new Date();
    var date_str = date.getFullYear()+"-"+add_zero(date.getMonth()+1)+"-"+add_zero(date.getDate())+" "+add_zero(date.getHours())
			       +":"+add_zero(date.getMinutes())+":"+add_zero(date.getSeconds());
   
	var pkg_my='';
	if(obj_check_id!=''){
		//修改操作
		pkg_my = '{"MOD":"03","FUN":"03","USR":"'+localStorage.user_name+'","ORG_NO":"'+localStorage.ORG_NO+'","PKG_TYPE":"0","PKG":{"OBJ_DATE":"'+meter_time+'","SYSTEM_DATE":"'+date_str+'","TIME_DIFF":"'+timeOffset+'","ASSET_NO":"'+asset_no+'","OBJ_CHECK_ID":"'+obj_check_id+'"}}';
	}else{
		//新增操作
		pkg_my = '{"MOD":"03","FUN":"02","USR":"'+localStorage.user_name+'","ORG_NO":"'+localStorage.ORG_NO+'","PKG_TYPE":"0","PKG":{"OBJ_DATE":"'+meter_time+'","SYSTEM_DATE":"'+date_str+'","TIME_DIFF":"'+timeOffset+'","ASSET_NO":"'+asset_no+'"}}';
	}
	
	$("#login_msg").text('数据上装中...');
	$(".checkcontent").html('数据上装中...');
	send_data("0000","2019",pkg_my,function(successData){
		try{
			successData = JSON.parse(successData);
			console.log("上装完成,数据返回为: "+JSON.stringify(successData));
			if(successData.PKG.RET=='01'){
				$("#login_msg").text(successData.PKG.PKG.MSG);
				$(".checkcontent").html('数据'+successData.PKG.PKG.MSG);
			}else{
				var js_msg = successData.PKG.PKG.MSG
				if(js_msg.indexOf("上装失败")!=-1){
					$("#login_msg").text(js_msg);
					$(".checkcontent").html(js_msg);
				}else{
					$("#login_msg").text("上装失败!"+js_msg);
					$(".checkcontent").html("上装失败!"+js_msg);
				}
			}
		}
		catch(e){
			$("#login_msg").text("数据上装失败!服务端返回数据错误!");
			$(".checkcontent").html("数据上装失败!服务端返回数据错误!");
		}
		
		setTimeout(function(){
			$("#waitlogin").fadeOut();
		},1000)
	},function(e){
		$(".checkcontent").html('数据上装失败了...,原因是: '+e);
		$("#login_msg").text(e);
		setTimeout(function(){
			$("#waitlogin").fadeOut();
		},1000)
	});
}


//如果数字小于10,则在前面加0
function add_zero(num){
	if(num<10){
		num='0'+num;
	}
	return num+'';
}

//截取数字,保留length位小数
Number.prototype.subStr = function(length){
	var that = this;
	that += '';
	try{
		//获取.所在的索引
		var index = that.indexOf('.');
		if(index!=-1 && length<=(that.length-(index+1))){
			return that.substring(0,index+length+1);
		}
	}
	catch(e){
		console.log("数据截取出错..."+e);
	}
	return that;
}
