<script type="text/javascript">
/**
 * * 检查能效服务情况对应表数据
 * @param cr_id=检查结果唯一标识
 * @param bptsdj=能效服务_有无变频调速电机
 * @param jndj=能效服务_照明是否为节能灯具
 * @param sfyr=能效服务_是否利用余热
 * @param gpdy=能效服务_有无化学用高频电源
 * @param fshgsb=能效服务_有无红外辐射烘干设备
 * @param kyj_ptsb=能效服务_有无空压机及配套设备
 * @param jdccsb=能效服务_有无静电除尘设备
 * @param jnktxt=能效服务_有无节能空调系统
 * @param jnyy=能效服务_用户是否存有节能意愿
 * @param smfw=能效服务_是否通知节能服务公司上门服务
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询界面数据
function get_yj_s_gwzyxj_energ_eff_data(json_where,sucessCB,failCB){
	var sql="select id as id,bptsdj as bptsdj,jndj as jndj,sfyr as sfyr,gpdy as gpdy,fshgsb as fshgsb,kyj_ptsb as kyj_ptsb,jdccsb as jdccsb,jnktxt as jnktxt,jnyy as jnyy,smfw as smfw,bptsdj_img as bptsdj_img,jndj_img as jndj_img,sfyr_img as sfyr_img,gpdy_img as gpdy_img,fshgsb_img as fshgsb_img,jdccsb_img as jdccsb_img,jnktxt_img as jnktxt_img,kyj_ptsb_img as kyj_ptsb_img,smfw_img as smfw_img from YJ_S_GWZYXJ where cr_id=?";
	db_execut_oneSQL(null,sql,json_where,sucessCB,failCB);
}
/**
 * 问题反馈
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询问题反馈数据
function get_yj_problem_feedback_data(json_where1,sucessCB1,failCB1){
	 var pro_sql="select problem as problem,statue as statue from YJ_PROBLEM_FEEDBACK where dtl_id=? and cons_id=? and rrio_code=? and modle_type=?";
	 db_execut_oneSQL(null,pro_sql,json_where1,sucessCB1,failCB1);
}

/**
 * 
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @param sstatue 数据状态，0为空，1有值；为空时执行插入，有值时执行更新
 * @return
 */
//保存界面数据
function save_energe_data(json_where,sucessCB1,failCB1,sstatue){
	var update="update YJ_S_GWZYXJ set bptsdj=?,jndj=?,sfyr=?,gpdy=?,fshgsb=?,kyj_ptsb=?,jdccsb=?,jnktxt=?,jnyy=?,smfw=?,bptsdj_img=?,jndj_img=?,sfyr_img=?,gpdy_img=?,fshgsb_img=?,jdccsb_img=?,jnktxt_img=?,kyj_ptsb_img=?,smfw_img=? where cr_id=?";
	var insert="INSERT INTO YJ_S_GWZYXJ (id,cr_id,bptsdj,jndj,sfyr,gpdy,fshgsb,kyj_ptsb,jdccsb,jnktxt,jnyy,smfw,bptsdj_img,jndj_img,sfyr_img,gpdy_img,fshgsb_img,jdccsb_img,jnktxt_img,kyj_ptsb_img,smfw_img) VALUES ('0',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if(sstatue==0){
	 db_execut_oneSQL(null,insert,json_where,sucessCB1,failCB1);
}else if(sstatue==1){
	 db_execut_oneSQL(null,update,json_where,sucessCB1,failCB1);
}
}
/**
 * 
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @param sstatue 数据状态，0为空，1有值；为空时执行插入，有值时执行更新
 * @return
 */
//保存问题反馈数据
function save_energepro_data(json_where,sucessCB1,failCB1,sstatue){
	var pro_update="update YJ_PROBLEM_FEEDBACK set PROBLEM=?,STATUE=? where dtl_id=? and cons_id=? and rrio_code=? and modle_type=?";
	var pro_insert="INSERT INTO YJ_PROBLEM_FEEDBACK (DTL_ID,CONS_ID,RRIO_CODE,MODLE_TYPE,PROBLEM,STATUE) VALUES (?,?,?,?,?,?)";
	if(sstatue==0){
		 db_execut_oneSQL(null,pro_insert,json_where,sucessCB1,failCB1);
	}else if(sstatue==1){
		 db_execut_oneSQL(null,pro_update,json_where,sucessCB1,failCB1);
	}
}
/*保存修改记录到表YJ_DATA_COMPARISON_DTL_ID*/
function save_Correct_Record(){
	var select_sql="select DATA_ID from YJ_DATA_COMPARISON_DTL_ID where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 db_execut_oneSQL(null,select_sql,[cons_info.dtl_id,cons_info.cons_id,'A0007'],save_sucessCB1,savefailCB1);
}
/*查询成功回调*/
var save_sucessCB1 = function(tx,res){
	 var sql_upnm="update YJ_DATA_COMPARISON_DTL_ID set LINE_DATA=?,TYPE=? where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 var sql_insert="insert into YJ_DATA_COMPARISON_DTL_ID (MODEL_TYPE,MODEL_TITLE,TYPE,OLD_DATA_INDEX,OLD_DATA,LINE_DATA,DTL_ID,CONS_ID) values (?,?,?,?,?,?,?,?)";
		 var result_len=res.rows.length;
//		 alert(result_len);
		 	if(result_len){//更新
		 		 db_execut_oneSQL(null,sql_upnm,['{"有无变频调速电机":"'+text1[0][temp_val[0]-1]+'","照明是否为节能灯具":"'+text1[1][temp_val[1]-1]+'","是否利用余热":"'+text1[2][temp_val[2]-1]+'","有无化学用高频电源":"'+text1[3][temp_val[3]-1]+'","有无红外线辐射烘干设备":"'+text1[4][temp_val[4]-1]+'","有无空压机及配套设备":"'+text1[5][temp_val[5]-1]+'","有无静电除尘设备":"'+text1[6][temp_val[6]-1]+'","有无节能空调系统":"'+text1[7][temp_val[7]-1]+'","用户是否存在节能意愿":"'+text1[8][temp_val[8]-1]+'","是否通知节能服务公司上门服务":"'+text1[9][temp_val[9]-1]+'"}',"2",cons_info.dtl_id,cons_info.cons_id,"A0007"],null,null);
		 	}else{//插入
		 		 db_execut_oneSQL(null,sql_insert,["A0007","检查能效服务情况","2","",json_olddate,'{"有无变频调速电机":"'+text1[0][temp_val[0]-1]+'","照明是否为节能灯具":"'+text1[1][temp_val[1]-1]+'","是否利用余热":"'+text1[2][temp_val[2]-1]+'","有无化学用高频电源":"'+text1[3][temp_val[3]-1]+'","有无红外线辐射烘干设备":"'+text1[4][temp_val[4]-1]+'","有无空压机及配套设备":"'+text1[5][temp_val[5]-1]+'","有无静电除尘设备":"'+text1[6][temp_val[6]-1]+'","有无节能空调系统":"'+text1[7][temp_val[7]-1]+'","用户是否存在节能意愿":"'+text1[8][temp_val[8]-1]+'","是否通知节能服务公司上门服务":"'+text1[9][temp_val[9]-1]+'"}',cons_info.dtl_id,cons_info.cons_id],null,null);
		 	}
	 }
/*查询失败回调*/
var savefailCB1=function(){
	 
}


</script>