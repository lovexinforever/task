

var yj_otdata="";		//YJ_S_GWZYXJ数据对象
var idsz="";																//数据库表中主键id
var yj_otdata_contr=""; //合同js对象


/*****上装时实时查询数据--id*****/
function select_ontime_data(){
	var sql="select * from YJ_S_GWZYXJ where CR_ID=?";
	db_execut_oneSQL(null,sql,[cons_info.cr_id],sucessCB_select_ontime_data,null);
	function sucessCB_select_ontime_data(tx,res){
		var ss=res.rows.length;
//		alert(ss+"ss");
		if(ss){
			yj_otdata=res.rows.item(0);
			idsz=yj_otdata.ID;
//			alert(idsz+"idsz");
		}else{
			
		}
	}
	setTimeout(function(){
		sz_main_data();
	},300)
}

//合同表查询
function select_ontime_data_contract_xb(){
	var sql="select * from YJ_CHECK_CONS_SUP_CONTR where dtl_id=? and cons_id=?";
	db_execut_oneSQL(null,sql,[cons_info.dtl_id,cons_info.cons_id],sucessCB_select_ontime_data11,null);
	function sucessCB_select_ontime_data11(tx,res){
		var ss=res.rows.length;
		if(ss){
			yj_otdata_contr=res.rows.item(0);
		}else{
			
		}
	}
}

/*****上装时实时查询数据--id*****/
//上装
function upload_statu(){
	opendailog("businessList_laoding_view");//弹出加载效果框
	select_ontime_data_contract_xb();
	select_ontime_data();//查询实时数据
	
	
}

/*上装主函数*/
function sz_main_data(){
	//上装--信息新增pkg
	var PKG='{"MOD":"2003","FUN":"2302","LEN":"39","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"CR_ID":"'+cons_info.cr_id+'","MLKG_YW":"'+setUndefined(yj_otdata.MLKG_YW)+'","MLKG_CZSJ":"'+setUndefined(yj_otdata.MLKG_CZSJ)+'","MLKG_CZ":"'+setUndefined(yj_otdata.MLKG_CZ)+'","BZTZZ_YW":"'+setUndefined(yj_otdata.BZTZZ_YW)+'","ZBYJ_ZZ":"'+setUndefined(yj_otdata.ZBYJ_ZZ)+'","ZBYJ_XQ":"'+setUndefined(yj_otdata.ZBYJ_XQ)+'","ZBYJ_SJ":"'+setUndefined(yj_otdata.ZBYJ_SJ)+'","ZBYJ_FD":"'+setUndefined(yj_otdata.ZBYJ_FD)+'","SYJL":"'+setUndefined(yj_otdata.SYJL)+'","SYRQ":"'+setUndefined(yj_otdata.SYRQ)+'","SYXMQQ":"'+setUndefined(yj_otdata.SYXMQQ)+'","QSSBXM":"'+setUndefined(yj_otdata.QSSBXM)+'","JHAPSJ":"'+setUndefined(yj_otdata.JHAPSJ)+'","ZTYXQK":"'+setUndefined(yj_otdata.ZTYXQK)+'","BYQ":"'+setUndefined(yj_otdata.BYQ)+'","BYQ_RQ":"'+setUndefined(yj_otdata.BYQ_RQ)+'","BYQ_GZ":"'+setUndefined(yj_otdata.BYQ_GZ)+'","GDYCG":"'+setUndefined(yj_otdata.GDYCG)+'","GDYCG_RQ":"'+setUndefined(yj_otdata.GDYCG_RQ)+'","GDYCG_GZ":"'+setUndefined(yj_otdata.GDYCG_GZ)+'","DLQ":"'+setUndefined(yj_otdata.DLQ)+'","DLQ_RQ":"'+setUndefined(yj_otdata.DLQ_RQ)+'","DLQ_GZ":"'+setUndefined(yj_otdata.DLQ_GZ)+'","CTPT":"'+setUndefined(yj_otdata.CTPT)+'","CTPT_RQ":"'+setUndefined(yj_otdata.CTPT_RQ)+'","CTPT_GZ":"'+setUndefined(yj_otdata.CTPT_GZ)+'","WGBC":"'+setUndefined(yj_otdata.WGBC)+'","WGBC_RQ":"'+setUndefined(yj_otdata.WGBC_RQ)+'","WGBC_GZ":"'+setUndefined(yj_otdata.WGBC_GZ)+'","DL":"'+setUndefined(yj_otdata.DL)+'","DL_RQ":"'+setUndefined(yj_otdata.DL_RQ)+'","DL_GZ":"'+setUndefined(yj_otdata.DL_GZ)+'","AQJL":"'+setUndefined(yj_otdata.AQJL)+'","AQJL_GZ":"'+setUndefined(yj_otdata.AQJL_GZ)+'","DGGL_FZR":"'+setUndefined(yj_otdata.DGGL_FZR)+'","DGGL_ZB_RS":"'+setUndefined(yj_otdata.DGGL_ZB_RS)+'","DGGL_ZB_YPZ":"'+setUndefined(yj_otdata.DGGL_ZB_YPZ)+'","DGGL_JX_RS":"'+setUndefined(yj_otdata.DGGL_JX_RS)+'","DGGL_JX_YPZ":"'+setUndefined(yj_otdata.DGGL_JX_YPZ)+'","GCZD_BDS_YXGC":"'+setUndefined(yj_otdata.GCZD_BDS_YXGC)+'","GCZD_BDS_GWZR":"'+setUndefined(yj_otdata.GCZD_BDS_GWZR)+'","GCZD_BDS_ZBZD":"'+setUndefined(yj_otdata.GCZD_BDS_ZBZD)+'","GCZD_BDS_JJB":"'+setUndefined(yj_otdata.GCZD_BDS_JJB)+'","GCZD_XHJC":"'+setUndefined(yj_otdata.GCZD_XHJC)+'","GCZD_DQ_DQQH":"'+setUndefined(yj_otdata.GCZD_DQ_DQQH)+'","GCZD_DQ_DQXS":"'+setUndefined(yj_otdata.GCZD_DQ_DQXS)+'","GCZD_DQ_QXGL":"'+setUndefined(yj_otdata.GCZD_DQ_QXGL)+'","GCZD_DZDSD":"'+setUndefined(yj_otdata.GCZD_DZDSD)+'","GCZD_CR":"'+setUndefined(yj_otdata.GCZD_CR)+'","GCZD_YXJL":"'+setUndefined(yj_otdata.GCZD_YXJL)+'","GCZD_SBQX":"'+setUndefined(yj_otdata.GCZD_SBQX)+'","GCZD_SBQXJX":"'+setUndefined(yj_otdata.GCZD_SBQXJX)+'","GCZD_JDBH":"'+setUndefined(yj_otdata.GCZD_JDBH)+'","GCZD_SGJL":"'+setUndefined(yj_otdata.GCZD_SGJL)+'","GCZD_WLRYJL":"'+setUndefined(yj_otdata.GCZD_WLRYJL)+'","DXCZP":"'+setUndefined(yj_otdata.DXCZP)+'","BDSBYQHJ":"'+setUndefined(yj_otdata.BDSBYQHJ)+'","BDSBYQHJ_PRO":"'+setUndefined(yj_otdata.BDSBYQHJ_PRO)+'","AQQJ":"'+setUndefined(yj_otdata.AQQJ)+'","AQQJ_SYRQ":"'+setUndefined(yj_otdata.AQQJ_SYRQ)+'","AQQJ_BHGS":"'+setUndefined(yj_otdata.AQQJ_BHGS)+'","XFQC":"'+setUndefined(yj_otdata.XFQC)+'","XFQC_SFGQ":"'+setUndefined(yj_otdata.XFQC_SFGQ)+'","FXDW":"'+setUndefined(yj_otdata.FXDW)+'","BPBJ":"'+setUndefined(yj_otdata.BPBJ)+'","BJNR":"'+setUndefined(yj_otdata.BJNR)+'","YJYA_GZ":"'+setUndefined(yj_otdata.YJYA_GZ)+'","YJYA_BA":"'+setUndefined(yj_otdata.YJYA_BA)+'","PDFZBR":"'+setUndefined(yj_otdata.PDFZBR)+'","PDFZRR":"'+setUndefined(yj_otdata.PDFZRR)+'","GDHE":"'+setUndefined(yj_otdata.GDHE)+'","SFFH":"'+setUndefined(yj_otdata_contr.HTQTNR)+'","DWDDXY":"'+setUndefined(yj_otdata_contr.DWDDXY)+'","ZFDXY":"'+setUndefined(yj_otdata_contr.ZFDXY)+'","DFJSXY":"'+setUndefined(yj_otdata_contr.DFJSXY)+'","BJLYC":"'+setUndefined(yj_otdata.BJLYC)+'","YCNR":"'+setUndefined(yj_otdata.YCNR)+'","WYQD":"'+setUndefined(yj_otdata.WYQD)+'","QDCCGC":"'+setUndefined(yj_otdata.QDCCGC)+'","SS":"'+setUndefined(yj_otdata.SS)+'","FKTXFX":"'+setUndefined(yj_otdata.FKTXFX)+'","BX":"'+setUndefined(yj_otdata.BX)+'","LJ":"'+setUndefined(yj_otdata.LJ)+'","YL":"'+setUndefined(yj_otdata.YL)+'","YL_SJ":"'+setUndefined(yj_otdata.YL_SJ)+'","YL_JS":"'+setUndefined(yj_otdata.YL_JS)+'","BPTSDJ":"'+setUndefined(yj_otdata.BPTSDJ)+'","JNDJ":"'+setUndefined(yj_otdata.JNDJ)+'","SFYR":"'+setUndefined(yj_otdata.SFYR)+'","GPDY":"'+setUndefined(yj_otdata.GPDY)+'","FSHGSB":"'+setUndefined(yj_otdata.FSHGSB)+'","KYJ_PTSB":"'+setUndefined(yj_otdata.KYJ_PTSB)+'","JDCCSB":"'+setUndefined(yj_otdata.JDCCSB)+'","JNKTXT":"'+setUndefined(yj_otdata.JNKTXT)+'","JNYY":"'+setUndefined(yj_otdata.JNYY)+'","SMFW":"'+setUndefined(yj_otdata.SMFW)+'"}}'
	//上装--信息修改pkg
	var PKG1='{"MOD":"2003","FUN":"2303","LEN":"39","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"ID":"'+idsz+'","CR_ID":"'+cons_info.cr_id+'","MLKG_YW":"'+setUndefined(yj_otdata.MLKG_YW)+'","MLKG_CZSJ":"'+setUndefined(yj_otdata.MLKG_CZSJ)+'","MLKG_CZ":"'+setUndefined(yj_otdata.MLKG_CZ)+'","BZTZZ_YW":"'+setUndefined(yj_otdata.BZTZZ_YW)+'","ZBYJ_ZZ":"'+setUndefined(yj_otdata.ZBYJ_ZZ)+'","ZBYJ_XQ":"'+setUndefined(yj_otdata.ZBYJ_XQ)+'","ZBYJ_SJ":"'+setUndefined(yj_otdata.ZBYJ_SJ)+'","ZBYJ_FD":"'+setUndefined(yj_otdata.ZBYJ_FD)+'","SYJL":"'+setUndefined(yj_otdata.SYJL)+'","SYRQ":"'+setUndefined(yj_otdata.SYRQ)+'","SYXMQQ":"'+setUndefined(yj_otdata.SYXMQQ)+'","QSSBXM":"'+setUndefined(yj_otdata.QSSBXM)+'","JHAPSJ":"'+setUndefined(yj_otdata.JHAPSJ)+'","ZTYXQK":"'+setUndefined(yj_otdata.ZTYXQK)+'","BYQ":"'+setUndefined(yj_otdata.BYQ)+'","BYQ_RQ":"'+setUndefined(yj_otdata.BYQ_RQ)+'","BYQ_GZ":"'+setUndefined(yj_otdata.BYQ_GZ)+'","GDYCG":"'+setUndefined(yj_otdata.GDYCG)+'","GDYCG_RQ":"'+setUndefined(yj_otdata.GDYCG_RQ)+'","GDYCG_GZ":"'+setUndefined(yj_otdata.GDYCG_GZ)+'","DLQ":"'+setUndefined(yj_otdata.DLQ)+'","DLQ_RQ":"'+setUndefined(yj_otdata.DLQ_RQ)+'","DLQ_GZ":"'+setUndefined(yj_otdata.DLQ_GZ)+'","CTPT":"'+setUndefined(yj_otdata.CTPT)+'","CTPT_RQ":"'+setUndefined(yj_otdata.CTPT_RQ)+'","CTPT_GZ":"'+setUndefined(yj_otdata.CTPT_GZ)+'","WGBC":"'+setUndefined(yj_otdata.WGBC)+'","WGBC_RQ":"'+setUndefined(yj_otdata.WGBC_RQ)+'","WGBC_GZ":"'+setUndefined(yj_otdata.WGBC_GZ)+'","DL":"'+setUndefined(yj_otdata.DL)+'","DL_RQ":"'+setUndefined(yj_otdata.DL_RQ)+'","DL_GZ":"'+setUndefined(yj_otdata.DL_GZ)+'","AQJL":"'+setUndefined(yj_otdata.AQJL)+'","AQJL_GZ":"'+setUndefined(yj_otdata.AQJL_GZ)+'","DGGL_FZR":"'+setUndefined(yj_otdata.DGGL_FZR)+'","DGGL_ZB_RS":"'+setUndefined(yj_otdata.DGGL_ZB_RS)+'","DGGL_ZB_YPZ":"'+setUndefined(yj_otdata.DGGL_ZB_YPZ)+'","DGGL_JX_RS":"'+setUndefined(yj_otdata.DGGL_JX_RS)+'","DGGL_JX_YPZ":"'+setUndefined(yj_otdata.DGGL_JX_YPZ)+'","GCZD_BDS_YXGC":"'+setUndefined(yj_otdata.GCZD_BDS_YXGC)+'","GCZD_BDS_GWZR":"'+setUndefined(yj_otdata.GCZD_BDS_GWZR)+'","GCZD_BDS_ZBZD":"'+setUndefined(yj_otdata.GCZD_BDS_ZBZD)+'","GCZD_BDS_JJB":"'+setUndefined(yj_otdata.GCZD_BDS_JJB)+'","GCZD_XHJC":"'+setUndefined(yj_otdata.GCZD_XHJC)+'","GCZD_DQ_DQQH":"'+setUndefined(yj_otdata.GCZD_DQ_DQQH)+'","GCZD_DQ_DQXS":"'+setUndefined(yj_otdata.GCZD_DQ_DQXS)+'","GCZD_DQ_QXGL":"'+setUndefined(yj_otdata.GCZD_DQ_QXGL)+'","GCZD_DZDSD":"'+setUndefined(yj_otdata.GCZD_DZDSD)+'","GCZD_CR":"'+setUndefined(yj_otdata.GCZD_CR)+'","GCZD_YXJL":"'+setUndefined(yj_otdata.GCZD_YXJL)+'","GCZD_SBQX":"'+setUndefined(yj_otdata.GCZD_SBQX)+'","GCZD_SBQXJX":"'+setUndefined(yj_otdata.GCZD_SBQXJX)+'","GCZD_JDBH":"'+setUndefined(yj_otdata.GCZD_JDBH)+'","GCZD_SGJL":"'+setUndefined(yj_otdata.GCZD_SGJL)+'","GCZD_WLRYJL":"'+setUndefined(yj_otdata.GCZD_WLRYJL)+'","DXCZP":"'+setUndefined(yj_otdata.DXCZP)+'","BDSBYQHJ":"'+setUndefined(yj_otdata.BDSBYQHJ)+'","BDSBYQHJ_PRO":"'+setUndefined(yj_otdata.BDSBYQHJ_PRO)+'","AQQJ":"'+setUndefined(yj_otdata.AQQJ)+'","AQQJ_SYRQ":"'+setUndefined(yj_otdata.AQQJ_SYRQ)+'","AQQJ_BHGS":"'+setUndefined(yj_otdata.AQQJ_BHGS)+'","XFQC":"'+setUndefined(yj_otdata.XFQC)+'","XFQC_SFGQ":"'+setUndefined(yj_otdata.XFQC_SFGQ)+'","FXDW":"'+setUndefined(yj_otdata.FXDW)+'","BPBJ":"'+setUndefined(yj_otdata.BPBJ)+'","BJNR":"'+setUndefined(yj_otdata.BJNR)+'","YJYA_GZ":"'+setUndefined(yj_otdata.YJYA_GZ)+'","YJYA_BA":"'+setUndefined(yj_otdata.YJYA_BA)+'","PDFZBR":"'+setUndefined(yj_otdata.PDFZBR)+'","PDFZRR":"'+setUndefined(yj_otdata.PDFZRR)+'","GDHE":"'+setUndefined(yj_otdata.GDHE)+'","SFFH":"'+setUndefined(yj_otdata_contr.HTQTNR)+'","DWDDXY":"'+setUndefined(yj_otdata_contr.DWDDXY)+'","ZFDXY":"'+setUndefined(yj_otdata_contr.ZFDXY)+'","DFJSXY":"'+setUndefined(yj_otdata_contr.DFJSXY)+'","BJLYC":"'+setUndefined(yj_otdata.BJLYC)+'","YCNR":"'+setUndefined(yj_otdata.YCNR)+'","WYQD":"'+setUndefined(yj_otdata.WYQD)+'","QDCCGC":"'+setUndefined(yj_otdata.QDCCGC)+'","SS":"'+setUndefined(yj_otdata.SS)+'","FKTXFX":"'+setUndefined(yj_otdata.FKTXFX)+'","BX":"'+setUndefined(yj_otdata.BX)+'","LJ":"'+setUndefined(yj_otdata.LJ)+'","YL":"'+setUndefined(yj_otdata.YL)+'","YL_SJ":"'+setUndefined(yj_otdata.YL_SJ)+'","YL_JS":"'+setUndefined(yj_otdata.YL_JS)+'","BPTSDJ":"'+setUndefined(yj_otdata.BPTSDJ)+'","JNDJ":"'+setUndefined(yj_otdata.JNDJ)+'","SFYR":"'+setUndefined(yj_otdata.SFYR)+'","GPDY":"'+setUndefined(yj_otdata.GPDY)+'","FSHGSB":"'+setUndefined(yj_otdata.FSHGSB)+'","KYJ_PTSB":"'+setUndefined(yj_otdata.KYJ_PTSB)+'","JDCCSB":"'+setUndefined(yj_otdata.JDCCSB)+'","JNKTXT":"'+setUndefined(yj_otdata.JNKTXT)+'","JNYY":"'+setUndefined(yj_otdata.JNYY)+'","SMFW":"'+setUndefined(yj_otdata.SMFW)+'"}}'
	if(idsz && idsz!=0){//表中存在id，则发送信息修改的pkg
		send_data("2303","2003",PKG1,successCallBack,faileCallBack);
	}else{//表中不存在id,则发送信息新增新增pkg
		send_data("2302","2003",PKG,successCallBack,faileCallBack);
	}
	//上装成功回调
	function successCallBack(message_ener){
try{
		$("#businessList_laoding_view").hide();//关闭加载效果框
		var msg_enercb = JSON.parse(message_ener);
		if(msg_enercb.RET=="00"){
			var msg_pkg_jx=msg_enercb.PKG.PKG;
			var fun=msg_enercb.FUN;
			if(msg_pkg_jx.SUCCESS_FLAG=="0"){
					insert_success_2();//弹出上装成功框
					//重要客户巡检记录信息新增
			       if(fun=="2302"){
			          db_execut_oneSQL(null,"update YJ_S_GWZYXJ set ID=?,UPLOADING_TYPE=?,UPLOADING_DATE=? where CR_ID=?",[msg_pkg_jx.id,2,new Date(),cons_info.cr_id],null,null);
					}
					//重要客户巡检记录信息修改
			        else if(fun=="2303"){
			    	 db_execut_oneSQL(null,"update YJ_S_GWZYXJ set UPLOADING_DATE=? where CR_ID=?",[new Date(),cons_info.cr_id],null,null);
					}
			}else{
				if(msg_pkg_jx.ERR_MSG){
					$("#yxzypt_msg").html(msg_pkg_jx.ERR_MSG);//给弹出框赋对应的提示消息
					onchange_val();
					$("#yxzypt_dailog").show();
				}else{
					$("#yxzypt_msg").html("上装失败!数据保存本地");//给弹出框赋对应的提示消息
					onchange_val();
					$("#yxzypt_dailog").show();
				}
			}
		}else{
				$("#yxzypt_msg").html("上装失败!数据保存本地");//给弹出框赋对应的提示消息
				onchange_val();
				$("#yxzypt_dailog").show();
		}
	}catch(e){
            $("#yxzypt_msg").html("上装失败!返回数据异常");//给弹出框赋对应的提示消息
            onchange_val();
            $("#yxzypt_dailog").show();
    }
}
	//上装失败回调
	function faileCallBack(){
		//$("#businessList_laoding_view").hide();//关闭加载效果框
		var pkgp="";
		if(idsz && idsz!=0){//表中存在id，则发送信息修改的pkg
			pkgp=PKG1;
			var msg_ti_str = '{"DTL_ID":"'+cons_info.dtl_id+'","CONS_ID":"'+cons_info.cons_id+'","MSG":"检查结果巡检记录上装失败","PKG":'+pkgp+',"ERROR_ID":"2303"}';
			upload_Data("2303","2003",pkgp,msg_ti_str,"yj_upload_proc");
		}else{//表中不存在id,则发送信息新增新增pkg
			pkgp=PKG;
			var msg_ti_str = '{"DTL_ID":"'+cons_info.dtl_id+'","CONS_ID":"'+cons_info.cons_id+'","MSG":"检查结果巡检记录上装失败","PKG":'+pkgp+',"ERROR_ID":"2302"}';
			upload_Data("2302","2003",pkgp,msg_ti_str,"yj_upload_proc");
		}
		setTimeout(function(){
			$("#businessList_laoding_view").css("display","none");//关闭加载效果框
		$("#yxzypt_msg").html("数据进入到上装队列，等待上装！");//给弹出框赋对应的提示消息
		onchange_val();
		$("#yxzypt_dailog").show();
		 },500);
	}
}

//数据库进行插入操作后，更新数据库数据标志 
function change_dataflag(){
	//更新界面数据状态，0为无数据，1为有数据
	if(data_staue==0){
		data_staue=1;
	}
}
function change_dataflag_pro(){
	//更新问题反馈表数据状态，0为无数据，1为有数据
	if(pro_data_staues==0){
		pro_data_staues=1;
	}
}