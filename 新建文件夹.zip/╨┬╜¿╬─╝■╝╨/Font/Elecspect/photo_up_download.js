<script type="text/javascript">
/**
 * 上传图片 
 * data String类型,{"FUN":"02","ORG_NO":sessionStorage.ORG_NO,"MOD":"2002","SSN":sessionStorage.SSN,"FILE":[{"NAME":"A1234678.jpg","URL":"2002/2012/09/06/0630000000789"}]} ;
 * 返回值 ： 1表示成功，0表示失败  {file_creat_time:"",file_size:"",msg:"",url:""}
 * 注意： 图片必须存在sdcadrd中photo目录下 
 */
/** 申请编号    APPNO
// 计划明细标识  DTL_ID
// 检查结果标识  INSPECT_ID
// 功能项号    FUN_ITEM    
// 检查项号    CHECK_ITEM   
 * ptoto_name:图片名称
 * photo_path：图片路径；
 * photo_service_path：图片服务器路径
 */
var check_i=new Array();//对应模块下面的所有图片的信息
/****************一个模块下全部图片上装***********************/
function upload_image_all_js(fun_model,function_name){
    check_i=new Array();
    var sql="select * from YJ_C_PHOTOESINFO where APP_NO=? and DTL_ID=? and CR_ID=? and FUN_ITEM=?";
    db_execut_oneSQL(null,sql,[sessionStorage.APP_NO_bl,cons_info.dtl_id,cons_info.cr_id,fun_model],function(tx,res){
        var ss=res.rows.length;
        if(ss){
            //查询到数据res.rows.item(0).DOWNLOAD_TYPE;
            for(var i=0;i<ss;i++){
               check_i[i]=res.rows.item(i);
                   if(res.rows.item(i).UPLOAD_TYPE==0){
                       var check_itemsv=check_i[i].FILE_NAME.split("_")[2].split(".")[0];//第几行拍照
                       if(check_i[i].FUN_ITEM=="A0011" && check_i[i].CHECK_ITEM=="05"){
                           upload_image_two_js("1010",fun_model,check_itemsv,check_i[i].FILE_SIZE,check_i[i].FILE_CREATE_TIME,check_i[i].FILE_PATH,check_i[i].FILE_NAME,function_name)
                        }else if(check_i[i].FUN_ITEM=="A0010" && check_i[i].CHECK_ITEM=="08"){
                           upload_image_two_js("1011",fun_model,check_itemsv,check_i[i].FILE_SIZE,check_i[i].FILE_CREATE_TIME,check_i[i].FILE_PATH,check_i[i].FILE_NAME,function_name)
                        }else{
                            upload_image_one_js(fun_model,check_itemsv,check_i[i].FILE_SIZE,check_i[i].FILE_CREATE_TIME,check_i[i].FILE_PATH,check_i[i].FILE_NAME,function_name);
                        }
                   }
            }
        }else{
        }
    },null);
}

/****************单张图片上装--检查项***********************/
function upload_image_one_js(fun_itemsv,check_itemsv,file_size,file_create_time,photo_path,ptoto_name,function_name){
    var photo_service_path=photo_path;                        //上传图片的服务器路劲
   
    upimage();//调用图片上传
    /*************调用图片上传*************/
    function upimage(){
        // $("#businessList_laoding_view").show();
        var data='{"FUN":"02","ORG_NO":"'+sessionStorage.ORG_NO+'","MOD":"2003","SSN":"'+sessionStorage.SSN+'","FILE":[{"NAME":"'+ptoto_name+'","path":"'+photo_path+'","INFO":"'+photo_service_path+'"}]}';
        var pkg = '{"MOD":"2003","FUN":"1007","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"APP_NO":"'+sessionStorage.APP_NO_bl+'","DTL_ID":"'+cons_info.dtl_id+'","CR_ID":"'+cons_info.cr_id+'","FUN_ITEM":"'+fun_itemsv+'","CHECK_ITEM":"'+check_itemsv+'","FILE_FORMAT":"JPG","FILE_SIZE":"'+file_size+'","FILE_CREATE_TIME":"'+file_create_time+'","FILE_NAME":"'+ptoto_name+'","FILE_PATH":"'+photo_path+'"}}';
        uploadImageCheck(data,"1007","2003",pkg,null,function_name);
    }
}


/********查询图片信息数据*******///
function check_imginfo(fun_itemsv,sucessCB_check_imginfo){
    var sql="select * from YJ_C_PHOTOESINFO where APP_NO=? and DTL_ID=? and CR_ID=? and FUN_ITEM=?"
    db_execut_oneSQL(null,sql,[sessionStorage.APP_NO_bl,cons_info.dtl_id,cons_info.cr_id,fun_itemsv],sucessCB_check_imginfo,null);
}

/**
 * 上装/下载-查看图片
 */
function upDown_checkphoto(FUN_ITEM,CHECK_ITEM,callback){
    db_execut_oneSQL(null,"select * from YJ_C_PHOTOESINFO where APP_NO=? and DTL_ID=? and CR_ID=? and FUN_ITEM=? and CHECK_ITEM=?",[sessionStorage.APP_NO_bl,cons_info.dtl_id,cons_info.cr_id,FUN_ITEM,CHECK_ITEM],function(tx,res){
        var ss=res.rows.length;
        if(ss){
            var size=res.rows.item(0).FILE_SIZE;
            var time=res.rows.item(0).FILE_CREATE_TIME;
            var path=res.rows.item(0).FILE_PATH;
            var name=res.rows.item(0).FILE_NAME;
            path = "2003"+path;
            name = name.replace("jpg","zip");//将jpg替换为zip
            var pkg_msg_down='{"FUN":"1006","MOD":"2003","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"APP_NO":"'+sessionStorage.APP_NO_bl+'","DTL_ID":"'+cons_info.dtl_id+'","CR_ID":"'+cons_info.cr_id+'","FUN_ITEM":"'+FUN_ITEM+'","CHECK_ITEM":"'+CHECK_ITEM+'","FILE_PATH":"'+path+'"}}';
            var pkg_msg_up1= '{"MOD":"2003","FUN":"1007","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"APP_NO":"'+sessionStorage.APP_NO_bl+'","DTL_ID":"'+cons_info.dtl_id+'","CR_ID":"'+cons_info.cr_id+'","FUN_ITEM":"'+FUN_ITEM+'","CHECK_ITEM":"'+CHECK_ITEM+'","FILE_FORMAT":"JPG","FILE_SIZE":"'+size+'","FILE_CREATE_TIME":"'+time+'","FILE_NAME":"'+name+'","FILE_PATH":"'+path+'"}}';
            var pkg_msg_up2='{"FUN":"02","ORG_NO":"'+sessionStorage.ORG_NO+'","MOD":"2003","SSN":"'+sessionStorage.SSN+'","FILE":[{"NAME":"'+name+'","URL":"'+path+'"}]}';
            scanPhoto("elec_photo/"+cons_info.dtl_id+"/"+FUN_ITEM+"/"+CHECK_ITEM+"/"+cons_info.dtl_id+"_"+FUN_ITEM+"_"+CHECK_ITEM,pkg_msg_up2,"0000","2003",pkg_msg_up1,pkg_msg_down,null,callback);
        }else{
            var pkg_msg_up1= '{"MOD":"2003","FUN":"1007","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"APP_NO":"'+sessionStorage.APP_NO_bl+'","DTL_ID":"'+cons_info.dtl_id+'","CR_ID":"'+cons_info.cr_id+'","FUN_ITEM":"'+FUN_ITEM+'","CHECK_ITEM":"'+CHECK_ITEM+'"}}';
            var pkg_msg_down='{"FUN":"1006","MOD":"2003","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"APP_NO":"'+sessionStorage.APP_NO_bl+'","DTL_ID":"'+cons_info.dtl_id+'","CR_ID":"'+cons_info.cr_id+'","FUN_ITEM":"'+FUN_ITEM+'","CHECK_ITEM":"'+CHECK_ITEM+'","FILE_PATH":"2003/elec_photo/'+cons_info.dtl_id+'/'+FUN_ITEM+'/'+CHECK_ITEM+'/"}}';
            scanPhoto(null,null,"0000","2003",pkg_msg_up1,pkg_msg_down,null,callback);
        }
    },null);
}

//查看--重要用户检查结果维护--现场检查图片
function upDown_checkphoto_xc(FUN_ITEM,CHECK_ITEM,callback){
        db_execut_oneSQL(null,"select * from YJ_C_PHOTOESINFO where APP_NO=? and DTL_ID=? and CR_ID=? and FUN_ITEM=? and CHECK_ITEM=?",[sessionStorage.APP_NO_bl,cons_info.dtl_id,cons_info.cr_id,FUN_ITEM,CHECK_ITEM],function(tx,res){
        var ss=res.rows.length;
        if(ss){
            var size=res.rows.item(0).FILE_SIZE;
            var time=res.rows.item(0).FILE_CREATE_TIME;
            var path=res.rows.item(0).FILE_PATH;
            var name=res.rows.item(0).FILE_NAME;
            path = "2003"+path;
            name = name.replace("jpg","zip");//将jpg替换为zip
            var pkg_msg_down='{"FUN":"1012","MOD":"2003","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"FILE_NAME":"'+name+'","FILE_PATH":"'+path+'"}}';
            var pkg_msg_up1= '{"MOD":"2003","FUN":"1010","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"APP_NO":"'+sessionStorage.APP_NO_bl+'","DTL_ID":"'+cons_info.dtl_id+'","CR_ID":"'+cons_info.cr_id+'","FUN_ITEM":"'+FUN_ITEM+'","CHECK_ITEM":"'+CHECK_ITEM+'","FILE_FORMAT":"JPG","FILE_SIZE":"'+size+'","FILE_CREATE_TIME":"'+time+'","FILE_NAME":"'+name+'","FILE_PATH":"'+path+'"}}';
            var pkg_msg_up2='{"FUN":"02","ORG_NO":"'+sessionStorage.ORG_NO+'","MOD":"2003","SSN":"'+sessionStorage.SSN+'","FILE":[{"NAME":"'+name+'","URL":"'+path+'"}]}';
            scanPhotoImportant("elec_photo/"+cons_info.dtl_id+"/"+FUN_ITEM+"/"+CHECK_ITEM+"/"+cons_info.dtl_id+"_"+FUN_ITEM+"_"+CHECK_ITEM,pkg_msg_up2,"0000","2003",pkg_msg_up1,pkg_msg_down,null,callback);
        }else{
            var pkg_msg_up1= '{"MOD":"2003","FUN":"1010","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"APP_NO":"'+sessionStorage.APP_NO_bl+'","DTL_ID":"'+cons_info.dtl_id+'","CR_ID":"'+cons_info.cr_id+'","FUN_ITEM":"'+FUN_ITEM+'","CHECK_ITEM":"'+CHECK_ITEM+'"}}';
            var pkg_msg_down='{"FUN":"1012","MOD":"2003","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"FILE_NAME":"'+cons_info.dtl_id+'_'+FUN_ITEM+'_'+CHECK_ITEM+'.jpg","FILE_PATH":"2003/elec_photo/'+cons_info.dtl_id+'/'+FUN_ITEM+'/'+CHECK_ITEM+'/"}}';
            scanPhotoImportant(null,null,"0000","2003",pkg_msg_up1,pkg_msg_down,null,callback);
        }
    },null);
}

//查看--重要用户检查结果维护--是否开具检查通知书
function upDown_checkphoto_kj(FUN_ITEM,CHECK_ITEM,callback){
        db_execut_oneSQL(null,"select * from YJ_C_PHOTOESINFO where APP_NO=? and DTL_ID=? and CR_ID=? and FUN_ITEM=? and CHECK_ITEM=?",[sessionStorage.APP_NO_bl,cons_info.dtl_id,cons_info.cr_id,FUN_ITEM,CHECK_ITEM],function(tx,res){
        var ss=res.rows.length;
        if(ss){
            var size=res.rows.item(0).FILE_SIZE;
            var time=res.rows.item(0).FILE_CREATE_TIME;
            var path=res.rows.item(0).FILE_PATH;
            var name=res.rows.item(0).FILE_NAME;
            path = "2003"+path;
            name = name.replace("jpg","zip");//将jpg替换为zip
            var pkg_msg_down='{"FUN":"1013","MOD":"2003","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"FILE_NAME":"'+name+'","FILE_PATH":"'+path+'"}}';
            var pkg_msg_up1= '{"MOD":"2003","FUN":"1011","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"APP_NO":"'+sessionStorage.APP_NO_bl+'","DTL_ID":"'+cons_info.dtl_id+'","CR_ID":"'+cons_info.cr_id+'","FUN_ITEM":"'+FUN_ITEM+'","CHECK_ITEM":"'+CHECK_ITEM+'","FILE_FORMAT":"JPG","FILE_SIZE":"'+size+'","FILE_CREATE_TIME":"'+time+'","FILE_NAME":"'+name+'","FILE_PATH":"'+path+'"}}';
            var pkg_msg_up2='{"FUN":"02","ORG_NO":"'+sessionStorage.ORG_NO+'","MOD":"2003","SSN":"'+sessionStorage.SSN+'","FILE":[{"NAME":"'+name+'","URL":"'+path+'"}]}';
            scanPhotoImportant("elec_photo/"+cons_info.dtl_id+"/"+FUN_ITEM+"/"+CHECK_ITEM+"/"+cons_info.dtl_id+"_"+FUN_ITEM+"_"+CHECK_ITEM,pkg_msg_up2,"0000","2003",pkg_msg_up1,pkg_msg_down,null,callback);
        }else{
            var pkg_msg_up1= '{"MOD":"2003","FUN":"1011","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"APP_NO":"'+sessionStorage.APP_NO_bl+'","DTL_ID":"'+cons_info.dtl_id+'","CR_ID":"'+cons_info.cr_id+'","FUN_ITEM":"'+FUN_ITEM+'","CHECK_ITEM":"'+CHECK_ITEM+'"}}';
            var pkg_msg_down='{"FUN":"1013","MOD":"2003","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"FILE_NAME":"'+cons_info.dtl_id+'_'+FUN_ITEM+'_'+CHECK_ITEM+'.jpg","FILE_PATH":"2003/elec_photo/'+cons_info.dtl_id+'/'+FUN_ITEM+'/'+CHECK_ITEM+'/"}}';
            scanPhotoImportant(null,null,"0000","2003",pkg_msg_up1,pkg_msg_down,null,callback);
        }
    },null);
}

/****************单张图片上装--是否开具检查通知书和现场检查图片***********************/
function upload_image_two_js(mod,fun_itemsv,check_itemsv,file_size,file_create_time,photo_path,ptoto_name,function_name){
    var photo_service_path=photo_path;                        //上传图片的服务器路劲
   
    upimage();//调用图片上传
    /*************调用图片上传*************/
    function upimage(){
        // $("#businessList_laoding_view").show();
        var data='{"FUN":"02","ORG_NO":"'+sessionStorage.ORG_NO+'","MOD":"2003","SSN":"'+sessionStorage.SSN+'","FILE":[{"NAME":"'+ptoto_name+'","path":"'+photo_path+'","INFO":"'+photo_service_path+'"}]}';
        var pkg = '{"MOD":"2003","FUN":"'+mod+'","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"APP_NO":"'+sessionStorage.APP_NO_bl+'","DTL_ID":"'+cons_info.dtl_id+'","CR_ID":"'+cons_info.cr_id+'","FUN_ITEM":"'+fun_itemsv+'","CHECK_ITEM":"'+check_itemsv+'","FILE_FORMAT":"JPG","FILE_SIZE":"'+file_size+'","FILE_CREATE_TIME":"'+file_create_time+'","FILE_NAME":"'+ptoto_name+'","FILE_PATH":"'+photo_path+'"}}';
        uploadImageCheck(data,mod,"2003",pkg,null,function_name);
    }
}
//提示框的提示信息
function dialogMes(str){
    $("#yxzypt_msg").html("");
    $("#yxzypt_msg").html(str);
     onchange_val();
    $("#yxzypt_dailog").show();
}

/***********************图片上装ftp服务器后，请求营销的成功回调*******************/
function success_uploadimg(msg){
     $("#businessList_laoding_view").hide();
    // //msg = JSON.parse(msg);
    // db_execut_oneSQL(null,"update YJ_C_PHOTOESINFO set DOWNLOAD_TYPE=? where APP_NO=? and DTL_ID=? and CR_ID=? and FUN_ITEM=? and CHECK_ITEM=?",[1,sessionStorage.APP_NO_bl,cons_info.dtl_id,cons_info.cr_id,msg.PKG.FUN_ITEM,msg.PKG.CHECK_ITEM],null,null);
     dialogMes(msg.result);
}
</script>