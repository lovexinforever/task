//所有页面头部信息


/**
 * 将用户信息（用户分类、重要性等级、用电类别、）拼接成一个字符串
 * @return
 */
function getHeaderInfo(arg1,arg2,arg3){
	var pageText = "";
	if(arg1!=null&&arg1!=""){
		pageText = arg1;
	}
	if(arg2!=null&&arg2!=""){
		pageText += "|"+arg2;
	}
	if(arg3!=null&&arg3!=""){
		pageText += "|"+arg3;
	}
	return pageText;
	
}