<script type="text/javascript">
//加载用检用户信息
 var busElecList = new Array();//本地电工数据集合
 
 $("#ydjc_loginuser_nav_bl").html("电工管理");
 
//新增
 function goto_Elecdatenewadd(){
     $("#elecManage").show();
 }
 
 //回退按钮
function ydjc_loginuser_bl_back(){
     changepage("Businesslist/html/business_list.html");
}

/**
 * 跳转到电工详情
 */
function goto_elecdetail(num){
    sessionStorage.busElecID=busElecList[num].ID;
    changepage("Businesslist/html/busElecdatedetail.html");
}

/**
 * 跳转新增电工页面
 */
function goto_elecAdds(data){
    $("#elecManage").hide();
    if(ydjcselectedFlag ==2){
         sessionStorage.elecAddData = JSON.stringify(data);
         sessionStorage.busNameOrNotBus = "busName";
         changepage('Checkuserrunmanage/html/elecNameList.html'); //跳转到NameList
    }else{
        var temp = new Array();temp.push(data[0]);
         sessionStorage.elecAddData = JSON.stringify(temp);
        changepage('Businesslist/html/businessELeAdd.html');  //跳转到新增
    }
}

//其他情况查询本地记录
slect_electlist_data();

/**
 * 本地电工列表初始化
 * LOCAL_STATE 默认为0， 1为保存在本地的电工，2已经上装到营销的电工
 */
function slect_electlist_data(){
    var sql = "select * from YJ_LOCAL_ELECTRICIAN where SYS_USER_NAME=? and LOCAL_STATE='1'";
    db_execut_oneSQL(null,sql,[sessionStorage.user_name],queryListSuccess,null);
}

//成功回调
function queryListSuccess(tx,res){
    var len=res.rows.length;
    if(len){
        for(var i=0;i<len;i++){
            busElecList[i]=res.rows.item(i);
        }
        val_ui_data();
    }else{
    	$("#apend_eleclist *").remove();
    	if($("#yxzypt_msg").html() != "电工批量上装成功")
        	aeMsgShow("未查询到电工数据");
    }
}

//页面数据初始化
function val_ui_data(){
    $("#apend_eleclist *").remove();
    var result="";
    for(var i=0;i<busElecList.length;i++){
             result += '<div style="margin-bottom: 20px;" onclick="goto_elecdetail('+i+')">'
                +'<div style="width: 50%;float: left;">电工姓名：'+busElecList[i].NAME+'</div>'
                +'<div style="width: 50%;float: left;"  >电工证类别：'+busElecList[i].LICENCETYPE+'</div>'
                +'<div>联系方式：'+busElecList[i].PHONE+'</div>'
                +'<div>电工证号：'+busElecList[i].LICENCENO+'</div>'
                +'<div>身份证号：'+busElecList[i].IDNO+'</div>'
                +'<div>电工证有效期：'+busElecList[i].EXPIRYDATE+'</div>'
                +'<div style="line-height: 20px;"><img src="../../Util/Images/greenline.png" width="100%" height="2px"/></div>'
            +'</div>';
    }
    $("#apend_eleclist").append(result);
}

/**********************
 * 新增电工弹出框逻辑
 *********************/
var ydjcELeIdArray = ["elmanageCERT_NO","elmanageIDNO","elmanageNAME"];
var ydjcselectedFlag = 0;//标记被选中的radio
sessionStorage.elecAddData="";
aeCancleClick();//取消事件绑定
//电工证号
$("#elmanageCERT_NO").on("click",function(){
    changeButton(0);
});
//身份证号
$("#elmanageIDNO").on("click",function(){
    changeButton(1);
});
//电工姓名
$("#elmanageNAME").on("click",function(){
    changeButton(2);
});
//确定
$("#eleManQuery").on("click",function(){
    var inputVal = "";
    if(ydjcselectedFlag == 0)  inputVal = $("#add02Val1").val()+"-"+$("#add02Val2").val();//电工证号
    else  inputVal = $("#elecManageAddVal01").val();
    //请求数据
    var name = ydjcselectedFlag==2?inputVal:"";
    var idno = ydjcselectedFlag==1?inputVal:"";
    var licenceno = ydjcselectedFlag==0?inputVal:"";
    addElecManSend(name,licenceno,idno);//调用接口
});

//取消
$("#eleMancancle").on("click",function(){
   $("#elecManage").hide();
});

function changeButton(i){
    ydjcselectedFlag = i;
    if(i==0){
        $("#elecManageAddVal01").hide();
        $("#elecManageAddVal02").show();
    }else{
        $("#elecManageAddVal01").show();
        $("#elecManageAddVal02").hide();
    }
    $("#"+ydjcELeIdArray[0]+" img").attr("src","../../Util/Images/radioboxoff.png");
    $("#"+ydjcELeIdArray[1]+" img").attr("src","../../Util/Images/radioboxoff.png");
    $("#"+ydjcELeIdArray[2]+" img").attr("src","../../Util/Images/radioboxoff.png");
    $("#"+ydjcELeIdArray[i]+" img").attr("src","../../Util/Images/radioboxon.png");
}

/**
 * 取消按钮绑定重置状态
 */
function aeCancleClick(){
    $("#elmanageCERT_NO").off("click");
    $("#elmanageIDNO").off("click");
    $("#elmanageNAME").off("click");
    $("#eleManQuery").off("click");
    $("#eleMancancle").off("click");
    $("#add02Val1").val("");
    $("#add02Val2").val("");
    $("#elecManageAddVal01").val("");
    $("#elecManageAddVal01").hide();
    $("#elecManageAddVal02").show();
    $("#"+ydjcELeIdArray[0]+" img").attr("src","../../Util/Images/radioboxon.png");
    $("#"+ydjcELeIdArray[1]+" img").attr("src","../../Util/Images/radioboxoff.png");
    $("#"+ydjcELeIdArray[2]+" img").attr("src","../../Util/Images/radioboxoff.png");
}

/**
 * 新增电工查询
 * @NAME 电工姓名
 * @LICENCENO 电工证号
 * @IDNO 身份证号
 */
function addElecManSend(name,licenceno,idno){
        $("#businessList_laoding_view").show();//显示Loading
        var PKG='{"MOD":"2003","FUN":"3001","LEN":"39","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"NAME":"'+name+'","LICENCENO":"'+licenceno+'","IDNO":"'+idno+'"}}'
        send_data("3001","2003",PKG,function(msg){
                        $("#businessList_laoding_view").hide();//关闭Loading
                        msg = JSON.parse(msg);
                        if(msg.RET=="00"){
                            var msg_pkg=msg.PKG.PKG;
                            var fun=msg.FUN;
                            if(msg_pkg.SUCCESS_FLAG=="0"){
                                    goto_elecAdds(msg_pkg.ELECTRICIAN);//跳转到新增电工
                            }else{
                                    if(msg_pkg.ERR_MSG) aeMsgShow(msg_pkg.ERR_MSG);
                                    else aeMsgShow("该电工未在电监会注册！");
                            }
                        }else{
                                aeMsgShow("获取电工信息失败");
                        }
        },function(e){
                $("#businessList_laoding_view").hide();//关闭Loading
                aeMsgShow("获取电工信息失败");
        });
}

/**
 * 批量新增上装
 */
var imgIndex=0;
var uploadMsg = "";
function uploadbatch(){
	
	if(busElecList.length >0){
		
		if(imgIndex >= busElecList.length){
			$("#businessList_laoding_view").hide();//关闭Loading
			if(uploadMsg !="")
				aeMsgShow(uploadMsg);
			else
				aeMsgShow("电工批量上装成功");
				
			uploadMsg ="";
			imgIndex = 0;
			busElecList=new Array();
			slect_electlist_data();
			return;
		}
		$("#businessList_laoding_view").show();// Loading
		var i =imgIndex;
		imgIndex++;
		
		var data = {"FUN":"02","ORG_NO":sessionStorage.ORG_NO,"MOD":"2003","SSN":sessionStorage.SSN,"FILE":[{"NAME":busElecList[i].IMAGE_NAME,"path":"/"+busElecList[i].IMAGE_PATH,"INFO":"2003/"+sessionStorage.ORG_NO+"/"+busElecList[i].IMAGE_PATH}]}
		uploadImageSign(data,function(e){//新增电工图片上传
			
			if(e.RET=="00"){
				uploadElec(busElecList[i],function(objStr){//新增电工信息
					if(objStr != "success")
						uploadMsg += busElecList[i].NAME+"电工信息上装失败;"
					uploadbatch();//上装下一个电工
				});
			}else{
				uploadMsg += busElecList[i].NAME+"的电工图片上传失败;"
				uploadbatch();//上装下一个电工
			}
		});
	}else{
		aeMsgShow("未查询到电工数据");
	}
}

/**
 * 单个新增上装
 */
function uploadElec(elecData,callback){
    var PKG1='{"MOD":"2003","FUN":"3003","LEN":"39","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"CONS_ID":"'+elecData.CONS_ID+'","IDNO":"'+elecData.IDNO+'","FILE_PATH":"2003/'+sessionStorage.ORG_NO+'/'+elecData.IMAGE_PATH+'","FILE_NAME":"'+elecData.IMAGE_NAME+'"}}'
    send_data("3003","2003",PKG1,successCallBack,faileCallBack);
    //上装成功回调
    function successCallBack(message_ener){
        var msg_enercb = JSON.parse(message_ener);
        if(msg_enercb.RET=="00"){
            var msg_pkg=msg_enercb.PKG.PKG;
            var fun=msg_enercb.FUN;
            if(msg_pkg.SUCCESS_FLAG=="0"){
                 var elecId = msg_enercb.PKG.PKG.ELECTRICIAN_ID;//返回的电工id
                 updateElecID(elecId,elecData.CONS_ID,elecData.LICENCENO);
                 callback("success");
            }else{
                callback("error");
            }
        }else{
            callback("error");
        }
    }
    //上装失败回调
    function faileCallBack(){
        callback("error");
    }
}

/**
 * 新增上装成功后 更新返回的电工ID 并将本地状态置为以上装2
 */
function updateElecID(ID,consId,licenceNo){
//    var sql = "update YJ_LOCAL_ELECTRICIAN set ID = ? , LOCAL_STATE=?  where CONS_ID=? AND LICENCENO=?";
//    db_execut_oneSQL(null,sql,[ID,'2',consId,licenceNo],null,null);
    var sql = "delete from YJ_LOCAL_ELECTRICIAN  where CONS_ID=? AND LICENCENO=?";
    db_execut_oneSQL(null,sql,[consId,licenceNo],null,null);
}

/**
 * 提示信息
 */
function aeMsgShow(msg){
	$("#yxzypt_msg").html("");
    $("#businessList_laoding_view").hide();//关闭加载效果框
    $("#yxzypt_msg").html(msg);//给弹出框赋对应的提示消息
    onchange_val();
    $("#yxzypt_dailog").show();
}
</script>