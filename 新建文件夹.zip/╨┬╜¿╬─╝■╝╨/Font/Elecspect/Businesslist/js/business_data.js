<script type="text/javascript">
/***********************************************获得待办事宜列表---开始*********************************************************/
/**
 * 用电检查待办事宜列表获取业务流程：
 *1.用户第一次进入待办事宜列表，需要从服务器同步数据到终端表中：yj_todo_something，where user_id=当前登录用户名
 *2.直接查询数据库数据调用JS接口get_yj_todo_somenthing() where user_id=当前登录用户名;
 *3.筛选功能：根据页面传入的条件筛选yj_todo_something where user_id=当前登录用户名 里面的数据。
 *4.单个数据包下载：根据app_no,user_id下载数据包。终端发送请求到平台，平台转发请求到服务器，平台接受请求，转发给终端业务。
 */
/**
 * 获得待办事宜列表
 * 返回数据如下：
 * @param APP_N0=申请编号
 * @param PLAN_NO=计划编号
 * @param INS_NAME=流程名称
 * @param ACT_NAME=活动名称
 * @param NOTES=说明
 * @param RCV_TIME=接收时间
 * @param DUE_TIME=到期时间
 * @param DOWNLOADING_TYPE=下装状态
 * @param mobile_sum=移动终端总户数
 * @param unexec_sum=未执行户数
 * @param unupload_sum=未上装户数
 */

function get_yj_todo_something(user_id){
	if(sessionStorage.bussess_refresh == "refresh"){//用户列表反馈刷新工单列表
		//alert("用户列表反馈刷新工单列表");
		refresh_bl_goto();//调用工单列表刷新
		sessionStorage.bussess_refresh="";
		return;
	}
	var sql="select count(user_id) as cs from yj_todo_something where user_id=?";
	db_execut_oneSQL(null,sql,[user_id],sucessCB_bl_1,failCB_bl_1);
	function sucessCB_bl_1(tx,res){
		 var count = res.rows.item(0).cs;
		 //数据已存在数据库
		 if(count>0){
			 //查询数据库
			 selectDB_yj_todo_something(user_id);
		 }
		 else{
			 //需要从服务器请求数据，然后插入数据库
			 first_yj_todo_something(user_id);
		 }
	}
	 //查询失败
	function failCB_bl_1(e){
		close_loading_view("查询移动终端数据库失败");
	}
	/**
	 * initPage_business_list_ydjc业务必须实现此方法。
	 * 从数据库查询待办事宜列表
	 * @param tx
	 */
	function selectDB_yj_todo_something(user_id){
	    
            var sql2="SELECT "+
                      "  S.APP_NO,"+ 
                      "  D.PLAN_NO, "+
                      "  S.INS_NAME, "+
                      "  S.ACT_NAME, "+
                      "  S.NOTES, "+
                      "  S.RCV_TIME,"+ 
                      "  S.DUE_TIME, "+
                      "  S.DOWNLOADING_TYPE, "+
                      "  S.UPLOADING_TYPE, "+
                      "  S.INSTANCE_ID, "+
                      "  COUNT(D.DTL_ID) mobile_sum, "+
                      "  COUNT(CASE when D.PLAN_STATUS_CODE != '08' and C.UPLOADING_TYPE = '0' then '0' end) unexec_sum, "+
                      "  COUNT(CASE when D.PLAN_STATUS_CODE != '08' and C.UPLOADING_TYPE = '1' THEN  '0'  end) unupload_sum, "+
                      "  COUNT(CASE when D.PLAN_STATUS_CODE = '08' THEN  '0'  end) upload_sum "+
                      "  FROM YJ_TODO_SOMETHING S"+
                      "  LEFT join  YJ_S_CHK_PLAN_DET D on  S.APP_NO = D.APP_NO"+
                      "  LEFT join YJ_C_CONS C on D.DTL_ID = C.DTL_ID and D.CONS_ID = C.CONS_ID"+
                      "  WHERE S.USER_ID =?  "+
                      "  GROUP BY S.APP_NO  order by S.APP_NO";
	  		
	  db_execut_oneSQL(null,sql2,[user_id],initPage_business_list_ydjc,function(e){
		  close_loading_view("查询移动终端数据库失败");
	  }); 
	}
	
}
/**
 * 第一次进入待办事宜列表。从服务器请求数据，插入数据到数据库。
 * @param user_id
 */
function first_yj_todo_something(user_id){
	//1.发送用电检查待办事宜列表请求到服务器
	var pkg='{"MOD":"2003","FUN":"1001","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"TYPECODE":"2003","USR":"'+user_id+'","TASK":[]}}';
    send_data("1001","2003",pkg,sendDataSucessCB_bl_1,sendDataFailCB_bl_1);
   //发送成功
	function sendDataSucessCB_bl_1(msg){
		msg=JSON.parse(msg);
		//发送请求失败
		if(msg.RET!="00"){
			 close_loading_view(getErrorMsg(msg.RET));
		}
		//成功
		else{
			try{
				var pkg=msg.PKG;
				if(pkg.RET=="10"){//数据返回成功
					var todosome=pkg.PKG.YJ_TODO_SOMETHING;
					insert_yj_todo_something(todosome,user_id);
				}else{
				  businessalert_Info(pkg.RET);
				}
			}catch(e){
				 close_loading_view("营销系统返回JSON格式错误");
			}
		}
	}
	//发送失败
    function sendDataFailCB_bl_1(msg){
    	//操作失败关闭加载效果
    	close_loading_view("请求待办事宜列表失败");
	}
    
}
/**
 * 把服务器获得的数据插入数据库，插入成功后，把从服务器获得数据直接发送到前端。
 * @param todosome
 * @param user_id
 */
function insert_yj_todo_something(todosome,user_id){
   var len=todosome.length;
   var params=new Array();
	for(var i=0;i<len;i++){
		var item=todosome[i];
		params[i]=[item.USER_ID,item.APP_NO,item.INS_NAME,item.ACT_NAME,item.NOTES,item.RCV_TIME,item.DUE_TIME,item.STATUS_CODE,item.ACT_ID,item.ALARM_DATA,item.INSTANCE_ID,item.LOCK_EMP,item.FINISH_EMP,item.PROCESS_NO];
	}
	//操作数据库
	var insert="INSERT INTO YJ_TODO_SOMETHING(USER_ID,APP_NO,INS_NAME,ACT_NAME,NOTES,RCV_TIME,DUE_TIME,STATUS_CODE,ACT_ID,ALARM_DATA,INSTANCE_ID,LOCK_EMP,FINISH_EMP,PROCESS_NO)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	db_batch_data_2(null,insert,params,sucessCB_bl_1,failCB_bl_1);
	
	function sucessCB_bl_1(){
	  //把数据推送到前端
	 get_yj_todo_something(user_id);
	}
    //操作失败	
    function failCB_bl_1(e){
      //操作失败关闭加载效果
    	close_loading_view("批量插入移动终端数据库失败");
	}
}
/***********************************************获得待办事宜列表---结束*********************************************************/


/***********************************************筛选待办事宜列表---开始*********************************************************/
/**
 * 筛选待办事宜列表
 * @param where
 */
function choose_yj_todo_something(user_id,where,time){
	 //开始使用事务操作数据库
    var sql="SELECT "+
          "  S.APP_NO,"+ 
          "  D.PLAN_NO, "+
          "  S.INS_NAME, "+
          "  S.ACT_NAME, "+
          "  S.NOTES, "+
          "  S.RCV_TIME,"+ 
          "  S.DUE_TIME, "+
          "  S.DOWNLOADING_TYPE, "+
          "  S.UPLOADING_TYPE, "+
          "  S.INSTANCE_ID, "+
          "  COUNT(D.DTL_ID) mobile_sum, "+
          "  COUNT(CASE when D.PLAN_STATUS_CODE != '08' and C.UPLOADING_TYPE = '0' then '0' end) unexec_sum, "+
          "  COUNT(CASE when D.PLAN_STATUS_CODE != '08' and C.UPLOADING_TYPE = '1' THEN  '0'  end) unupload_sum, "+
          "  COUNT(CASE when D.PLAN_STATUS_CODE = '08' THEN  '0'  end) upload_sum "+
          "  FROM YJ_TODO_SOMETHING S"+
          "  LEFT join  YJ_S_CHK_PLAN_DET D on  S.APP_NO = D.APP_NO"+
          "  LEFT join YJ_C_CONS C on D.DTL_ID = C.DTL_ID and D.CONS_ID = C.CONS_ID"+
          "  WHERE S.USER_ID =?  "+proce_json_where(where,"S")+time+"  " +
          " GROUP BY S.APP_NO  order by S.APP_NO";
	 
	db_execut_oneSQL(null,sql,[user_id],initPage_business_list_ydjc,function(e){
		//操作失败关闭加载效果
    	close_loading_view("查询移动终端数据库失败");
	});
}
/***********************************************筛选待办事宜列表---结束*********************************************************/



/***********************************************刷新待办事宜列表---开始*********************************************************/
/**
 * 需要优化：先删除终端数据，在插入。
 * 刷新待办事宜列表
 * 业务说明：
 * 1.发送请求到服务器
 * 2.接受返回的JSON
 * 3.根据服务器返回的app_no集合。操作数据库数据：1.更新存在的数据。2.插入新的数据
 * @param user_id 登陆用户id
 * @returns
 */
function refresh_yj_todo_something(user_id,refresh_sucess_error){
	  //1.发送用电检查待办事宜列表请求到服务器
	var pkg='{"MOD":"2003","FUN":"1001","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"TYPECODE":"2003","USR":"'+user_id+'","TASK":[]}}';
	send_data("1001","2003",pkg,sendDataSucessCB_bl,sendDataFailCB_bl);
	 //发送成功
		function sendDataSucessCB_bl(msg){
			msg=JSON.parse(msg);
			//失败
			if(msg.RET!="00"){
				//操作失败关闭加载效果
				refresh_sucess_error(getErrorMsg(msg.RET));
			}
			//成功
			else{
				try{
					var pkg=msg.PKG;
					if(pkg.RET=="10"){//数据返回成功
						var todosome=pkg.PKG.YJ_TODO_SOMETHING;
						filter_yj_todo_something(user_id,todosome,refresh_sucess_error);
					}else{
					     businessalert_Info(pkg.RET);
					}
				}catch(e){
					//操作失败关闭加载效果
					refresh_sucess_error("营销系统返回JSON格式错误");
				}
			}
			//是否有其他的失败标志
		}
		//发送失败
	    function sendDataFailCB_bl(msg){
	    	//操作失败关闭加载效果
	    	refresh_sucess_error("请求待办事宜列表失败");
		}
}
/**
 * 2.接受返回的JSON
 * 根据服务器传回来的待办事宜列表数据。过滤出，需要更新的app_no
 * @param todosome 服务端发送多来的待办事宜数据。jsonArray[{JSON格式}]
 */
function filter_yj_todo_something(user_id,todosome,refresh_sucess_error){
	
	var len=todosome.length;
	//('app_no','app_no',......)集合
	var ids="";
	//所有的删除语句
    var delete_list10=new Array();
	for(var i=0;i<len;i++){
		ids+=("'"+todosome[i].APP_NO+(i==(len-1)?"'":"',"));
	}
	////////////////////////////////////////////////////////////////
   //当刷新的APP_NO数小于本地的APP_NO的个数时，删除本地那些没有下载的工单列表项
    
var app_sql="select APP_NO from YJ_TODO_SOMETHING where USER_ID=? and APP_NO not in ("+ids+")"
db_execut_oneSQL(null,app_sql,[user_id],function(tx,res){
    try{
        var apparr=new Array();// 本地工单编号数组
        var app_lenth=res.rows.length
        var all_dtl_length = new Array();// 本地工单的所有用户id的数组
        var dtl_length = new Array();// 本地工单的未执行用户id的数组
	    // alert("app_lenth=YJ_TODO_SOMETHING="+app_lenth);
        var testk=0
        select_dtlnum();// 查询用户id
        function select_dtlnum(){
        	if(testk< app_lenth){
	        	apparr.push(res.rows.item(testk));
                db_execut_oneSQL(null,"select dtl_id from YJ_S_CHK_PLAN_DET where app_no=?",[apparr[testk].APP_NO],function(ta,resd){// 查询app_no下的所有用户
	          		all_dtl_length.push(resd.rows.length);
	                db_execut_oneSQL(null,"select dtl_id,id,cons_id from YJ_S_CHK_PLAN_DET where app_no=? and PLAN_STATUS_CODE!='08'",[apparr[testk].APP_NO],function(ta,resd){// 查询app_no下的未执行的用户
	                  		dtl_length.push(resd.rows.length);
		 	    			if(dtl_length[testk]==all_dtl_length[testk]){ // 如果未执行的用户和本地总用户数据相同则删除工单
			                      delete_list10.push("delete from YJ_TODO_SOMETHING where USER_ID='"+user_id+"' and app_no="+apparr[testk].APP_NO);
			                 }
	                  		//alert('length'+dtl_length[testk]);
	                  		 if(dtl_length[testk] > 0){
		                  		for(var i=0;i<resd.rows.length;i++){
			                  		//alert("JSON.stringify"+JSON.stringify(resd.rows.item(i)));
			                  		delete_list10.push("delete from YJ_S_CHK_PLAN_DET where DTL_ID="+resd.rows.item(i).DTL_ID);
			                  		selectconsnum(apparr[testk],resd.rows.item(i));
		                  		}
		                  		function selectconsnum(appno,dtl){
				                 	 	db_execut_oneSQL(null,"select * from YJ_C_CONS where dtl_id=?",[dtl.DTL_ID],function(tx,resb){
			                 	 	 	if(resb.rows.length>0){
			                                	if(resb.rows.item(0).DOWNLOADING_TYPE == 1){
				                                	// 删除已下装且未执行的用户的所有数据
			                                		 select_mobileDB_make_deleteSQL_DTLID(appno.APP_NO,dtl.DTL_ID,dtl.ID,dtl.CONS_ID,delete_list10);
			                                	}else{
			                                		// 改用户没有下载数据，只有列表
			                                	    delete_list10.push("delete from YJ_C_CONS where dtl_id="+dtl.DTL_ID);
			                                	}
			                 	 	 	}
		 		                 	 },errorCB_shuaxin);
		                  		}
			                }
	                  		testk++;
	                  		if(testk == app_lenth){
	                  			setTimeout(function(){
							    	//alert("delete_list10-->"+delete_list10);
							        delete_shuaxindata();
							    },1000);
							    return;
	                  		}
	                  		select_dtlnum();
	                  },null);
                  },null);
        	}else{
        		delete_shuaxindata();
       	   }
        }

    }catch(e){
        close_loading_view("删除待办事宜表数据异常");
    }
},errorCB_shuaxin);

  function delete_shuaxindata(){//删除
  	 var ydjc = window.sqlitePlugin.openDatabase("ydjc.db", "1.0","ydjc.db", 10*1024*1024);
	      	if(delete_list10.length>0){
			 	var num0 = 0;
			 	var flag_state0 = false;
				 ydjc.transaction(function(tx){
			 		for(var i=0;i<delete_list10.length;i++){
					 tx.executeSql(delete_list10[i],[],function(tx,res){
						num0++;
						if(num0>=delete_list10.length){
							//插入结束。开始更新插入标志
							console.log("i="+i+"|||num0=="+num0);
							 delete_list10=null;
							 update_insertdata();
						}
					 },function(e){
						 if(!flag_state0){
							 refresh_sucess_error("批量删除移动终端数据失败");
							 flag_state0=true;
						 }
					 });
			 	}
		 	});
		}else{
			update_insertdata();//开始更新
		}
 }
     
     
     //////////////////////////////////////////////////////////////////
	//开始使用事务操作数据库
	function update_insertdata(){
	    //alert("开始更新");
       var sql="select app_no from yj_todo_something where user_id=? and app_no in ("+ids+")";
       db_execut_oneSQL(null,sql,[user_id],sucessCB_shuaxin,errorCB_shuaxin)
	}
	//Call Back sucess error
	function sucessCB_shuaxin(tx,res){
		 var rows= res.rows;
		 //需要更新的app_no个数
		 var update_len=rows.length;
	    //更新的app_no：把app_no组装成app_no,app_no,...格式
		 var update_app_nos;
		 if(update_len==len){//全部是更新的
			 //开始更新数据库
			 update_yj_todo_something(todosome,"",refresh_sucess_error);
		 }else{//有一部分是插入的
			 for(var j=0;j<update_len;j++){
				 update_app_nos+=rows.item(j).APP_NO+",";
			 }
			 if(setUndefined(update_app_nos)==""){
			     update_app_nos="no_data";
			 }
			 //开始更新数据库
			 update_yj_todo_something(todosome,update_app_nos,refresh_sucess_error);
		 }
	}
	function errorCB_shuaxin(err){
		//操作失败关闭加载效果
		close_loading_view("查询移动终端待办事宜表失败");
	}
	
}
/**
 * 3.根据服务器返回的app_no集合。操作数据库数据：1.更新存在的数据。2.插入新的数据,
 * 数据库操作接受后，把从服务器获得的数据发送到页面中。
 * @param todosome
 * @param update_app_nos
 */
function update_yj_todo_something(todosome,update_app_nos,refresh_sucess_error){
	var length=todosome.length;
	var update_list=new Array();
	var insert_list=new Array();
	var insert="INSERT INTO YJ_TODO_SOMETHING(USER_ID,APP_NO,INS_NAME,ACT_NAME,NOTES,RCV_TIME,DUE_TIME,STATUS_CODE,ACT_ID,ALARM_DATA,INSTANCE_ID,LOCK_EMP,FINISH_EMP,PROCESS_NO)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	var update="UPDATE YJ_TODO_SOMETHING SET INS_NAME=?,ACT_NAME=?,NOTES=?,RCV_TIME=?,DUE_TIME=?,STATUS_CODE=?,ACT_ID=?,ALARM_DATA=?,INSTANCE_ID=?,LOCK_EMP=?,FINISH_EMP=?,PROCESS_NO=? WHERE APP_NO=? AND USER_ID=?";
try{
	if(update_app_nos==""){//全部更新
		for(var i=0;i<length;i++){
			var item=todosome[i];
			update_list.push([item.INS_NAME,item.ACT_NAME,item.NOTES,item.RCV_TIME,item.DUE_TIME,item.STATUS_CODE,item.ACT_ID,item.ALARM_DATA,item.INSTANCE_ID,item.LOCK_EMP,item.FINISH_EMP,item.PROCESS_NO,item.APP_NO,item.USER_ID]);
		}
		if(update_list.length>0){
			db_batch_data_2(null,update,update_list,function(){
				todosome=null;
				update_lis=null;
				insert_list=null;
				refresh_sucess_error(1);
			},function(){
				todosome=null;
				update_lis=null;
				insert_list=null;
				refresh_sucess_error("更新移动终端待办事宜表失败");
			});
		}
	}
	else{//插入和更新
		for(var i=0;i<length;i++){
			var item=todosome[i];
			var index=update_app_nos.indexOf(item.APP_NO);
			if(index>-1){//更新
				update_list.push([item.INS_NAME,item.ACT_NAME,item.NOTES,item.RCV_TIME,item.DUE_TIME,item.STATUS_CODE,item.ACT_ID,item.ALARM_DATA,item.INSTANCE_ID,item.LOCK_EMP,item.FINISH_EMP,item.PROCESS_NO,item.APP_NO,item.USER_ID]);
			}else{//插入
				insert_list.push([item.USER_ID,item.APP_NO,item.INS_NAME,item.ACT_NAME,item.NOTES,item.RCV_TIME,item.DUE_TIME,item.STATUS_CODE,item.ACT_ID,item.ALARM_DATA,item.INSTANCE_ID,item.LOCK_EMP,item.FINISH_EMP,item.PROCESS_NO]);
			}
		}
		todosome=null;
		if(insert_list.length>0){
			db_batch_data_2(null,insert,insert_list,function(){
				insert_list=null;
				if(update_list.length>0){
					db_batch_data_2(null,update,update_list,function(){
						update_list=null;
						refresh_sucess_error(1);//成功回调
					},function(){
						refresh_sucess_error("更新移动终端待办事宜表失败");
					});
				}else{
				    refresh_sucess_error(1);//成功回调
				}
				
			},function(){
				insert_list=null;
				update_list=null;
				refresh_sucess_error("插入移动终端待办事宜表失败");
			});
		}
	}
}catch(e){
    refresh_sucess_error("更新移动终端待办事宜表失败");
}
}
/***********************************************刷新待办事宜列表---结束*********************************************************/

/***********************************************单个工单数据包下载---开始*********************************************************/
var read_download_files;

var havedown_statues=new Array();
if(setUndefined(localStorage.valstatue)!=""){
    havedown_statues=localStorage.valstatue.split(",");
}
//alert(havedown_statues+"===havedown_statues======="+havedown_statues.length);
/**
 * 单个工单数据包下载
 *
 * 数据包下载-->插入数据到数据库业务流程说明：
 * 1.发送user_id,app_no,cons_id到服务器
 * 2.平台转发请求到服务器
 * 3.平台下载数据包到data/data/files目录下，解压并，删除zip包，最终生成：data/data/files/app_no/*.txt。
 * 4.业务循环调用read_db_file();把对应的数据插入到数据库表中
 * 数据插入前的数据处理过程：
 * 1.根据读到的ID，在数据库中删除原有的记录
 * 2.把新记录插入到数据库中。
 */
function download_yj_todo_something_one(user_id,app_no,sucess_dowanload){
	 //1.发送用电检查待办事宜列表请求到服务器
	 console.log("download_yj_todo_something_one--->"+app_no);
	var pkg ='{"MOD":"2003","FUN":"1003","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"APP_NO":"'+app_no+'","EMP_NO":"'+sessionStorage.EMP_NO+'","USR":"'+user_id+'","TASK":[]}}'; 
	
	send_data("1003","2003",pkg,sendDataSucessCB_1,sendDataFailCB_2);
	
	   //发送成功
	   function sendDataSucessCB_1(msg){
	   		console.log("返回数据："+msg);
		     msg=JSON.parse(msg);
			//失败
			if(msg.RET!="00"){
			   sucess_dowanload(getErrorMsg(msg.RET));
		   }else{
			   try{
				   var pkg=msg.PKG;
					if(pkg.RET=="10"){//数据返回成功
						 var zipPath=null;
						  var add=pkg.PKG.APP_NO_PACKAGE_ADDR[0]; 
						  //下载地址
						  var zip=sessionStorage.DOWN_URL+"/"+add.filePath;
						  //下载ZIP包
						  donwloadAndZip(zip,zipPath,function(zipmsg){
							  //下载，解压成功,文件个数一致，大小一致
							  if(zipmsg.msg==1 && zipmsg.num==add.fileNum){
								//包含的文件名
								  var files=add.fileNames;
								  read_db_file_2(files.split("|"),returnt_proc_db_SQL,app_no,sucess_dowanload);
							  	//sucess_dowanload(1);
							  }
							  //下载，解压失败
							  else{
								  sucess_dowanload("解压缩文件失败");
							  }
						  });
					}else if(pkg.RET=="14"){
					    //查询本地数据
					        var sql="select plan_no from yj_s_chk_plan where app_no=?";
                              db_execut_oneSQL(null,sql,[app_no],function(tx,res){
                                  if(res.rows.length>0){
                                       sucess_dowanload(2);
                                  }else{
                                      sucess_dowanload("该工单下没数据");
                                  }
                                  var temp_falg=false;
                                  for(var i=0;i<havedown_statues.length;i++){
                                      if(havedown_statues[i]==app_no){
                                            temp_falg=true;
                                      }
                                  }
                                  if(!temp_falg){
                                        havedown_statues.push(app_no);
                                        localStorage.valstatue=havedown_statues;
                                  }
                                  document.getElementById("ydjcblone_"+app_no).parentNode.previousSibling.lastChild.innerHTML="该工单下用户已执行";
                              },null);
					}else{
					    businessalert_success_Info(pkg.RET);
					}
			   }catch(e){
					 //操作失败关闭加载效果
						refresh_sucess_error(getErrorMsg(pkg.RET));
				   }
		   }
	   }
	   //发送失败
	   function sendDataFailCB_2(msg){
		   sucess_dowanload("发送下载数据包请求失败");
	   }
}



/**
 * 挨个读取所有数据文件。最终组装成批量的删除 语句和插入语句。最终在批量的操作数据库
 */
function read_db_file_2(files,returnt_proc_db_SQL,app_no,sucess_dowanload0){
	console.log("read_db_file_2="+app_no);
	 var path="file:///data/data/com.elec.mobile.platform.login/files/";
//	 var path="file:///mnt/sdcard/";
	 var files_length=files.length;
	 //所有的插入语句
   	 var insert_list=new Array();
   	 //所有的删除语句
   	 var delete_list=new Array();
	 //开始读取第一个
   	 read();
	function read(){
		 //完整路径
		 var fullPaht=path+files[0];
		//console.log("--------------------"+files.length+"-----------------------------------"+fullPaht);
		window.resolveLocalFileSystemURI(fullPaht,function(fileEntry){
			fileEntry.file(function(file){
				var tablename=(fileEntry.name).split(".")[0];
				var reader = new FileReader();
		        reader.onloadend = function(evt) {
		            var rst=evt.target.result;//读到的文件内容
		            var inserts=get_insert_sql_2(tablename,rst);
		             addArrayTOotherArray(insert_list,inserts);
		            var deletes=get_DTL_IDS_2(tablename,rst);
		            if(deletes!="")delete_list.push(deletes);
		            if(files.length>1){
	            		files.splice(0,1);
		            	read();
		            }else if(files.length==1){
		                //文件读取完毕后删除文件。目前不需要删除。如果要删除打开以下注释代码即可。
		            	//fileEntry.getParent(function(parent){
		            		//parent.removeRecursively(function(parent){
		            			//console.log("Remove Recursively Succeeded");
		            		//},function(e){
		            			// console.log("Remove Recursively fail");
		            		//});
		            	//},function(error){
		            		//console.log("+++++++++++++++++Parent fulpath ERROR-----------------------------------"+error.code);
		            	//});
		            	files=null;
		            	returnt_proc_db_SQL(insert_list,delete_list,app_no,sucess_dowanload0);
		            	insert_list=null;
		            	delete_list=null;
		            }
		        };
		        reader.readAsText(file);
			}, function(e){
				sucess_dowanload0("读取压缩文件内容失败");
			});
			
		},function(e){
			sucess_dowanload0("打开压缩文件内容失败");
		}); 
		tablename=null;
		fulpath=null;
	}
	/**
	 * 把数组2中的内容添加到数组1中。
	 * @param a1 数组1
	 * @param a2 数组2
	 * @returns
	 */
	function addArrayTOotherArray(a1,a2){
		for(var w=0;w<a2.length;w++){
			a1.push(a2[w]);
		}
	}
}
//读取文件，并组装DELETE,INSERT语句结束
function returnt_proc_db_SQL(insert_list,delete_list,app_no,sucess_dowanload1){
	//console.log("APP_NO=="+app_no+" DELETE------------------length: "+delete_list.length);
	//console.log("APP_NO=="+app_no+" INSERT------------------length: "+insert_list.length);
	var ydjc = window.sqlitePlugin.openDatabase("ydjc.db", "1.0","ydjc.db", 10*1024*1024);
	 //删除问题反馈
	 delete_list.push("DELETE FROM YJ_PROBLEM_FEEDBACK WHERE DTL_ID IN(SELECT D.DTL_ID FROM YJ_S_CHK_PLAN P,YJ_S_CHK_PLAN_DET D WHERE P.PLAN_NO=D.PLAN_NO AND P.APP_NO='"+app_no+"')");
	//删除修改记录YJ_DATA_COMPARISON_DTL_ID
	 delete_list.push("DELETE FROM YJ_DATA_COMPARISON_DTL_ID WHERE DTL_ID IN(SELECT D.DTL_ID FROM YJ_S_CHK_PLAN P,YJ_S_CHK_PLAN_DET D WHERE P.PLAN_NO=D.PLAN_NO AND P.APP_NO='"+app_no+"')");
	//删除上装错误日志YJ_DATA_COMPARISON_ERROR
	 delete_list.push("DELETE FROM YJ_DATA_COMPARISON_ERROR WHERE DTL_ID IN(SELECT D.DTL_ID FROM YJ_S_CHK_PLAN P,YJ_S_CHK_PLAN_DET D WHERE P.PLAN_NO=D.PLAN_NO AND P.APP_NO='"+app_no+"')"); 
	 //开始，删除
	exe_delete();
	//删除
	 function exe_delete(){
		 ydjc.transaction(function(tx){
			 tx.executeSql(delete_list[0],[],function(tx,res){
				// console.log("*******************"+delete_list.length+"********************" +"DELETE------SQL: "+delete_list[0]);
				 if(delete_list.length>1){
					 delete_list.splice(0,1);
					 exe_delete();
				 }else if(delete_list.length==1){//删除结束。开始插入。
					 delete_list=null;
                  //删除结束。开始插入
					 exe_insert(sucess_dowanload1);
				 }
			 },function(e){
				 sucess_dowanload1("批量删除移动终端数据失败");
			 });
		 });
	 }
	 //插入
	 function exe_insert(sucess_dowanload2){
		 ydjc.transaction(function(tx){
			 tx.executeSql(insert_list[0],[],function(tx,res){
				 //console.log("*******************"+insert_list.length+"********************" +"INSERT------SQL: "+insert_list[0]);
				 if(insert_list.length>1){
					 insert_list.splice(0,1);
					 exe_insert(sucess_dowanload2);
				 }else if(insert_list.length==1){//插入结束。开始更新插入标志。
					 insert_list=null;
					 //插入结束。开始更新插入标志
					 exe_update(sucess_dowanload2);
				 }
			 },function(error){
				 sucess_dowanload2("批量插入移动终端数据失败");
			 });
		 });
	 }
	 //更新下载标识
	 function exe_update(sucess_dowanload3){
		 var update_cons_sql="UPDATE YJ_C_CONS SET DOWNLOADING_TYPE=1 WHERE DTL_ID IN(SELECT dt.dtl_id from yj_s_chk_plan p,yj_s_chk_plan_det dt,yj_c_cons cs where p.plan_no=dt.plan_no and dt.dtl_id=cs.dtl_id and dt.cons_id=cs.cons_id and p.app_no=?)";
	     var update_app_no_sql="UPDATE YJ_TODO_SOMETHING SET DOWNLOADING_TYPE=1 WHERE APP_NO=?";
	     ydjc.transaction(function(tx){
	    	 tx.executeSql(update_cons_sql,[app_no],function(tx,res){
	    		 ydjc.transaction(function(tx){
	    			 tx.executeSql(update_app_no_sql,[app_no],function(tx,res){
	    				 //开始更新设备关联MOBILE_EQUIP_ID
	    				 exe_update_MOBILE_EQUIP_ID(sucess_dowanload3);
	    			 },function(e){
	    				 sucess_dowanload3("更新移动终端待办事宜表失败");
	    			 });
	    			 
	    		 });
	    	 },function(e){
	    		 
	    		 sucess_dowanload3("更新移动终端用户信息表失败");
	    	 });
	    	 
	     });
	 }
	 //更新设备关联MOBILE_EQUIP_ID
	 function exe_update_MOBILE_EQUIP_ID(sucess_dowanload4){
		 //查询出插入后，产生的MOBILE_EQUIP_ID
		 var select_MOBILE_EQUIP_ID="SELECT MOBILE_EQUIP_ID,EQUIP_ID,TYPE_CODE FROM YJ_C_EQUIP_RUN";
		 var update_list=new Array();
		 ydjc.transaction(function(tx){
			 tx.executeSql(select_MOBILE_EQUIP_ID,[],function(tx,res){
				 if(res.rows.length==0){
					 sucess_dowanload4(1);//没有查询到设备id，关闭加载效果。
					 return;
				 }
				 //01自备电厂
				 var update_01="UPDATE YJ_C_SPARE_POWER SET MOBILE_EQUIP_ID=";
				 //04:避雷器
				 var update_04="UPDATE YJ_C_ARRESTER SET MOBILE_EQUIP_ID=";
				 //05:继电保护装置
				 var update_05="UPDATE YJ_C_RELAY_PROTECT_DEV SET MOBILE_EQUIP_ID=";
				 //06:断路器
				 var update_06="UPDATE YJ_C_BREAKER SET MOBILE_EQUIP_ID=";
				 //07:无功补偿设备
				 var update_07="UPDATE YJ_C_RPC_EQUIP SET MOBILE_EQUIP_ID=";
				 //08:自备应急电源
				 var update_08="UPDATE YJ_C_SPARE_GENERATOR SET MOBILE_EQUIP_ID=";
				//09:电缆
				 var update_09="UPDATE YJ_C_JCDDL SET MOBILE_EQUIP_ID=";
				 
				 for(var i=0;i<res.rows.length;i++){
					 var item=res.rows.item(i);
					 if(!item.EQUIP_ID || item.EQUIP_ID=="" || item.EQUIP_ID=="null"){
					 }else{
						 if(item.TYPE_CODE=="01"){
							 update_list.push(update_01+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
						 }
						 
						 else if(item.TYPE_CODE=="04"){
							 update_list.push(update_04+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
						 }
						 
						 else if(item.TYPE_CODE=="05"){
							 update_list.push(update_05+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
						 }
						 
						 else if(item.TYPE_CODE=="06"){
							 update_list.push(update_06+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
						 }
						 
						 else if(item.TYPE_CODE=="07"){
							 update_list.push(update_07+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
						 }
						 
	                     else if(item.TYPE_CODE=="08"){
	                    	 update_list.push(update_08+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
						 }
						 
	                     else if(item.TYPE_CODE=="09"){
	                    	 update_list.push(update_09+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
						 }
					 }
				 }
				 //开始更新
				  ydjc.transaction(function(tx){
					  var exe_sum_error=0;
					  var exe_sum_sucess=1;
					 for(var u in update_list){
						 if(exe_sum_error>0){
							 close_loading_view("批量更新终端数据库失败");
							 break;
						 }
					   tx.executeSql(update_list[u],[],function(tx,res){
						   
						   if(exe_sum_sucess==update_list.length){
						
							   exe_update_MOBILE_BUG_ID(sucess_dowanload4);
							  // return;
						   }
						   exe_sum_sucess++;
					   },function(e){
						   sucess_dowanload4("更新移动终端设备关联表失败");
						   exe_sum_error++;
					   });
					   
					 }
					// sucess_dowanload4(1);
				 });
				 
			 },function(e){
				 sucess_dowanload4("查询移动终端设备表失败");
			 });
			 
		 });
	 }
	 
	 //更新安全隐患在整改中的外键：MOBILE_BUG_ID
	 function exe_update_MOBILE_BUG_ID(sucess_dowanload5){
		 //查询出插入后，产生的MOBILE_BUG_ID
		 var select_MOBILE_BUG_ID="SELECT MOBILE_BUG_ID,ID FROM YJ_S_SAFETY_BUG";
		 var update_list=new Array();
		 ydjc.transaction(function(tx){
			 tx.executeSql(select_MOBILE_BUG_ID,[],function(tx,res){
				 if(res.rows.length==0){
					 sucess_dowanload5(1);//没有查询到MOBILE_BUG_ID，关闭加载效果。
					 return;
				 }
				 var update_sql="UPDATE YJ_S_IMPROVE SET MOBILE_BUG_ID=";
				 for(var i=0;i<res.rows.length;i++){
					 update_list.push(update_sql+res.rows.item(i).MOBILE_BUG_ID+" WHERE ID2="+res.rows.item(i).ID);
				 }
				if(update_list.length>0){
				 //开始更新
				  ydjc.transaction(function(tx){
					  var exe_sum_error_li=0;
					  var exe_sum_sucess_li=1;
					 for(var u in update_list){
						 if(exe_sum_error_li>0){
							 close_loading_view("批量更新终端数据库失败");
							 break;
						 }
					   tx.executeSql(update_list[u],[],function(tx,res){
						   if(exe_sum_sucess_li==update_list.length){
						
							   sucess_dowanload5(1);
							   return;
						   }
						   exe_sum_sucess_li++;
					   },function(e){
						   sucess_dowanload5("更新移动终端设备关联表失败");
						   exe_sum_error_li++;
					   });
					   
					 }
				 });
			    }
			 },function(e){ sucess_dowanload5("查询移动终端设备表失败");});
		 });
	 }
}

/**
 * 根据xx.txt文件内容组装成SQL语句。
 * @param table 表明
 * @param str .txt文件内容
 * @returns insert语句
 */
function get_insert_sql_2(table,str){
	var sqllist=new Array();
	if(str=="" || str==null || str=="null"){
		
	}else{
		//获得所有的记录
		var datas=str.split("\n");
		//获得数据库字段
		var column=datas[0];
		//替换'|'为','
		column=column.replace(/\|/g,",");
		//拼接插入字符串
		var inset="INSERT INTO "+table+"("+column+") VALUES";
		 datas.splice(0,1);//移除字段头部
         for(var i=0;i<datas.length;i++){
		    var values="(";
            var val=datas[i];
		    var vals=val.split("|");
			var len=vals.length;
		   for(var j=0;j<len;j++){
            	values+=("'"+vals[j]+(j==(len-1)?"'":"',"));
            }
			values+=")";
			sqllist[i]=inset+values;
        }
	}
	return sqllist;
}

/**
 *除了YJ_S_CHK_PLAN以外表，提取里面的DTL_ID
 *YJ_S_CHK_PLAN提取出PLAN_NO
 * @param str
 * @returns {Array}
 */
function get_DTL_IDS_2(tablename,str){
	   if(str=="" || str==null || str=="null"){
			
		}else{
			//获得所有的记录
			var datas=str.split("\n");
            //列头
			var columns=datas[0].split("|");
			 var index=-1;
			 var item=null;
			 var delete_sql="DELETE FROM "+tablename+" WHERE ";
			 for(var i=0;i<columns.length;i++){
				 item=columns[i];
				 if(tablename=="YJ_S_CHK_PLAN"){
						if(item=="APP_NO"){
							index=i;
							delete_sql+="APP_NO IN";
							break;
						}
					}else if(tablename=="YJ_C_CONS"){
                        if(item=="DTL_ID"){
                            index=i;
                            delete_sql+="DTL_ID IN";
                            break;
                        }
                    }
                   else if(tablename=="YJ_S_CHK_PLAN_DET"){
                        if(item=="DTL_ID"){
                            index=i;
                            delete_sql+="DTL_ID IN";
                            break;
                        }
                    }else if(tablename=="YJ_S_APP_REPLY"){
						if(item=="AR_ID"){
							index=i;
							delete_sql+="AR_ID IN";
							break;
						}
					}
					else if(tablename=="YJ_S_GWZYXJ" || tablename=="YJ_S_HR_CHKRESULT" || tablename=="YJ_S_IMPROVE" || tablename=="YJ_S_POWER_ACCI" || tablename=="YJ_S_SAFETY_BUG"){
						if(item=="ID"){
							index=i;
							delete_sql+="ID IN";
							break;
						}
					}
                   else if(tablename=="YJ_NEWELECTRICIAN_INFO"){
                        if(item=="CONS_ID"){
                            index=i;
                            delete_sql+="CONS_ID IN";
                            break;
                        }
                    }
					//else if(tablename=="YJ_S_HR_CHKRESULT"){
						//if(item=="ID"){
							//index=i;
							//delete_sql+="ID IN";
							//break;
						//}
					//}
					else if(tablename=="YJ_S_HR_IMPORTANT_CUST"){
						if(item=="CR_ID"){
							index=i;
							delete_sql+="CR_ID IN";
							break;
						}
					}
					//else if(tablename=="YJ_S_IMPROVE"){
						//if(item=="ID"){
							//index=i;
							//break;
						//}
					//S}
					//else if(tablename=="YJ_S_POWER_ACCI"){
						//if(item=="ID"){
							//index=i;
						//	break;
						//}
					//}
					else if(tablename=="YJ_S_PREVENTIVE_TEST"){
						if(item=="TEST_ID"){
							index=i;
							delete_sql+="TEST_ID IN";
							break;
						}
					}
					//else if(tablename=="YJ_S_SAFETY_BUG"){
						//if(item=="ID"){
							//index=i;
							//break;
						//}
					//}
					else{
						if(item=="DTL_ID"){
							index=i;
							delete_sql+="DTL_ID IN";
							break;
						}
					}
			 }
			 var dtl_ids="(";
			for(var j=1;j<datas.length;j++){
				var values=datas[j].split("|");
				dtl_ids+=("'"+values[index]+(j==(datas.length-1)?"'":"',"));
			}
			 dtl_ids+=")";
			 if(index>-1)
			 return delete_sql+dtl_ids;
		}
		return "";
}
/***********************************************单个工单数据包下载---结束*********************************************************/

/**
 * 关闭效果
 */
function close_loading_view(msg){
	$("#yxzypt_msg").html("");
	//弹出错误信息
	 $("#yxzypt_msg").html(msg);
	 onchange_val();
	 $("#yxzypt_dailog").show();
	//操作失败关闭加载效果
	 $("#businessList_laoding_view").hide();
}
/***********************************************请求营销数据返回信息提示*********************************************************/
function businessalert_Info(pkg_ret){
    if(pkg_ret=="11"){
         close_loading_view("请求模块错误 没有该模块");
    }else if(pkg_ret=="12"){
        close_loading_view("请求业务功能错误 没有该业务功能");
    }else if(pkg_ret=="13"){
        close_loading_view("请求业务功能错误 业务数据格式不正确");
    }else if(pkg_ret=="14"){
        close_loading_view("该用户下没有工单");
    }else if(pkg_ret=="99"){
        close_loading_view("请求业务功能错误 业务功能没有启用");
    }
}
function businessalert_success_Info(pkg_ret){
    if(pkg_ret=="11"){
         sucess_dowanload("请求模块错误 没有该模块");
    }else if(pkg_ret=="12"){
        sucess_dowanload("请求业务功能错误 没有该业务功能");
    }else if(pkg_ret=="13"){
        sucess_dowanload("请求业务功能错误 业务数据格式不正确");
    }else if(pkg_ret=="99"){
        sucess_dowanload("请求业务功能错误 业务功能没有启用");
    }
}

/**
 * 根据DTL_ID、CR_ID组装出所有的需要删除的数据。
 * @param dtl_id 工单id
 * @param cr_id  检查结果id
 * @param callback_suces  成功回调
 * @param callback_fail   错误回调
 */
function select_mobileDB_make_deleteSQL_DTLID(app_no,dtl_id,cr_id,cons_id,deletes_list){
    //所有的删除语句
    //var deletes_list=new Array();
    try{
        
        //1.整改表删除
            var YJ_S_IMPROVE="DELETE FROM YJ_S_IMPROVE WHERE ID2 IN(SELECT ID FROM YJ_S_SAFETY_BUG WHERE ID2="+cr_id+")";
                deletes_list.push(YJ_S_IMPROVE);
        //2.DTL_ID,CR_ID删除的表
        
            ////////////DTL_ID\\\\\\\\\\\\
            //核查用户供电合同表
            var YJ_CHECK_CONS_SUP_CONTR="DELETE FROM YJ_CHECK_CONS_SUP_CONTR WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_CHECK_CONS_SUP_CONTR);
            //避雷器档案
            var YJ_C_ARRESTER="DELETE FROM YJ_C_ARRESTER WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_ARRESTER);
                
            //断路器档案
            var YJ_C_BREAKER="DELETE FROM YJ_C_BREAKER WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_BREAKER);            
            //用户基础档案
            var YJ_C_CONS="DELETE FROM YJ_C_CONS WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_CONS);   
                
            //运行设备信息
            var YJ_C_EQUIP_RUN="DELETE FROM YJ_C_EQUIP_RUN WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_EQUIP_RUN);
            //电缆设备档案
            var YJ_C_JCDDL="DELETE FROM YJ_C_JCDDL WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_JCDDL);
                
            //进线电源
            var YJ_C_PS="DELETE FROM YJ_C_PS WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_PS);
            //继电保护装置档案
            var YJ_C_RELAY_PROTECT_DEV="DELETE FROM YJ_C_RELAY_PROTECT_DEV WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_RELAY_PROTECT_DEV);
                
            //无功补偿设备档案
            var YJ_C_RPC_EQUIP="DELETE FROM YJ_C_RPC_EQUIP WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_RPC_EQUIP);
            //用户受电点关系表
            var YJ_C_SP="DELETE FROM YJ_C_SP WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_SP);
                
            //自备发电机档案
            var YJ_C_SPARE_GENERATOR="DELETE FROM YJ_C_SPARE_GENERATOR WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_SPARE_GENERATOR);
            //自备电源档案
            var YJ_C_SPARE_POWER="DELETE FROM YJ_C_SPARE_POWER WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_SPARE_POWER);
                
            //修改记录
            var YJ_DATA_COMPARISON_DTL_ID="DELETE FROM YJ_DATA_COMPARISON_DTL_ID WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_DATA_COMPARISON_DTL_ID);
            //上装错误日志
            var YJ_DATA_COMPARISON_ERROR="DELETE FROM YJ_DATA_COMPARISON_ERROR WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_DATA_COMPARISON_ERROR);
                
            //变压器档案
            var YJ_G_TRAN="DELETE FROM YJ_G_TRAN WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_G_TRAN);
            //用户计量装置
            var YJ_MP_CONS="DELETE FROM YJ_MP_CONS WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_MP_CONS);
                
            //用户计量互感器装置
            var YJ_MP_IT="DELETE FROM YJ_MP_IT WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_MP_IT);
            //计量电表关系信息
            var YJ_MP_METER="DELETE FROM YJ_MP_METER WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_MP_METER);
                
            //用户计量互感器装置
            var YJ_PROBLEM_FEEDBACK="DELETE FROM YJ_PROBLEM_FEEDBACK WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_PROBLEM_FEEDBACK);
            //查询用户电费台账信息
            var YJ_RCVBL_FLOW="DELETE FROM YJ_RCVBL_FLOW WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_RCVBL_FLOW);
                
            //检查计划信息明细
            var YJ_S_CHK_PLAN_DET="DELETE FROM YJ_S_CHK_PLAN_DET WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_S_CHK_PLAN_DET);
            //非重要客户巡检记录
            var YJ_S_GWZYXJ_UN="DELETE FROM YJ_S_GWZYXJ_UN WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_S_GWZYXJ_UN);

                //检查结果信息
            var YJ_S_INSPECT_RSLT="DELETE FROM YJ_S_INSPECT_RSLT WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_S_INSPECT_RSLT);
            
           ////////////CR_ID\\\\\\\\\\\\
           //重要客户巡检记录
           var YJ_S_GWZYXJ="DELETE FROM YJ_S_GWZYXJ WHERE CR_ID="+cr_id;
               deletes_list.push(YJ_S_GWZYXJ);
           //重要客户检查结果记录实体
           var YJ_S_HR_CHKRESULT="DELETE FROM YJ_S_HR_CHKRESULT WHERE CR_ID="+cr_id;
               deletes_list.push(YJ_S_HR_CHKRESULT);
               
           //重要客户档案信息
           var YJ_S_HR_IMPORTANT_CUST="DELETE FROM YJ_S_HR_IMPORTANT_CUST WHERE CR_ID="+cr_id;
               deletes_list.push(YJ_S_HR_IMPORTANT_CUST);
               
           //用电事故信息
           var YJ_S_POWER_ACCI="DELETE FROM YJ_S_POWER_ACCI WHERE CR_ID="+cr_id;
               deletes_list.push(YJ_S_POWER_ACCI);
           //预防性试验信息
           var YJ_S_PREVENTIVE_TEST="DELETE FROM YJ_S_PREVENTIVE_TEST WHERE CR_ID="+cr_id;
               deletes_list.push(YJ_S_PREVENTIVE_TEST);
           //安全隐患信息
           var YJ_S_SAFETY_BUG="DELETE FROM YJ_S_SAFETY_BUG WHERE ID2="+cr_id;
               deletes_list.push(YJ_S_SAFETY_BUG);
           ////////////APP_NO删除表\\\\\\\\\\\\
            //客户签收信息表删除
            var YJ_S_APP_REPLY="DELETE FROM YJ_S_APP_REPLY WHERE APP_NO='"+app_no+"'";
            deletes_list.push(YJ_S_APP_REPLY);
            
            //检查计划信息
            var YJ_S_CHK_PLAN="DELETE FROM YJ_S_CHK_PLAN WHERE APP_NO='"+app_no+"'";
            deletes_list.push(YJ_S_CHK_PLAN);
            
            ////////////YJ_NEWELECTRICIAN_INFO删除表\\\\\\\\\\\\
            var YJ_NEWELECTRICIAN_INFO="DELETE FROM YJ_NEWELECTRICIAN_INFO WHERE CONS_ID='"+cons_id+"'";
            deletes_list.push(YJ_NEWELECTRICIAN_INFO);
            
            return;
    }catch(e){
        close_loading_view("组装删除JS语法错误！");
        return;
    }
}

</script>
