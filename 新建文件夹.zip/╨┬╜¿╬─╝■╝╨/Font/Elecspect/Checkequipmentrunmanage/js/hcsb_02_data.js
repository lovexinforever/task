<script type="text/javascript">
/**
 * 检查设备运行管理
 * @param cr_id=检查结果唯一标识
 * @param mlkg_yw=1母联开关
 * @param mlkg_czsj=1母联开关_最近一次操作日期
 * @param mlkg_cz=1母联开关_操作时
 * @param bztzz_yw=2备自投装置
 * @param zbyj_zz=3自备应急发电装置
 * @param zbyj_xq=3自备应急发电装置_是否满足需求
 * @param zbyj_sj=3自备应急发电装置_发电机试机情况
 * @param zbyj_fd=3自备应急发电装置_防倒装置
 * @param ztyxqk=5设备运行情况_受电设备整体运行时间
 * @param byq=5设备运行情况_变压器运行状况
 * @param gdycg=5设备运行情况_高低压成套柜
 * @param dlq=5设备运行情况_高低压断路器、负荷开关
 * @param ctpt=5设备运行情况_计量、保护CT/PT
 * @param wgbc=5设备运行情况_无功补偿设备
 * @param dl=5设备运行情况_电缆(含进、出线)
 * @param aqjl=5设备运行情况_各项安全距离
 * @param bjlyc=20表计计量有无异常
 * @param ycnr=20表计计量有无异常_异常内容
 * @param ss=22负控装置情况_各项视数是否正常
 * @param fktxfx=22负控装置情况_负控天线是否倒下或朝向错误方向
 * @param bx=22负控装置情况_是否报修
 * @param lj=22负控装置情况_负控与总开连接是否正常
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询界面数据
function get_yj_s_gwzyxj_hcsb02_data(json_where,sucessCB,failCB){
	var sql="select id as id,cr_id as cr_id,mlkg_yw as mlkg_yw,mlkg_czsj as mlkg_czsj,mlkg_cz as mlkg_cz,bztzz_yw as bztzz_yw,zbyj_zz as zbyj_zz,zbyj_xq as zbyj_xq,zbyj_sj as zbyj_sj,zbyj_fd as zbyj_fd,ztyxqk as ztyxqk,byq as byq,gdycg as gdycg,dlq as dlq,ctpt as ctpt,wgbc as wgbc,dl as dl,aqjl as aqjl,bjlyc as bjlyc,ycnr as ycnr,ss as ss,fktxfx as fktxfx,bx as bx,lj as lj,mlkg_yw_img as mlkg_yw_img,bztzz_yw_img as bztzz_yw_img,zbyj_zz_img as zbyj_zz_img,ztyxqk_img as ztyxqk_img,bjlyc_img as bjlyc_img,ss_img as ss_img,BYQ_RQ,BYQ_GZ,GDYCG_RQ,GDYCG_GZ,DLQ_RQ,DLQ_GZ,CTPT_RQ,CTPT_GZ,WGBC_RQ,WGBC_GZ,DL_RQ,DL_GZ,AQJL_GZ from YJ_S_GWZYXJ where cr_id=?";
	db_execut_oneSQL(null,sql,json_where,sucessCB,failCB);
}

/**
 * 问题反馈
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询问题反馈数据
function get_yj_problem_feedback_data(json_where1,sucessCB1,failCB1){
	 var pro_sql="select problem as problem,statue as statue from YJ_PROBLEM_FEEDBACK where dtl_id=? and cons_id=? and rrio_code=? and modle_type=?";
	 db_execut_oneSQL(null,pro_sql,json_where1,sucessCB1,failCB1);
}

/**
 * 
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @param sstatue 数据状态，0为空，1有值；为空时执行插入，有值时执行更新
 * @return
 */
//保存界面数据
function save_hcsb02_data(json_where,sucessCB1,failCB1,sstatue){
	var update="update YJ_S_GWZYXJ set mlkg_yw=?,mlkg_czsj=?,mlkg_cz=?,bztzz_yw=?,zbyj_zz=?,zbyj_xq=?,zbyj_sj=?,zbyj_fd=?,ztyxqk=?,byq=?,gdycg=?,dlq=?,ctpt=?,wgbc=?,dl=?,aqjl=?,bjlyc=?,ycnr=?,ss=?,fktxfx=?,bx=?,lj=?,mlkg_yw_img=?,bztzz_yw_img=?,zbyj_zz_img=?,ztyxqk_img=?,bjlyc_img=?,ss_img=?,BYQ_RQ=?,BYQ_GZ=?,GDYCG_RQ=?,GDYCG_GZ=?,DLQ_RQ=?,DLQ_GZ=?,CTPT_RQ=?,CTPT_GZ=?,WGBC_RQ=?,WGBC_GZ=?,DL_RQ=?,DL_GZ=?,AQJL_GZ=? where cr_id=?";
	var insert="INSERT INTO YJ_S_GWZYXJ (id,cr_id,mlkg_yw,mlkg_czsj,mlkg_cz,bztzz_yw,zbyj_zz,zbyj_xq,zbyj_sj,zbyj_fd,ztyxqk,byq,gdycg,dlq,ctpt,wgbc,dl,aqjl,bjlyc,ycnr,ss,fktxfx,bx,lj,mlkg_yw_img,bztzz_yw_img,zbyj_zz_img,ztyxqk_img,bjlyc_img,ss_img,BYQ_RQ,BYQ_GZ,GDYCG_RQ,GDYCG_GZ,DLQ_RQ,DLQ_GZ,CTPT_RQ,CTPT_GZ,WGBC_RQ,WGBC_GZ,DL_RQ,DL_GZ,AQJL_GZ) VALUES ('0',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if(sstatue==0){
	 db_execut_oneSQL(null,insert,json_where,sucessCB1,failCB1);
}else if(sstatue==1){
	 db_execut_oneSQL(null,update,json_where,sucessCB1,failCB1);
}
}
/**
 * 
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @param sstatue 数据状态，0为空，1有值；为空时执行插入，有值时执行更新
 * @return
 */
//保存问题反馈数据
function save_hcsb02pro_data(json_where,sucessCB1,failCB1,sstatue){
	var pro_update="update YJ_PROBLEM_FEEDBACK set PROBLEM=?,STATUE=? where dtl_id=? and cons_id=? and rrio_code=? and modle_type=?";
	var pro_insert="INSERT INTO YJ_PROBLEM_FEEDBACK (DTL_ID,CONS_ID,RRIO_CODE,MODLE_TYPE,PROBLEM,STATUE) VALUES (?,?,?,?,?,?)";
	if(sstatue==0){
		 db_execut_oneSQL(null,pro_insert,json_where,sucessCB1,failCB1);
	}else if(sstatue==1){
		 db_execut_oneSQL(null,pro_update,json_where,sucessCB1,failCB1);
	}
}

/*保存修改记录到表YJ_DATA_COMPARISON_DTL_ID*/
function save_Correct_Record(){
	var select_sql="select DATA_ID from YJ_DATA_COMPARISON_DTL_ID where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 db_execut_oneSQL(null,select_sql,[cons_info.dtl_id,cons_info.cons_id,'A0005'],save_sucessCB1,savefailCB1);
}					
/*查询成功回调*/
var save_sucessCB1 = function(tx,res){
	 var sql_upnm="update YJ_DATA_COMPARISON_DTL_ID set LINE_DATA=?,TYPE=? where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 var sql_insert="insert into YJ_DATA_COMPARISON_DTL_ID (MODEL_TYPE,MODEL_TITLE,TYPE,OLD_DATA_INDEX,OLD_DATA,LINE_DATA,DTL_ID,CONS_ID) values (?,?,?,?,?,?,?,?)";
		 var result_len=res.rows.length;
		 if(result_len){//更新
		 		 db_execut_oneSQL(null,sql_upnm,['{"母联开关":"'+text1[0][(temp_val[0]-1)]+'","母联开关_最近一次操作日期":"'+$('#mlkg_czsj').val()+'","母联开关_操作时":"'+text1[1][(temp_val[1]-1)]+'","备自投装置":"'+text1[2][(temp_val[2]-1)]+'","自备应急发电装置":"'+text1[3][(temp_val[3]-1)]+'","自备应急发电装置_是否满足需求":"'+text1[4][(temp_val[4]-1)]+'","自备应急发电装置_发电机试机情况":"'+text1[5][(temp_val[5]-1)]+'","自备应急发电装置_防倒装置":"'+text1[6][(temp_val[6]-1)]+'","设备运行情况_受电设备整体运行时间":"'+text1[7][(temp_val[7]-1)]+'","设备运行情况_变压器运行状况":"'+text1[8][(temp_val[8]-1)]+'","设备运行情况_高低压成套柜":"'+text1[9][(temp_val[9]-1)]+'","设备运行情况_高低压断路器、负荷开关":"'+text1[10][(temp_val[10]-1)]+'","设备运行情况_计量、保护CT/PT":"'+text1[11][(temp_val[11]-1)]+'","设备运行情况_无功补偿设备":"'+text1[12][(temp_val[12]-1)]+'","设备运行情况_电缆(含进、出线)":"'+text1[13][(temp_val[13]-1)]+'","设备运行情况_各项安全距离":"'+text1[14][(temp_val[14]-1)]+'","表计计量有无异常":"'+text1[15][(bjlyc_val-1)]+'","表计计量有无异常_异常内容":"'+$('#ycnr').val()+'","负控装置情况_各项视数是否正常":"'+text1[16][(temp_val[15]-1)]+'","负控装置情况_负控天线是否倒下或朝向错误方向":"'+text1[17][(fktxfx_val-1)]+'","负控装置情况未报修":"'+text1[18][(bx_val-1)]+'","负控装置情况_负控与总开连接是否正常":"'+text1[19][(temp_val[16]-1)]+'","设备运行情况_变压器_故障日期":"'+$('#byq_gzdate').val()+'","设备运行情况_变压器_故障内容":"'+$('#byq_gzcont').val()+'","设备运行情况_高低压成套柜_故障日期":"'+$('#gdytj_gzdate').val()+'","设备运行情况_高低压成套柜_故障内容":"'+$('#gdytj_gzcont').val()+'","设备运行情况_高低压断路器、负荷开关_故障日期":"'+$('#gdydlq_gzdata').val()+'","设备运行情况_高低压断路器、负荷开关_故障内容":"'+$('#gdydlq_gzcont').val()+'","设备运行情况_计量、保护CT/PT_故障日期":"'+$('#jlbh_gzdate').val()+'","设备运行情况_计量、保护CT/PT_故障内容":"'+$('#jlbh_gzcont').val()+'","设备运行情况_无功补偿设备_故障日期":"'+$('#wgbc_gzdate').val()+'","设备运行情况_无功补偿设备_故障内容":"'+$('#wgbc_gzdate').val()+'","设备运行情况_电缆(含进、出线)_故障日期":"'+$('#dl_gzdate').val()+'","设备运行情况_电缆(含进、出线)_故障内容":"'+$('#dl_gzcont').val()+'","设备运行情况_各项安全距离_安全距离不满足项目":"'+$('#aqjl_xm').val()+'"}',"2",cons_info.dtl_id,cons_info.cons_id,"A0005"],null,null);
		 	}else{//插入
		 		 db_execut_oneSQL(null,sql_insert,["A0005","核查设备运行管理","2","",json_olddata,'{"母联开关":"'+text1[0][(temp_val[0]-1)]+'","母联开关_最近一次操作日期":"'+$('#mlkg_czsj').val()+'","母联开关_操作时":"'+text1[1][(temp_val[1]-1)]+'","备自投装置":"'+text1[2][(temp_val[2]-1)]+'","自备应急发电装置":"'+text1[3][(temp_val[3]-1)]+'","自备应急发电装置_是否满足需求":"'+text1[4][(temp_val[4]-1)]+'","自备应急发电装置_发电机试机情况":"'+text1[5][(temp_val[5]-1)]+'","自备应急发电装置_防倒装置":"'+text1[6][(temp_val[6]-1)]+'","设备运行情况_受电设备整体运行时间":"'+text1[7][(temp_val[7]-1)]+'","设备运行情况_变压器运行状况":"'+text1[8][(temp_val[8]-1)]+'","设备运行情况_高低压成套柜":"'+text1[9][(temp_val[9]-1)]+'","设备运行情况_高低压断路器、负荷开关":"'+text1[10][(temp_val[10]-1)]+'","设备运行情况_计量、保护CT/PT":"'+text1[11][(temp_val[11]-1)]+'","设备运行情况_无功补偿设备":"'+text1[12][(temp_val[12]-1)]+'","设备运行情况_电缆(含进、出线)":"'+text1[13][(temp_val[13]-1)]+'","设备运行情况_各项安全距离":"'+text1[14][(temp_val[14]-1)]+'","表计计量有无异常":"'+text1[15][(bjlyc_val-1)]+'","表计计量有无异常_异常内容":"'+$('#ycnr').val()+'","负控装置情况_各项视数是否正常":"'+text1[16][(temp_val[15]-1)]+'","负控装置情况_负控天线是否倒下或朝向错误方向":"'+text1[17][(fktxfx_val-1)]+'","负控装置情况未报修":"'+text1[18][(bx_val-1)]+'","负控装置情况_负控与总开连接是否正常":"'+text1[19][(temp_val[16]-1)]+'","设备运行情况_变压器_故障日期":"'+$('#byq_gzdate').val()+'","设备运行情况_变压器_故障内容":"'+$('#byq_gzcont').val()+'","设备运行情况_高低压成套柜_故障日期":"'+$('#gdytj_gzdate').val()+'","设备运行情况_高低压成套柜_故障内容":"'+$('#gdytj_gzcont').val()+'","设备运行情况_高低压断路器、负荷开关_故障日期":"'+$('#gdydlq_gzdata').val()+'","设备运行情况_高低压断路器、负荷开关_故障内容":"'+$('#gdydlq_gzcont').val()+'","设备运行情况_计量、保护CT/PT_故障日期":"'+$('#jlbh_gzdate').val()+'","设备运行情况_计量、保护CT/PT_故障内容":"'+$('#jlbh_gzcont').val()+'","设备运行情况_无功补偿设备_故障日期":"'+$('#wgbc_gzdate').val()+'","设备运行情况_无功补偿设备_故障内容":"'+$('#wgbc_gzdate').val()+'","设备运行情况_电缆(含进、出线)_故障日期":"'+$('#dl_gzdate').val()+'","设备运行情况_电缆(含进、出线)_故障内容":"'+$('#dl_gzcont').val()+'","设备运行情况_各项安全距离_安全距离不满足项目":"'+$('#aqjl_xm').val()+'"}',cons_info.dtl_id,cons_info.cons_id],null,null);
		 	}
	 }
/*查询失败回调*/
var savefailCB1=function(){
	 
}


</script>