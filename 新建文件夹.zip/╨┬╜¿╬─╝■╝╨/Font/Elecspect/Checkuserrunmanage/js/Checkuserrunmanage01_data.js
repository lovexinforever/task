<script type="text/javascript">
/**
 * 对应界面==核查用户运行管理信息-重要用户
 * 对应表==重要客户巡检记录（YJ_S_GWZYXJ）表的一部分数据
 * @param DTL_ID=工单id
 * @param CONS_ID=工单下用户id
 * @param SYRQ=4电气设备预防性试验_最近一次试验时间      
 * @param SYJL=4电气设备预防性试验_试验记录				 
 * @param SYXMQQ=4电气设备预防性试验_试验项目是否齐全		  
 * @param QSSBXM=4电气设备预防性试验_缺少设备项目			
 * @param JHAPSJ=4电气设备预防性试验_计划安排预试时间			  
 * @param DGGL_FZR=6电工管理_电气负责人					  
 * @param DGGL_ZB_RS=6电工管理_值班电工人数			  
 * @param DGGL_ZB_YPZ=6电工管理_值班电工应配置人数		  
 * @param DGGL_JX_RS=6电工管理_检修电工人数			  
 * @param DGGL_JX_YPZ=6电工管理_检修电工应配置人数		  
 * @param BDSBYQHJ=9配电所及变压器环境					
 * @param BDSBYQHJ_IMG=9配电所及变压器环境_拍照			
 * @param BDSBYQHJ_PRO=9配电所及变压器环境_问题描述      
 * @param AQQJ=10安全工器具							 
 * @param AQQJ_SYRQ=10安全工器具_前一次试验日期			  
 * @param AQQJ_BHGS=10安全工器具_不合格安全工器具件数      
 * @param AQQJ_IMG=10安全工器具_拍照						
 * @param XFQC=11消防器材								
 * @param XFQC_SFGQ=11消防器材_是否过期				
 * @param FXDW=12防小动物措施							
 * @param FXDW_IMG=12防小动物措施_拍照					
 * @param BPBJ=13备品备件									
 * @param BJNR=13备品备件_备件内容						  
 * @param BPBJ_IMG=13备品备件_拍照					
 * @param YJYA_GZ=14应急预案_用户端故障应急预案				
 * @param YJYA_BA=14应急预案_非电性质保安措施			
 * @param YJYA_IMG=14应急预案_拍照					
 * @param PDFZBR=15值班名单与联系电话_配电房值班人员		  
 * @param PDFZRR=15值班名单与联系电话_配电房负责人		  
 * @param YL=23本年度应急演练							
 * @param YL_SJ=23本年度应急演练_演练时间				  
 * @param YL_JS=23本年度应急演练_供电公司在演练中承担角色	
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询界面数据
function get_yj_s_gwzyxj_userrun01_data(json_where,sucessCB,failCB){
	var sql="select id as id,syrq as syrq,syjl as syjl,syxmqq as syxmqq,qssbxm as qssbxm,jhapsj as jhapsj,dggl_fzr as dggl_fzr,dggl_zb_rs as dggl_zb_rs,dggl_zb_ypz as dggl_zb_ypz,dggl_jx_rs as dggl_jx_rs,dggl_jx_ypz as dggl_jx_ypz,bdsbyqhj as bdsbyqhj,bdsbyqhj_img as bdsbyqhj_img,bdsbyqhj_pro as bdsbyqhj_pro,aqqj as aqqj,aqqj_syrq as aqqj_syrq,aqqj_bhgs as aqqj_bhgs,aqqj_img as aqqj_img,xfqc as xfqc,xfqc_sfgq as xfqc_sfgq,fxdw as fxdw,fxdw_img as fxdw_img,bpbj as bpbj,bjnr as bjnr,bpbj_img as bpbj_img,yjya_gz as yjya_gz,yjya_ba as yjya_ba,yjya_img as yjya_img,pdfzbr as pdfzbr,pdfzrr as pdfzrr,yl as yl,yl_sj as yl_sj,yl_js as yl_js from YJ_S_GWZYXJ where cr_id=?";
	db_execut_oneSQL(null,sql,json_where,sucessCB,failCB);
}
/**
 * 问题反馈
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询问题反馈数据
function get_yj_problem_feedback_data(json_where1,sucessCB1,failCB1){
	 var pro_sql="select problem as problem,statue as statue from YJ_PROBLEM_FEEDBACK where dtl_id=? and cons_id=? and rrio_code=? and modle_type=?";
	 db_execut_oneSQL(null,pro_sql,json_where1,sucessCB1,failCB1);
}

/**
 * /*保存界面数据
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @param sstatue 数据状态，0为空，1有值；为空时执行插入，有值时执行更新
 * @return
 */
function save_userrun01_data(json_where,sucessCB1,failCB1,sstatue){
	var update="update YJ_S_GWZYXJ set syrq=?,syjl=?,syxmqq=?,qssbxm=?,jhapsj=?,dggl_fzr=?,dggl_zb_rs=?,dggl_zb_ypz=?,dggl_jx_rs=?,dggl_jx_ypz=?,bdsbyqhj=?,bdsbyqhj_pro=?,aqqj=?,aqqj_syrq=?,aqqj_bhgs=?,xfqc=?,xfqc_sfgq=?,fxdw=?,bpbj=?,bjnr=?,yjya_gz=?,yjya_ba=?,pdfzbr=?,pdfzrr=?,yl=?,yl_sj=?,yl_js=?,bdsbyqhj_img=?,aqqj_img=?,fxdw_img=?,bpbj_img=?,yjya_img=? where cr_id=?";
	var insert="INSERT INTO YJ_S_GWZYXJ (id,cr_id,syrq,syjl,syxmqq,qssbxm,jhapsj,dggl_fzr,dggl_zb_rs,dggl_zb_ypz,dggl_jx_rs,dggl_jx_ypz,bdsbyqhj,bdsbyqhj_pro,aqqj,aqqj_syrq,aqqj_bhgs,xfqc,xfqc_sfgq,fxdw,bpbj,bjnr,yjya_gz,yjya_ba,pdfzbr,pdfzrr,yl,yl_sj,yl_js,bdsbyqhj_img,aqqj_img,fxdw_img,bpbj_img,yjya_img) VALUES ('0',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if(sstatue==0){
	 db_execut_oneSQL(null,insert,json_where,sucessCB1,failCB1);
}else if(sstatue==1){
	 db_execut_oneSQL(null,update,json_where,sucessCB1,failCB1);
}
}
/**
 * 保存问题反馈数据
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @param sstatue 数据状态，0为空，1有值；为空时执行插入，有值时执行更新
 * @return
 */
function save_userrunpro01_data(json_where,sucessCB1,failCB1,sstatue){
	var pro_update="update YJ_PROBLEM_FEEDBACK set PROBLEM=?,STATUE=? where dtl_id=? and cons_id=? and rrio_code=? and modle_type=?";
	var pro_insert="INSERT INTO YJ_PROBLEM_FEEDBACK (DTL_ID,CONS_ID,RRIO_CODE,MODLE_TYPE,PROBLEM,STATUE) VALUES (?,?,?,?,?,?)";
	if(sstatue==0){
		 db_execut_oneSQL(null,pro_insert,json_where,sucessCB1,failCB1);
	}else if(sstatue==1){
		 db_execut_oneSQL(null,pro_update,json_where,sucessCB1,failCB1);
	}
}

/*保存修改记录到表YJ_DATA_COMPARISON_DTL_ID*/
function save_Correct_Record(){
	var select_sql="select DATA_ID from YJ_DATA_COMPARISON_DTL_ID where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 db_execut_oneSQL(null,select_sql,[cons_info.dtl_id,cons_info.cons_id,'A0004'],save_sucessCB1,savefailCB1);
}

/*查询成功回调*/
var save_sucessCB1 = function(tx,res){
	 var sql_upnm="update YJ_DATA_COMPARISON_DTL_ID set LINE_DATA=?,TYPE=? where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 var sql_insert="insert into YJ_DATA_COMPARISON_DTL_ID (MODEL_TYPE,MODEL_TITLE,TYPE,OLD_DATA_INDEX,OLD_DATA,LINE_DATA,DTL_ID,CONS_ID) values (?,?,?,?,?,?,?,?)";
		 var result_len=res.rows.length;
		 	if(result_len){//更新
		 		 db_execut_oneSQL(null,sql_upnm,['{"最后一次试验时间":"'+$('#syrq').val()+'","试验记录":"'+text1[0][(temp_val[0]-1)]+'","试验项目是否齐全":"'+text1[1][(temp_val[1]-1)]+'","缺少设备项目":"'+input_val[0]+'","计划安排预试时间":"'+$('#jhapsj').val()+'","电气负责人":"'+input_val[1]+'","值班电工人数":"'+input_val[2]+'","值班电工应配置人数":"'+input_val[3]+'","检修电工人数":"'+input_val[4]+'","检修电工应配置人数":"'+input_val[5]+'","配电所及变压器环境是否存在问题":"'+text1[2][(bdsbyqhj_val-1)]+'","问题描述":"'+input_val[6]+'","安全工器具":"'+text1[3][(temp_val[2]-1)]+'","前一次试验时间":"'+$('#aqqj_syrq').val()+'","不合格安全工器具件数":"'+input_val[7]+'","消防器材":"'+text1[4][(temp_val[3]-1)]+'","是否过期":"'+text1[5][(temp_val[4]-1)]+'","防小动物措施":"'+text1[6][(temp_val[5]-1)]+'","备品备件":"'+text1[7][(bpbj_val-1)]+'","备件内容":"'+input_val[8]+'","用户端故障应急预案":"'+text1[8][(temp_val[6]-1)]+'","非电性质保安措施":"'+text1[9][(temp_val[7]-1)]+'","配电房值班人员":"'+input_val[9]+'","配电房负责人员":"'+input_val[10]+'","本年度应急演练":"'+text1[10][(temp_val[8]-1)]+'","演练时间":"'+$('#yl_sj').val()+'","演练中承担角色":"'+text1[11][(temp_val[9]-1)]+'"}',"2",cons_info.dtl_id,cons_info.cons_id,"A0004"],null,null);
		 	}else{//插入
		 		 db_execut_oneSQL(null,sql_insert,["A0004","核查用户运行管理","2","",json_olddata,'{"最后一次试验时间":"'+$('#syrq').val()+'","试验记录":"'+text1[0][(temp_val[0]-1)]+'","试验项目是否齐全":"'+text1[1][(temp_val[1]-1)]+'","缺少设备项目":"'+input_val[0]+'","计划安排预试时间":"'+$('#jhapsj').val()+'","电气负责人":"'+input_val[1]+'","值班电工人数":"'+input_val[2]+'","值班电工应配置人数":"'+input_val[3]+'","检修电工人数":"'+input_val[4]+'","检修电工应配置人数":"'+input_val[5]+'","配电所及变压器环境是否存在问题":"'+text1[2][(bdsbyqhj_val-1)]+'","问题描述":"'+input_val[6]+'","安全工器具":"'+text1[3][(temp_val[2]-1)]+'","前一次试验时间":"'+$('#aqqj_syrq').val()+'","不合格安全工器具件数":"'+input_val[7]+'","消防器材":"'+text1[4][(temp_val[3]-1)]+'","是否过期":"'+text1[5][(temp_val[4]-1)]+'","防小动物措施":"'+text1[6][(temp_val[5]-1)]+'","备品备件":"'+text1[7][(bpbj_val-1)]+'","备件内容":"'+input_val[8]+'","用户端故障应急预案":"'+text1[8][(temp_val[6]-1)]+'","非电性质保安措施":"'+text1[9][(temp_val[7]-1)]+'","配电房值班人员":"'+input_val[9]+'","配电房负责人员":"'+input_val[10]+'","本年度应急演练":"'+text1[10][(temp_val[8]-1)]+'","演练时间":"'+$('#yl_sj').val()+'","演练中承担角色":"'+text1[11][(temp_val[9]-1)]+'"}',cons_info.dtl_id,cons_info.cons_id],null,null);
		 	}
	 }
/*查询失败回调*/
var savefailCB1=function(){
	 
}


</script>