<script type="text/javascript">
/**
 * 对应界面==核查用户运行管理信息-非重要用户
 * 对应表==用户运行管理---非重要用户运行管理信息表（YJ_S_GWZYXJ_UN）
 * @param DTL_ID=工单下用户id
 * @param CONS_ID=工单下用户id
 * @param AQGQJ=1.检查安全工器具是否符合要求
 * @param AQGQJ_IMG=1.检查安全工器具是否符合要求_拍照
 * @param XFQC=2.检查消防器材是否符合要求
 * @param XFQC_IMG=2.检查消防器材是否符合要求_拍照
 * @param SFYT=3.检查“四防一通”是否符合要求
 * @param SFYT_IMG=3.检查“四防一通”是否符合要求_拍照
 * @param BPBJ=4.检查备品备件
 * @param BPBJ_IMG=4.检查备品备件_拍照
 * @param BPDSHJ=5.检查变、配电所环境
 * @param BPDSHJ_IMG=5.检查变、配电所环境_拍照
 * @param ZBGZRY_DGJWZYXKZ=6.检查值班工作人员是否齐备，是否持有有效“电工进网作业许可证”
 * @param GZYJYA=7.检查是否有故障应急预案
 * @param WFDXZBACS=8.检查有无非电性质保安措施
 * @param WFDXZBACS_IMG=8.检查有无非电性质保安措施_拍照
 * @param YHYFXSY=9.检查用户预防性试验是否超期
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询界面数据
function get_yj_s_gwzyxj_un_userrun_data(json_where,sucessCB,failCB){
	var sql="select aqgqj as aqgqj,aqgqj_img as aqgqj_img,xfqc as xfqc,xfqc_img as xfqc_img,sfyt as sfyt,sfyt_img as sfyt_img,bpbj as bpbj,bpbj_img as bpbj_img,bpdshj as bpdshj,bpdshj_img as bpdshj_img,zbgzry_dgjwzyxkz as zbgzry_dgjwzyxkz,gzyjya as gzyjya,wfdxzbacs as wfdxzbacs,wfdxzbacs_img as wfdxzbacs_img,yhyfxsy as yhyfxsy from YJ_S_GWZYXJ_UN where dtl_id=? and cons_id=?";
	db_execut_oneSQL(null,sql,json_where,sucessCB,failCB);
}
/**
 * 问题反馈
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询问题反馈数据
function get_yj_problem_feedback_data(json_where1,sucessCB1,failCB1){
	 var pro_sql="select problem as problem,statue as statue from YJ_PROBLEM_FEEDBACK where dtl_id=? and cons_id=? and rrio_code=? and modle_type=?";
	 db_execut_oneSQL(null,pro_sql,json_where1,sucessCB1,failCB1);
}

/**
 * /*保存界面数据
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @param sstatue 数据状态，0为空，1有值；为空时执行插入，有值时执行更新
 * @return
 */
function save_userrun_data(json_where,sucessCB1,failCB1,sstatue){
	var update="update YJ_S_GWZYXJ_UN set aqgqj=?,aqgqj_img=?,xfqc=?,xfqc_img=?,sfyt=?,sfyt_img=?,bpbj=?,bpbj_img=?,bpdshj=?,bpdshj_img=?,zbgzry_dgjwzyxkz=?,gzyjya=?,wfdxzbacs=?,wfdxzbacs_img=?,yhyfxsy=? where dtl_id=? and cons_id=?";
	var insert="INSERT INTO YJ_S_GWZYXJ_UN (dtl_id,cons_id,aqgqj,aqgqj_img,xfqc,xfqc_img,sfyt,sfyt_img,bpbj,bpbj_img,bpdshj,bpdshj_img,zbgzry_dgjwzyxkz,gzyjya,wfdxzbacs,wfdxzbacs_img,yhyfxsy) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
if(sstatue==0){
	 db_execut_oneSQL(null,insert,json_where,sucessCB1,failCB1);
}else if(sstatue==1){
	 db_execut_oneSQL(null,update,json_where,sucessCB1,failCB1);
}
}

/*保存修改记录到表YJ_DATA_COMPARISON_DTL_ID*/
function save_Correct_Record(){
	var select_sql="select DATA_ID from YJ_DATA_COMPARISON_DTL_ID where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 db_execut_oneSQL(null,select_sql,[cons_info.dtl_id,cons_info.cons_id,'A0004'],save_sucessCB1,savefailCB11);
}
/*查询成功回调*/
var save_sucessCB1 = function(tx,res){
	 var sql_upnm="update YJ_DATA_COMPARISON_DTL_ID set LINE_DATA=?,TYPE=? where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 var sql_insert="insert into YJ_DATA_COMPARISON_DTL_ID (MODEL_TYPE,MODEL_TITLE,TYPE,OLD_DATA_INDEX,OLD_DATA,LINE_DATA,DTL_ID,CONS_ID) values (?,?,?,?,?,?,?,?)";
		 var result_len=res.rows.length;
		 	if(result_len){//更新
		 		 db_execut_oneSQL(null,sql_upnm,['{"检查安全工器具是否符合要求":"'+text1[0][(temp_val[0]-1)]+'","检查消防器材是否符合要求":"'+text1[1][(temp_val[1]-1)]+'","检查“四防一通”是否符合要求":"'+text1[2][(temp_val[2]-1)]+'","检查备品备件":"'+text1[3][(temp_val[3]-1)]+'","检查变、配电所环境":"'+text1[4][(temp_val[4]-1)]+'","检查值班工作人员是否齐备":"'+text1[5][(temp_val[5]-1)]+'","检查是否有故障应急预案":"'+text1[6][(temp_val[6]-1)]+'","检查有无非电性质保安措施":"'+text1[7][(temp_val[7]-1)]+'","检查用户预防性试验是否超期":"'+text1[8][(temp_val[8]-1)]+'"}',"2",cons_info.dtl_id,cons_info.cons_id,"A0004"],null,null);
		 	}else{//插入
		 		 db_execut_oneSQL(null,sql_insert,["A0004","核查用户运行管理","2","",json_olddata,'{"检查安全工器具是否符合要求":"'+text1[0][(temp_val[0]-1)]+'","检查消防器材是否符合要求":"'+text1[1][(temp_val[1]-1)]+'","检查“四防一通”是否符合要求":"'+text1[2][(temp_val[2]-1)]+'","检查备品备件":"'+text1[3][(temp_val[3]-1)]+'","检查变、配电所环境":"'+text1[4][(temp_val[4]-1)]+'","检查值班工作人员是否齐备":"'+text1[5][(temp_val[5]-1)]+'","检查是否有故障应急预案":"'+text1[6][(temp_val[6]-1)]+'","检查有无非电性质保安措施":"'+text1[7][(temp_val[7]-1)]+'","检查用户预防性试验是否超期":"'+text1[8][(temp_val[8]-1)]+'"}',cons_info.dtl_id,cons_info.cons_id],null,null);
		 	}
	 }
/*查询失败回调*/
var savefailCB11=function(){
	 
}

/**
 * 保存问题反馈数据
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @param sstatue 数据状态，0为空，1有值；为空时执行插入，有值时执行更新
 * @return
 */
function save_userrunpro_data(json_where,sucessCB1,failCB1,sstatue){
	var pro_update="update YJ_PROBLEM_FEEDBACK set PROBLEM=?,STATUE=? where dtl_id=? and cons_id=? and rrio_code=? and modle_type=?";
	var pro_insert="INSERT INTO YJ_PROBLEM_FEEDBACK (DTL_ID,CONS_ID,RRIO_CODE,MODLE_TYPE,PROBLEM,STATUE) VALUES (?,?,?,?,?,?)";
	if(sstatue==0){
		 db_execut_oneSQL(null,pro_insert,json_where,sucessCB1,failCB1);
	}else if(sstatue==1){
		 db_execut_oneSQL(null,pro_update,json_where,sucessCB1,failCB1);
	}
}
</script>