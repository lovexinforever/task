<script type="text/javascript">
var leave_flag=false;

//跳转到别的页面-（用检首页）
function to_another(){
    if(sessionStorage.YJDC_NAVTREE_URL=="0"){
             changepage("Checkuserinfo/Userbaseinfo/html/Userbaseinfo.html");
     }else{
            changepage(sessionStorage.YJDC_NAVTREE_URL);
            sessionStorage.YJDC_NAVTREE_URL="0";
     } 
}
//是否离开当前页面
function yes_or_leave(){
    if(leave_flag){
        $("#confirm_dailog").show();
    }else{
        to_another();
    }
}
//点击离开页面的按钮时调用
function compare_data(ary1,ary2){
    leave_flag=false;
    for(i=0;i<ary1.length;i++){
         // alert(setUndefined(ary1[i])+"====1===2=="+setUndefined(ary2[i])+"+++++++++++++++"+i);
        if(setUndefined(ary1[i])!=setUndefined(ary2[i])){
            // alert(i+"=="+setUndefined(ary1[i])+"====="+setUndefined(ary2[i]));
         leave_flag=true;
         break;
        }
    }
    yes_or_leave(); 
}



</script>

