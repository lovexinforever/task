<script type="text/javascript">
/**
 * 查询用户电费台账信息对应表
 * @param dtl_id=用电检查工单ID
 * @param rcvbl_amt_id=应收电费标识
 * @param cons_id=用电客户ID
 * @param org_no=供电公司
 * @param t_pq=总电量
 * @param rcvbl_amt=应收电费
 * @param rcved_amt=实收电费
 * @param settle_flag=结清标志
 * @param rcvbl_ym=月份
 * @param dltbqk=1.检查是否存在电量突变情况
 * @param glys=2.检查功率因数是否正常
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询界面数据
function get_yj_rcvbl_flow_elec_data(json_where,sucessCB,failCB){
	var sql="select rcvbl_amt_id as rcvbl_amt_id,org_no as org_no,t_pq as t_pq,rcvbl_amt as rcvbl_amt,rcved_amt as rcved_amt,settle_flag as settle_flag,rcvbl_ym as rcvbl_ym,dltbqk as dltbqk,glys as glys,pf_eval_mode as pf_eval_mode from YJ_RCVBL_FLOW where dtl_id=? and cons_id=? order by rcvbl_ym desc";
	 	db_execut_oneSQL(null,sql,json_where,sucessCB,failCB);
}
/**
 * 问题反馈
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询问题反馈数据
function get_yj_problem_feedback_data(json_where1,sucessCB1,failCB1){
	 var pro_sql="select problem as problem,statue as statue from YJ_PROBLEM_FEEDBACK where dtl_id=? and cons_id=? and rrio_code=? and modle_type=?";
	 db_execut_oneSQL(null,pro_sql,json_where1,sucessCB1,failCB1);
}

/**
 * /*保存界面数据
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
function save_elec_data(json_where,sucessCB1,failCB1){
	var update="update YJ_RCVBL_FLOW set dltbqk=?,glys=? where dtl_id=? and cons_id=?";
	 db_execut_oneSQL(null,update,json_where,sucessCB1,failCB1);
}
/**
 * 保存问题反馈数据
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @param sstatue 数据状态，0为空，1有值；为空时执行插入，有值时执行更新
 * @return
 */
function save_elecpro_data(json_where,sucessCB1,failCB1,sstatue){
	var pro_update="update YJ_PROBLEM_FEEDBACK set PROBLEM=?,STATUE=? where dtl_id=? and cons_id=? and rrio_code=? and modle_type=?";
	var pro_insert="INSERT INTO YJ_PROBLEM_FEEDBACK (DTL_ID,CONS_ID,RRIO_CODE,MODLE_TYPE,PROBLEM,STATUE) VALUES (?,?,?,?,?,?)";
	if(sstatue==0){
		 db_execut_oneSQL(null,pro_insert,json_where,sucessCB1,failCB1);
	}else if(sstatue==1){
		 db_execut_oneSQL(null,pro_update,json_where,sucessCB1,failCB1);
	}
}

/*保存修改记录到表YJ_DATA_COMPARISON_DTL_ID*/
function save_Correct_Record_e(){
	var select_sql="select DATA_ID from YJ_DATA_COMPARISON_DTL_ID where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 db_execut_oneSQL(null,select_sql,[cons_info.dtl_id,cons_info.cons_id,'A0002'],save_sucessCB1,savefailCB1);
}

/*查询成功回调*/
var save_sucessCB1 = function(tx,res){
	 var sql_upnm="update YJ_DATA_COMPARISON_DTL_ID set LINE_DATA=?,TYPE=? where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 var sql_insert="insert into YJ_DATA_COMPARISON_DTL_ID (MODEL_TYPE,MODEL_TITLE,TYPE,OLD_DATA_INDEX,OLD_DATA,LINE_DATA,DTL_ID,CONS_ID) values (?,?,?,?,?,?,?,?)";
		 var result_len=res.rows.length;
//		 alert(result_len);
		 	if(result_len){//更新
		 		 db_execut_oneSQL(null,sql_upnm,['{"检查是否存在电量突变情况":"'+text1[0][temp_val[0]]+'","检查功率因数是否正常":"'+text1[1][temp_val[1]]+'"}',"2",cons_info.dtl_id,cons_info.cons_id,"A0002"],null,null);
		 	}else{//插入
		 		 db_execut_oneSQL(null,sql_insert,["A0002","核查用户电费台帐信息","2","",json_pdlidata,'{"检查是否存在电量突变情况":"'+text1[0][temp_val[0]]+'","检查功率因数是否正常":"'+text1[1][temp_val[1]]+'"}',cons_info.dtl_id,cons_info.cons_id],null,null);
		 	}
	 }
/*查询失败回调*/
var savefailCB1=function(){
	 
}
</script>