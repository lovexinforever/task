<script type="text/javascript">
/**
/**核查用户供电合同信息
 * 非重要用户供电合同信息-对应表信息
 * @param DTL_ID=工单id
 * @param CONS_ID=用电客户ID
 * @param RRIO_CODE=重要性等级
 * @param YDHT=1.检查用电合同是否到期
 * @param DJLB=2.核查电价类别是否变更
 * @param DWDDXY=3.核查是否签订电网调度协议
 * @param ZCHFXY=4.核查资产划分协议是否超期
 * @param ZCHFXYZCFJD=5.核查资产划分协议资产分界点是否变更
 * @param ZFDXY=6.核查是否签订自发电协议
 * @param DFJSXY=7.核查是否签订电费结算协议
 * @param DBDL=8.核查定比定量是否与合同一致
 * @param LSYD=9.核查临时用电是否要到期
 * @param HTQTNR=10.核查合同其他内容是否符合现场情况
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询界面数据
function get_yj_check_cons_sup_contr_usercontr_data(json_where,sucessCB,failCB){
	var sql="select ydht as ydht,djlb as djlb,dwddxy as dwddxy,zchfxy as zchfxy,zchfxyzcfjd as zchfxyzcfjd,zfdxy as zfdxy,dfjsxy as dfjsxy,dbdl as dbdl,lsyd as lsyd,htqtnr as htqtnr,gdhe as gdhe from YJ_CHECK_CONS_SUP_CONTR where dtl_id=? and cons_id=?";
	db_execut_oneSQL(null,sql,json_where,sucessCB,failCB);
}
/**
 * 问题反馈
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询问题反馈数据
function get_yj_problem_feedback_data(json_where1,sucessCB1,failCB1){
	 var pro_sql="select problem as problem,statue as statue from YJ_PROBLEM_FEEDBACK where dtl_id=? and cons_id=? and rrio_code=? and modle_type=?";
	 db_execut_oneSQL(null,pro_sql,json_where1,sucessCB1,failCB1);
}

/**
 * /*保存界面数据
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @param sstatue 数据状态，0为空，1有值；为空时执行插入，有值时执行更新
 * @return
 */
function save_usercontr_data(json_where,sucessCB1,failCB1,sstatue){
	var update="update YJ_CHECK_CONS_SUP_CONTR set YDHT=?,DJLB=?,LSYD=?,ZCHFXY=?,ZCHFXYZCFJD=?,DBDL=?,DWDDXY=?,ZFDXY=?,DFJSXY=?,HTQTNR=?,GDHE=? where DTL_ID=? and CONS_ID=?";
	var insert="INSERT INTO YJ_CHECK_CONS_SUP_CONTR (DTL_ID,CONS_ID,RRIO_CODE,YDHT,DJLB,LSYD,ZCHFXY,ZCHFXYZCFJD,DBDL,DWDDXY,ZFDXY,DFJSXY,HTQTNR,GDHE) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	if(sstatue==0){
		 db_execut_oneSQL(null,insert,json_where,sucessCB1,failCB1);
	}else if(sstatue==1){
		 db_execut_oneSQL(null,update,json_where,sucessCB1,failCB1);
	}
}

/*保存修改记录到表YJ_DATA_COMPARISON_DTL_ID*/
function save_Correct_Record(){
	var select_sql="select DATA_ID from YJ_DATA_COMPARISON_DTL_ID where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 db_execut_oneSQL(null,select_sql,[cons_info.dtl_id,cons_info.cons_id,'A0003'],save_sucessCB1,savefailCB1);
}

/*查询成功回调*/
var save_sucessCB1 = function(tx,res){
	 var sql_upnm="update YJ_DATA_COMPARISON_DTL_ID set LINE_DATA=?,TYPE=? where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 var sql_insert="insert into YJ_DATA_COMPARISON_DTL_ID (MODEL_TYPE,MODEL_TITLE,TYPE,OLD_DATA_INDEX,OLD_DATA,LINE_DATA,DTL_ID,CONS_ID) values (?,?,?,?,?,?,?,?)";
		 var result_len=res.rows.length;
//		 alert(result_len);
		 	if(result_len){//更新
		 		 db_execut_oneSQL(null,sql_upnm,['{"核查用电合同是否到期":"'+text1[0][(temp_val[0]-1)]+'","核查电价类别是否变更":"'+text1[1][(temp_val[1]-1)]+'","检查临时用电是否要到期":"'+text1[2][(temp_val[2]-1)]+'","核查资产划分协议是否超期":"'+text1[3][(temp_val[3]-1)]+'","核查资产划分协议资产分界点是否改变":"'+text1[4][(temp_val[4]-1)]+'","检查定比定量是否与合同一致":"'+text1[5][(temp_val[5]-1)]+'","核查是否签订电费调度协议":"'+text1[6][(temp_val[6]-1)]+'","核查是否签订自发电协议":"'+text1[7][(temp_val[7]-1)]+'","核查是否签订电费结算协议":"'+text1[8][(temp_val[8]-1)]+'","核查合同其他内容是否符合现场情况":"'+text1[9][(temp_val[9]-1)]+'","供用电合同":"'+text1[10][(temp_val[10]-1)]+'"}',"2",cons_info.dtl_id,cons_info.cons_id,"A0003"],null,null);
		 	}else{//插入
		 		 db_execut_oneSQL(null,sql_insert,["A0003","核查用户供电合同信息","2","",json_olddata,'{"核查用电合同是否到期":"'+text1[0][(temp_val[0]-1)]+'","核查电价类别是否变更":"'+text1[1][(temp_val[1]-1)]+'","检查临时用电是否要到期":"'+text1[2][(temp_val[2]-1)]+'","核查资产划分协议是否超期":"'+text1[3][(temp_val[3]-1)]+'","核查资产划分协议资产分界点是否改变":"'+text1[4][(temp_val[4]-1)]+'","检查定比定量是否与合同一致":"'+text1[5][(temp_val[5]-1)]+'","核查是否签订电费调度协议":"'+text1[6][(temp_val[6]-1)]+'","核查是否签订自发电协议":"'+text1[7][(temp_val[7]-1)]+'","核查是否签订电费结算协议":"'+text1[8][(temp_val[8]-1)]+'","核查合同其他内容是否符合现场情况":"'+text1[9][(temp_val[9]-1)]+'","供用电合同":"'+text1[10][(temp_val[10]-1)]+'"}',cons_info.dtl_id,cons_info.cons_id],null,null);
		 	}
	 }
/*查询失败回调*/
var savefailCB1=function(){
	 
}

/**
 * 保存问题反馈数据
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @param sstatue 数据状态，0为空，1有值；为空时执行插入，有值时执行更新
 * @return
 */
function save_usercontrpro_data(json_where,sucessCB1,failCB1,sstatue){
	var pro_update="update YJ_PROBLEM_FEEDBACK set PROBLEM=?,STATUE=? where dtl_id=? and cons_id=? and rrio_code=? and modle_type=?";
	var pro_insert="INSERT INTO YJ_PROBLEM_FEEDBACK (DTL_ID,CONS_ID,RRIO_CODE,MODLE_TYPE,PROBLEM,STATUE) VALUES (?,?,?,?,?,?)";
	if(sstatue==0){
		 db_execut_oneSQL(null,pro_insert,json_where,sucessCB1,failCB1);
	}else if(sstatue==1){
		 db_execut_oneSQL(null,pro_update,json_where,sucessCB1,failCB1);
	}
}

/*****查询合同文件*******/
function select_loc_file(sucessCB,failCB){
	var sql="select LOC_FILE from YJ_C_CONS where dtl_id=? and cons_id=?";
	db_execut_oneSQL(null,sql,[cons_info.dtl_id,cons_info.cons_id],sucessCB,failCB);
}


/*****上装时实时查询数据--id*****/
var yj_otdata="";		//YJ_S_GWZYXJ数据对象
var yj_otdata_contr=""; //合同js对象
var idsz="";																//数据库表中主键id
var data_length="";
//YJ_S_GWZYXJ查询
function select_ontime_data_contract(){
	var sql="select * from YJ_S_GWZYXJ where CR_ID=?";
	db_execut_oneSQL(null,sql,[cons_info.cr_id],sucessCB_select_ontime_data,null);
	function sucessCB_select_ontime_data(tx,res){
		var ss=res.rows.length;
		data_length=ss;
		if(ss){
			yj_otdata=res.rows.item(0);
			idsz=yj_otdata.ID;
			select_ontime_data_contract_1();
		}else{
			select_ontime_data_contract_1();
		}
	}
	setTimeout(function(){
		sz_main_data_contract();
	},1000)
}
//合同表查询
function select_ontime_data_contract_1(){
	var sql="select * from YJ_CHECK_CONS_SUP_CONTR where dtl_id=? and cons_id=?";
	db_execut_oneSQL(null,sql,[cons_info.dtl_id,cons_info.cons_id],sucessCB_select_ontime_data11,null);
	function sucessCB_select_ontime_data11(tx,res){
		var ss=res.rows.length;
		if(ss){
			yj_otdata_contr=res.rows.item(0);
		}else{
			
		}
	}
}

/*****上装时实时查询数据--id*****/
//上装
function upload_statu_contract(){
	opendailog("businessList_laoding_view");//弹出加载效果框
	select_ontime_data_contract();//查询实时数据
	
	
}

/*上装主函数*/
function sz_main_data_contract(){
	//上装--信息新增pkg
	var PKG='{"MOD":"2003","FUN":"2302","LEN":"39","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"CR_ID":"'+cons_info.cr_id+'","MLKG_YW":"'+setUndefined(yj_otdata.MLKG_YW)+'","MLKG_CZSJ":"'+setUndefined(yj_otdata.MLKG_CZSJ)+'","MLKG_CZ":"'+setUndefined(yj_otdata.MLKG_CZ)+'","BZTZZ_YW":"'+setUndefined(yj_otdata.BZTZZ_YW)+'","ZBYJ_ZZ":"'+setUndefined(yj_otdata.ZBYJ_ZZ)+'","ZBYJ_XQ":"'+setUndefined(yj_otdata.ZBYJ_XQ)+'","ZBYJ_SJ":"'+setUndefined(yj_otdata.ZBYJ_SJ)+'","ZBYJ_FD":"'+setUndefined(yj_otdata.ZBYJ_FD)+'","SYJL":"'+setUndefined(yj_otdata.SYJL)+'","SYRQ":"'+setUndefined(yj_otdata.SYRQ)+'","SYXMQQ":"'+setUndefined(yj_otdata.SYXMQQ)+'","QSSBXM":"'+setUndefined(yj_otdata.QSSBXM)+'","JHAPSJ":"'+setUndefined(yj_otdata.JHAPSJ)+'","ZTYXQK":"'+setUndefined(yj_otdata.ZTYXQK)+'","BYQ":"'+setUndefined(yj_otdata.BYQ)+'","BYQ_RQ":"'+setUndefined(yj_otdata.BYQ_RQ)+'","BYQ_GZ":"'+setUndefined(yj_otdata.BYQ_GZ)+'","GDYCG":"'+setUndefined(yj_otdata.GDYCG)+'","GDYCG_RQ":"'+setUndefined(yj_otdata.GDYCG_RQ)+'","GDYCG_GZ":"'+setUndefined(yj_otdata.GDYCG_GZ)+'","DLQ":"'+setUndefined(yj_otdata.DLQ)+'","DLQ_RQ":"'+setUndefined(yj_otdata.DLQ_RQ)+'","DLQ_GZ":"'+setUndefined(yj_otdata.DLQ_GZ)+'","CTPT":"'+setUndefined(yj_otdata.CTPT)+'","CTPT_RQ":"'+setUndefined(yj_otdata.CTPT_RQ)+'","CTPT_GZ":"'+setUndefined(yj_otdata.CTPT_GZ)+'","WGBC":"'+setUndefined(yj_otdata.WGBC)+'","WGBC_RQ":"'+setUndefined(yj_otdata.WGBC_RQ)+'","WGBC_GZ":"'+setUndefined(yj_otdata.WGBC_GZ)+'","DL":"'+setUndefined(yj_otdata.DL)+'","DL_RQ":"'+setUndefined(yj_otdata.DL_RQ)+'","DL_GZ":"'+setUndefined(yj_otdata.DL_GZ)+'","AQJL":"'+setUndefined(yj_otdata.AQJL)+'","AQJL_GZ":"'+setUndefined(yj_otdata.AQJL_GZ)+'","DGGL_FZR":"'+setUndefined(yj_otdata.DGGL_FZR)+'","DGGL_ZB_RS":"'+setUndefined(yj_otdata.DGGL_ZB_RS)+'","DGGL_ZB_YPZ":"'+setUndefined(yj_otdata.DGGL_ZB_YPZ)+'","DGGL_JX_RS":"'+setUndefined(yj_otdata.DGGL_JX_RS)+'","DGGL_JX_YPZ":"'+setUndefined(yj_otdata.DGGL_JX_YPZ)+'","GCZD_BDS_YXGC":"'+setUndefined(yj_otdata.GCZD_BDS_YXGC)+'","GCZD_BDS_GWZR":"'+setUndefined(yj_otdata.GCZD_BDS_GWZR)+'","GCZD_BDS_ZBZD":"'+setUndefined(yj_otdata.GCZD_BDS_ZBZD)+'","GCZD_BDS_JJB":"'+setUndefined(yj_otdata.GCZD_BDS_JJB)+'","GCZD_XHJC":"'+setUndefined(yj_otdata.GCZD_XHJC)+'","GCZD_DQ_DQQH":"'+setUndefined(yj_otdata.GCZD_DQ_DQQH)+'","GCZD_DQ_DQXS":"'+setUndefined(yj_otdata.GCZD_DQ_DQXS)+'","GCZD_DQ_QXGL":"'+setUndefined(yj_otdata.GCZD_DQ_QXGL)+'","GCZD_DZDSD":"'+setUndefined(yj_otdata.GCZD_DZDSD)+'","GCZD_CR":"'+setUndefined(yj_otdata.GCZD_CR)+'","GCZD_YXJL":"'+setUndefined(yj_otdata.GCZD_YXJL)+'","GCZD_SBQX":"'+setUndefined(yj_otdata.GCZD_SBQX)+'","GCZD_SBQXJX":"'+setUndefined(yj_otdata.GCZD_SBQXJX)+'","GCZD_JDBH":"'+setUndefined(yj_otdata.GCZD_JDBH)+'","GCZD_SGJL":"'+setUndefined(yj_otdata.GCZD_SGJL)+'","GCZD_WLRYJL":"'+setUndefined(yj_otdata.GCZD_WLRYJL)+'","DXCZP":"'+setUndefined(yj_otdata.DXCZP)+'","BDSBYQHJ":"'+setUndefined(yj_otdata.BDSBYQHJ)+'","BDSBYQHJ_PRO":"'+setUndefined(yj_otdata.BDSBYQHJ_PRO)+'","AQQJ":"'+setUndefined(yj_otdata.AQQJ)+'","AQQJ_SYRQ":"'+setUndefined(yj_otdata.AQQJ_SYRQ)+'","AQQJ_BHGS":"'+setUndefined(yj_otdata.AQQJ_BHGS)+'","XFQC":"'+setUndefined(yj_otdata.XFQC)+'","XFQC_SFGQ":"'+setUndefined(yj_otdata.XFQC_SFGQ)+'","FXDW":"'+setUndefined(yj_otdata.FXDW)+'","BPBJ":"'+setUndefined(yj_otdata.BPBJ)+'","BJNR":"'+setUndefined(yj_otdata.BJNR)+'","YJYA_GZ":"'+setUndefined(yj_otdata.YJYA_GZ)+'","YJYA_BA":"'+setUndefined(yj_otdata.YJYA_BA)+'","PDFZBR":"'+setUndefined(yj_otdata.PDFZBR)+'","PDFZRR":"'+setUndefined(yj_otdata.PDFZRR)+'","GDHE":"'+setUndefined(yj_otdata_contr.GDHE)+'","SFFH":"'+setUndefined(yj_otdata_contr.HTQTNR)+'","DWDDXY":"'+setUndefined(yj_otdata_contr.DWDDXY)+'","ZFDXY":"'+setUndefined(yj_otdata_contr.ZFDXY)+'","DFJSXY":"'+setUndefined(yj_otdata_contr.DFJSXY)+'","BJLYC":"'+setUndefined(yj_otdata.BJLYC)+'","YCNR":"'+setUndefined(yj_otdata.YCNR)+'","WYQD":"'+setUndefined(yj_otdata.WYQD)+'","QDCCGC":"'+setUndefined(yj_otdata.QDCCGC)+'","SS":"'+setUndefined(yj_otdata.SS)+'","FKTXFX":"'+setUndefined(yj_otdata.FKTXFX)+'","BX":"'+setUndefined(yj_otdata.BX)+'","LJ":"'+setUndefined(yj_otdata.LJ)+'","YL":"'+setUndefined(yj_otdata.YL)+'","YL_SJ":"'+setUndefined(yj_otdata.YL_SJ)+'","YL_JS":"'+setUndefined(yj_otdata.YL_JS)+'","BPTSDJ":"'+setUndefined(yj_otdata.BPTSDJ)+'","JNDJ":"'+setUndefined(yj_otdata.JNDJ)+'","SFYR":"'+setUndefined(yj_otdata.SFYR)+'","GPDY":"'+setUndefined(yj_otdata.GPDY)+'","FSHGSB":"'+setUndefined(yj_otdata.FSHGSB)+'","KYJ_PTSB":"'+setUndefined(yj_otdata.KYJ_PTSB)+'","JDCCSB":"'+setUndefined(yj_otdata.JDCCSB)+'","JNKTXT":"'+setUndefined(yj_otdata.JNKTXT)+'","JNYY":"'+setUndefined(yj_otdata.JNYY)+'","SMFW":"'+setUndefined(yj_otdata.SMFW)+'"}}'
	//上装--信息修改pkg
	var PKG1='{"MOD":"2003","FUN":"2303","LEN":"39","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"ID":"'+idsz+'","CR_ID":"'+cons_info.cr_id+'","MLKG_YW":"'+setUndefined(yj_otdata.MLKG_YW)+'","MLKG_CZSJ":"'+setUndefined(yj_otdata.MLKG_CZSJ)+'","MLKG_CZ":"'+setUndefined(yj_otdata.MLKG_CZ)+'","BZTZZ_YW":"'+setUndefined(yj_otdata.BZTZZ_YW)+'","ZBYJ_ZZ":"'+setUndefined(yj_otdata.ZBYJ_ZZ)+'","ZBYJ_XQ":"'+setUndefined(yj_otdata.ZBYJ_XQ)+'","ZBYJ_SJ":"'+setUndefined(yj_otdata.ZBYJ_SJ)+'","ZBYJ_FD":"'+setUndefined(yj_otdata.ZBYJ_FD)+'","SYJL":"'+setUndefined(yj_otdata.SYJL)+'","SYRQ":"'+setUndefined(yj_otdata.SYRQ)+'","SYXMQQ":"'+setUndefined(yj_otdata.SYXMQQ)+'","QSSBXM":"'+setUndefined(yj_otdata.QSSBXM)+'","JHAPSJ":"'+setUndefined(yj_otdata.JHAPSJ)+'","ZTYXQK":"'+setUndefined(yj_otdata.ZTYXQK)+'","BYQ":"'+setUndefined(yj_otdata.BYQ)+'","BYQ_RQ":"'+setUndefined(yj_otdata.BYQ_RQ)+'","BYQ_GZ":"'+setUndefined(yj_otdata.BYQ_GZ)+'","GDYCG":"'+setUndefined(yj_otdata.GDYCG)+'","GDYCG_RQ":"'+setUndefined(yj_otdata.GDYCG_RQ)+'","GDYCG_GZ":"'+setUndefined(yj_otdata.GDYCG_GZ)+'","DLQ":"'+setUndefined(yj_otdata.DLQ)+'","DLQ_RQ":"'+setUndefined(yj_otdata.DLQ_RQ)+'","DLQ_GZ":"'+setUndefined(yj_otdata.DLQ_GZ)+'","CTPT":"'+setUndefined(yj_otdata.CTPT)+'","CTPT_RQ":"'+setUndefined(yj_otdata.CTPT_RQ)+'","CTPT_GZ":"'+setUndefined(yj_otdata.CTPT_GZ)+'","WGBC":"'+setUndefined(yj_otdata.WGBC)+'","WGBC_RQ":"'+setUndefined(yj_otdata.WGBC_RQ)+'","WGBC_GZ":"'+setUndefined(yj_otdata.WGBC_GZ)+'","DL":"'+setUndefined(yj_otdata.DL)+'","DL_RQ":"'+setUndefined(yj_otdata.DL_RQ)+'","DL_GZ":"'+setUndefined(yj_otdata.DL_GZ)+'","AQJL":"'+setUndefined(yj_otdata.AQJL)+'","AQJL_GZ":"'+setUndefined(yj_otdata.AQJL_GZ)+'","DGGL_FZR":"'+setUndefined(yj_otdata.DGGL_FZR)+'","DGGL_ZB_RS":"'+setUndefined(yj_otdata.DGGL_ZB_RS)+'","DGGL_ZB_YPZ":"'+setUndefined(yj_otdata.DGGL_ZB_YPZ)+'","DGGL_JX_RS":"'+setUndefined(yj_otdata.DGGL_JX_RS)+'","DGGL_JX_YPZ":"'+setUndefined(yj_otdata.DGGL_JX_YPZ)+'","GCZD_BDS_YXGC":"'+setUndefined(yj_otdata.GCZD_BDS_YXGC)+'","GCZD_BDS_GWZR":"'+setUndefined(yj_otdata.GCZD_BDS_GWZR)+'","GCZD_BDS_ZBZD":"'+setUndefined(yj_otdata.GCZD_BDS_ZBZD)+'","GCZD_BDS_JJB":"'+setUndefined(yj_otdata.GCZD_BDS_JJB)+'","GCZD_XHJC":"'+setUndefined(yj_otdata.GCZD_XHJC)+'","GCZD_DQ_DQQH":"'+setUndefined(yj_otdata.GCZD_DQ_DQQH)+'","GCZD_DQ_DQXS":"'+setUndefined(yj_otdata.GCZD_DQ_DQXS)+'","GCZD_DQ_QXGL":"'+setUndefined(yj_otdata.GCZD_DQ_QXGL)+'","GCZD_DZDSD":"'+setUndefined(yj_otdata.GCZD_DZDSD)+'","GCZD_CR":"'+setUndefined(yj_otdata.GCZD_CR)+'","GCZD_YXJL":"'+setUndefined(yj_otdata.GCZD_YXJL)+'","GCZD_SBQX":"'+setUndefined(yj_otdata.GCZD_SBQX)+'","GCZD_SBQXJX":"'+setUndefined(yj_otdata.GCZD_SBQXJX)+'","GCZD_JDBH":"'+setUndefined(yj_otdata.GCZD_JDBH)+'","GCZD_SGJL":"'+setUndefined(yj_otdata.GCZD_SGJL)+'","GCZD_WLRYJL":"'+setUndefined(yj_otdata.GCZD_WLRYJL)+'","DXCZP":"'+setUndefined(yj_otdata.DXCZP)+'","BDSBYQHJ":"'+setUndefined(yj_otdata.BDSBYQHJ)+'","BDSBYQHJ_PRO":"'+setUndefined(yj_otdata.BDSBYQHJ_PRO)+'","AQQJ":"'+setUndefined(yj_otdata.AQQJ)+'","AQQJ_SYRQ":"'+setUndefined(yj_otdata.AQQJ_SYRQ)+'","AQQJ_BHGS":"'+setUndefined(yj_otdata.AQQJ_BHGS)+'","XFQC":"'+setUndefined(yj_otdata.XFQC)+'","XFQC_SFGQ":"'+setUndefined(yj_otdata.XFQC_SFGQ)+'","FXDW":"'+setUndefined(yj_otdata.FXDW)+'","BPBJ":"'+setUndefined(yj_otdata.BPBJ)+'","BJNR":"'+setUndefined(yj_otdata.BJNR)+'","YJYA_GZ":"'+setUndefined(yj_otdata.YJYA_GZ)+'","YJYA_BA":"'+setUndefined(yj_otdata.YJYA_BA)+'","PDFZBR":"'+setUndefined(yj_otdata.PDFZBR)+'","PDFZRR":"'+setUndefined(yj_otdata.PDFZRR)+'","GDHE":"'+setUndefined(yj_otdata_contr.GDHE)+'","SFFH":"'+setUndefined(yj_otdata_contr.HTQTNR)+'","DWDDXY":"'+setUndefined(yj_otdata_contr.DWDDXY)+'","ZFDXY":"'+setUndefined(yj_otdata_contr.ZFDXY)+'","DFJSXY":"'+setUndefined(yj_otdata_contr.DFJSXY)+'","BJLYC":"'+setUndefined(yj_otdata.BJLYC)+'","YCNR":"'+setUndefined(yj_otdata.YCNR)+'","WYQD":"'+setUndefined(yj_otdata.WYQD)+'","QDCCGC":"'+setUndefined(yj_otdata.QDCCGC)+'","SS":"'+setUndefined(yj_otdata.SS)+'","FKTXFX":"'+setUndefined(yj_otdata.FKTXFX)+'","BX":"'+setUndefined(yj_otdata.BX)+'","LJ":"'+setUndefined(yj_otdata.LJ)+'","YL":"'+setUndefined(yj_otdata.YL)+'","YL_SJ":"'+setUndefined(yj_otdata.YL_SJ)+'","YL_JS":"'+setUndefined(yj_otdata.YL_JS)+'","BPTSDJ":"'+setUndefined(yj_otdata.BPTSDJ)+'","JNDJ":"'+setUndefined(yj_otdata.JNDJ)+'","SFYR":"'+setUndefined(yj_otdata.SFYR)+'","GPDY":"'+setUndefined(yj_otdata.GPDY)+'","FSHGSB":"'+setUndefined(yj_otdata.FSHGSB)+'","KYJ_PTSB":"'+setUndefined(yj_otdata.KYJ_PTSB)+'","JDCCSB":"'+setUndefined(yj_otdata.JDCCSB)+'","JNKTXT":"'+setUndefined(yj_otdata.JNKTXT)+'","JNYY":"'+setUndefined(yj_otdata.JNYY)+'","SMFW":"'+setUndefined(yj_otdata.SMFW)+'"}}'
	if(idsz && idsz!=0){//表中存在id，则发送信息修改的pkg
		send_data("2303","2003",PKG1,successCallBack,faileCallBack);
	}else{//表中不存在id,则发送信息新增新增pkg
		send_data("2302","2003",PKG,successCallBack,faileCallBack);
	}
	//上装成功回调
	function successCallBack(message_ener){
		$("#businessList_laoding_view").hide();//关闭加载效果框
		var msg_enercb = JSON.parse(message_ener);
		if(msg_enercb.RET=="00"){
			var msg_pkg_jx=msg_enercb.PKG.PKG;
			var fun=msg_enercb.FUN;
			if(msg_pkg_jx.SUCCESS_FLAG=="0"){
					insert_success_2();//弹出上装成功框
					//重要客户巡检记录信息新增
			       if(fun=="2302"){
			    		if(data_length>0){
			    			db_execut_oneSQL(null,"update YJ_S_GWZYXJ set ID=?,UPLOADING_TYPE=?,UPLOADING_DATE=? where CR_ID=?",[msg_pkg_jx.id,2,new Date(),cons_info.cr_id],null,null);
			    		}else{
			    			db_execut_oneSQL(null,"insert into YJ_S_GWZYXJ (ID,UPLOADING_TYPE,UPLOADING_DATE,CR_ID) values (?,?,?,?)",[msg_pkg_jx.id,2,new Date(),cons_info.cr_id],null,null);
			    		}
			          
					}
					//重要客户巡检记录信息修改
			        else if(fun=="2303"){
			    	 db_execut_oneSQL(null,"update YJ_S_GWZYXJ set UPLOADING_DATE=? where CR_ID=?",[new Date(),cons_info.cr_id],null,null);
					}
			}else{
				if(msg_pkg_jx.ERR_MSG){
					$("#yxzypt_msg").html(msg_pkg_jx.ERR_MSG);//给弹出框赋对应的提示消息
					onchange_val();
					$("#yxzypt_dailog").show();
				}else{
					$("#yxzypt_msg").html("上装失败!数据保存本地");//给弹出框赋对应的提示消息
					onchange_val();
					$("#yxzypt_dailog").show();
				}
			}
		}else{
				$("#yxzypt_msg").html("上装失败!数据保存本地");//给弹出框赋对应的提示消息
				onchange_val();
				$("#yxzypt_dailog").show();
		}
	}
	//上装失败回调
	function faileCallBack(){
//		$("#businessList_laoding_view").hide();//关闭加载效果框
		var pkgp="";
		if(idsz && idsz!=0){//表中存在id，则发送信息修改的pkg
			pkgp=PKG1;
			var msg_ti_str = '{"DTL_ID":"'+cons_info.dtl_id+'","CONS_ID":"'+cons_info.cons_id+'","MSG":"检查结果巡检记录上装失败","PKG":'+pkgp+',"ERROR_ID":"2303"}';
			upload_Data("2303","2003",pkgp,msg_ti_str,"yj_upload_proc");
		}else{//表中不存在id,则发送信息新增新增pkg
			pkgp=PKG;
			var msg_ti_str = '{"DTL_ID":"'+cons_info.dtl_id+'","CONS_ID":"'+cons_info.cons_id+'","MSG":"检查结果巡检记录上装失败","PKG":'+pkgp+',"ERROR_ID":"2302"}';
			upload_Data("2302","2003",pkgp,msg_ti_str,"yj_upload_proc");
		}
		setTimeout(function(){
			$("#businessList_laoding_view").css("display","none");//关闭加载效果框
		$("#yxzypt_msg").html("数据进入到上装队列，等待上装！");//给弹出框赋对应的提示消息
		onchange_val();
		$("#yxzypt_dailog").show();
		 },500);
	}
}

//数据库进行插入操作后，更新数据库数据标志 
function change_dataflag(){
	//更新界面数据状态，0为无数据，1为有数据
	if(data_staue==0){
		data_staue=1;
	}
}
function change_dataflag_pro(){
	//更新问题反馈表数据状态，0为无数据，1为有数据
	if(pro_data_staues==0){
		pro_data_staues=1;
	}
}

</script>