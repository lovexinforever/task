<script type="text/javascript">
/**
 * 返回数据
 * @param CONS_NO=用户编号
 * @param ADDR=联系人地址
 * @param HOMEPHONE=住宅电话
 * @param CHECKER_NO=检查员 CONTACT_ID 联系方式ID
 * @param CONS_NAME=用户名称
 * @param ELEC_ADDR=用电地址
 * @param CONTACT_NAME=联系人
 * @param OFFICE_TEL=办公电话
 * @param EMAIL=电子邮件
 * @param MOBILE
 * @param dtl_id 
 * @param cons_id
 * @param sucessCB
 * @param failCB
 * @return
 */

//查询数据
function  get_yj_c_cons_baseinfo1(dtl_id,cons_id,sucessCB,failCB){
	var sql="select CONS_NO,ADDR,HOMEPHONE,CHECKER_NO,CONTACT_ID,cons_name as cons_name,elec_addr as elec_addr,contact_name as contact_name,office_tel as office_tel,email as email,mobile as mobile from yj_c_cons where  dtl_id=? and cons_id=?";
	db_execut_oneSQL(null,sql,[dtl_id,cons_id],sucessCB,failCB);
}
//保存修改后的数据
function save_yj_c_cons_baseinfo1(jsonwhere,sucessCB,failCB){
	var sql="update YJ_C_CONS set cons_name=?,elec_addr=?,contact_name=?,office_tel=?,mobile=?,email=? where dtl_id=? and cons_id=?";
	db_execut_oneSQL(null,sql,jsonwhere,sucessCB,failCB);
}

/*保存修改记录到表YJ_DATA_COMPARISON_DTL_ID*/
function save_Correct_Record_base(){
	var select_sql="select DATA_ID from YJ_DATA_COMPARISON_DTL_ID where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 db_execut_oneSQL(null,select_sql,[cons_info.dtl_id,cons_info.cons_id,'A0000'],save_sucessCB1,savefailCB1);
}

/*查询成功回调*/
var save_sucessCB1 = function(tx,res){
	 var sql_upnm="update YJ_DATA_COMPARISON_DTL_ID set LINE_DATA=?,TYPE=? where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 var sql_insert="insert into YJ_DATA_COMPARISON_DTL_ID (MODEL_TYPE,MODEL_TITLE,TYPE,OLD_DATA_INDEX,OLD_DATA,LINE_DATA,DTL_ID,CONS_ID) values (?,?,?,?,?,?,?,?)";
		 var result_len=res.rows.length;
//		 alert(result_len);
		 	if(result_len){//更新
		 		 db_execut_oneSQL(null,sql_upnm,['{"用户名称":"'+$('#text_CONS_NAME_edite').val()+'","用电地址":"'+$('#text_ELEC_ADDR_edite').val()+'","联系人":"'+$('#text_CONTACT_NAME_edite').val()+'","办公电话":"'+$('#text_OFFICE_TEL_edite').val()+'","移动电话":"'+$('#text_MOBILE_edite').val()+'"}',"2",cons_info.dtl_id,cons_info.cons_id,"A0000"],null,null);
		 	}else{//插入
		 		 db_execut_oneSQL(null,sql_insert,["A0000","用检首页-用户基本信息","2","",json_olddata,'{"用户名称":"'+$('#text_CONS_NAME_edite').val()+'","用电地址":"'+$('#text_ELEC_ADDR_edite').val()+'","联系人":"'+$('#text_CONTACT_NAME_edite').val()+'","办公电话":"'+$('#text_OFFICE_TEL_edite').val()+'","移动电话":"'+$('#text_MOBILE_edite').val()+'"}',cons_info.dtl_id,cons_info.cons_id],null,null);
		 	}
	 }
/*查询失败回调*/
var savefailCB1=function(){
	 
}

//数据上装
function baseinfo_Dataup(){
    opendailog("businessList_laoding_view");//弹出加载效果框
    //上装--信息 pkg
    var PKG1='{"MOD":"2003","FUN":"2101","LEN":"39","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"CONS_NO":"'+setUndefined(yj_c_cons_1.CONS_NO)+'","ADDR":"'+setUndefined(yj_c_cons_1.ADDR)+'","CONTACT_NAME":"'+setUndefined($('#text_CONTACT_NAME_edite').val())+'","OFFICE_TEL":"'+setUndefined($('#text_OFFICE_TEL_edite').val())+'","HOMEPHONE":"'+setUndefined(yj_c_cons_1.HOMEPHONE)+'","MOBILE":"'+setUndefined($('#text_MOBILE_edite').val())+'","CHECKER_NO":"'+setUndefined(sessionStorage.EMP_NO)+'","CONTACT_ID":"'+setUndefined(yj_c_cons_1.CONTACT_ID)+'"}}'
    send_data("2101","2003",PKG1,successCBack_baseinfo,faileCBack_baseinfo);
    //成功回调
    function successCBack_baseinfo(message_ener){
        try{
            $("#businessList_laoding_view").hide();//关闭加载效果框
            var msg_enercb = JSON.parse(message_ener);
            if(msg_enercb.RET=="00"){
                var msg_pkg=msg_enercb.PKG.PKG;
                var fun=msg_enercb.FUN;
                if(msg_pkg.SUCCESS_FLAG=="0"){
                    insert_success_2();//弹出上装成功框
                }else{
                    $("#yxzypt_msg").html("");
                    if(msg_pkg.ERR_MSG){
                        $("#yxzypt_msg").html(msg_pkg.ERR_MSG);//给弹出框赋对应的提示消息
                    }else{
                        $("#yxzypt_msg").html("上装失败");//给弹出框赋对应的提示消息
                    }
                        onchange_val();
                        $("#yxzypt_dailog").show();
                }
            }else{
                    $("#yxzypt_msg").html("上装失败!数据保存本地");//给弹出框赋对应的提示消息
                    onchange_val();
                    $("#yxzypt_dailog").show();
            }
        }catch(e){
            $("#yxzypt_msg").html("上装失败!返回数据异常");//给弹出框赋对应的提示消息
            onchange_val();
            $("#yxzypt_dailog").show();
        }
    }
    //失败回调
    function faileCBack_baseinfo(){
        //组装失败信息
        var msg_ti_str = '{"DTL_ID":"'+cons_info.dtl_id+'","CONS_ID":"'+cons_info.cons_id+'","MSG":"检查结果巡检记录上装失败","PKG":'+PKG1+',"ERROR_ID":"2101"}';
        upload_Data("2101","2003",PKG1,msg_ti_str,"yj_upload_proc");
        setTimeout(function(){
            $("#businessList_laoding_view").css("display","none");//关闭加载效果框
            $("#yxzypt_msg").html("数据进入到上装队列，等待上装！");//给弹出框赋对应的提示消息
            onchange_val();
            $("#yxzypt_dailog").show();
         },500);
    }
}


</script>