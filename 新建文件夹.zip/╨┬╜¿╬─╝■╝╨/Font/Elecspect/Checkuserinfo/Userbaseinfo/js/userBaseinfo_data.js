<script type="text/javascript">
/**
 * 返回数据
 * @param CONS_NO=用户编号
 * @param ADDR=联系人地址
 * @param HOMEPHONE=住宅电话
 * @param CHECKER_NO=检查员 emp_NO
 * @param CONS_NAME=用户名称
 * @param ELEC_ADDR=用电地址 CONTACT_ID 联系方式ID
 * @param CONTACT_NAME=联系人
 * @param OFFICE_TEL=办公电话
 * @param EMAIL=电子邮件
 * @param MOBILE
 * @param dtl_id 
 * @param cons_id
 * @param sucessCB
 * @param failCB
 * @return
 */
function  get_yj_c_cons_baseinfo(dtl_id,cons_id,sucessCB,failCB){
	var sql="select CONS_NO,ADDR,HOMEPHONE,CHECKER_NO,CONTACT_ID,cons_name as cons_name,elec_addr as elec_addr,contact_name as contact_name,office_tel as office_tel,email as email,mobile as mobile from yj_c_cons where  dtl_id=? and cons_id=?";
	db_execut_oneSQL(null,sql,[dtl_id,cons_id],sucessCB,failCB);
}

</script>