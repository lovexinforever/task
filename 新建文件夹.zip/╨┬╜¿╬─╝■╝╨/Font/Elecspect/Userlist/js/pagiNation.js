<script type="text/javascript">

/**
 * 分页符
 * @type pagiNation
 */
var pN = {

	mCurrentPage : 1, // 默认第一页

	mShowDataNum : 100, // 默认显示100条数据

	mLimitNum : 0, // 默认数据从0开始查

	mAllDataNum : 0, // 总共数据条目

	mAllPageNum : 0, // 总共页数

	/**
	 * 初始化 "分页符页码" 和 "总页数"
	 */
	initPageNum : function() {

		if ((pN.mAllDataNum % pN.mShowDataNum) > 0) {// 取模大于0

			pN.mAllPageNum = Math.floor(pN.mAllDataNum / pN.mShowDataNum) + 1;
		} else {// 取模等于0
			pN.mAllPageNum = Math.floor(pN.mAllDataNum / pN.mShowDataNum);
		}
		return "第" + pN.mCurrentPage + "页（总共" + pN.mAllPageNum + "页）"
	},

	/**
	 * 显示哪一页
	 */
	showPaginNation : function() {

	},

	/**
	 * 设置当前页 , 并设置当前SQL需要查询的起点
	 * 
	 * @param {}
	 *            ctPage
	 */
	setCurrentPage : function(ctPage) {
		pN.mCurrentPage = ctPage;
		pN.mLimitNum = (ctPage - 1) * 100;
	},

	/**
	 * 页面跳转时 ： 清空页码标记,
	 */
	clearPageFalg : function() {
		pN.mCurrentPage = 1;
		pN.mLimitNum = 0;
		pN.mAllNum = 0;
	}
};


/** *********分页栏 逻辑************* */
// 上一页
$("#lastPage").click(function() {
	if(pN.mCurrentPage<=1){
		showToast("已经是第一页")
	}else{
		pN.setCurrentPage(pN.mCurrentPage-1);
		$("#businessList_laoding_view").show();
		selectDB_yj_c_cons_userlist_2(sessionStorage.APP_NO_bl);
	}
});

// 下一页
$("#nextPage").click(function() {
	if(pN.mCurrentPage == pN.mAllPageNum){
		showToast("已经是最后一页")
	}else{
		pN.setCurrentPage(pN.mCurrentPage+1);
		$("#businessList_laoding_view").show();
		selectDB_yj_c_cons_userlist_2(sessionStorage.APP_NO_bl);
	}
});

/**
 * 修改分页栏显示的页码
 */
function changePageNum(numString) {
	$("#pageInfo").html(numString);
}


/**
 * 初始化数据数据总数目
 */
function initAllDataNum(){
	    var sqlst="select count(plan_det.dtl_id) as dataNum " +
    		"from yj_c_cons cons,(select det.dtl_id,det.id,det.cons_id,det.CHK_DATE " +
    		"from YJ_S_CHK_PLAN plan,YJ_S_CHK_PLAN_DET det " +
    		"where plan.PLAN_NO=det.PLAN_NO and plan.app_no=det.app_no and plan.app_no=?) plan_det " +
    		"where cons.dtl_id=plan_det.dtl_id and cons.cons_id=plan_det.cons_id order by plan_det.CHK_DATE,cons.CONS_NO  ";
    db_execut_oneSQL(null,sqlst,[sessionStorage.APP_NO_bl],function(tx,res){
    	if(res.rows.length>0){
	    	pN.mAllDataNum = res.rows.item(0).dataNum;		//初始分页 总数据数
//	    	pN.mAllDataNum = 101;		//初始分页 总数据数
    	}
    },null);
}

/**
 * 当数据总数大于100时才显示分页符
 */
function hideShowPagi(){
	if(pN.mAllDataNum<pN.mShowDataNum){
		$("#pagiAction").hide();
		$("#mainContentPage").css("margin-top","0px");
	}else{
		$("#pagiAction").show();
		$("#mainContentPage").css("margin-top","30px");
	}
}

$("#pageInfo").click(function(){
   	 var listHtml = "";
   	 $("#tp_info").html("分页");//titile
   	 for(var i=0;i<pN.mAllPageNum;i++){
   	 	listHtml += "<li><a><div id='uslist_xllb_"+i+"' style='padding-right:45px; color:#707070;'>第"+(i+1)+"页</div></a></li>";
   	 }
   	 $("#lb_info").html(listHtml);//1.填充下拉列表框内容
	 opendailog("my_sld_li");//2.显示下拉列表框
	 
   	 //绑定选中事件
	 for(var j=0;j<pN.mAllPageNum;j++){
	     document.getElementById("uslist_xllb_"+j).addEventListener("click", function(e){
	     	var thisIds = $(this).attr("id");
	     	j = Number(thisIds.split("uslist_xllb_")[1]);
	     	
	     	if(pN.mCurrentPage != (j+1)){
				pN.setCurrentPage(j+1);
				$("#businessList_laoding_view").show();
				selectDB_yj_c_cons_userlist_2(sessionStorage.APP_NO_bl);
				$("#pageInfo").html("第" + (j+1) + "页（总共" + pN.mAllPageNum + "页）");
				$("#ydjc_userlist_cons_sort_code").attr("name",j+1);
	     	}
			close_dailog_removeMemor();//关闭下拉列表框，并删除生产的代码
	     });
	 }
});


</script>