<script type="text/javascript">
/***********************************************获得用户列表---开始*********************************************************/
/**
 * 根据app_no查询出对应的用户列表数据
 * 先查询数据库表（YJ_S_CHK_PLAN），数据是否已经下载，如果下载直接查询数据；否则先从服务器抓取数据，插入数据库，再返回页面。
 * 服务器返回3张表的数据：YJ_S_CHK_PLAN、YJ_S_CHK_PLAN_DET、YJ_C_CONS
 * 
 * @param app_no
 */
function getYj_c_cons_userlist(app_no){
	var sql="select count(plan_no) cs from yj_s_chk_plan where app_no=?";
	db_execut_oneSQL(null,sql,[app_no],sucessCB_1,failCB_1);
	function sucessCB_1(tx,res){
		 var count = res.rows.item(0).cs;
		 //数据已存在数据库
		 if(count>0){
			 //查询数据库
			 selectDB_yj_c_cons_userlist_2(app_no);
		 }
		 //需要从服务器请求数据，然后插入数据库
		 else{
			 first_yj_c_cons_userlist_2(app_no);
		 }
	}
	 //查询失败
	function failCB_1(e){
		//关闭加载效果
		close_loading_view("查询移动终端数据库失败");
	}
}
/**
 * 查询数据然后返回给页面
 * @param app_no
 */
function selectDB_yj_c_cons_userlist_2(app_no){
	initAllDataNum();
    var sql="select cons.MEAS_MODE as meas_mode,cons.VOLT_CODE as volt_code,cons.UPLOADING_TYPE as UPLOADING_TYPE, " +
    		"cons.DTL_ID as dtl_id,cons.CONS_ID as cons_id,cons.CONS_NO as cons_no," +
    		"cons.ISFISHY as isfishy,cons.CONS_NAME as cons_name,cons." +
    		"CONS_SORT_CODE as cons_sort_code,cons.RRIO_CODE as rrio_code,cons.ELEC_ADDR as elec_addr," +
    		"cons.ELEC_TYPE_CODE as elec_type_code,cons.downloading_type as downloading_type," +
    		"plan_det.id as cr_id,plan_det.plan_status_code as plan_status_code, " +
    		"( CASE when ( rrio_code !='' and rrio_code notnull  OR volt_code in ('AC05001','AC02201','AC01101','AC00351')  OR (volt_code in ('AC00201','AC00101') AND meas_mode = 1 ))  then '是' else '否' end  ) as ydzyxj " +
    		"from yj_c_cons cons,(select det.dtl_id,det.id,det.cons_id,det.plan_status_code,det.CHK_DATE " +
    		"from YJ_S_CHK_PLAN plan,YJ_S_CHK_PLAN_DET det " +
    		"where plan.PLAN_NO=det.PLAN_NO and plan.app_no=det.app_no and plan.app_no=?) plan_det " +
    		"where cons.dtl_id=plan_det.dtl_id and cons.cons_id=plan_det.cons_id order by plan_det.CHK_DATE,cons.CONS_NO limit  "+pN.mLimitNum+" , "+pN.mShowDataNum;
    db_execut_oneSQL(null,sql,[app_no],initPage_userlist_ydjc_2,function(e){
        //关闭加载效果
        close_loading_view("查询移动终端数据库失败");
    });
}
/**
 * 第一次进入用户列表，需要请求服务器数据，然后插入到数据库中
 * @param app_no
 */
function first_yj_c_cons_userlist_2(app_no){
	var pkg='{"MOD":"2003","FUN":"1002","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"TYPECODE":"2003","APP_NO":"'+app_no+'","TASK":[]}}';	
	send_data("1002","2003",pkg,sendDataSucessCB_ul_1,sendDataFailCB_ul_1);
	//发送成功
	function sendDataSucessCB_ul_1(msg){
		msg=JSON.parse(msg);
		if(msg.RET!="00"){
			//关闭加载效果
			close_loading_view(getErrorMsg(msg.RET));
		}else{
			try{
				var pkg=msg.PKG;
				if(pkg.RET=="10"){//数据返回成功
					insert_db_server_data_2(pkg.PKG,app_no);
				}else if(pkg.RET=="14"){//刷新工单
					//sessionStorage.bussess_refresh = "refresh";//用户列表返回数据为空了，设置进入待办事宜时重新刷新工单列表
					close_loading_view("该工单下用户检查工作均已执行完毕!");//用户列表没有数据时候，服务器返回空，不用刷新用户列表
				}else{
					close_loading_view("请求服务异常，请重试!");
				}
			}catch(e){
				//关闭加载效果
				close_loading_view("该工单下用户检查工作均已执行完毕");
			}
		}
	}
	//发送失败
	function sendDataFailCB_ul_1(){
		//关闭加载效果
		close_loading_view("请求用户列表失败");
	}
	
}
/**
 * 得到服务器的json数据。解析数据，插入到数据。然后刷新页面
 * @param pkg
 * @returns
 */
function insert_db_server_data_2(pkg,app_no){
	var insert_list=new Array();
	var pkg_obj=null;
	var inser_sql=null;
	var yj_chk_plan=pkg.YJ_S_CHK_PLAN;
	for(var i=0;i<yj_chk_plan.length;i++){
		pkg_obj=yj_chk_plan[i];
		inser_sql="INSERT INTO YJ_S_CHK_PLAN(PLAN_NO,EMP_NO,APP_NO,ORG_NO,PLAN_DESC,TYPE_CODE,PLAN_YEAR,CHK_MONTH,CONTENT_CODE) VALUES('"+pkg_obj.PLAN_NO+"','"+pkg_obj.EMP_NO+"','"+pkg_obj.APP_NO+"','"+pkg_obj.ORG_NO+"','"+pkg_obj.PLAN_DESC+"','"+pkg_obj.TYPE_CODE+"','"+pkg_obj.PLAN_YEAR+"','"+pkg_obj.CHK_MONTH+"','"+pkg_obj.CONTENT_CODE+"')";
		insert_list.push(inser_sql);
	}
	
	var yj_chk_plan_det=pkg.YJ_S_CHK_PLAN_DET;
	for(var j=0;j<yj_chk_plan_det.length;j++){
		pkg_obj=yj_chk_plan_det[j];
		inser_sql="INSERT INTO YJ_S_CHK_PLAN_DET(APP_NO,PLAN_NO,TYPE_CODE,CERT_ID,CHK_MONTH,ACTUAL_CHK_DATE,PLAN_STATUS_CODE,ASSIGNER,CONTENT_CODE,CHK_DATE,ASSIGN_TIME,CONS_ID,PLAN_YEAR,TAST_SRC,DTL_ID,ID)" +
				                  "VALUES('"+setUndefined(pkg_obj.APP_NO)+"','"+setUndefined(pkg_obj.PLAN_NO)+"','"+setUndefined(pkg_obj.TYPE_CODE)+"','"+setUndefined(pkg_obj.CERT_ID)+"','"+setUndefined(pkg_obj.CHK_MONTH)+"','"+setUndefined(pkg_obj.ACTUAL_CHK_DATE)+"','"+setUndefined(pkg_obj.PLAN_STATUS_CODE)+"','"+setUndefined(pkg_obj.ASSIGNER)+"','"+setUndefined(pkg_obj.CONTENT_CODE)+"','"+setUndefined(pkg_obj.CHK_DATE)+"','"+setUndefined(pkg_obj.ASSIGN_TIME)+"','"+setUndefined(pkg_obj.CONS_ID)+"','"+setUndefined(pkg_obj.PLAN_YEAR)+"','"+setUndefined(pkg_obj.TAST_SRC)+"','"+setUndefined(pkg_obj.DTL_ID)+"','"+setUndefined(pkg_obj.ID)+"')";
		insert_list.push(inser_sql);
	}

	var yj_c_cons=pkg.YJ_C_CONS;
	for(var w=0;w<yj_c_cons.length;w++){
		pkg_obj=yj_c_cons[w];
		inser_sql="INSERT INTO YJ_C_CONS(RUN_CAP,CONS_SORT_CODE,MR_SECT_NO,EMAIL,OFFICE_TEL,LOC_FILE,COUNTY_CODE,TMP_DATE,CHECKER_NAME,CONTRACT_CAP,ORG_NO,ISFISHY,HEC_INDUSTRY_CODE,MOBILE,ELEC_ADDR,TRANSFER_CODE,MEAS_MODE,VOLT_CODE,LODE_ATTR_CODE,STATUS_CODE,TMP_FLAG,TRADE_CODE,PS_DATE,CHK_CYCLE,CHECKER_NO,CONS_NO,CONS_ID,ELEC_TYPE_CODE,DUE_DATE,DTL_ID,RRIO_CODE,CONTACT_NAME,CONS_NAME)VALUES('"+setUndefined(pkg_obj.RUN_CAP)+"','"+setUndefined(pkg_obj.CONS_SORT_CODE)+"','"+setUndefined(pkg_obj.MR_SECT_NO)+"','"+setUndefined(pkg_obj.EMAIL)+"','"+setUndefined(pkg_obj.OFFICE_TEL)+"','"+setUndefined(pkg_obj.LOC_FILE)+"','"+setUndefined(pkg_obj.COUNTY_CODE)+"','"+setUndefined(pkg_obj.TMP_DATE)+"','"+setUndefined(pkg_obj.CHECKER_NAME)+"','"+setUndefined(pkg_obj.CONTRACT_CAP)+"','"+setUndefined(pkg_obj.ORG_NO)+"','"+setUndefined(pkg_obj.ISFISHY)+"','"+setUndefined(pkg_obj.HEC_INDUSTRY_CODE)+"','"+setUndefined(pkg_obj.MOBILE)+"','"+setUndefined(pkg_obj.ELEC_ADDR)+"','"+setUndefined(pkg_obj.TRANSFER_CODE)+"','"+setUndefined(pkg_obj.MEAS_MODE)+"','"+setUndefined(pkg_obj.VOLT_CODE)+"','"+setUndefined(pkg_obj.LODE_ATTR_CODE)+"','"+setUndefined(pkg_obj.STATUS_CODE)+"','"+setUndefined(pkg_obj.TMP_FLAG)+"','"+setUndefined(pkg_obj.TRADE_CODE)+"','"+setUndefined(pkg_obj.PS_DATE)+"','"+setUndefined(pkg_obj.CHK_CYCLE)+"','"+setUndefined(pkg_obj.CHECKER_NO)+"','"+setUndefined(pkg_obj.CONS_NO)+"','"+setUndefined(pkg_obj.CONS_ID)+"','"+setUndefined(pkg_obj.ELEC_TYPE_CODE)+"','"+setUndefined(pkg_obj.DUE_DATE)+"','"+setUndefined(pkg_obj.DTL_ID)+"','"+setUndefined(pkg_obj.RRIO_CODE)+"','"+setUndefined(pkg_obj.CONTACT_NAME)+"','"+setUndefined(pkg_obj.CONS_NAME)+"')";
		insert_list.push(inser_sql);
	}
	
	if(insert_list.length>0){
		 var ydjc = window.sqlitePlugin.openDatabase("ydjc.db", "1.0","ydjc.db",10*1024*1024);
		 ydjc.transaction(function(tx){
			 var exe_sum=0;
			 var exe_sum_error=0;
			 for(var m in insert_list){
				 if(exe_sum_error>0){
					 close_loading_view("批量插入移动终端数据库失败");
					 break;
				 }
				 tx.executeSql(insert_list[m],[],function(tx,res){
					 if(exe_sum==(insert_list.length-1)){//成功
					 	refresh_flag="";
						 selectDB_yj_c_cons_userlist_2(app_no);
					 }
					 exe_sum++;
				 },function(e){
					 exe_sum_error++;
				 });
			 }
		 });
	}
	
}
/***********************************************获得用户列表---结束*********************************************************/


/***********************************************全部工单下载---开始*********************************************************/
/**
 * 单个工单数据包下载
 *
 * 数据包下载-->插入数据到数据库业务流程说明：
 * 1.发送user_id,app_no,cons_id到服务器
 * 2.平台转发请求到服务器
 * 3.平台下载数据包到data/data/files目录下，解压并，删除zip包，最终生成：data/data/files/app_no/*.txt。
 * 4.业务循环调用read_db_file();把对应的数据插入到数据库表中
 * 数据插入前的数据处理过程：
 * 1.根据读到的ID，在数据库中删除原有的记录
 * 2.把新记录插入到数据库中。
 */
function download_userlist_data_all(user_id,app_no,sucess_dowanload){
	var pkg ='{"MOD":"2003","FUN":"1003","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"APP_NO":"'+app_no+'","EMP_NO":"'+sessionStorage.EMP_NO+'","USR":"'+user_id+'","TASK":[]}}';
	download_userlist_data_temple("1003",pkg,user_id,app_no,sucess_dowanload,100,null,null);
}
//单用户数据包下载
function download_userlist_data_one(cons_id,dtl_id,cons_no,cons_name,rrio_code,user_id,app_no,id,sucess_dowanload){
	var pkg ='{"MOD":"2003","FUN":"1004","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"CONS_NO":"'+cons_no+'","RRIO_CODE":"'+rrio_code+'","CONS_NAME":"'+cons_name+'","APP_NO":"'+app_no+'","EMP_NO":"'+sessionStorage.EMP_NO+'","CONS_ID":"'+cons_id+'","DTL_ID":"'+dtl_id+'","USR":"'+user_id+'","CR_ID":"'+id+'","TASK":[]}}';
	download_userlist_data_temple("1004",pkg,user_id,app_no,sucess_dowanload,1,cons_id,dtl_id);
}
//下载服务
function download_userlist_data_temple(fun,pkg,user_id,app_no,sucess_dowanload,type,cons_id,dtl_id){
	 //1.发送用电检查待办事宜列表请求到服务器
	send_data(fun,"2003",pkg,sendDataSucessCB_1,sendDataFailCB_1);
	   //发送成功
	   function sendDataSucessCB_1(msg){
   try{
		    msg=JSON.parse(msg);
			if(msg.RET!="00"){
			   sucess_dowanload(getErrorMsg(msg.RET));
		   }else{
				    var pkg=msg.PKG;
					if(pkg.RET=="10"){//数据返回成功
						  var zipPath=null;
						  var add=pkg.PKG.APP_NO_PACKAGE_ADDR[0]; 
						  //下载地址
						  var zip=sessionStorage.DOWN_URL+"/"+add.filePath;
						  //下载ZIP包
						  donwloadAndZip(zip,zipPath,function(zipmsg){
							  //下载，解压成功
							  if(zipmsg.msg==1 && zipmsg.num==add.fileNum){
								//包含的文件名
								  var files=add.fileNames;
								  read_db_file_2(files.split("|"),returnt_proc_db_SQL,app_no,sucess_dowanload,type,cons_id,dtl_id);
							  }
							  //下载，解压失败
							  else{
								  sucess_dowanload("下载失败，请重新下载!");
							  }
						  });
					}else{
						sucess_dowanload("该用户检查工作均已执行完毕");
					}
		   }
	   }catch(e){
		   sucess_dowanload("该用户检查工作均已执行完毕");  
	   }
   }
	   //发送失败
	   function sendDataFailCB_1(msg){
		   sucess_dowanload("发送下载数据包请求失败");
	   }
}



/**
 * 挨个读取所有数据文件。最终组装成批量的删除 语句和插入语句。最终在批量的操作数据库
 */
function read_db_file_2(files,returnt_proc_db_SQL,app_no,sucess_dowanload,type,cons_id,dtl_id){
	 var path="file:///data/data/com.elec.mobile.platform.login/files/";
	 var files_length=files.length;
	 //所有的插入语句
   	 var insert_list=new Array();
   	 //所有的删除语句
   	 var delete_list=new Array();
	 //开始读取以第一个
   	 read();
	function read(){
		 //完整路径
		 var fullPaht=path+files[0];
		window.resolveLocalFileSystemURI(fullPaht,function(fileEntry){
            
			fileEntry.file(function(file){
				var tablename=(fileEntry.name).split(".")[0];
				var reader = new FileReader();
		        reader.onloadend = function(evt) {
		            var rst=evt.target.result;//读到的文件内容
		            var inserts=get_insert_sql_2(tablename,rst);
		             addArrayTOotherArray(insert_list,inserts);
		            var deletes=get_DTL_IDS_2(tablename,rst);
		            if(deletes!="")delete_list.push(deletes);
		            if(files.length>1){
		            	files.splice(0,1);
		            	read();
		            }else if(files.length==1){
		            	//文件读取完毕后删除文件。目前不需要删除。如果要删除打开以下注释代码即可。
		            	//fileEntry.getParent(function(parent){
		            		//parent.removeRecursively(function(parent){
		            			//console.log("Remove Recursively Succeeded");
		            		//},function(e){
		            			// console.log("Remove Recursively fail");
		            		//});
		            	//},function(error){
		            		//console.log("+++++++++++++++++Parent fulpath ERROR-----------------------------------"+error.code);
		            	//});
		            	files=null;
		            	if(type==1){
		            		returnt_proc_db_SQL_dowanloadOne(insert_list,delete_list,app_no,sucess_dowanload,cons_id,dtl_id);
		            	}else if(type==100){
		            		returnt_proc_db_SQL(insert_list,delete_list,app_no,sucess_dowanload);
		            	}
		            	insert_list=null;
		            	delete_list=null;
		            }
		        };
		        reader.readAsText(file);
			}, function(e){
				sucess_dowanload("读取压缩文件内容失败");
			});
			
		},function(e){
			sucess_dowanload("打开压缩文件内容失败")
		}); 
		tablename=null;
		fulpath=null;
	}
	
	function addArrayTOotherArray(a1,a2){
		for(var w=0;w<a2.length;w++){
			a1.push(a2[w]);
		}
	}
}
//读取文件，并组装DELETE,INSERT语句结束-------------------------------------全部工单下载
function returnt_proc_db_SQL(insert_list,delete_list,app_no,sucess_dowanload){
	console.log("APP_NO=="+app_no+" DELETE------------------length: "+delete_list.length);
	console.log("APP_NO=="+app_no+" INSERT------------------length: "+insert_list.length);
	var ydjc = window.sqlitePlugin.openDatabase("ydjc.db", "1.0","ydjc.db", 10*1024*1024);
	//删除问题反馈
	 delete_list.push("DELETE FROM YJ_PROBLEM_FEEDBACK WHERE DTL_ID IN(SELECT D.DTL_ID FROM YJ_S_CHK_PLAN P,YJ_S_CHK_PLAN_DET D WHERE P.PLAN_NO=D.PLAN_NO AND P.APP_NO='"+app_no+"')");
	//删除修改记录YJ_DATA_COMPARISON_DTL_ID
	 delete_list.push("DELETE FROM YJ_DATA_COMPARISON_DTL_ID WHERE DTL_ID IN(SELECT D.DTL_ID FROM YJ_S_CHK_PLAN P,YJ_S_CHK_PLAN_DET D WHERE P.PLAN_NO=D.PLAN_NO AND P.APP_NO='"+app_no+"')");
	//删除上装错误日志YJ_DATA_COMPARISON_ERROR
	 delete_list.push("DELETE FROM YJ_DATA_COMPARISON_ERROR WHERE DTL_ID IN(SELECT D.DTL_ID FROM YJ_S_CHK_PLAN P,YJ_S_CHK_PLAN_DET D WHERE P.PLAN_NO=D.PLAN_NO AND P.APP_NO='"+app_no+"')"); 
	 //开始，删除
	exe_delete();
	//删除
	 function exe_delete(){
		 ydjc.transaction(function(tx){
			 tx.executeSql(delete_list[0],[],function(tx,res){
				 //console.log("*******************"+delete_list.length+"********************" +"DELETE------SQL: "+delete_list[0]);
				 if(delete_list.length>1){
					 delete_list.splice(0,1);
					 exe_delete();
				 }else if(delete_list.length==1){//删除结束。开始插入。
					 delete_list=null;
					 //删除结束。开始插入
					 exe_insert();
				 }
			 },function(e){
				 sucess_dowanload("批量删除移动终端数据失败");
			 });
		 });
		 
	 }
	 //插入
	 function exe_insert(){
		 ydjc.transaction(function(tx){
			 tx.executeSql(insert_list[0],[],function(tx,res){
				 //console.log("*******************"+insert_list.length+"********************" +"INSERT------SQL: "+insert_list[0]);
				 if(insert_list.length>1){
					 insert_list.splice(0,1);
					 exe_insert();
				 }else if(insert_list.length==1){//插入结束。开始更新插入标志。
					 insert_list=null;
					 //插入结束。开始更新插入标志;
					 exe_update();
				 }
			 },function(e){
				 sucess_dowanload("批量插入移动终端数据失败");
			 });
		 });
	 }
	 //更新
	 function exe_update(){
		 var update_cons_sql="UPDATE YJ_C_CONS SET DOWNLOADING_TYPE=1 WHERE DTL_ID IN(SELECT dt.dtl_id from yj_s_chk_plan p,yj_s_chk_plan_det dt,yj_c_cons cs where p.plan_no=dt.plan_no and dt.dtl_id=cs.dtl_id and dt.cons_id=cs.cons_id and p.app_no=?)";
	     var update_app_no_sql="UPDATE YJ_TODO_SOMETHING SET DOWNLOADING_TYPE=1 WHERE APP_NO=?";
	     ydjc.transaction(function(tx){
	    	 tx.executeSql(update_cons_sql,[app_no],function(tx,res){
	    		 ydjc.transaction(function(tx){
	    			 tx.executeSql(update_app_no_sql,[app_no],function(tx,res){
	    				 //下载结束。。。刷新页面
	    				 sucess_dowanload(1);
	    			 },function(e){
	    				 sucess_dowanload("更新移动终端待办事宜表失败");
	    			 });
	    			 
	    		 });
	    	 },function(e){
	    		 sucess_dowanload("更新移动终端用户信息表失败");
	    	 });
	    	 
	     });
	 }
}


//读取文件，并组装DELETE,INSERT语句结束------------------------------------------------------单个工单下载
function returnt_proc_db_SQL_dowanloadOne(insert_list,delete_list,app_no,sucess_dowanload,cons_id,dtl_id){
	//console.log("APP_NO=="+app_no+" DELETE------------------length: "+delete_list.length);
	//console.log("APP_NO=="+app_no+" INSERT------------------length: "+insert_list.length);
	var ydjc = window.sqlitePlugin.openDatabase("ydjc.db", "1.0","ydjc.db", 10*1024*1024);
	//删除问题反馈
	 delete_list.push("DELETE FROM YJ_PROBLEM_FEEDBACK WHERE DTL_ID='"+dtl_id+"'");
	//删除修改记录YJ_DATA_COMPARISON_DTL_ID
	 delete_list.push("DELETE FROM YJ_DATA_COMPARISON_DTL_ID WHERE DTL_ID='"+dtl_id+"'");
	//删除上装错误日志YJ_DATA_COMPARISON_ERROR
	 delete_list.push("DELETE FROM YJ_DATA_COMPARISON_ERROR WHERE DTL_ID='"+dtl_id+"'"); 
	//开始，删除
	exe_delete();
	//删除
//	 function exe_delete(){
//		 ydjc.transaction(function(tx){
//			 tx.executeSql(delete_list[0],[],function(tx,res){
//				 //console.log("*******************"+delete_list.length+"********************" +"DELETE------SQL: "+delete_list[0]);
//				 if(delete_list.length>1){
//					 delete_list.splice(0,1);
//					 exe_delete();
//				 }else if(delete_list.length==1){//删除结束。开始插入。
//					 delete_list=null;
//					//删除结束。开始插入
//					 exe_insert();
//				 }
//			 },function(e){
//				 sucess_dowanload("批量删除移动终端数据失败");
//			 });
//		 });
//		 
//	 }
	 //插入
//	 function exe_insert(){
//		 ydjc.transaction(function(tx){
//			 tx.executeSql(insert_list[0],[],function(tx,res){
////				 console.log("*******************"+insert_list.length+"********************" +"INSERT------SQL: "+insert_list[0]);
//				 if(insert_list.length>1){
//					 insert_list.splice(0,1);
//					 exe_insert();
//				 }else if(insert_list.length==1){//插入结束。开始更新插入标志。
//					 insert_list=null;
//					//插入结束。开始更新插入标志
//					 exe_update();
//				 }
//			 },function(e){
//				 sucess_dowanload("批量插入移动终端数据失败");
//			 });
//		 });
//	 }
/*******************插入  同时插入  删除***************************/
 function exe_delete(){//删除
 	if(delete_list.length>0){
		 	var num0 = 0;
		 	var flag_state0 = false;
			 ydjc.transaction(function(tx){
		 		for(var i=0;i<delete_list.length;i++){
				 tx.executeSql(delete_list[i],[],function(tx,res){
					num0++;
					// console.log("i="+i+"|||num0=="+num0);
					if(num0>=delete_list.length){
						// 插入结束。开始更新插入标志
						console.log("i="+i+"|||num0=="+num0);
						 delete_list=null;
						 exe_insert();
					}
				 },function(e){
					 if(!flag_state0){
						 sucess_dowanload("批量删除移动终端数据失败");
						 flag_state0=true;
					 }
				 });
		 	}
	 	});
 	}else{
 		 exe_insert();
 	}
 }
 function exe_insert(){//插入
 	if(insert_list.length>0){
		 	var num = 0;
		 	var flag_state = false;
			 ydjc.transaction(function(tx){
		 		for(var i=0;i<insert_list.length;i++){
				 tx.executeSql(insert_list[i],[],function(tx,res){
					num++;
					//console.log("i="+i+"|||num=="+num);
					if(num>=insert_list.length){
						//插入结束。开始更新插入标志
						console.log("i="+i+"|||num=="+num);
						 insert_list=null;
						 exe_update();
					}
				 },function(e){
					 if(!flag_state){
						 sucess_dowanload("批量插入移动终端数据失败");
						 flag_state=true;
					 }
				 });
		 	}
	 	});
 	}else{
 		exe_update();
 	}
}
/*******************插入  同时插入  删除***************************/
	 /**
	  * 更新
	  * 1.更新YJ_C_CONS下载标识为1
	  * 2.如果本下载时当前工单的最后一个用户，并且工单未被下载过。就需要更新工单下载标识为：下载完成。
	  * @returns
	  */
	 function exe_update(){
		 var update_cons_sql="UPDATE YJ_C_CONS SET DOWNLOADING_TYPE=1 WHERE DTL_ID=? and CONS_ID=?";
	     ydjc.transaction(function(tx){
	    	 tx.executeSql(update_cons_sql,[dtl_id,cons_id],function(tx,res){
	    		 ydjc.transaction(function(tx){
	    			 tx.executeSql("SELECT COUNT(DOWNLOADING_TYPE) as dt FROM YJ_TODO_SOMETHING WHERE APP_NO=? AND DOWNLOADING_TYPE=0",[app_no],function(tx,res){
	    				   if(res.rows.item(0).dt==1){//需要更新工单列表
	    					   ydjc.transaction(function(tx){
	    						   tx.executeSql("UPDATE YJ_TODO_SOMETHING SET DOWNLOADING_TYPE=1 WHERE APP_NO=?",[app_no],function(tx,res){
	    							   exe_update_MOBILE_EQUIP_ID();
	    						   },function(e){
	    							   sucess_dowanload("查询移动终端数据库失败");
	    						   }); 
	    					   });
	    				   }else{
	    					   //所有操作结束，返回给业务。
	    					   exe_update_MOBILE_EQUIP_ID();
	    				   }
	    			 },function(e){
	    				 sucess_dowanload("查询移动终端数据库失败");
	    			 });
	    		 });
	    		 
	    	 },function(e){
	    		 sucess_dowanload("更新移动终端用户表失败");
	    	 });
	    	 
	     });
	 }
	 
	 
	 //更新设备关联MOBILE_EQUIP_ID
	 function exe_update_MOBILE_EQUIP_ID(){
		 //查询出插入后，产生的MOBILE_EQUIP_ID
		 var select_MOBILE_EQUIP_ID="SELECT MOBILE_EQUIP_ID,EQUIP_ID,TYPE_CODE FROM YJ_C_EQUIP_RUN";
		 var update_list=new Array();
		 ydjc.transaction(function(tx){
			 tx.executeSql(select_MOBILE_EQUIP_ID,[],function(tx,res){
				 if(res.rows.length==0){
					 sucess_dowanload(1);//没有查询到设备id，关闭加载效果。
					 return;
				 }
				 //01自备电厂
				 var update_01="UPDATE YJ_C_SPARE_POWER SET MOBILE_EQUIP_ID=";
				 //04:避雷器
				 var update_04="UPDATE YJ_C_ARRESTER SET MOBILE_EQUIP_ID=";
				 //05:继电保护装置
				 var update_05="UPDATE YJ_C_RELAY_PROTECT_DEV SET MOBILE_EQUIP_ID=";
				 //06:断路器
				 var update_06="UPDATE YJ_C_BREAKER SET MOBILE_EQUIP_ID=";
				 //07:无功补偿设备
				 var update_07="UPDATE YJ_C_RPC_EQUIP SET MOBILE_EQUIP_ID=";
				 //08:自备应急电源
				 var update_08="UPDATE YJ_C_SPARE_GENERATOR SET MOBILE_EQUIP_ID=";
				//09:电缆
				 var update_09="UPDATE YJ_C_JCDDL SET MOBILE_EQUIP_ID=";
				 
				 for(var i=0;i<res.rows.length;i++){
					 var item=res.rows.item(i);
					 if(!item.EQUIP_ID || item.EQUIP_ID=="" || item.EQUIP_ID=="null"){
					 }else{
						 if(item.TYPE_CODE=="01"){
							 update_list.push(update_01+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
						 }
						 
						 else if(item.TYPE_CODE=="04"){
							 update_list.push(update_04+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
						 }
						 
						 else if(item.TYPE_CODE=="05"){
							 update_list.push(update_05+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
						 }
						 
						 else if(item.TYPE_CODE=="06"){
							 update_list.push(update_06+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
						 }
						 
						 else if(item.TYPE_CODE=="07"){
							 update_list.push(update_07+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
						 }
						 
	                     else if(item.TYPE_CODE=="08"){
	                    	 update_list.push(update_08+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
						 }
						 
	                     else if(item.TYPE_CODE=="09"){
	                    	 update_list.push(update_09+item.MOBILE_EQUIP_ID+" WHERE EQUIP_ID="+item.EQUIP_ID);
						 }
					 }
				 }
			      //开始更新
				  var exe_sum_error=0;
				  var u = 0;
				  updateMOBILE_EQUIP_ID();
				  //更新设备主键
				  function updateMOBILE_EQUIP_ID(){
			        ydjc.transaction(function(tx){
					      if(exe_sum_error>0){
                              sucess_dowanload("批量更新终端数据库失败");
                              return;
                           }
                	      tx.executeSql(update_list[u],[],function(tx,res){
                               if(u==(update_list.length-1)){//成功
                                   //sucess_dowanload(1);
                                   //开始更新安全隐患在整改中的外键：MOBILE_BUG_ID
                                   exe_update_MOBILE_BUG_ID();
                                }
                    	        if(u<(update_list.length-1)){
                                   u++;
                                   updateMOBILE_EQUIP_ID();
                    	        }
                          },function(e){
                               sucess_dowanload("更新移动终端设备关联表失败");
                               exe_sum_error++;
                         });
                   });
				 }
				 
			 },function(e){
				 sucess_dowanload("查询移动终端设备表失败");
			 });
			 
		 });
	 }
	 
	 //更新安全隐患在整改中的外键：MOBILE_BUG_ID
	 function exe_update_MOBILE_BUG_ID(){
		 //查询出插入后，产生的MOBILE_BUG_ID
		 var select_MOBILE_BUG_ID="SELECT MOBILE_BUG_ID,ID FROM YJ_S_SAFETY_BUG";
		 var update_list=new Array();
		 ydjc.transaction(function(tx){
			 tx.executeSql(select_MOBILE_BUG_ID,[],function(tx,res){
				 if(res.rows.length==0){
					 sucess_dowanload(1);//没有查询到MOBILE_BUG_ID，关闭加载效果。
					 return;
				 }
				 var update_sql="UPDATE YJ_S_IMPROVE SET MOBILE_BUG_ID=";
				 for(var i=0;i<res.rows.length;i++){
					 update_list.push(update_sql+res.rows.item(i).MOBILE_BUG_ID+" WHERE ID2="+res.rows.item(i).ID);
				 }
				if(update_list.length>0){
				 //开始更新
				  ydjc.transaction(function(tx){
					  var exe_sum_error=0;
					 for(var u in update_list){
						 if(exe_sum_error>0){
							 sucess_dowanload("批量更新终端数据库失败");
							 break;
						 }
					   tx.executeSql(update_list[u],[],function(tx,res){
						   if(u==(update_list.length-1)){//成功
							   //下载结束。。。刷新页面
			    			   sucess_dowanload(1);
							}
					   },function(e){
						   sucess_dowanload("更新移动终端设备关联表失败");
						   exe_sum_error++;
					   });
					   
					 }
				 });
			    }
			 },function(e){ sucess_dowanload("查询移动终端设备表失败");});
		 });
	 }
}
/**
 * insertSQL 是从下标0开始存入的。
 * 根据xx.txt文件内容组装成SQL语句。
 * @param table 表明
 * @param str .txt文件内容
 * @returns insert语句
 */
function get_insert_sql_2(table,str){
	var sqllist=new Array();
	if(str=="" || str==null || str=="null"){
		
	}else{
		//获得所有的记录
		var datas=str.split("\n");
		//获得数据库字段
		var column=datas[0];
		//替换'|'为','
		column=column.replace(/\|/g,",");
		//拼接插入字符串
		var inset="INSERT INTO "+table+"("+column+") VALUES";
		 datas.splice(0,1);//移除字段头部
         for(var i=0;i<datas.length;i++){
		    var values="(";
            var val=datas[i];
		    var vals=val.split("|");
			var len=vals.length;
		   for(var j=0;j<len;j++){
		   		vals[j] = vals[j].replace(/([']*)/g,"");
            	values+=("'"+vals[j]+(j==(len-1)?"'":"',"));
            }
			values+=")";
			sqllist[i]=inset+values;
        }
	}
	return sqllist;
}

/**
 *除了YJ_S_CHK_PLAN以外表，提取里面的DTL_ID
 *YJ_S_CHK_PLAN提取出PLAN_NO
 * @param str
 * @returns {Array}
 */
function get_DTL_IDS_2(tablename,str){
	   if(str=="" || str==null || str=="null"){
			
		}else{
			//获得所有的记录
			var datas=str.split("\n");
             //列头
			var columns=datas[0].split("|");
			 var index=-1;
			 var item=null;
			 var delete_sql="DELETE FROM "+tablename+" WHERE ";
			 for(var i=0;i<columns.length;i++){
				 item=columns[i];
                  if(tablename=="YJ_S_APP_REPLY"){
						if(item=="AR_ID"){
							index=i;
							delete_sql+="AR_ID IN";
							break;
						}
					}else if(tablename=="YJ_S_CHK_PLAN"){
                        if(item=="APP_NO"){
                            index=i;
                            delete_sql+="APP_NO IN";
                            break;
                        }
					}else if(tablename=="YJ_S_CHK_PLAN_DET"){
                        if(item=="DTL_ID"){
                            index=i;
                            delete_sql+="DTL_ID IN";
                            break;
                        }
                    }
					else if(tablename=="YJ_C_CONS"){
                        if(item=="DTL_ID"){
                            index=i;
                            delete_sql+="DTL_ID IN";
                            break;
                        }
                    }
					else if(tablename=="YJ_S_GWZYXJ" || tablename=="YJ_S_HR_CHKRESULT" || tablename=="YJ_S_IMPROVE" || tablename=="YJ_S_POWER_ACCI" || tablename=="YJ_S_SAFETY_BUG"){
						if(item=="ID"){
							index=i;
							delete_sql+="ID IN";
							break;
						}
					}
                   else if(tablename=="YJ_NEWELECTRICIAN_INFO"){
                        if(item=="CONS_ID"){
                            index=i;
                            delete_sql+="CONS_ID IN";
                            break;
                        }
                    }
					//else if(tablename=="YJ_S_HR_CHKRESULT"){
						//if(item=="ID"){
							//index=i;
							//delete_sql+="ID IN";
							//break;
						//}
					//}
					else if(tablename=="YJ_S_HR_IMPORTANT_CUST"){
						if(item=="CR_ID"){
							index=i;
							delete_sql+="CR_ID IN";
							break;
						}
					}
					//else if(tablename=="YJ_S_IMPROVE"){
						//if(item=="ID"){
							//index=i;
							//break;
						//}
					//S}
					//else if(tablename=="YJ_S_POWER_ACCI"){
						//if(item=="ID"){
							//index=i;
						//	break;
						//}
					//}
					else if(tablename=="YJ_S_PREVENTIVE_TEST"){
						if(item=="TEST_ID"){
							index=i;
							delete_sql+="TEST_ID IN";
							break;
						}
					}
					//else if(tablename=="YJ_S_SAFETY_BUG"){
						//if(item=="ID"){
							//index=i;
							//break;
						//}
					//}
					else{
						if(item=="DTL_ID"){
							index=i;
							delete_sql+="DTL_ID IN";
							break;
						}
					}
			 }
			 var dtl_ids="(";
			for(var j=1;j<datas.length;j++){
				var values=datas[j].split("|");
				dtl_ids+=("'"+values[index]+(j==(datas.length-1)?"'":"',"));
			}
			 dtl_ids+=")";
			 if(index>-1)
			 return delete_sql+dtl_ids;
		}
		return "";
}

/***********************************************全部用户工单下载---结束*********************************************************/


/***********************************************筛选---开始*********************************************************/

function select_user_list_dbData(app_no,where){
	initAllDataNum();
	refresh_flag="";//筛选标志置空
	var sql_="select cons.MEAS_MODE as meas_mode,cons.VOLT_CODE as volt_code,cons.UPLOADING_TYPE as UPLOADING_TYPE, " +
			"cons.DTL_ID as dtl_id,cons.CONS_ID as cons_id,cons.CONS_NO as cons_no,cons.ISFISHY as isfishy," +
			"cons.CONS_NAME as cons_name,cons.CONS_SORT_CODE as cons_sort_code,cons.RRIO_CODE as rrio_code," +
			"cons.ELEC_ADDR as elec_addr,cons.ELEC_TYPE_CODE as elec_type_code,cons.downloading_type as downloading_type," +
			"plan_det.id as cr_id,plan_det.plan_status_code as plan_status_code,  " +
			"( CASE when ( rrio_code !='' and rrio_code notnull  OR volt_code in ('AC05001','AC02201','AC01101','AC00351')  OR (volt_code in ('AC00201','AC00101') AND meas_mode = 1 ))  then '是' else '否' end  ) as ydzyxj " +
			"from yj_c_cons cons,(select det.dtl_id,det.id,det.cons_id,det.plan_status_code,det.CHK_DATE from " +
			"YJ_S_CHK_PLAN plan,YJ_S_CHK_PLAN_DET det " +
			"where plan.PLAN_NO=det.PLAN_NO and plan.APP_NO=det.APP_NO and plan.app_no=?) plan_det " +
			"where cons.dtl_id=plan_det.dtl_id and cons.cons_id=plan_det.cons_id "+where+" order by plan_det.CHK_DATE,cons.CONS_NO limit  "+pN.mLimitNum+" , "+pN.mShowDataNum;
	db_execut_oneSQL(null,sql_,[app_no],initPage_userlist_ydjc_2,function(e){
		//关闭加载效果
		close_loading_view("查询移动终端数据库失败");
	});
}
/***********************************************筛选---结束*********************************************************/


///**********************************************刷新---开始*********************************************************/
/**
 * 获得服务器上的数据。先删除本地数据，在插入到数据库 中。
 */
function refresh_userlist_data(app_no){
	var pkg='{"MOD":"2003","FUN":"1002","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"TYPECODE":"2003","APP_NO":"'+app_no+'","TASK":[]}}';
	send_data("1002","2003",pkg,sendDataSucessCB_ul,sendDataFailCB_ul);
	//发送成功
	function sendDataSucessCB_ul(msg){
		msg=JSON.parse(msg);
		if(msg.RET!="00"){
			//关闭加载效果
			close_loading_view(getErrorMsg(msg.RET));
		}else{
			try{
				var pkg=msg.PKG;
				if(pkg.RET=="10"){
					insert_db_refresh_uldata(pkg.PKG,app_no);
				}else if(pkg.RET=="14"){//刷新工单
//					alert("pkg.RET|="+pkg.RET);
					//开启加载效果
					$("#businessList_laoding_view").show();
					sessionStorage.bussess_refresh = "refresh";//用户列表返回数据为空了，设置进入待办事宜时重新刷新工单列表
					refresh_flag = "14";
					insert_db_refresh_uldata(pkg.PKG,app_no);//刷新下用户列表
					//close_loading_view("该工单下用户检查工作均已执行完毕!");
				}else{
					close_loading_view("请求服务异常，请重试!");
				}
			}catch(e){
				//关闭加载效果
				close_loading_view("该工单下用户检查工作均已执行完毕");
			}
		}
	}
	//发送失败
	function sendDataFailCB_ul(){
		//关闭加载效果
		close_loading_view("发送下载数据请求失败");
	}
}
//
function insert_db_refresh_uldata(pkg,app_no){
	var insert_list=new Array();
	var delete_list=new Array();
	var pkg_obj=null;
	var inser_sql=null;
	var delete_sql=null;
	var ids="";
    if(setUndefined(pkg.YJ_S_CHK_PLAN)==""){
        var yj_chk_plan=""
    }else{
        var yj_chk_plan=pkg.YJ_S_CHK_PLAN;
    }
	for(var i=0;i<yj_chk_plan.length;i++){
		pkg_obj=yj_chk_plan[i];
		inser_sql="INSERT INTO YJ_S_CHK_PLAN(PLAN_NO,EMP_NO,APP_NO,ORG_NO,PLAN_DESC,TYPE_CODE,PLAN_YEAR,CHK_MONTH,CONTENT_CODE) VALUES('"+pkg_obj.PLAN_NO+"','"+pkg_obj.EMP_NO+"','"+pkg_obj.APP_NO+"','"+pkg_obj.ORG_NO+"','"+pkg_obj.PLAN_DESC+"','"+pkg_obj.TYPE_CODE+"','"+pkg_obj.PLAN_YEAR+"','"+pkg_obj.CHK_MONTH+"','"+pkg_obj.CONTENT_CODE+"')";
		ids+=("'"+pkg_obj.APP_NO+(i==(yj_chk_plan.length-1)?"'":"',"));
		insert_list.push(inser_sql);
	}
	delete_sql="DELETE FROM YJ_S_CHK_PLAN WHERE APP_NO IN("+ids+")";
	delete_list.push(delete_sql);
	ids="";
    
    if(setUndefined(pkg.YJ_S_CHK_PLAN_DET)==""){
        var yj_chk_plan_det=""
    }else{
       var yj_chk_plan_det=pkg.YJ_S_CHK_PLAN_DET;
    }
	for(var j=0;j<yj_chk_plan_det.length;j++){
		pkg_obj=yj_chk_plan_det[j];
		inser_sql="INSERT INTO YJ_S_CHK_PLAN_DET(APP_NO,PLAN_NO,TYPE_CODE,CERT_ID,CHK_MONTH,ACTUAL_CHK_DATE,PLAN_STATUS_CODE,ASSIGNER,CONTENT_CODE,CHK_DATE,ASSIGN_TIME,CONS_ID,PLAN_YEAR,TAST_SRC,DTL_ID,ID)" +
				                  "VALUES('"+pkg_obj.APP_NO+"','"+pkg_obj.PLAN_NO+"','"+setUndefined(pkg_obj.TYPE_CODE)+"','"+setUndefined(pkg_obj.CERT_ID)+"','"+setUndefined(pkg_obj.CHK_MONTH)+"','"+setUndefined(pkg_obj.ACTUAL_CHK_DATE)+"','"+setUndefined(pkg_obj.PLAN_STATUS_CODE)+"','"+setUndefined(pkg_obj.ASSIGNER)+"','"+setUndefined(pkg_obj.CONTENT_CODE)+"','"+setUndefined(pkg_obj.CHK_DATE)+"','"+setUndefined(pkg_obj.ASSIGN_TIME)+"','"+setUndefined(pkg_obj.CONS_ID)+"','"+setUndefined(pkg_obj.PLAN_YEAR)+"','"+setUndefined(pkg_obj.TAST_SRC)+"','"+setUndefined(pkg_obj.DTL_ID)+"','"+setUndefined(pkg_obj.ID)+"')";
		ids+=("'"+pkg_obj.DTL_ID+(j==(yj_chk_plan_det.length-1)?"'":"',"));
		insert_list.push(inser_sql);
	}
	delete_sql="DELETE FROM YJ_S_CHK_PLAN_DET WHERE DTL_ID IN("+ids+")";
	delete_list.push(delete_sql);
    db_execut_oneSQL(null,"SELECT * from YJ_S_CHK_PLAN_DET where PLAN_STATUS_CODE!='08' and APP_NO=? and DTL_ID NOT IN("+ids+")",[app_no],function(tx,res){
        for(var k=0;k<res.rows.length;k++){
            //alert("k--"+k+"---res.rows.item(k).DTL_ID--"+res.rows.item(k).DTL_ID+"--id-"+res.rows.item(k).ID);
            var res_delete=res.rows.item(k);
            select_mobileDB_make_deleteSQL_DTLID(res_delete.APP_NO,res_delete.DTL_ID,res_delete.ID,res_delete.CONS_ID,delete_list);
        }
        ////////////////////////////////////        
                ids="";
                if(setUndefined(pkg.YJ_C_CONS)==""){
                    var yj_c_cons=""
                }else{
                    var yj_c_cons=pkg.YJ_C_CONS;
                }
                for(var w=0;w<yj_c_cons.length;w++){
                    pkg_obj=yj_c_cons[w];
                    inser_sql="INSERT INTO YJ_C_CONS(RUN_CAP,CONS_SORT_CODE,MR_SECT_NO,EMAIL,OFFICE_TEL,LOC_FILE,COUNTY_CODE,TMP_DATE,CHECKER_NAME,CONTRACT_CAP,ORG_NO,ISFISHY,HEC_INDUSTRY_CODE,MOBILE,ELEC_ADDR,TRANSFER_CODE,MEAS_MODE,VOLT_CODE,LODE_ATTR_CODE,STATUS_CODE,TMP_FLAG,TRADE_CODE,PS_DATE,CHK_CYCLE,CHECKER_NO,CONS_NO,CONS_ID,ELEC_TYPE_CODE,DUE_DATE,DTL_ID,RRIO_CODE,CONTACT_NAME,CONS_NAME)VALUES('"+setUndefined(pkg_obj.RUN_CAP)+"','"+setUndefined(pkg_obj.CONS_SORT_CODE)+"','"+setUndefined(pkg_obj.MR_SECT_NO)+"','"+setUndefined(pkg_obj.EMAIL)+"','"+setUndefined(pkg_obj.OFFICE_TEL)+"','"+setUndefined(pkg_obj.LOC_FILE)+"','"+setUndefined(pkg_obj.COUNTY_CODE)+"','"+setUndefined(pkg_obj.TMP_DATE)+"','"+setUndefined(pkg_obj.CHECKER_NAME)+"','"+setUndefined(pkg_obj.CONTRACT_CAP)+"','"+setUndefined(pkg_obj.ORG_NO)+"','"+setUndefined(pkg_obj.ISFISHY)+"','"+setUndefined(pkg_obj.HEC_INDUSTRY_CODE)+"','"+setUndefined(pkg_obj.MOBILE)+"','"+setUndefined(pkg_obj.ELEC_ADDR)+"','"+setUndefined(pkg_obj.TRANSFER_CODE)+"','"+setUndefined(pkg_obj.MEAS_MODE)+"','"+setUndefined(pkg_obj.VOLT_CODE)+"','"+setUndefined(pkg_obj.LODE_ATTR_CODE)+"','"+setUndefined(pkg_obj.STATUS_CODE)+"','"+setUndefined(pkg_obj.TMP_FLAG)+"','"+setUndefined(pkg_obj.TRADE_CODE)+"','"+setUndefined(pkg_obj.PS_DATE)+"','"+setUndefined(pkg_obj.CHK_CYCLE)+"','"+setUndefined(pkg_obj.CHECKER_NO)+"','"+setUndefined(pkg_obj.CONS_NO)+"','"+setUndefined(pkg_obj.CONS_ID)+"','"+setUndefined(pkg_obj.ELEC_TYPE_CODE)+"','"+setUndefined(pkg_obj.DUE_DATE)+"','"+setUndefined(pkg_obj.DTL_ID)+"','"+setUndefined(pkg_obj.RRIO_CODE)+"','"+setUndefined(pkg_obj.CONTACT_NAME)+"','"+setUndefined(pkg_obj.CONS_NAME)+"')";
                    ids+=("'"+pkg_obj.DTL_ID+(w==(yj_c_cons.length-1)?"'":"',"));
                    insert_list.push(inser_sql);
                }
                delete_sql="DELETE FROM YJ_C_CONS WHERE DTL_ID IN("+ids+")";
                delete_list.push(delete_sql);
                addArrayTOotherArray(delete_list,insert_list);
                //alert("delete_list---------"+delete_list);
                if(delete_list.length>0){
                    
                     var ydjc = window.sqlitePlugin.openDatabase("ydjc.db", "1.0","ydjc.db",10*1024*1024);
                     ydjc.transaction(function(tx){
                         var update_dowanload_types="("; 
                         var select_dowanload_num="SELECT DTL_ID FROM YJ_C_CONS WHERE DOWNLOADING_TYPE=1 AND DTL_ID IN(SELECT D.DTL_ID FROM YJ_S_CHK_PLAN P,YJ_S_CHK_PLAN_DET D WHERE P.PLAN_NO=D.PLAN_NO AND P.APP_NO=?)";
                         tx.executeSql(select_dowanload_num,[app_no],function(tx,res){
                            for(var f=0;f<res.rows.length;f++){
                                update_dowanload_types+=("'"+res.rows.item(f).DTL_ID+(f==(res.rows.length-1)?"')":"',"));
                            }
                             ydjc.transaction(function(tx){
                                 var exe_sum=0;
                                 var exe_sum_error=0;
                                 for(var m in delete_list){
                                     if(exe_sum_error>0){
                                         close_loading_view("批量插入移动终端数据库失败");
                                         break;
                                     }
                                     tx.executeSql(delete_list[m],[],function(tx,res){
                                         console.log(update_dowanload_types+"--------exec--------------------------------------------------------------"+exe_sum);
                                         if(exe_sum==(delete_list.length-1)){//成功
                                             if(update_dowanload_types=="("){
                                                 selectDB_yj_c_cons_userlist_2(app_no);
                                             }else{//更新下所有的下载标识
                                                 ydjc.transaction(function(tx){
                                                     var updat_dtl_dowanl_type_1="UPDATE YJ_C_CONS SET DOWNLOADING_TYPE=1 WHERE DTL_ID IN"+update_dowanload_types;
                                                     tx.executeSql(updat_dtl_dowanl_type_1,[],function(tx,res){
                                                         selectDB_yj_c_cons_userlist_2(app_no);
                                                     },function(e){
                                                         close_loading_view("批量更新下装标识失败"); 
                                                     });
                                                 });
                                             }
                                         }
                                         exe_sum++;
                                     },function(e){
                                         exe_sum_error++;
                                     });
                                 }
                             });
                        
                         },function(e){
                             close_loading_view("查询已下装用户信息失败");
                         });
                     });
                }
      /////////////////////////////////
    },null)

	function addArrayTOotherArray(a1,a2){
		for(var w=0;w<a2.length;w++){
			a1.push(a2[w]);
		}
	}
}

/***********************************************刷新---结束*********************************************************/
/**
 * 关闭效果
 */
function close_loading_view(msg){
	//弹出错误信息
	 $("#yxzypt_msg").html(msg);
	onchange_val();
	 $("#yxzypt_dailog").show();
	//操作失败关闭加载效果
	 $("#businessList_laoding_view").hide();
}
/**
 * 根据DTL_ID、CR_ID组装出所有的需要删除的数据。
 * @param dtl_id 工单id
 * @param cr_id  检查结果id
 * @param callback_suces  成功回调
 * @param callback_fail   错误回调
 */
function select_mobileDB_make_deleteSQL_DTLID(app_no,dtl_id,cr_id,cons_id,deletes_list){
    //所有的删除语句
    //var deletes_list=new Array();
    try{
        
        //1.整改表删除
            var YJ_S_IMPROVE="DELETE FROM YJ_S_IMPROVE WHERE ID2 IN(SELECT ID FROM YJ_S_SAFETY_BUG WHERE ID2="+cr_id+")";
                deletes_list.push(YJ_S_IMPROVE);
        //2.DTL_ID,CR_ID删除的表
        
            ////////////DTL_ID\\\\\\\\\\\\
            //核查用户供电合同表
            var YJ_CHECK_CONS_SUP_CONTR="DELETE FROM YJ_CHECK_CONS_SUP_CONTR WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_CHECK_CONS_SUP_CONTR);
            //避雷器档案
            var YJ_C_ARRESTER="DELETE FROM YJ_C_ARRESTER WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_ARRESTER);
                
            //断路器档案
            var YJ_C_BREAKER="DELETE FROM YJ_C_BREAKER WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_BREAKER);            
            //用户基础档案
            var YJ_C_CONS="DELETE FROM YJ_C_CONS WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_CONS);   
                
            //运行设备信息
            var YJ_C_EQUIP_RUN="DELETE FROM YJ_C_EQUIP_RUN WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_EQUIP_RUN);
            //电缆设备档案
            var YJ_C_JCDDL="DELETE FROM YJ_C_JCDDL WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_JCDDL);
                
            //进线电源
            var YJ_C_PS="DELETE FROM YJ_C_PS WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_PS);
            //继电保护装置档案
            var YJ_C_RELAY_PROTECT_DEV="DELETE FROM YJ_C_RELAY_PROTECT_DEV WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_RELAY_PROTECT_DEV);
                
            //无功补偿设备档案
            var YJ_C_RPC_EQUIP="DELETE FROM YJ_C_RPC_EQUIP WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_RPC_EQUIP);
            //用户受电点关系表
            var YJ_C_SP="DELETE FROM YJ_C_SP WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_SP);
                
            //自备发电机档案
            var YJ_C_SPARE_GENERATOR="DELETE FROM YJ_C_SPARE_GENERATOR WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_SPARE_GENERATOR);
            //自备电源档案
            var YJ_C_SPARE_POWER="DELETE FROM YJ_C_SPARE_POWER WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_C_SPARE_POWER);
                
            //修改记录
            var YJ_DATA_COMPARISON_DTL_ID="DELETE FROM YJ_DATA_COMPARISON_DTL_ID WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_DATA_COMPARISON_DTL_ID);
            //上装错误日志
            var YJ_DATA_COMPARISON_ERROR="DELETE FROM YJ_DATA_COMPARISON_ERROR WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_DATA_COMPARISON_ERROR);
                
            //变压器档案
            var YJ_G_TRAN="DELETE FROM YJ_G_TRAN WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_G_TRAN);
            //用户计量装置
            var YJ_MP_CONS="DELETE FROM YJ_MP_CONS WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_MP_CONS);
                
            //用户计量互感器装置
            var YJ_MP_IT="DELETE FROM YJ_MP_IT WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_MP_IT);
            //计量电表关系信息
            var YJ_MP_METER="DELETE FROM YJ_MP_METER WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_MP_METER);
                
            //用户计量互感器装置
            var YJ_PROBLEM_FEEDBACK="DELETE FROM YJ_PROBLEM_FEEDBACK WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_PROBLEM_FEEDBACK);
            //查询用户电费台账信息
            var YJ_RCVBL_FLOW="DELETE FROM YJ_RCVBL_FLOW WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_RCVBL_FLOW);
                
            //检查计划信息明细
            var YJ_S_CHK_PLAN_DET="DELETE FROM YJ_S_CHK_PLAN_DET WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_S_CHK_PLAN_DET);
            //非重要客户巡检记录
            var YJ_S_GWZYXJ_UN="DELETE FROM YJ_S_GWZYXJ_UN WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_S_GWZYXJ_UN);
             
            //检查结果信息
            var YJ_S_INSPECT_RSLT="DELETE FROM YJ_S_INSPECT_RSLT WHERE DTL_ID="+dtl_id;
                deletes_list.push(YJ_S_INSPECT_RSLT);
            
           ////////////CR_ID\\\\\\\\\\\\
           //重要客户巡检记录
           var YJ_S_GWZYXJ="DELETE FROM YJ_S_GWZYXJ WHERE CR_ID="+cr_id;
               deletes_list.push(YJ_S_GWZYXJ);
           //重要客户检查结果记录实体
           var YJ_S_HR_CHKRESULT="DELETE FROM YJ_S_HR_CHKRESULT WHERE CR_ID="+cr_id;
               deletes_list.push(YJ_S_HR_CHKRESULT);
               
           //重要客户档案信息
           var YJ_S_HR_IMPORTANT_CUST="DELETE FROM YJ_S_HR_IMPORTANT_CUST WHERE CR_ID="+cr_id;
               deletes_list.push(YJ_S_HR_IMPORTANT_CUST);
               
           //用电事故信息
           var YJ_S_POWER_ACCI="DELETE FROM YJ_S_POWER_ACCI WHERE CR_ID="+cr_id;
               deletes_list.push(YJ_S_POWER_ACCI);
           //预防性试验信息
           var YJ_S_PREVENTIVE_TEST="DELETE FROM YJ_S_PREVENTIVE_TEST WHERE CR_ID="+cr_id;
               deletes_list.push(YJ_S_PREVENTIVE_TEST);
           //安全隐患信息
           var YJ_S_SAFETY_BUG="DELETE FROM YJ_S_SAFETY_BUG WHERE ID2="+cr_id;
               deletes_list.push(YJ_S_SAFETY_BUG);
           ////////////APP_NO删除表\\\\\\\\\\\\
            //客户签收信息表删除
            var YJ_S_APP_REPLY="DELETE FROM YJ_S_APP_REPLY WHERE APP_NO='"+app_no+"'";
            deletes_list.push(YJ_S_APP_REPLY);
            ////////////YJ_NEWELECTRICIAN_INFO删除表\\\\\\\\\\\\
            var YJ_NEWELECTRICIAN_INFO="DELETE FROM YJ_NEWELECTRICIAN_INFO WHERE CONS_ID='"+cons_id+"'";
            deletes_list.push(YJ_NEWELECTRICIAN_INFO);
            
            return;
    }catch(e){
        close_loading_view("组装删除JS语法错误！");
        return;
    }
}
</script>