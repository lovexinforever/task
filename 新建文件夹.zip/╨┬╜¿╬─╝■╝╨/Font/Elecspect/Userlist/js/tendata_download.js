<script type="text/javascript">
var concel_downflag="";

var download_num=0;//已下载的个数

var all_download_num=new Array();//全部下载的个数

var cons_noarr = new Array();//页面点击 √ 时，获取到的数据下载的相关参数

var download_tendata = new Array();//点击√时保存session

var ten_flag = 0; // 初始化10标志

var savearrdata = "savearrdata"+sessionStorage.APP_NO_bl;//唯一标记
if(sessionStorage[savearrdata]){
    cons_noarr = sessionStorage[savearrdata].split(",");
}
// function creat_cons_noarr(id,name){//下载方法所需要的参数格式。
    // this.id = id;
    // this.name = name;
// }
//点击√触发的方法
function changeTo_tendatadownload(id,name){
    var src =  $("#"+id).attr("src");
    
    if(src == "../../Util/Images/checkboxon.png"){//当前图片为已勾选，点击取消选中
	    
        $("#"+id).attr("src","../../Util/Images/checkboxoff.png");
        sessionStorage[name.split("_")[1]] = "";
        download_tendata.splice(download_tendata.indexOf(name.split("_")[1]),1);
        cons_noarr.splice(cons_noarr.indexOf(id+"/"+name),1);
        sessionStorage[savearrdata] = cons_noarr;//将数据保存到session中
        
    }else if(src == "../../Util/Images/checkboxoff.png"){//当前图片为没有勾选，点击选中
    	
	    if(download_tendata.length>=10){
	    	
		     $("#yxzypt_msg").html("选中需下载用户不能超过10条");
		     onchange_val();
		     $("#yxzypt_dailog").show();
		      return;
	    }
    	
        $("#"+id).attr("src","../../Util/Images/checkboxon.png");
        sessionStorage[name.split("_")[1]] = "checked";//标记当前cons_no被点击选中
        download_tendata[download_tendata.length] = sessionStorage[name.split("_")[1]];//标记已选中打√的cons_no
        cons_noarr[cons_noarr.length] = id+"/"+name;
        sessionStorage[savearrdata] = cons_noarr;//将数据保存到session中
    }
}


//点击下载用户数据包
function dowanload_tendata_userlist_id(){
    if(!cons_noarr.length){//没有选中的用户
         $("#yxzypt_msg").html("请选择需要下载的用户");
         onchange_val();
         $("#yxzypt_dailog").show();
         return;
    }
    all_download_num.length = download_tendata.length;
    download_num=0;
    concel_downflag="";//取消的标志置空
    $("#businessList_download_view").show();
    $("#all_download_num").html(all_download_num.length);//赋值全部下载的个数
    $("#have_download_num").html(download_num);//赋值正在下载的
    dowanload_tendataxx();
}

function dowanload_tendataxx(){
        var cons_idtemp = cons_noarr[0].split("/")[0];
        var dtl_idtemp = cons_noarr[0].split("/")[1];
        download_num+=1;//已下载的个数+1
        $("#have_download_num").html(download_num);//赋值已下载的个数
        //改变图标下载状态
        $("#ydjcimg_"+cons_idtemp.split("_")[1]).attr("src","../../Util/Images/dowanload_ing.gif");
        download_userlist_data_one(cons_idtemp.split("_")[1],dtl_idtemp.split("_")[1],dtl_idtemp.split("_")[3],dtl_idtemp.split("_")[4],dtl_idtemp.split("_")[5],sessionStorage.user_name,sessionStorage.APP_NO_bl,dtl_idtemp.split("_")[2],tendata_view);
}

function tendata_view(msg){
       if(msg==1){
            $("#ydjcimg_"+cons_noarr[0].split("/")[0].split("_")[1]).attr("src","../../Util/Images/downloadover.png");
            if(concel_downflag=="concel"){//取消全部下载
                 selectDB_yj_c_cons_userlist_2(sessionStorage.APP_NO_bl);//初始化页面
                 $("#businessList_laoding_view").hide();//关闭加载效果
                return;
             }
             if(cons_noarr.length>1){
                cons_noarr.splice(0,1);
                dowanload_tendataxx();
            }else if(cons_noarr.length==1){
                 selectDB_yj_c_cons_userlist_2(sessionStorage.APP_NO_bl);//初始化页面
                 $("#businessList_download_view").hide();
            }
        }else{
             $("#ydjcimg_"+cons_noarr[0].split("/")[0].split("_")[1]).attr("src","../../Util/Images/download3.png");
             if(concel_downflag=="concel"){//取消全部下载
                 selectDB_yj_c_cons_userlist_2(sessionStorage.APP_NO_bl);//初始化页面
                 $("#businessList_laoding_view").hide();//关闭加载效果
                return;
             }
             $("#yxzypt_msg").html(msg);
             onchange_val();
             $("#yxzypt_dailog").show();
             $("#businessList_download_view").hide();
        }
}

 /*****************************全部下载时取消下载*******************************/
 $("#concel_downid").click(function(){
     cancel_download_all_data(cons_noarr[0].split("/")[0].split("_")[1]);
 });
function cancel_download_all_data(app_id){
    concel_downflag="concel";
    $("#businessList_download_view").hide();
    $("#businessList_laoding_view").show();//开启加载效果
    $("#ydjcblone_"+app_id).attr("src","../../Util/Images/dowanload_ing.gif");
}
</script>