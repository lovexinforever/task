
/**
 * 
 * @param server_msg 服务器返回的数据
 * @param yj_msg 业务自己组装的数据；格式如：{"DTL_ID":,"CONS_ID":,"MSG":"上装核查能效服务数据失败:",。。。。}前2个是必填项
 * 
 */
function yj_upload_proc(server_msg,yj_msg){
	//转化为JSON对象
	yj_msg = JSON.parse(yj_msg)
	server_msg=JSON.parse(server_msg);
	var yjpkg_msg=yj_msg.PKG;
	var pkg=server_msg.PKG.PKG;
    if(server_msg.RET=="00" && pkg.SUCCESS_FLAG==0){//上装成功
		var fun=server_msg.FUN;
		//自备电厂设备档案新增
		if(fun=="2201"){
			var sql1 = "update YJ_C_EQUIP_RUN set equip_id=?,UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			var sql2 = "update YJ_C_SPARE_POWER set equip_id=?,SPARE_PS_ID=?,UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,[pkg.equip_id,"1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			//注意 此处接口字段名字有问题  pkg.GEN_ID 应为pkg.SPARE_PS_ID
			db_execut_oneSQL(null, sql2,[pkg.equip_id,pkg.spare_ps_id,"1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//自备电厂设备档案修改
		else if(fun=="2202"){
			var sql1 = "update YJ_C_EQUIP_RUN set UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			var sql2 = "update YJ_C_SPARE_POWER set UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//自备电厂设备档案删除
		else if(fun=="2203"){
			var sql1 = "delete from YJ_C_EQUIP_RUN  where MOBILE_EQUIP_ID=?";
			var sql2 = "delete from YJ_C_SPARE_POWER where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,[yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,[yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//续电器保护装置设备档案新增
        else if(fun=="2204"){
        	var sql1 = "update YJ_C_EQUIP_RUN set equip_id=?,UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			var sql2 = "update YJ_C_RELAY_PROTECT_DEV set equip_id=?,RELAY_DEV_ID=?,UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,[pkg.equip_id,"1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,[pkg.equip_id,pkg.relay_dev_id,"1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//续电器保护装置设备档案修改
        else if(fun=="2205"){
        	var sql1 = "update YJ_C_EQUIP_RUN set UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			var sql2 = "update YJ_C_RELAY_PROTECT_DEV set UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//续电器保护装置设备档案删除
        else if(fun=="2206"){
        	var sql1 = "delete from  YJ_C_EQUIP_RUN  where MOBILE_EQUIP_ID=?";
			var sql2 = "delete from  YJ_C_RELAY_PROTECT_DEV  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,[yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,[yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//避雷器设备档案增加
        else if(fun=="2207"){
        	var sql1 = "update YJ_C_EQUIP_RUN set equip_id=?,UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			var sql2 = "update YJ_C_ARRESTER set equip_id=?,ARRESTER_ID=?,UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,[pkg.equip_id,"1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,[pkg.equip_id,pkg.arrester_id,"1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//避雷器设备档案修改
        else if(fun=="2208"){
        	var sql1 = "update YJ_C_EQUIP_RUN set UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			var sql2 = "update YJ_C_ARRESTER set UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//避雷器设备档案删除
        else if(fun=="2209"){
        	var sql1 = "delete from YJ_C_EQUIP_RUN  where MOBILE_EQUIP_ID=?";
			var sql2 = "delete from YJ_C_ARRESTER  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,[yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,[yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//新增自备应急电源设备档案
        else if(fun=="2210"){
        	var sql1 = "update YJ_C_EQUIP_RUN set equip_id=?,UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			var sql2 = "update YJ_C_SPARE_GENERATOR set equip_id=?,GEN_ID=?,UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,[pkg.equip_id,"1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			//注意 此处借口字段名字有问题   pkg.SPARE_PS_ID应为pkg.GEN_ID
			db_execut_oneSQL(null, sql2,[pkg.equip_id,pkg.gen_id,"1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//修改自备应急电源设备档案
        else if(fun=="2211"){
        	var sql1 = "update YJ_C_EQUIP_RUN set UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			var sql2 = "update YJ_C_SPARE_GENERATOR set UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//删除自备应急电源设备档案
        else if(fun=="2212"){
        	var sql1 = "delete from  YJ_C_EQUIP_RUN  where MOBILE_EQUIP_ID=?";
			var sql2 = "delete from YJ_C_SPARE_GENERATOR  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,[yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,[yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//新增电缆设备档案
        else if(fun=="2213"){
        	var sql1 = "update YJ_C_EQUIP_RUN set equip_id=?,UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			var sql2 = "update YJ_C_JCDDL set equip_id=?,DL_ID=?,UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,[pkg.equip_id,"1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,[pkg.equip_id,pkg.dl_id,"1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//修改电缆设备档案
        else if(fun=="2214"){
        	var sql1 = "update YJ_C_EQUIP_RUN set UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			var sql2 = "update YJ_C_JCDDL set UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//删除电缆设备档案
        else if(fun=="2215"){
        	var sql1 = "delete from YJ_C_EQUIP_RUN where MOBILE_EQUIP_ID=?";
			var sql2 = "delete from YJ_C_JCDDL where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,[yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,[yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//新增无功补偿设备档案
        else if(fun=="2216"){
        	var sql1 = "update YJ_C_EQUIP_RUN set equip_id=?,UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			var sql2 = "update YJ_C_RPC_EQUIP set equip_id=?,RP_ID=?,UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,[pkg.equip_id,"1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,[pkg.equip_id,pkg.rp_id,"1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//修改无功补偿设备档案
        else if(fun=="2217"){
        	var sql1 = "update YJ_C_EQUIP_RUN set UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			var sql2 = "update YJ_C_RPC_EQUIP set UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//删除无功补偿设备档案
        else if(fun=="2218"){
        	var sql1 = "delete from YJ_C_EQUIP_RUN where MOBILE_EQUIP_ID=?";
			var sql2 = "delete from  YJ_C_RPC_EQUIP  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,[yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,[yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//新增断路器设备档案
        else if(fun=="2219"){
        	var sql1 = "update YJ_C_EQUIP_RUN set equip_id=?,UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			var sql2 = "update YJ_C_BREAKER set equip_id=?,DISJUNCTOR_ID=?,UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,[pkg.equip_id,"1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,[pkg.equip_id,pkg.disjunctor_id,"1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//修改断路器设备档案
        else if(fun=="2220"){
        	var sql1 = "update YJ_C_EQUIP_RUN set UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			var sql2 = "update YJ_C_BREAKER set UPLOADING_TYPE=?,UPLOADING_DATE=?  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//删除断路器设备档案
        else if(fun=="2221"){
        	var sql1 = "delete from  YJ_C_EQUIP_RUN where MOBILE_EQUIP_ID=?";
			var sql2 = "delete from YJ_C_BREAKER  where MOBILE_EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,[yj_msg.ID],exec_sucess_yj,exec_fail_yj);
			db_execut_oneSQL(null, sql2,[yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		}
		//变压器档案修改
        else if(fun=="2222"){
        	var sql1 = "update yj_g_tran set UPLOADING_TYPE=?,UPLOADING_DATE=?  where EQUIP_ID=?";
			db_execut_oneSQL(null, sql1,["1",new Date(),yj_msg.ID],exec_sucess_yj,exec_fail_yj);
		
		}
		//检查结果维护变更
        else if(fun=="2301"){
        	localStorage["uploading"+yjpkg_msg.APP_NO+yj_msg.DTL_ID] = 1;//用户列表 图标状态（处理中 处理完成）
        	db_execut_oneSQL(null,"update yj_c_cons set uploading_type=? where DTL_ID=? and CONS_ID=?",["2",yj_msg.DTL_ID,yj_msg.CONS_ID],null,null);
        	db_execut_oneSQL(null,"update YJ_S_CHK_PLAN_DET set PLAN_STATUS_CODE=? where DTL_ID=? and CONS_ID=?",["08",yj_msg.DTL_ID,yj_msg.CONS_ID],null,null);
        }
		//重要客户巡检记录信息新增
        else if(fun=="2302"){
          db_execut_oneSQL(null,"update YJ_S_GWZYXJ set ID=?,UPLOADING_TYPE=?,UPLOADING_DATE=? where CR_ID=?",[pkg.id,2,new Date(),yj_msg.CR_ID],exec_sucess_yj,exec_fail_yj);
		}
		//重要客户巡检记录信息修改
        else if(fun=="2303"){
    	 db_execut_oneSQL(null,"update YJ_S_GWZYXJ set UPLOADING_DATE=? where CR_ID=?",[new Date(),yj_msg.CR_ID],exec_sucess_yj,exec_fail_yj);
		}
		//重要客户巡检检查结果信息新增
        else if(fun=="2304"){
    	db_execut_oneSQL(null,"update YJ_S_HR_CHKRESULT set ID=?,UPLOADING_TYPE=?,UPLOADING_DATE=? where CR_ID=?",[pkg.id,2,new Date(),yj_msg.CR_ID],exec_sucess_yj,exec_fail_yj);
		}
		//重要客户巡检检查结果信息修改
        else if(fun=="2305"){
    	 db_execut_oneSQL(null,"update YJ_S_HR_CHKRESULT set UPLOADING_DATE=? where CR_ID=?",[new Date(),yj_msg.CR_ID],exec_sucess_yj,exec_fail_yj);
		}else if(fun=="2904"){ //用户签收
			db_execut_oneSQL(null,"update YJ_S_APP_REPLY set AR_ID=? where AR_ID=?",[pkg.ID,yj_msg.ERROR_ID],exec_sucess_yj,exec_fail_yj);
		}
		//重要用户档案管理修改
        else if(fun=="2103"){
	    	 db_execut_oneSQL(null,"update YJ_S_HR_IMPORTANT_CUST set UPLOADING_DATE=? where CR_ID=?",[new Date(),cons_info.cr_id],null,null);
        }
		//重要用户档案管理新增
        else if(fun=="2102"){
	    	db_execut_oneSQL(null,"update YJ_S_HR_IMPORTANT_CUST set UPLOADING_TYPE=?,UPLOADING_DATE=? where CR_ID=?",[2,new Date(),cons_info.cr_id],null,null);
        }
		//用电事故记录--修改
        else if(fun=="2902"){
	    	 db_execut_oneSQL(null,"update YJ_S_POWER_ACCI set UPLOADING_DATE=? where CR_ID=? AND ID=?",[new Date(),cons_info.cr_id,sessionStorage.id],null,null);
        }
		//用电事故记录--删除
        else if(fun=="2903"){
	         //重要客户巡检记录信息删除
             var sql="delete from YJ_S_POWER_ACCI where CR_ID=? and ID=?";
             db_execut_oneSQL(null,sql,[sessionStorage.cr_id,sessionStorage.id],null,null);
        }else if(fun=="2904"){
        	 //用户签收新增
        //	alert("yj_msg.ERROR_ID="+yj_msg.ERROR_ID+"id="+pkg.ID)
        	var sql = "update YJ_S_APP_REPLY set AR_ID=? where AR_ID=?";
		
            db_execut_oneSQL(null,sql,[pkg.ID,yj_msg.ERROR_ID],null,null);
        	
        }
		//用电事故记录--新增
        else if(fun=="2901"){
	    	 db_execut_oneSQL(null,"update YJ_S_POWER_ACCI set ID=?,UPLOADING_DATE=? where CR_ID=? and ID=(SELECT MAX(ID) FROM YJ_S_POWER_ACCI)",[pkg.ID,new Date(),cons_info.cr_id],null,null);
        }
		
		//安全隐患信息--修改
        else if(fun=="2907"){
	    	 db_execut_oneSQL(null,"update YJ_S_SAFETY_BUG set UPLOADING_DATE=? where MOBILE_BUG_ID=?",[new Date(),sessionStorage.aqyh01_ID_VALUE],null,null);
        }
		//安全隐患信息--删除
        else if(fun=="2908"){
             //重要客户巡检检查结果信息删除
             db_execut_oneSQL(null,"DELETE FROM YJ_S_SAFETY_BUG WHERE MOBILE_BUG_ID=?",[sessionStorage.aqyh01_ID_VALUE],null,null);
        }
		//安全隐患信息--新增
        else if(fun=="2906"){
	    	 db_execut_oneSQL(null,"update YJ_S_SAFETY_BUG set ID=?,UPLOADING_DATE=? where MOBILE_BUG_ID=? and ID2=?",[pkg.ID,new Date(),insertId_id,cons_info.cr_id],null,null);
        }

	}else{//上装错误
		//alert(yj_msg.EQUIP_NAME);
		var devices_add_fun = [2201,2204,2207,2210,2213,2216,2219];//设备的添加fun
		var devices_change_fun = [2202,2205,2208,2211,2214,2217,2220];//设备的修改fun
		var devices_delete_fun = [2203,2206,2209,2212,2215,2218,2221];//设备的修改fun
		var devices_byq =2222; //高压设备
		var fun = Number(yjpkg_msg.FUN);
	
		if((devices_add_fun.indexOf(fun)!=-1)||(devices_change_fun.indexOf(fun)!=-1)||(devices_delete_fun.indexOf(fun)!=-1)||fun==devices_byq){ //7种设备+高压变压器
			  
				if(devices_delete_fun.indexOf(fun)!=-1){ //如果是删除
				    db_execut_oneSQL(null,"select * from YJ_DATA_COMPARISON_ERROR where ERROR_ID=? and DTL_ID=? and FUN=?",[yj_msg.ID,yj_msg.DTL_ID,fun],function(tx,res){
				        if(res.rows.length!=0){
				             db_execut_oneSQL(null,"update YJ_DATA_COMPARISON_ERROR set PKG=? AND EQUIP_NAME=? AND TYPE_CODE=? where ERROR_ID=?",[yj_msg.PKG,yj_msg.EQUIP_NAME,yj_msg.TYPE_CODE,yj_msg.ID],exec_sucess_yj,exec_fail_yj);
				        }else if(res.rows.length==0){
				             db_execut_oneSQL(null,"INSERT INTO YJ_DATA_COMPARISON_ERROR(ERROR_ID,PKG,FUN,DTL_ID,CONS_ID,ERROR_MSG,EQUIP_NAME,TYPE_CODE)VALUES(?,?,?,?,?,?,?,?)",[yj_msg.ID,yj_msg.PKG,yjpkg_msg.FUN,yj_msg.DTL_ID,yj_msg.CONS_ID,yj_msg.MSG,yj_msg.EQUIP_NAME,yj_msg.TYPE_CODE],exec_sucess_yj,exec_fail_yj);
				        }
				    },null);
				}else{
				    db_execut_oneSQL(null,"select * from YJ_DATA_COMPARISON_ERROR where ERROR_ID=? and DTL_ID=? and FUN=?",[yj_msg.ID,yj_msg.DTL_ID,fun],function(tx,res){
				        if(res.rows.length!=0){
				             db_execut_oneSQL(null,"update YJ_DATA_COMPARISON_ERROR set PKG=? where ERROR_ID=?",[yj_msg.PKG,yj_msg.ID],exec_sucess_yj,exec_fail_yj);
				        }else if(res.rows.length==0){
				             db_execut_oneSQL(null,"INSERT INTO YJ_DATA_COMPARISON_ERROR(ERROR_ID,PKG,FUN,DTL_ID,CONS_ID,ERROR_MSG)VALUES(?,?,?,?,?,?)",[yj_msg.ID,yj_msg.PKG,yjpkg_msg.FUN,yj_msg.DTL_ID,yj_msg.CONS_ID,yj_msg.MSG],exec_sucess_yj,exec_fail_yj);
				        }
				    },null);
				}
			
			

		}else{//其他项 检查项
			//上装错误
                    db_execut_oneSQL(null,"select * from YJ_DATA_COMPARISON_ERROR where ERROR_ID=? and DTL_ID=?",[yj_msg.ERROR_ID,yj_msg.DTL_ID],function(tx,res){
                        if(res.rows.length!=0){
                             db_execut_oneSQL(null,"update YJ_DATA_COMPARISON_ERROR set PKG=? where ERROR_ID=? and DTL_ID=? and FUN=?",[yj_msg.PKG,yj_msg.ERROR_ID,yj_msg.DTL_ID,yjpkg_msg.FUN],exec_sucess_yj,exec_fail_yj);
                        }else if(res.rows.length==0){
                             db_execut_oneSQL(null,"INSERT INTO YJ_DATA_COMPARISON_ERROR(ERROR_ID,PKG,FUN,DTL_ID,CONS_ID,ERROR_MSG)VALUES(?,?,?,?,?,?)",[yj_msg.ERROR_ID,yj_msg.PKG,yjpkg_msg.FUN,yj_msg.DTL_ID,yj_msg.CONS_ID,yj_msg.MSG],exec_sucess_yj,exec_fail_yj);
                        }
                    },null);

		}
		
    }
        //操作数据库成功
        function exec_sucess_yj(tx,res){
        	
        }
        //操作数据库失败
        function exec_fail_yj(e){
            
        } 
}