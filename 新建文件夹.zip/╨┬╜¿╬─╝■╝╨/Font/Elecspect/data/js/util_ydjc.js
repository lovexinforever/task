
/**
 * 把xx.txt转成jsonArray数组
 * @param str
 * @returns {Array}
 */
function get_json(str){
	   var jsonAraay=new Array();
	   if(str=="" || str==null || str=="null"){
			
		}else{
			//获得所有的记录
			var datas=str.split("\n");
			
			var columns=datas[0].split("|");
			
			for(var i=1;i<datas.length;i++){
				var values=datas[i].split("|");
				var json={};
				for(var j=0;j<values.length;j++){
					json[columns[j]]=values[j];
				}
				//alert(JSON.stringify(json));
				jsonAraay[i]=json;
			}
		}
		//alert(JSON.stringify(jsonAraay));
		return jsonAraay;
}














