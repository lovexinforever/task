
/**
 * 平台上装图片成功后的回调，用于插入数据库
 * 根据平台，此方法回掉成功后表示图片上装成功后，更新数据库
 * 
 */
function image_upload_callbacke(image_msg){
	//转化为JSON对象,app_no/dtl_id/cr_id为页面中获得的数据,其中图片名字包含YJ_C_PHOTOESINFO表中fun_item和check_item信息

	if(image_msg!=null){
		var imagename = image_msg.PKG.FILE_NAME.split(".")[0].split("_");
		var  sql2_call = "update YJ_C_PHOTOESINFO set DOWNLOAD_TYPE=?  where app_no=? and dtl_id=? and cr_id=? and fun_item=? and check_item=?";
		 var  value2_call = ["1",sessionStorage.APP_NO_bl,cons_info.dtl_id,cons_info.cr_id,imagename[0],imagename[1]];
			db_execut_oneSQL(null,sql2_call,value2_call,function(tx,res){
				
			},function(e){
				
			})
	}
	
}