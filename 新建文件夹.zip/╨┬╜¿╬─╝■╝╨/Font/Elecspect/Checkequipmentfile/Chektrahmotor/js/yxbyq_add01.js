<script type="text/javascript">
/**
  *高压变压器对象
  */



function insertto(sql,success){
	


}





</script>

