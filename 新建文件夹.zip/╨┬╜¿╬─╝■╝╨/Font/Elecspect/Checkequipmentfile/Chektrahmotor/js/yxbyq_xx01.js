<script type="text/javascript">
/**
  *高压变压器对象
  */

function getdevices(dtl_id,sun){
	var sql = "select j.org_name,e.equip_id,e.tg_id,e.tg_no,e.org_no,e.cons_id,e.type_code,e.chg_remark,e.tran_name,e.inst_addr,e.inst_date,e.plate_cap,e.frst_run_date," +
	"e.actual_start_date,e.actual_stop_use_date,e.plan_resume_date,e.ms_flag,e.run_status_code,e.pub_priv_flag,e.chg_cap,e.due_date,e.protect_mode," +
	"e.ground_flag,e.frstside_volt_code,e.sndside_volt_code,e.model_no,e.k_value,e.factory_name,e.made_no,e.made_date,e.wire_group_code,e.cool_mode," +
	"e.rv_hv,e.rc_hv,e.rv_mv,e.rc_mv,e.rv_lv,e.rc_lv,e.sc_resi,e.k_current,e.test_date,e.test_cycle,e.pr_code,e.main_wiring_mode,e.oil_no,e.subjoint_grade," +
	"e.subjoint_loc,e.ground_resi,e.rp_tl_value,e.ap_tl_value,e.ts_no,e.ts_alg_flag,e.kzdl,e.kzsh,e.dlsh,e.zkyj " +
	"from yj_g_tran e left join o_org j on j.org_no=e.org_no where e.dtl_id="+dtl_id+";"
	
	db_execut_oneSQL(null,sql,[],sun,null);

}





</script>

