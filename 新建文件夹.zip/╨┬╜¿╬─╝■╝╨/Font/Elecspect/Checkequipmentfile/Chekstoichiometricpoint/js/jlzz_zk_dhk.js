<script type="text/javascript">

function goto_jzllxx_html(){
	
	$("#goto_jlzz_zk_html").trigger("click");	//跳转到计量详细页面
	
}

//document.addEventListener("deviceready",show_jlzz_zk_data, false);	//预加载show_jlzz_zk_data方法
//
//var jlzk_=new Array($("#jlzk_01"),$("#jlzk_02"),$("#jlzk_03"));		//将tr的id定义为数组
//
//var jl_jw_addr=new Array($("#jl_jw_addr01"),$("#jl_jw_addr02"),$("#jl_jw_addr03"));		//将显示经纬度地址的标签的id定义为数组
//
//function show_jlzz_zk_data(){
//	
//	var yj_mp_cons_jlzz_zk=new Yj_mp_cons_jlzz_zk(cons_info.dtl_id,cons_info.cons_id,null,null,null,null,null,null,null,null,null,null);//用户计量装置js对象
//	
//	var callbk_show=function(jsarray){	//定义callbk_show回调函数
//		
//		if(jsarray==0){
//			 //没有数据
//
//			//	alert(e+"--no_data");
//		}else{
//			//查询到数据，给界面元素赋值
////			yj_mp_cons_jlzz_zk=jsarray[0];
////			alert(JSON.stringify(yj_mp_cons_jlzz_zk));
//			for(i=0;i<jsarray.length;i++){
//				
//				jlzk_[i].remove();//清除tr标签里面所有的元素
//				
//				var rs="<td width='55%'>计量点："+jsarray[i].mp_name+"<br /> 电表数量："+jsarray[i].meter_num+" <br />计量点地址："+jsarray[i].mp_addr+"</td><td width='45%'>计量点级数："+jsarray[i].mp_level+"<br />互感器数量："+jsarray[i].it_num+" <br /></td>"
//				
//				jlzk_[i].append("adgcjg");//向tr添加内容rs；
//				
//				jl_jw_addr[i].html("经纬度地址："+jsarray[i].gps);//给经纬度地址赋值
//	
//			}
//	
//		}
//	
//	}
//	
//	select_db(yj_mp_cons_jlzz_zk,callbk_show);//查询数据库
//}


</script>