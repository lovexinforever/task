/**
 * 用户计量装置检查
 * @param dtl_id=用电检查工单ID
 * @param cons_id=用户ID
 * @param mp_id=计量点ID
 * @param mp_name=计量点名称
 * @param mp_addr=计量点地址
 * @param meter_num=电表数量
 * @param it_num=互感器数量
 * @param mp_level=计量点级数
 * @param ps_id=进线电源ID
 * @param gps=GPS地址
 * @param uploading_type=上传状态
 * @param uploading_date=上传时间
 * @return
 */
function Yj_mp_cons_jlzz_zk(dtl_id,cons_id,mp_id,mp_name,mp_addr,meter_num,it_num,mp_level,ps_id,gps,uploading_type,uploading_date){
	this.tablename="YJ_MP_CONS";
	this.dtl_id=dtl_id;
	this.cons_id=cons_id;
	this.mp_id=mp_id;
	this.mp_name=mp_name;
	this.mp_addr=mp_addr;
	this.meter_num=meter_num;
	this.it_num=it_num;
	this.mp_level=mp_level;
	this.ps_id=ps_id;
	this.gps=gps;
	this.uploading_type=uploading_type;
	this.uploading_date=uploading_date;
}
/**
 * 计量电表关系信息
 * @param dtl_id=用电检查工单ID
 * @param meter_id=电表ID
 * @param asset_no=电表资产编号
 * @param manufacturer=生产厂商
 * @param made_date=出厂日期
 * @param mp_id=计量点ID
 * @return
 */
function Yj_mp_meter(dtl_id,meter_id,asset_no,manufacturer,made_date,mp_id){
	this.tablename="YJ_MP_METER";
	this.dtl_id=dtl_id;
	this.meter_id=meter_id;
	this.asset_no=asset_no;
	this.manufacturer=manufacturer;
	this.made_date=made_date;
	this.mp_id=mp_id;
}

/**
 * 用户计量互感器装置
 * @param dtl_id=用电检查工单ID
 * @param mp_id=计量点ID
 * @param it_id=互感器标识
 * @param asset_no=互感器资产编号
 * @param sort_code=类别
 * @param rc_ratio_code=电流变比
 * @param ta_pre_code=TA准确度等级
 * @param volt_ratio_code=电压变比
 * @param tv_pre_code=TV准确度等级
 * @param phase_code=相别
 * @param model_code=型号
 * @param bar_code=条形码
 * @return
 */
function Yj_mp_it(dtl_id,mp_id,it_id,asset_no,sort_code,rc_ratio_code,ta_pre_code,volt_ratio_code,tv_pre_code,phase_code,model_code,bar_code){
	this.tablename="YJ_MP_IT";
	this.dtl_id=dtl_id;
	this.mp_id=mp_id;
	this.it_id=it_id;
	this.asset_no=asset_no;
	this.sort_code=sort_code;
	this.rc_ratio_code=rc_ratio_code;
	this.ta_pre_code=ta_pre_code;
	this.volt_ratio_code=volt_ratio_code;
	this.tv_pre_code=tv_pre_code;
	this.phase_code=phase_code;
	this.model_code=model_code;
	this.bar_code=bar_code;
}




