// JavaScript Document
function check_box_change(obj)
{
	var radio1 = document.getElementById("radio1");
	var radio2 = document.getElementById("radio2");
	if(obj==1){
		if(radio1.src!="../../../../../Util/Images/radioboxon.png")
		{
			
			radio1.src = "../../../../../Util/Images/radioboxon.png";
			radio2.src = "../../../../../Util/Images/radioboxoff.png";
		}
	}
	else if(obj==2){
		
		if(radio2.src!="../../../../../Util/Images/radioboxon.png")
		{
			
			radio2.src = "../../../../../Util/Images/radioboxon.png";
			radio1.src = "../../../../../Util/Images/radioboxoff.png";
		}
	}
}

function check_box_change2(obj)
{
	var radio3 = document.getElementById("radio3");
	var radio4 = document.getElementById("radio4");
	if(obj==1){
		if(radio3.src!="../../../../../Util/Images/radioboxon.png")
		{
			
			radio3.src = "../../../../../Util/Images/radioboxon.png";
			radio4.src = "../../../../../Util/Images/radioboxoff.png";
		}
	}
	else if(obj==2){
		
		if(radio4.src!="../../../../../Util/Images/radioboxon.png")
		{
			
			radio4.src = "../../../../../Util/Images/radioboxon.png";
			radio3.src = "../../../../../Util/Images/radioboxoff.png";
		}
	}
}