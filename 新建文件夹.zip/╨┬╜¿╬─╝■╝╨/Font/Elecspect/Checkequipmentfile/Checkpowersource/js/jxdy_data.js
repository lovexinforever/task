<script type="text/javascript">
//进线电源第一个页面
function jxdy_data_start(id){
	var sql=" select ps_photo_com as ps_photo_com,ps_chg as ps_chg,cons_id as cons_id,dtl_id as dtl_id,ps_no as ps_no, ps_id as ps_id, phase_code as phase_code,ps_volt as ps_volt ,line_name as line_name,tg_no as tg_no,tg_name as tg_name from yj_c_ps where DTL_ID=?";
	db_execut_oneSQL(null,sql,[id],jxdy_first_success,jxdy_first_fail);
	function jxdy_first_success(tx,res){
		var data=res.rows;
		sendfont_yj_c_ps(data);
	}
	function jxdy_first_fail(){}
}
function select_mpname(line_name,ps_id,dtl_id){
	//var sql="select cns.mp_name as mp_name from yj_mp_cons cns ,yj_c_ps ps where cns.line_name =ps.line_name and ps.line_name=?";
	var sql=" select *,cns.mp_name as mp_name "+
				"  from yj_mp_cons cns ,yj_c_ps ps "+
				"  where cns.dtl_id = ps.dtl_id  "+  
				"  and cns.line_name=? "+
				"  and ps.ps_id = ?  "+
				"  and cns.dtl_id  = ? " ;
	db_execut_oneSQL(null,sql,[line_name,ps_id,dtl_id],jxdy_name_success,jxdy_name_fail);
	function jxdy_name_success(tx,res){
		var data=res.rows;
		sendfont_name(data);
	}
	function jxdy_name_fail(){}
}
//保存进线电源是否有变更
function saveinfo_toyjcps(arr){
	var sql="update yj_c_ps set ps_chg=?,ps_photo_com=?,remark=? where dtl_id=?";
	db_execut_oneSQL(null,sql,arr,jxdy_save_success,jxdy_save_fail);
	function jxdy_save_fail(){}
}
//进线电源编号页面
function jxdy_num_start(id){
	var sql="select ps_id as ps_id,dtl_id as dtl_id,ps_no as ps_no,subs_name as subs_name,line_name as line_name,tg_name as tg_name,type_code as type_code,"+
  "phase_code as phase_code,ps_volt as ps_volt,ps_cap as ps_cap,ps_attr as ps_attr,linein_mode as linein_mode,"+
  "linein_pole_no as linein_pole_no,lv_box_no as lv_box_no,pr_point as pr_point,protect_mode as protect_mode,run_mode as run_mode,"+
 "relay_protect_mode as relay_protect_mode,remark as remark from yj_c_ps  where dtl_id=? ";
	db_execut_oneSQL(null,sql,[id],jxdy_num_success,jxdy_num_fail);
	function jxdy_num_success(tx,res){
		var data=res.rows;
		sendfont_yj_c_ps_num(data);
	}
	function jxdy_num_fail(){}
}
//修改页面
function jxdy_modify_start(id){
	var sql="select ps_no as ps_no,subs_name as subs_name,line_name as line_name,tg_name as tg_name,type_code as type_code,"+
  "phase_code as phase_code,ps_volt as ps_volt,ps_cap as ps_cap,ps_attr as ps_attr,linein_mode as linein_mode,"+
  "linein_pole_no as linein_pole_no,lv_box_no as lv_box_no,pr_point as pr_point,protect_mode as protect_mode,run_mode as run_mode,"+
  "relay_protect_mode as relay_protect_mode,remark as remark from yj_c_ps where ps_id=?";
	db_execut_oneSQL(null,sql,[id],jxdy_num_success,jxdy_num_fail);
	function jxdy_num_success(tx,res){
		var data=res.rows;
		sendfont_yj_c_ps_modify(data);
	}
	function jxdy_num_fail(){}
}
function jxdy_ps_save(id){
	var sql="update yj_c_ps set ps_no=?,subs_name=?,line_name=?,tg_name=?,type_code=?,phase_code=?,ps_volt=?,ps_cap=?,ps_attr=?,linein_mode=?,linein_pole_no=?,lv_box_no=?,pr_point=?,protect_mode=?,run_mode=?,relay_protect_mode=?,remark=? where ps_id=?";
	db_execut_oneSQL(null,sql,id,jxdy_change_success,null);
	
}
</script>