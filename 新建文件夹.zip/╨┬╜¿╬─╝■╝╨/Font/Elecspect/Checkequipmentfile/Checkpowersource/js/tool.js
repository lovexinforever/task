// JavaScript Document
//弹出框
document.write('<div class="Pop-up-layer Pop-up-layer2">');
document.write('<div class="round3">');
document.write('<div class="round rr">');
document.write('<table width="100%" height="100%">');
document.write('<tr align="center" valign="middle"> ');
document.write('<td width="33%"><a href="#"><img src="../../../../Util/Images/pz.png" /></a></td>');
document.write('<td width="33%"><a href="#"><img src="../../../../Util/Images/ly.png" /></a></td>');
document.write('<td width="33%"><a href="#"><img src="../../../../Util/Images/sm.png" /></a></td>');
document.write('</tr>');
document.write('<tr align="center" valign="middle">');
document.write('<td width="33%"><a href="#"><img src="../../../../Util/Images/cz.png" /></a></td>');
document.write('<td width="33%"><a href="#"><img  src="../../../../Util/Images/zm.png" /></a></td>');
document.write('<td width="33%"></td>');
document.write('</tr>');
document.write('</table>');
document.write('<div class="trang2"><img src="../../../../Util/Images/triangle2.png" width="21" height="22" /></div>');
document.write('</div>');
document.write('</div>');
document.write('</div>');


    
        
          
           
              
              
              
            
              
              
              
              
            
          
          
        
    
