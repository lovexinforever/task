<script type="text/javascript">
/**
 * 
 * @param sql  查询语句
 * @param value  查询条件
 * @param sucessCB
 * @param errorCB
 * @return
 */
function selectInfo(sql,value,sucessCB,errorCB){
	var ydjc_db = window.sqlitePlugin.openDatabase("ydjc.db", "1.0", "ydjc.db", 10*1024*1024);
	ydjc_db.transaction(queryDB);

	function queryDB(tx){
		 tx.executeSql(sql,value,sucessCB,errorCB);
	}
	
}

/**
 * 弹出框内容
 * @return
 */
function alertInfoMes(str){
	$("#yxzypt_msg").html("");

	if(str){
		 if(str.indexOf("成功")!=-1){
		        $("#change_wcnm").attr("src","../../Util/Images/success.png");
		    }else{
		        $("#change_wcnm").attr("src","../../Util/Images/warn.png");
		    }
			$("#yxzypt_msg").html(str);
	}else{
		   $("#change_wcnm").attr("src","../../Util/Images/warn.png");
		$("#yxzypt_msg").html("服务器返回信息错误");
		
	}
	
	 $("#yxzypt_dailog").show();
	
}

</script>



	
	
	