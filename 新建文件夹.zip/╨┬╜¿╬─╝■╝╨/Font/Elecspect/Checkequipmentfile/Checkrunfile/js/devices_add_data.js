<script type="text/javascript">

/**
 * 获得该工单下的所有受力点
 * @param dtl_id
 * @return
 */
function getcsp(dtl_id,su_getcsp){
	var sql = "select sp_id,sp_name from YJ_C_SP where dtl_id=? ";
	db_execut_oneSQL(null,sql,[dtl_id],su_getcsp,null);
	
}

function getAllbreakers(condition,su_getbreadkers){
	var sql = "select equip_id,equip_name from YJ_C_EQUIP_RUN where dtl_id=? and type_code=? ";
	db_execut_oneSQL(null,sql,condition,su_getbreadkers,null);
}

function getEquipIdFromtables(getMaxId){
	var  sql = "select max(equip_id) as id_max from YJ_C_EQUIP_RUN ";
	db_execut_oneSQL(null,sql,null,getMaxId,null);
}

//保存设备基础信息
function savaInfo(sql1,value1,sql2,value2,sucessCB_yxsb,errorCB){
	var ydjc_db = window.sqlitePlugin.openDatabase("ydjc.db", "1.0", "ydjc.db", 10*1024*1024);
	ydjc_db.transaction(queryDB);
	var mobile_id=0;
	function queryDB(tx){
		 tx.executeSql(sql1,value1,function(tx,res){
			  mobile_id = res.insertId;
			 ydjc_db.transaction(function(tx){
				 value2.push(mobile_id);
				 tx.executeSql(sql2,value2,function(tx,res){
					 sucessCB_yxsb(mobile_id);
				 },function(e){
					// alert("保存失败");
					 
				 });
			 });
			 
		 },function(e){
			// alert("保存失败");
		 });
	}
}

/**
 * 弹出框内容
 * @return
 */
function alertInfoMes(str){
	
	$("#yxzypt_msg").html("");

	if(str){
		 if(str.indexOf("成功")!=-1){
		        $("#change_wcnm").attr("src","../../Util/Images/success.png");
		    }else{
		        $("#change_wcnm").attr("src","../../Util/Images/warn.png");
		    }
			$("#yxzypt_msg").html(str);
	}else{
		 $("#change_wcnm").attr("src","../../Util/Images/warn.png");
		$("#yxzypt_msg").html("服务器返回信息错误");
		
	}
	
	 $("#yxzypt_dailog").show();
	
}


//保存设备基础信息
function uploadUpdate(sql1,value1,sql2,value2){
	var ydjc_db = window.sqlitePlugin.openDatabase("ydjc.db", "1.0", "ydjc.db", 10*1024*1024);
	ydjc_db.transaction(queryDB);
	
	function queryDB(tx){
		 tx.executeSql(sql1,value1,function(tx,res){
			 ydjc_db.transaction(function(tx){
				 tx.executeSql(sql2,value2,function(tx,res){
						//alert("更改成功--");
				 },function(e){
					
					 
				 });
			 });
			 
		 },function(e){
			
		 });
	}
}

//正整数验证
function numberVolite(myInput){
	
	if(myInput.value<0||myInput.value.indexOf(".")!=-1){
		alert("请输入非负整数");
		myInput.value="";
		return;
	}
	if(myInput.value.length>1&&myInput.value.substring(0,1)==0){
		alert("请输入非负整数");
		myInput.value="";
		return;
	}
}

//非负数验证以及最大数验证
function numberVoliteMax(myInput,maxnumber){
	if(myInput.value<0||myInput.value>maxnumber){
		alert("请输入0到"+maxnumber+"之间的数");
		myInput.value="";
	}
}
//检验字符长度,长度不能超过length
function voliteLength(obj,length){
	var str = obj.value;
	var bytelen = 0,len = str.length;
	if(str){
		for(var i=0;i<len;i++){
			if (str.charCodeAt(i)>255) {
				bytelen +=2;
			}else{
				bytelen ++;
			}
		}
		if(bytelen>length){
			obj.value="";
			alertInfoMes("字节长度不能超过"+length);
			
		}
	}
	
}

/**
 * @param obj 控件对象
 * @param integersize 整数的位数
 * @param ysize 小数的位数
 * @param max 最大数
 * @return 错误信息
 */
function validate(obj,ysize,max){ 
	if(obj.value!=""){
		var regstring = "^[0-9]+(.[0-9]{1,"+ysize+"})?$";
		var reg = new RegExp(regstring); 
		if(!reg.test(obj.value)){
			alert("请输入小数位不超过"+ysize+"位的数字!")
			obj.value="";
		}
		else if(obj.value>=max){
			 alert("请输小于"+max+"的数!")
			 obj.value="";
		}
	}
}


</script>



	
	
	