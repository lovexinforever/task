<script type="text/javascript">
/**
 * 
 */

function changeInfo(sql1,value1,sql2,value2,sucessCB_c,errorCB_c){
	var ydjc_db = window.sqlitePlugin.openDatabase("ydjc.db", "1.0", "ydjc.db", 10*1024*1024);
	//开始使用事务操作数据库
	ydjc_db.transaction(queryDB_c);
	//操作数据库
	function queryDB_c(tx){
		 tx.executeSql(sql1,value1,sucessCB_c,errorCB_c);
		 tx.executeSql(sql2,value2,sucessCB_c,errorCB_c);
	}
}

/**
 * 弹出框内容
 * @return
 */
function alertInfoMes(str){
	$("#yxzypt_msg").html("");

	if(str){
		 if(str.indexOf("成功")!=-1){
		        $("#change_wcnm").attr("src","../../Util/Images/success.png");
		    }else{
		        $("#change_wcnm").attr("src","../../Util/Images/warn.png");
		    }
			$("#yxzypt_msg").html(str);
	}else{
		  $("#change_wcnm").attr("src","../../Util/Images/warn.png");
		$("#yxzypt_msg").html("服务器返回信息错误");
		
	}
	
	 $("#yxzypt_dailog").show();
	
}

//正整数验证
function numberVolite(myInput){
	if(myInput.value<0||myInput.value.indexOf(".")!=-1){
		alert("请输入非负整数");
		myInput.value="";
		return;
	}
	if(myInput.value.length>1&&myInput.value.substring(0,1)==0){
		alert("请输入非负整数");
		myInput.value="";
		return;
	}
}

//非负数验证以及最大数验证
function numberVoliteMax(myInput,maxnumber){
	
	if(myInput.value<0||myInput.value>maxnumber){
		alert("请输入0到"+maxnumber+"之间的数");
		myInput.value="";
	}
}

//检验字符长度,长度不能超过length
function voliteLength(obj,length){
	var str = obj.value;
	var bytelen = 0,len = str.length;
	if(str){
		for(var i=0;i<len;i++){
			if (str.charCodeAt(i)>255) {
				bytelen +=2;
			}else{
				bytelen ++;
			}
		}
		if(bytelen>length){
			obj.value="";
			alertInfoMes("字节长度不能超过"+length);
			
		}
	}
	
}

//查看图片调用的的方法
function camera_check_transfer(fun_item,type_code_value,check_callback){
	// 查询本地图片
	 var sql_devices  = "select * from YJ_C_PHOTOESINFO where app_no=? and dtl_id=? and cr_id=? and fun_item=? and check_item=?"; 
	var select_devices =[sessionStorage.APP_NO_bl,cons_info.dtl_id,cons_info.cr_id,fun_item,data.EQUIP_ID];
	db_execut_oneSQL(null,sql_devices,select_devices,function(tx,res){
		var photo_service_path = null;//图片地址
		var upPkg = null;//传给营销的图片上装信息
		var upData = null;//传给平台的
		 var downPkg = null;//下载的pkg
		 var appjson = '{"APP_NO":"'+sessionStorage.APP_NO_bl+'","DTL_ID":"'+cons_info.dtl_id+'","CR_ID":"'+cons_info.cr_id+'","FUN_ITEM":"'+fun_item+'","CHECK_ITEM":"'+data.EQUIP_ID+'"}';
			if(res.rows.length!=0){
				var  image = res.rows.item(0);
				 photo_service_path="2003"+image.FILE_PATH; 
				 image.FILE_NAME = image.FILE_NAME.replace("jpg","zip");
				 upPkg = '{"MOD":"2003","FUN":"1008","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"EQUIP_ID":"'+data.EQUIP_ID+'","TYPE_CODE":"'+type_code_value+'","FILE_FORMAT":"JPG","FILE_SIZE":"'+image.FILE_SIZE+'","FILE_CREATE_TIME":"'+image.FILE_CREATE_TIME+'","FILE_NAME":"'+image.FILE_NAME+'","FILE_PATH":"'+photo_service_path+'"}}';
				  upData='{"FUN":"0000","ORG_NO":"'+sessionStorage.ORG_NO+'","MOD":"2003","SSN":"'+sessionStorage.SSN+'","FILE":[{"NAME":"'+image.FILE_NAME+'","URL":"'+photo_service_path+'"}]}';
				  downPkg = '{"MOD":"2003","FUN":"1009","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"EQUIP_ID":"'+data.EQUIP_ID+'","TYPE_CODE":"'+type_code_value+'","FILE_PATH":"'+photo_service_path+'"}}'
					scanPhoto(image.FILE_PATH+image.FILE_NAME, upData, "0000", "2003", upPkg, downPkg,appjson, check_callback) ;
			}else{
				//var imagename = "fun_item_"+data.EQUIP_ID+".jpg";
				photo_service_path="2003/elec_photo/"+cons_info.dtl_id+"/"+fun_item+"/"+data.EQUIP_ID+"/"; 
				 upPkg = '{"MOD":"2003","FUN":"1008","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"EQUIP_ID":"'+data.EQUIP_ID+'","TYPE_CODE":"'+type_code_value+'"}}';
				//  upData='{"FUN":"0000","ORG_NO":"'+sessionStorage.ORG_NO+'","MOD":"2003","SSN":"'+sessionStorage.SSN+'","FILE":[{"NAME":"'+imagename+'","URL":"'+photo_service_path+'"}]}';
				  downPkg = '{"MOD":"2003","FUN":"1009","ORG_NO":"'+sessionStorage.ORG_NO+'","LEN":39,"PKG":{"EQUIP_ID":"'+data.EQUIP_ID+'","TYPE_CODE":"'+type_code_value+'","FILE_PATH":"'+photo_service_path+'"}}'
				  scanPhoto(null, null, "0000", "2003", upPkg, downPkg,appjson, check_callback) ;
			}
			
	},null);
}

//改变查看图片的状态
function changeimagestatus(fun,check,id){
		 var sql_devices  = "select * from YJ_C_PHOTOESINFO where app_no=? and dtl_id=? and cr_id=? and fun_item=? and check_item=?"; 
		var select_devices =[sessionStorage.APP_NO_bl,cons_info.dtl_id,cons_info.cr_id,fun,check];
		db_execut_oneSQL(null,sql_devices,select_devices,function(tx,res){
			if(res.rows.length!=0){
				var  image = res.rows.item(0);
				var image_upload = image.UPLOAD_TYPE;//图片的上装状态 0表示未上装 1表示已上装
				var image_download = image.DOWNLOAD_TYPE;//图片的上装状态0表示未下载 1表示已下载
					if(image_upload==1&&image_download==0){
						$("#"+id).attr("src","../../Util/Images/but_ck01_upload.png");
					}else if(image_upload==0&&image_download==1){
						$("#"+id).attr("src","../../Util/Images/but_ck01_download.png");
					}
			
			}else{
				
				$("#"+id).attr("src","../../Util/Images/but_ck01.png");
			}
	},null);
}


/**
 * @param obj 控件对象
 * @param integersize 整数的位数
 * @param ysize 小数的位数
 * @param max 最大数
 * @return 错误信息
 */
function validate(obj,ysize,max){ 
	if(obj.value!=""){
		var regstring = "^[0-9]+(.[0-9]{1,"+ysize+"})?$";
		var reg = new RegExp(regstring); 
		if(!reg.test(obj.value)){
			alert("请输入小数位不超过"+ysize+"位的正数!")
			obj.value="";
		}
		else if(obj.value>=max){
			 alert("请输小于"+max+"的正数!")
			 obj.value="";
		}
	}
}

</script>



	
	
	