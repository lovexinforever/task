 <script type="text/javascript" charset="utf-8">
 
    function get_yxsb_zk01(dtl_id){
    	var sql=" select e.MOBILE_EQUIP_ID,e.dtl_id,e.equip_id,e.equip_name,e.type_code from YJ_C_EQUIP_RUN e where e.dtl_id=? order by e.type_code,e.MOBILE_EQUIP_ID";
    	db_execut_oneSQL(null,sql,[dtl_id],initPage_yxsbzk01_ydjc,null);
    }
 </script>