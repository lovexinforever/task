<script type="text/javascript">
/**
 * 重要客户检查结果记录实体
 * @param cr_id=检查结果标识
 * @param aqyd=1安全用电整体评价
 * @param aqydpj=1安全用电整体评价_评价内容
 * @param dypz=2.1存在主要隐患_电源配置不到位
 * @param dypzyh=2.1存在主要隐患_电源配置不到位_处理意见
 * @param yjdypz=2.2存在主要隐患_应急电源配置不足
 * @param yjdypzyh=2.2存在主要隐患_应急电源配置不足_处理意见
 * @param fdcpz=2.3存在主要隐患_移动发电车接入存在障碍
 * @param fdcpzyh=2.3存在主要隐患_移动发电车接入存在障碍_处理意见
 * @param zbdgpz=2.4存在主要隐患_值班电工人数配置不足
 * @param zbdgpzyh=2.4存在主要隐患_值班电工人数配置不足_处理意见
 * @param dqsbpz=2.5存在主要隐患_电气设备预防性试验超周期
 * @param dqsbpzyh=2.5存在主要隐患_电气设备预防性试验超周期_处理意见
 * @param qtqx=2.6存在主要隐患_其它缺陷
 * @param qtqxyh=2.6存在主要隐患_其它缺陷_处理意见
 * @param khfk=3客户反馈信息记录
 * @param khfkxx=3客户反馈信息记录_处理意见
 * @param jccs=4检查日期记录_本年度第N次
 * @param yhs=4检查日期记录_本年累计应整改隐患N条
 * @param yzgyh=4检查日期记录_已整改N条
 * @param sfkj=5是否开具检查通知书告知用户检查结果
 * @param file_name=5检查通知书_上传文件
 * @param score=SCORE
 * @param uploading_type=上装状态
 * @param uploading_date=上装时间
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询界面数据
function get_yj_s_hr_chkresult_checkresult_data(json_where,sucessCB,failCB){
	var sql="select id as id,aqyd as aqyd,aqydpj as aqydpj,dypz as dypz,dypzyh as dypzyh,yjdypz as yjdypz,yjdypzyh as yjdypzyh,fdcpz as fdcpz,fdcpzyh as fdcpzyh,zbdgpz as zbdgpz,zbdgpzyh as zbdgpzyh,dqsbpz as dqsbpz,dqsbpzyh as dqsbpzyh,qtqx as qtqx,qtqxyh as qtqxyh,khfk as khfk,khfkxx as khfkxx,jccs as jccs,yhs as yhs,yzgyh as yzgyh,sfkj as sfkj,file_name as file_name,score as score,uploading_type as uploading_type,uploading_date as uploading_date,dypz_img as dypz_img,yjdypz_img as yjdypz_img,fdcpz_img as fdcpz_img,zbdgpz_img as zbdgpz_img,dqsbpz_img as dqsbpz_img,qtqx_img as qtqx_img from YJ_S_HR_CHKRESULT where cr_id=?";
	db_execut_oneSQL(null,sql,json_where,sucessCB,failCB);
}
/**
 * 重要客户巡检记录--对应有无窃电行为
 * @param cr_id=检查结果唯一标识
 * @param wyqd=21有无违约、窃电行为
 * @param qdccgc=21有无违约、窃电行为_窃电查处过程
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询有无窃电行为
function get_yj_s_gwzyxj_checkresult_data(json_where1,sucessCB1,failCB1){
	 var p_sql="select wyqd as wyqd,qdccgc as qdccgc,wyqd_img as wyqd_img from YJ_S_GWZYXJ where cr_id=?";
	 db_execut_oneSQL(null,p_sql,json_where1,sucessCB1,failCB1);
}

/**
 * /*保存界面数据
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @param sstatue 数据状态，0为空，1有值；为空时执行插入，有值时执行更新
 * @return
 */
function save_checkresult_data(json_where,sucessCB1,failCB1,sstatue){
	var update="update YJ_S_HR_CHKRESULT set aqyd=?,aqydpj=?,dypz=?,dypzyh=?,yjdypz=?,yjdypzyh=?,fdcpz=?,fdcpzyh=?,zbdgpz=?,zbdgpzyh=?,dqsbpz=?,dqsbpzyh=?,qtqx=?,qtqxyh=?,khfk=?,khfkxx=?,jccs=?,yhs=?,yzgyh=?,sfkj=?,dypz_img=?,yjdypz_img=?,fdcpz_img=?,zbdgpz_img=?,dqsbpz_img=?,qtqx_img=?,file_name=? where cr_id=?";
	var insert="INSERT INTO YJ_S_HR_CHKRESULT (id,cr_id,aqyd,aqydpj,dypz,dypzyh,yjdypz,yjdypzyh,fdcpz,fdcpzyh,zbdgpz,zbdgpzyh,dqsbpz,dqsbpzyh,qtqx,qtqxyh,khfk,khfkxx,jccs,yhs,yzgyh,sfkj,dypz_img,yjdypz_img,fdcpz_img,zbdgpz_img,dqsbpz_img,qtqx_img,file_name) VALUES ('0',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	if(sstatue==0){
	 db_execut_oneSQL(null,insert,json_where,sucessCB1,failCB1);
	}else if(sstatue==1){
	 db_execut_oneSQL(null,update,json_where,sucessCB1,failCB1);
	}
}
/*保存修改记录到表YJ_DATA_COMPARISON_DTL_ID*/
function save_Correct_Record(){
	var select_sql="select DATA_ID from YJ_DATA_COMPARISON_DTL_ID where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 db_execut_oneSQL(null,select_sql,[cons_info.dtl_id,cons_info.cons_id,'A0010'],save_sucessCB1,savefailCB1);
}
/*查询成功回调*/
var save_sucessCB1 = function(tx,res){
	 var sql_upnm="update YJ_DATA_COMPARISON_DTL_ID set LINE_DATA=?,TYPE=? where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 var sql_insert="insert into YJ_DATA_COMPARISON_DTL_ID (MODEL_TYPE,MODEL_TITLE,TYPE,OLD_DATA_INDEX,OLD_DATA,LINE_DATA,DTL_ID,CONS_ID) values (?,?,?,?,?,?,?,?)";
		 var result_len=res.rows.length;
//		 alert(result_len);
		 	if(result_len){//更新
		 		 db_execut_oneSQL(null,sql_upnm,['{"安全用电整体评价":"'+text1[0][(aqyd_val-1)]+'","安全用电整体评价_评价内容":"'+input_val[0]+'","电源配置":"'+text1[1][(dypz_val-1)]+'","电源配置不到位_处理意见":"'+input_val[1]+'","应急电源配置":"'+text1[2][(yjdypz_val-1)]+'","应急电源配置不足_处理意见":"'+input_val[2]+'","移动发电车":"'+text1[3][(fdcpz_val-1)]+'","移动发电车接入存在障碍_处理意见":"'+input_val[3]+'","值班电工人数":"'+text1[4][(zbdgpz_val-1)]+'","值班电工人数配置不足_处理意见":"'+input_val[4]+'","电气设备预防性试验超周期":"'+text1[5][(dqsbpz_val-1)]+'","电气设备预防性试验超周期_处理意见":"'+input_val[5]+'","其它缺陷":"'+text1[6][(qtqx_val-1)]+'","其它缺陷_处理意见":"'+input_val[6]+'","客户反馈信息记录":"'+text1[7][(khfk_val-1)]+'","客户反馈信息记录_处理意见":"'+input_val[7]+'","检查日期记录_本年度第N次":"'+input_val[8]+'","检查日期记录_本年累计应整改隐患N条":"'+input_val[9]+'","检查日期记录_已整改N条":"'+input_val[10]+'","是否开具检查通知书告知用户检查结果":"'+text1[8][(sfkj_val-1)]+'","有无违约、窃电行为":"'+text1[9][(wyqd_val-1)]+'","有无违约、窃电行为_处理意见":"'+$('#qdccgc').val()+'"}',"2",cons_info.dtl_id,cons_info.cons_id,"A0010"],null,null);
		 	}else{//插入
		 		 db_execut_oneSQL(null,sql_insert,["A0010","检查结果维护","2","",json_olddata,'{"安全用电整体评价":"'+text1[0][(aqyd_val-1)]+'","安全用电整体评价_评价内容":"'+input_val[0]+'","电源配置":"'+text1[1][(dypz_val-1)]+'","电源配置不到位_处理意见":"'+input_val[1]+'","应急电源配置":"'+text1[2][(yjdypz_val-1)]+'","应急电源配置不足_处理意见":"'+input_val[2]+'","移动发电车":"'+text1[3][(fdcpz_val-1)]+'","移动发电车接入存在障碍_处理意见":"'+input_val[3]+'","值班电工人数":"'+text1[4][(zbdgpz_val-1)]+'","值班电工人数配置不足_处理意见":"'+input_val[4]+'","电气设备预防性试验超周期":"'+text1[5][(dqsbpz_val-1)]+'","电气设备预防性试验超周期_处理意见":"'+input_val[5]+'","其它缺陷":"'+text1[6][(qtqx_val-1)]+'","其它缺陷_处理意见":"'+input_val[6]+'","客户反馈信息记录":"'+text1[7][(khfk_val-1)]+'","客户反馈信息记录_处理意见":"'+input_val[7]+'","检查日期记录_本年度第N次":"'+input_val[8]+'","检查日期记录_本年累计应整改隐患N条":"'+input_val[9]+'","检查日期记录_已整改N条":"'+input_val[10]+'","是否开具检查通知书告知用户检查结果":"'+text1[8][(sfkj_val-1)]+'","有无违约、窃电行为":"'+text1[9][(wyqd_val-1)]+'","有无违约、窃电行为_处理意见":"'+$('#qdccgc').val()+'"}',cons_info.dtl_id,cons_info.cons_id],null,null);
		 	}
	 }
/*查询失败回调*/
var savefailCB1=function(){
	 
}

/**
 * /*保存界面数据(有无窃电行为)
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @param sstatue 数据状态，0为空，1有值；为空时执行插入，有值时执行更新
 * @return
 */
function save_checkresultbb_data(json_where,sucessCB1,failCB1,sstatue){
	var p_update="update YJ_S_GWZYXJ set wyqd=?,qdccgc=?,wyqd_img=? where cr_id=?";
	var p_insert="INSERT INTO YJ_S_GWZYXJ (id,cr_id,wyqd,qdccgc,wyqd_img) VALUES ('0',?,?,?,?)";
	if(sstatue==0){
		 db_execut_oneSQL(null,p_insert,json_where,sucessCB1,failCB1);
	}else if(sstatue==1){
		 db_execut_oneSQL(null,p_update,json_where,sucessCB1,failCB1);
	}
}

/*****上装时实时查询数据--id*****/
var yj_otdatares="";		//YJ_S_GWZYXJ数据对象
var idszres="";																//数据库表中主键id
function select_ontime_datares(){
	var sql="select * from YJ_S_HR_CHKRESULT where CR_ID=?";
	db_execut_oneSQL(null,sql,[cons_info.cr_id],sucessCB_select_ontime_datares,null);
	function sucessCB_select_ontime_datares(tx,res){
		var ss=res.rows.length;
		if(ss){
			yj_otdatares=res.rows.item(0);
			idszres=yj_otdatares.ID;
		}else{
			
		}
	}
	setTimeout(function(){
		sz_main_datares();
	},1000)
}

/*****上装时实时查询数据--id*****/


//上装
function upload_statu4(){
	opendailog("businessList_laoding_view");//弹出加载效果框
	select_ontime_datares();
}
function sz_main_datares(){
//上装--信息新增pkg
var PKG='{"MOD":"2003","FUN":"2304","LEN":39,"ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"CR_ID":"'+cons_info.cr_id+'","AQYD":"'+setUndefined(aqyd_val)+'","AQYDPJ":"'+setUndefined(input_val[0])+'","DYPZ":"'+setUndefined(dypz_val)+'","DYPZYH":"'+setUndefined(input_val[1])+'","YJDYPZ":"'+setUndefined(yjdypz_val)+'","YJDYPZYH":"'+setUndefined(input_val[2])+'","FDCPZ":"'+setUndefined(fdcpz_val)+'","FDCPZYH":"'+setUndefined(input_val[3])+'","ZBDGPZ":"'+setUndefined(zbdgpz_val)+'","ZBDGPZYH":"'+setUndefined(input_val[4])+'","DQSBPZ":"'+setUndefined(dqsbpz_val)+'","DQSBPZYH":"'+setUndefined(input_val[5])+'","QTQX":"'+setUndefined(qtqx_val)+'","QTQXYH":"'+setUndefined(input_val[6])+'","KHFK":"'+setUndefined(khfk_val)+'","KHFKXX":"'+setUndefined(input_val[7])+'","JCCS":"'+setUndefined(input_val[8])+'","YHS":"'+setUndefined(input_val[9])+'","YZGYH":"'+setUndefined(input_val[10])+'","SFKJ":"'+setUndefined(sfkj_val)+'","FILE_NAME":"'+setUndefined(pic_name[7])+'"}}'
//上装--信息修改pkg
var PKG1='{"MOD":"2003","FUN":"2305","LEN":39,"ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"ID":"'+idszres+'","CR_ID":"'+cons_info.cr_id+'","AQYD":"'+setUndefined(aqyd_val)+'","AQYDPJ":"'+setUndefined(input_val[0])+'","DYPZ":"'+setUndefined(dypz_val)+'","DYPZYH":"'+setUndefined(input_val[1])+'","YJDYPZ":"'+setUndefined(yjdypz_val)+'","YJDYPZYH":"'+setUndefined(input_val[2])+'","FDCPZ":"'+setUndefined(fdcpz_val)+'","FDCPZYH":"'+setUndefined(input_val[3])+'","ZBDGPZ":"'+setUndefined(zbdgpz_val)+'","ZBDGPZYH":"'+setUndefined(input_val[4])+'","DQSBPZ":"'+setUndefined(dqsbpz_val)+'","DQSBPZYH":"'+setUndefined(input_val[5])+'","QTQX":"'+setUndefined(qtqx_val)+'","QTQXYH":"'+setUndefined(input_val[6])+'","KHFK":"'+setUndefined(khfk_val)+'","KHFKXX":"'+setUndefined(input_val[7])+'","JCCS":"'+setUndefined(input_val[8])+'","YHS":"'+setUndefined(input_val[9])+'","YZGYH":"'+setUndefined(input_val[10])+'","SFKJ":"'+setUndefined(sfkj_val)+'","FILE_NAME":"'+setUndefined(pic_name[7])+'"}}'
if(idszres && idszres!=0){//表中存在id，则发送信息修改的pkg
	send_data("2305","2003",PKG1,successCallBack,faileCallBack);
}else{//表中不存在id,则发送信息新增新增pkg
	send_data("2304","2003",PKG,successCallBack,faileCallBack);
}
//上装成功回调
function successCallBack(message_ener){
	var msg_enercb = JSON.parse(message_ener);
	if(msg_enercb.RET=="00"){
		var msg_pkg=msg_enercb.PKG.PKG;
		var fun=msg_enercb.FUN;
		if(msg_pkg.SUCCESS_FLAG=="0"){
				//重要客户巡检检查结果信息新增
		        if(fun=="2304"){
		    	db_execut_oneSQL(null,"update YJ_S_HR_CHKRESULT set ID=?,UPLOADING_TYPE=?,UPLOADING_DATE=? where CR_ID=?",[msg_pkg.id,2,new Date(),cons_info.cr_id],null,null);
				}
				//重要客户巡检检查结果信息修改
		        else if(fun=="2305"){
		    	 db_execut_oneSQL(null,"update YJ_S_HR_CHKRESULT set UPLOADING_DATE=? where CR_ID=?",[new Date(),cons_info.cr_id],null,null);
				}
		        upload_statu();//调用页面最下面2条数据的接口
		}else{
			$("#businessList_laoding_view").hide();//关闭加载效果框
			$("#yxzypt_msg").html("");
            if(msg_pkg.ERR_MSG){
                $("#yxzypt_msg").html(msg_pkg.ERR_MSG);//给弹出框赋对应的提示消息
            }else{
                $("#yxzypt_msg").html("上装失败!数据保存本地");//给弹出框赋对应的提示消息
            }
		    onchange_val();
			$("#yxzypt_dailog").show();
		}
	}else{
		$("#businessList_laoding_view").hide();//关闭加载效果框
		$("#yxzypt_msg").html("");
			$("#yxzypt_msg").html("上装失败!数据保存本地");//给弹出框赋对应的提示消息
			 onchange_val();
			$("#yxzypt_dailog").show();
	}
}
//上装失败回调
function faileCallBack(){
//	$("#businessList_laoding_view").hide();//关闭加载效果框
	var pkgp="";
	if(idszres && idszres!=0){//表中存在id，则发送信息修改的pkg
		pkgp=PKG1;
		var msg_ti_str = '{"DTL_ID":"'+cons_info.dtl_id+'","CONS_ID":"'+cons_info.cons_id+'","MSG":"检查结果巡检记录上装失败","PKG":'+pkgp+',"ERROR_ID":"2305"}';
		upload_Data("2305","2003",pkgp,msg_ti_str,"yj_upload_proc");
	}else{//表中不存在id,则发送信息新增新增pkg
		pkgp=PKG;
		var msg_ti_str = '{"DTL_ID":"'+cons_info.dtl_id+'","CONS_ID":"'+cons_info.cons_id+'","MSG":"检查结果巡检记录上装失败","PKG":'+pkgp+',"ERROR_ID":"2304"}';
		upload_Data("2304","2003",pkgp,msg_ti_str,"yj_upload_proc");
	}
	setTimeout(function(){
		$("#businessList_laoding_view").css("display","none");//关闭加载效果框
	$("#yxzypt_msg").html("数据进入到上装队列，等待上装！");//给弹出框赋对应的提示消息
	   onchange_val();
	$("#yxzypt_dailog").show();
	 },500);
}
}

</script>