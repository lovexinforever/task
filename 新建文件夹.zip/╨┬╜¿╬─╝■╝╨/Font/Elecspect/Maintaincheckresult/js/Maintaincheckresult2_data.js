<script type="text/javascript">
/**
 * 检查结果信息对应表
 * @param cr_id=检查结果标识
 * @param dtl_id=计划明细标识
 * @param cons_no=用户编号
 * @param cons_name=用户名称
 * @param elec_addr=用电地址
 * @param assigner=派工人员
 * @param assign_time=派工时间
 * @param checker_name=检查人员
 * @param otherperson_name=其他人员
 * @param chk_date=检查日期
 * @param problem=存在问题
 * @param chk_rslt=检查结果
 * @param violate_flag=有无违约用电窃电行为
 * @param equip_defect_flag=有无设备缺陷
 * @param mr_excp_flag=有无计量异常
 * @param prc_mistake_flag=有无电价执行错误
 * @param signature=用户签字
 * @param cons_opinion=用户意见
 * @param prio_code=重要性等级
 * @param handle_flag=处理标志
 * @param final_conc=认定结果
 * @param chk_file=现场检查照片
 * @param uploading_type=上装状态
 * @param uploading_date=上装时间
 * @param ZT 电表扫描与电表资产编号比对
 * @param LATITUDE 经纬度
 * @param LONGITUDE 经纬度
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询界面数据
function get_yj_s_inspect_rslt_checkres_data(json_where,sucessCB,failCB){
	var sql="select ZT,LATITUDE,LONGITUDE,cons_no as cons_no,cons_name as cons_name,elec_addr as elec_addr,assigner as assigner,assign_time as assign_time,checker_name as checker_name,otherperson_name as otherperson_name,chk_date as chk_date,problem as problem,chk_rslt as chk_rslt,violate_flag as violate_flag,equip_defect_flag as equip_defect_flag,mr_excp_flag as mr_excp_flag,prc_mistake_flag as prc_mistake_flag,signature as signature,cons_opinion as cons_opinion,prio_code as prio_code,handle_flag as handle_flag,final_conc as final_conc,chk_file as chk_file,uploading_type as uploading_type,uploading_date as uploading_date,violate_flag_img as violate_flag_img,equip_defect_flag_img as equip_defect_flag_img,mr_excp_flag_img as mr_excp_flag_img,prc_mistake_flag_img as prc_mistake_flag_img,chk_file as chk_file,problem_img as problem_img from YJ_S_INSPECT_RSLT where dtl_id=?";
	db_execut_oneSQL(null,sql,json_where,sucessCB,failCB);
}
/**
 * 问题反馈
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @return
 */
//查询问题反馈数据
function get_yj_problem_feedback_data(json_where1,sucessCB1,failCB1){
	 var pro_sql="select rrio_code as rrio_code,modle_type as modle_type,problem as problem,statue as statue from YJ_PROBLEM_FEEDBACK where dtl_id=? and cons_id=?";
	 db_execut_oneSQL(null,pro_sql,json_where1,sucessCB1,failCB1);
}

/**
 * /*保存界面数据
 * @param json_where 查询条件的值
 * @param sucessCB成功回调
 * @param failCB失败回调
 * @param sstatue 数据状态，0为空，1有值；为空时执行插入，有值时执行更新
 * @return
 */
function save_checkres_data(json_where,sucessCB1,failCB1,sstatue){
	var update="update YJ_S_INSPECT_RSLT set cons_no=?,cons_name=?,elec_addr=?,checker_name=?,otherperson_name=?,chk_date=?,chk_rslt=?,signature=?,violate_flag=?,equip_defect_flag=?,mr_excp_flag=?,prc_mistake_flag=?,problem=?,cons_opinion=?,violate_flag_img=?,equip_defect_flag_img=?,mr_excp_flag_img=?,prc_mistake_flag_img=?,chk_file=?,problem_img=? where dtl_id=?";
	var insert="INSERT INTO YJ_S_INSPECT_RSLT (cr_id,dtl_id,cons_no,cons_name,elec_addr,checker_name,otherperson_name,chk_date,chk_rslt,signature,violate_flag,equip_defect_flag,mr_excp_flag,prc_mistake_flag,problem,cons_opinion,violate_flag_img,equip_defect_flag_img,mr_excp_flag_img,prc_mistake_flag_img,chk_file,problem_img) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	if(sstatue==0){
		 db_execut_oneSQL(null,insert,json_where,sucessCB1,failCB1);
	}else if(sstatue==1){
		 db_execut_oneSQL(null,update,json_where,sucessCB1,failCB1);
	}
}


/*保存修改记录到表YJ_DATA_COMPARISON_DTL_ID--重要用户*/
function save_Correct_Record(){
	var select_sql="select DATA_ID from YJ_DATA_COMPARISON_DTL_ID where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 db_execut_oneSQL(null,select_sql,[cons_info.dtl_id,cons_info.cons_id,'A0011'],save_sucessCB2,savefailCB2);
}
/*查询成功回调*/
var save_sucessCB2 = function(tx,res){
	 var sql_upnm="update YJ_DATA_COMPARISON_DTL_ID set LINE_DATA=?,TYPE=? where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 var sql_insert="insert into YJ_DATA_COMPARISON_DTL_ID (MODEL_TYPE,MODEL_TITLE,TYPE,OLD_DATA_INDEX,OLD_DATA,LINE_DATA,DTL_ID,CONS_ID) values (?,?,?,?,?,?,?,?)";
		 var result_len=res.rows.length;
//		 alert(result_len);
		 	if(result_len){//更新
		 		 db_execut_oneSQL(null,sql_upnm,['{"检查日期":"'+$('#chk_date_01').val()+'","检查结果":"'+$('#chk_rslt_01').val()+'","用户签字":"'+$('#signature_01').val()+'","有无违约用电窃电行为":"'+text1[0][(violate_flag_val-1)]+'","有无设备缺陷":"'+text1[1][(equip_defect_flag_val-1)]+'","有无计量异常":"'+text1[2][(mr_excp_flag_val-1)]+'","有无电价执行错误":"'+text1[3][(prc_mistake_flag_val-1)]+'","存在问题":"'+$('#problem_01').val()+'","用户意见":"'+$('#cons_opinion_01').val()+'"}',"2",cons_info.dtl_id,cons_info.cons_id,"A0011"],null,null);
		 	}else{//插入
		 		 db_execut_oneSQL(null,sql_insert,["A0011","检查结果维护","2","",json_olddata,'{"检查日期":"'+$('#chk_date_01').val()+'","检查结果":"'+$('#chk_rslt_01').val()+'","用户签字":"'+$('#signature_01').val()+'","有无违约用电窃电行为":"'+text1[0][(violate_flag_val-1)]+'","有无设备缺陷":"'+text1[1][(equip_defect_flag_val-1)]+'","有无计量异常":"'+text1[2][(mr_excp_flag_val-1)]+'","有无电价执行错误":"'+text1[3][(prc_mistake_flag_val-1)]+'","存在问题":"'+$('#problem_01').val()+'","用户意见":"'+$('#cons_opinion_01').val()+'"}',cons_info.dtl_id,cons_info.cons_id],null,null);
		 	}
	 }
/*查询失败回调*/
var savefailCB2=function(){
	 
}


/*保存修改记录到表YJ_DATA_COMPARISON_DTL_ID--非重要用户*/
function save_Correct_Record1(){
	var select_sql="select DATA_ID from YJ_DATA_COMPARISON_DTL_ID where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 db_execut_oneSQL(null,select_sql,[cons_info.dtl_id,cons_info.cons_id,'A0011'],save_sucessCB1,savefailCB1);
}
/*查询成功回调*/
var save_sucessCB1 = function(tx,res){
	 var sql_upnm="update YJ_DATA_COMPARISON_DTL_ID set LINE_DATA=?,TYPE=? where DTL_ID=? and CONS_ID=? and MODEL_TYPE=?";
	 var sql_insert="insert into YJ_DATA_COMPARISON_DTL_ID (MODEL_TYPE,MODEL_TITLE,TYPE,OLD_DATA_INDEX,OLD_DATA,LINE_DATA,DTL_ID,CONS_ID) values (?,?,?,?,?,?,?,?)";
		 var result_len=res.rows.length;
//		 alert(result_len);
		 	if(result_len){//更新
		 		 db_execut_oneSQL(null,sql_upnm,['{"检查日期":"'+$('#chk_date').val()+'","检查结果":"'+$('#chk_rslt').val()+'","用户签字":"'+$('#signature').val()+'","有无违约用电窃电行为":"'+text1[0][(violate_flag_val-1)]+'","有无设备缺陷":"'+text1[1][(equip_defect_flag_val-1)]+'","有无计量异常":"'+text1[2][(mr_excp_flag_val-1)]+'","有无电价执行错误":"'+text1[3][(prc_mistake_flag_val-1)]+'","存在问题":"'+$('#problem_2').val()+'","用户意见":"'+$('#cons_opinion').val()+'"}',"2",cons_info.dtl_id,cons_info.cons_id,"A0011"],null,null);
		 	}else{//插入
		 		 db_execut_oneSQL(null,sql_insert,["A0011","检查结果维护","2","",json_olddata,'{"检查日期":"'+$('#chk_date').val()+'","检查结果":"'+$('#chk_rslt').val()+'","用户签字":"'+$('#signature').val()+'","有无违约用电窃电行为":"'+text1[0][(violate_flag_val-1)]+'","有无设备缺陷":"'+text1[1][(equip_defect_flag_val-1)]+'","有无计量异常":"'+text1[2][(mr_excp_flag_val-1)]+'","有无电价执行错误":"'+text1[3][(prc_mistake_flag_val-1)]+'","存在问题":"'+$('#problem_2').val()+'","用户意见":"'+$('#cons_opinion').val()+'"}',cons_info.dtl_id,cons_info.cons_id],null,null);
		 	}
	 }
/*查询失败回调*/
var savefailCB1=function(){
//	 alert("shibai ");
}

var thisTid = "";//ASSET_NO	移动终端编号
getTid(function(e){thisTid =e;},null);

var pic_infos=new Array();
//上装--重要用户
function upload_statu5(){
    console.log("=========================================="+pic_name[4]);
	var pic_chk_file=setUndefined(pic_name[4]);
	pic_chk_file = pic_chk_file.replace("jpg","zip");//将jpg替换为zip
	opendailog("businessList_laoding_view");//弹出加载效果框
	//经度纬度
	var LONGITUDE = setUndefined(yj_s_inspect_rslt.LONGITUDE);
	var LATITUDE = setUndefined(yj_s_inspect_rslt.LATITUDE);
	
	var SCAN_FLAG = compare_assetNo_type =="01"?"1":(compare_assetNo_type=="00"?"2":"0");//未扫描（0）,扫描匹配（1）,扫描未匹配（2）
	var PHOTO_FLAG = pic_chk_file==""?"0":"1";//（0无图片，1有图片）
	var GPS_FLAG = LONGITUDE==""?"0":"1";//0未定位，1已定位
	var d = new Date();
	var localTime = d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()+" "+d.toLocaleTimeString()//本地当前时间
	localTime = "";

	//发送电表扫描比对数据.
	var PKG1='{"MOD":"04","FUN":"01","PKG_TYPE":"0","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"APP_NO":"'+sessionStorage.APP_NO_bl+'","CONS_NO":"'+cons_info.cons_no+'","FLOOR":"1","LONGITUDE":"'+LONGITUDE+'","LATITUDE":"'+LATITUDE+'","ZT":"'+compare_assetNo_type+'"}}'
    send_data("0000","2001",PKG1,null,null);
	
	//更新用户状态为为上装（初始值是0 ，未上装是1，上装成功是2）
	db_execut_oneSQL(null,"update yj_c_cons set uploading_type=? where DTL_ID=? and CONS_ID=?",["1",cons_info.dtl_id,cons_info.cons_id],null,null);
	var PKG='{"MOD":"2003","FUN":"2301","LEN":39,"ORG_NO":"'+sessionStorage.ORG_NO+'","APP_NO":"'+sessionStorage.APP_NO_bl+'","CONS_NO":"'+cons_info.cons_no+'","USR":"'+sessionStorage.user_name+'","PKG":{"ID":"'+cons_info.cr_id+'","DTL_ID":"'+cons_info.dtl_id+'","CONS_NO":"'+cons_info.cons_no+'","CHK_DATE":"'+$('#chk_date_01').val()+'","CHK_RSLT":"'+chk_res_val+'","PROBLEM":"'+$('#problem_01').val()+'","CONS_OPINION":"'+$('#cons_opinion_01').val()+'","VIOLATE_FLAG":"'+violate_flag_val+'","EQUIP_DEFECT_FLAG":"'+equip_defect_flag_val+'","MR_EXCP_FLAG":"'+mr_excp_flag_val+'","PRC_MISTAKE_FLAG":"'+prc_mistake_flag_val+'","PRIO_CODE":"","HANDLE_FLAG":"","FINAL_CONC":"","CHK_FILE":"'+pic_chk_file+'","MODIFY_SUGGEST":"","ASSIGNER":"","ASSIGN_TIME":"","SIGNATURE":"'+$('#signature_01').val()+'","LONGITUDE":"'+LONGITUDE+'","LATITUDE":"'+LATITUDE+'","SCAN_FLAG":"'+SCAN_FLAG+'","PHOTO_FLAG":"'+PHOTO_FLAG+'","GPS_FLAG":"'+GPS_FLAG+'","ASSET_NO":"'+thisTid+'","UPDATE_TIME":"'+localTime+'"}}'
	send_data("2301","2003",PKG,successCallBack,faileCallBack);
	//上装成功回调
	function successCallBack(message_ener){
		$("#businessList_laoding_view").hide();//关闭加载效果框
		var msg_enercb = JSON.parse(message_ener);
		if(msg_enercb.RET=="00"){
			var msg_pkg=msg_enercb.PKG.PKG;
			var fun=msg_enercb.FUN;
			if(msg_pkg.SUCCESS_FLAG=="0"){
					insert_success_2();//弹出上装成功框
					//检查结果维护变更
					if(fun=="2301"){
			        	localStorage["uploading"+sessionStorage.APP_NO_bl+cons_info.dtl_id] = 1;//用户列表 图标状态（处理中 处理完成）
			        	//更新上装状态
			        	db_execut_oneSQL(null,"update yj_c_cons set uploading_type=? where DTL_ID=? and CONS_ID=?",["2",cons_info.dtl_id,cons_info.cons_id],null,null);
		        		//更新执行状态
						db_execut_oneSQL(null,"update YJ_S_CHK_PLAN_DET set PLAN_STATUS_CODE=? where DTL_ID=? and CONS_ID=?",["08",cons_info.dtl_id,cons_info.cons_id],null,null);
					}
			}else{
                    if(msg_pkg.ERR_MSG){
                        aeMsgShow(msg_pkg.ERR_MSG);
                    }else{
                        aeMsgShow("上装失败");
                    }
                }
		}else{
				aeMsgShow("上装失败!数据保存本地");
		}
	}
	//上装失败回调
	function faileCallBack(){
	    db_execut_oneSQL(null,"update yj_c_cons set uploading_type=? where DTL_ID=? and CONS_ID=?",["1",cons_info.dtl_id,cons_info.cons_id],null,null);
		var pkgp="";
		var msg_ti_str = '{"DTL_ID":"'+cons_info.dtl_id+'","CONS_ID":"'+cons_info.cons_id+'","MSG":"检查结果实体记录上装失败","PKG":'+PKG+',"ERROR_ID":"2301"}';
			pkgp=PKG;
			upload_Data("2301","2003",pkgp,msg_ti_str,"yj_upload_proc");
		setTimeout(function(){
			$("#businessList_laoding_view").css("display","none");//关闭加载效果框
			aeMsgShow("数据进入到上装队列，等待上装！");
		 },500);
	}
}

//上装--非重要用户
function upload_statu5_un(){
    console.log("=========================================="+pic_name[4]);
	var pic_chk_file=setUndefined(pic_name[4]);
	pic_chk_file = pic_chk_file.replace("jpg","zip");//将jpg替换为zip
	opendailog("businessList_laoding_view");//弹出加载效果框
	
	//经度纬度
	var LONGITUDE = setUndefined(yj_s_inspect_rslt_un.LONGITUDE);
	var LATITUDE = setUndefined(yj_s_inspect_rslt_un.LATITUDE);
	
	var SCAN_FLAG = compare_assetNo_type =="01"?"1":(compare_assetNo_type=="00"?"2":"0");//未扫描（0）,扫描匹配（1）,扫描未匹配（2）
	var PHOTO_FLAG = pic_chk_file==""?"0":"1";//（0无图片，1有图片）
	var GPS_FLAG = LONGITUDE==""?"0":"1";//0未定位，1已定位
	var d = new Date();
	var localTime = d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()+" "+d.toLocaleTimeString()//本地当前时间
	localTime = "";
	
	//发送电表扫描比对数据.
    var PKG1='{"MOD":"04","FUN":"01","PKG_TYPE":"0","ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"APP_NO":"'+sessionStorage.APP_NO_bl+'","CONS_NO":"'+cons_info.cons_no+'","FLOOR":"1","LONGITUDE":"'+LONGITUDE+'","LATITUDE":"'+LATITUDE+'","ZT":"'+compare_assetNo_type+'"}}'
    send_data("0000","2001",PKG1,null,null);
	
    //更新用户状态为为上装（初始值是0 ，未上装是1，上装成功是2）
	db_execut_oneSQL(null,"update yj_c_cons set uploading_type=? where DTL_ID=? and CONS_ID=?",["1",cons_info.dtl_id,cons_info.cons_id],null,null);
	var PKG='{"MOD":"2003","FUN":"2301","LEN":39,"ORG_NO":"'+sessionStorage.ORG_NO+'","APP_NO":"'+sessionStorage.APP_NO_bl+'","CONS_NO":"'+cons_info.cons_no+'","USR":"'+sessionStorage.user_name+'","PKG":{"ID":"'+cons_info.cr_id+'","DTL_ID":"'+cons_info.dtl_id+'","CONS_NO":"'+cons_info.cons_no+'","CHK_DATE":"'+$('#chk_date').val()+'","CHK_RSLT":"'+chk_res_val+'","PROBLEM":"'+$('#problem_2').val()+'","CONS_OPINION":"'+$('#cons_opinion').val()+'","VIOLATE_FLAG":"'+violate_flag_val+'","EQUIP_DEFECT_FLAG":"'+equip_defect_flag_val+'","MR_EXCP_FLAG":"'+mr_excp_flag_val+'","PRC_MISTAKE_FLAG":"'+prc_mistake_flag_val+'","PRIO_CODE":"","HANDLE_FLAG":"","FINAL_CONC":"","CHK_FILE":"'+pic_chk_file+'","MODIFY_SUGGEST":"","ASSIGNER":"","ASSIGN_TIME":"","SIGNATURE":"'+$('#signature').val()+'","LONGITUDE":"'+LONGITUDE+'","LATITUDE":"'+LATITUDE+'","SCAN_FLAG":"'+SCAN_FLAG+'","PHOTO_FLAG":"'+PHOTO_FLAG+'","GPS_FLAG":"'+GPS_FLAG+'","ASSET_NO":"'+thisTid+'","UPDATE_TIME":"'+localTime+'"}}'
	send_data("2301","2003",PKG,successCallBack,faileCallBack);
	//上装成功回调
	function successCallBack(message_ener){
		$("#businessList_laoding_view").hide();//关闭加载效果框
		var msg_enercb = JSON.parse(message_ener);
		if(msg_enercb.RET=="00"){
			var msg_pkg=msg_enercb.PKG.PKG;
			var fun=msg_enercb.FUN;
			if(msg_pkg.SUCCESS_FLAG=="0"){
					insert_success_2();//弹出上装成功框
					//检查结果维护变更
					if(fun=="2301"){
			        	localStorage["uploading"+sessionStorage.APP_NO_bl+cons_info.dtl_id] = 1;//上装状态
			        	//更新上装状态
			        	db_execut_oneSQL(null,"update yj_c_cons set uploading_type=? where DTL_ID=? and CONS_ID=?",["2",cons_info.dtl_id,cons_info.cons_id],null,null);
			        	//更新执行状态
						db_execut_oneSQL(null,"update YJ_S_CHK_PLAN_DET set PLAN_STATUS_CODE=? where DTL_ID=? and CONS_ID=?",["08",cons_info.dtl_id,cons_info.cons_id],null,null);
					}
			}else{
                    if(msg_pkg.ERR_MSG){
                        aeMsgShow(msg_pkg.ERR_MSG);
                    }else{
                        aeMsgShow("上装失败");
                    }
            }
		}else{
				aeMsgShow("上装失败!数据保存本地");
		}
	}
	//上装失败回调
	function faileCallBack(){
	    db_execut_oneSQL(null,"update yj_c_cons set uploading_type=? where DTL_ID=? and CONS_ID=?",["1",cons_info.dtl_id,cons_info.cons_id],null,null);
		var pkgp="";
		var msg_ti_str = '{"DTL_ID":"'+cons_info.dtl_id+'","CONS_ID":"'+cons_info.cons_id+'","MSG":"检查结果实体记录上装失败","PKG":'+PKG+',"ERROR_ID":"2301"}';
			pkgp=PKG;
			upload_Data("2301","2003",pkgp,msg_ti_str,"yj_upload_proc");
		setTimeout(function(){
			$("#businessList_laoding_view").css("display","none");//关闭加载效果框
			aeMsgShow("数据进入到上装队列，等待上装！");
		 },500);
	}
}
/**
 * 提示信息
 */
function aeMsgShow(msg){
    $("#yxzypt_msg").html(msg);//给弹出框赋对应的提示消息
    onchange_val();
    $("#yxzypt_dailog").show();
}

</script>