<script>
// *******GPS js*********//
var updatelist = new Array();

var pkglist = new Array()

var jd_val = ""; //经度

var wd_val = "";//纬度

var gpsxsdate = new Array();// GPS相关信息

var GpsUploadFlag = false;//GPS定位成功，并成功上装数据到营销系统标志

function check_GPS() {
	  get_GPS_info(300, function(str) {	// 获取GPS
			
			jd_val = str.slice(0, str.indexOf(","));// 经度
			
			wd_val = str.slice(str.indexOf(",") + 1);// 纬度
		    
			
		   if(jd_val == "0.0" || wd_val =="0.0"){
		   		msgInfo("GPS获取失败");//对话框弹出显示经纬度
                return;
            }
			select_NullGpsInfo();// 组装 Gps的updatahe 和 pgk
			
		}, function(e) {// 获取失败
			msgInfo(e);
		});
}


//查询NULL的 Gps ,组装sql和pkg上装
function select_NullGpsInfo() {
	 $("#jlzz_zk_dhk_laoding_view").show();
	var search_sql = "SELECT LONGITUDE,LATITUDE,MP_ID  FROM  YJ_MP_CONS  WHERE DTL_ID=? and (LONGITUDE isnull or LONGITUDE='') ";
	db_execut_oneSQL(null, search_sql, [cons_info.dtl_id], function(tx, res) {//查询出Gps为空的计量点信息
		if(res.rows.length>0){//有计量点gps信息
			var mpidgps;
			for (var s = 0; s < res.rows.length; s++) {
				
				mpidgps = setUndefined(res.rows.item(s).MP_ID);
				updatelist.push("UPDATE YJ_MP_CONS SET LONGITUDE='"+jd_val+"' , LATITUDE='"+wd_val+"'  WHERE DTL_ID="+cons_info.dtl_id+" AND MP_ID="+mpidgps);
				var pkg = "{'MP_ID':'" + mpidgps + "','floor':'1','longitude':'" + jd_val + "','latitude':'" + wd_val + "'}";
				var data = "{'MOD':'2003','FUN':'2916','LEN':" + pkg.length+ ",'PKG':" + pkg + "}";
				pkglist.push(data);
				
				if(s == res.rows.length-1){
					updataGps_uploadGps();//组装完成后开始更新上装
				}
			 }
		}else{//无gps信息
			save_gps_to_finish(jd_val, wd_val);// 经纬度存入检查结果维护数表
			 $("#jlzz_zk_dhk_laoding_view").hide();
			msgInfo("GPS校正成功");
		}
	},null);
}

//更新GPS并上装
function updataGps_uploadGps(){
	try{
		if(updatelist.length>0){
			 var ydjc = window.sqlitePlugin.openDatabase("ydjc.db", "1.0","ydjc.db", 10*1024*1024);
			 ydjc.transaction(function(tx){
			 		for(var i=0;i<updatelist.length;i++){
					 tx.executeSql(updatelist[i],[],function(tx,res){
						if(i==updatelist.length-1){
							//插入结束。开始更新插入标志
							 updatelist=new Array();
						}
					 },null);
			 	}
		 	});
 		}
 		if(pkglist.length>0){
 			 msgInfo("GPS获取成功。<br />经度：" + jd_val.slice(0,10) + "°<br /> 纬度：" + wd_val.slice(0,10) + "° <br /> 正在上装，请稍候...");//对话框弹出显示经纬度
		 	 var flag_state = false;//为true表示其中有gps上装成功,为false表示全部上装失败
		 	 var flag_state1 = 0;
		 	for(var i = 0; i<pkglist.length;i++){
					send_data("1001", "2003", pkglist[i], function(e) {
							flag_state1++;
							flag_state=true;
							if(flag_state1==pkglist.length){
								//插入结束。开始更新插入标志
								 pkglist=new Array();
								 save_gps_to_finish(jd_val, wd_val);// 经纬度存入检查结果维护数表
								 $("#jlzz_zk_dhk_laoding_view").hide();
								 msgInfo("GPS校正成功");
							}
					},function(){
							flag_state1++;
							if(flag_state1 == pkglist.length && flag_state){
								  save_gps_to_finish(jd_val, wd_val);// 经纬度存入检查结果维护数表
								  pkglist=new Array();
								  $("#jlzz_zk_dhk_laoding_view").hide();
								  msgInfo("GPS校正成功");
							}else if(flag_state1 == pkglist.length && !flag_state){
								  $("#jlzz_zk_dhk_laoding_view").hide();
								  pkglist=new Array();
								  msgInfo("Gps上装失败");
							}
					});
		 	}
 		}
	}catch(e){
		$("#jlzz_zk_dhk_laoding_view").hide();
		msgInfo("Gps上装失败");
	}
}

// 经纬度存入检查结果维护数据库
function save_gps_to_finish(s, t) {
	var update_sql = "UPDATE YJ_S_INSPECT_RSLT SET LONGITUDE=? , LATITUDE=?  WHERE DTL_ID=?";
	db_execut_oneSQL(null, update_sql, [s, t, cons_info.dtl_id], null, null);
}

//弹出框
function msgInfo(msg){
		$("#yxzypt_msg").html("");
		$("#yxzypt_msg").html(msg);//给弹出框赋对应的提示消息
		onchange_val();
		$("#yxzypt_dailog").show();
}
/*验证Gps是否需要校对*/

function checkResultGpsStatues(callback){
		var sql1 = "SELECT LONGITUDE,LATITUDE FROM YJ_S_INSPECT_RSLT WHERE DTL_ID=?";
		db_execut_oneSQL(null, sql1, [cons_info.dtl_id], function(tx, res) {
			if(setUndefined(res.rows.item(0).LONGITUDE) != "" && setUndefined(res.rows.item(0).LONGITUDE)!="0.0"){//计量点GPS上装成功后才将gps值插入YJ_S_INSPECT_RSLT
				GpsUploadFlag = true;//当不为0.0和空表示计量点GPS获取并上装成功过。
			}else{
				GpsUploadFlag = false;
			}
			callback();
			return;
		},null)
}


</script>


