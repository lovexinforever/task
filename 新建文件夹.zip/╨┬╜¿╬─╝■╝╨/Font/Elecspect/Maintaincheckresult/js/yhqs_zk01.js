<script type="text/javascript">
/**
 * 通过申请编号获得用户签收记录
 * @param app_no 申请编号
 * @return
 */
		function get_yhqs(app_no,initPage_yhqszk){
			var sql=" select * from YJ_S_APP_REPLY where APP_NO=?";
	    	db_execut_oneSQL(null,sql,[app_no],initPage_yhqszk,null);
		}
</script>