<script type="text/javascript">

var ydjc_assetNo="";//扫描到的电表资产编号
sessionStorage.btsmsb = 0;//蓝牙设备连接标志，0失败，1成功
var msg_length = 0;
var msg_size = 0;
//点击扫描按钮
$("#test_Btsm").click(function(){
    //alert("=sessieonStorage.btsmsb=="+sessionStorage.btsmsb);
    //先断开与扫描设备的连接
    if(sessionStorage.btsmsb==1){
        bluetooth_disconnect(function(e){
                sessionStorage.btsmsb =0;//蓝牙设备连接失败
                //showToast("设备已断开连接")
        });
    }else{
        //再连接蓝牙设备
        connectBtsm();
    }
});

//蓝牙扫描设备电源关闭后，回调方法，设备已断开连接
function changeState(e){
    // 断开与扫描设备的连接
    bluetooth_disconnect(function(e){
        if(e.msg == 1) {
                sessionStorage.btsmsb =0;//蓝牙设备连接失败
                showToast("设备已断开连接");
                connectBtsm(); //先断开，再连接蓝牙设备
        }
    });
}
//蓝牙扫描连接
function connectBtsm(){
    bluetooth_conn(function(e){
            if(e.msg == 1){
                sessionStorage.btsmsb=1;//蓝牙设备连接成功
            }else{
                sessionStorage.btsmsb =0;//蓝牙设备连接失败
                showToast("与扫描设备连接失败,请重连!");
            }
    });
}

//蓝牙扫描连接成功后，扫描后处理得到的资产编号
function get_barcode(e){
            var barcode = (e).replace(/[\r\n]/g, "");//去掉换行
            barcode = getlastassetno1(barcode);
            if(barcode.length > 10) {
                barcode = barcode.substring((barcode.length - 10), barcode.length);
            }
            ydjc_assetNo=barcode;
            //alert(ydjc_assetNo+"===ydjc_assetNo");
            //扫描到资产编号后，查询数据库
            db_execut_oneSQL(null,"select ASSET_NO from yj_mp_meter where DTL_ID=? and ASSET_NO=?",[cons_info.dtl_id,ydjc_assetNo],function(tx,res){
                var len=res.rows.length;
                if(len>0){
                    compare_assetNo_type="01";//匹配到资产编号
                    $("#asset_noBtsm").val("扫描电表匹配成功!扫描电表资产编号为:"+ydjc_assetNo);
                    //showToast("与资产编号为:"+ydjc_assetNo+"的电表匹配成功");
                }else{
                    compare_assetNo_type="00";//没有匹配到资产编号
                    $("#asset_noBtsm").val("扫描电表匹配失败!扫描电表资产编号为:"+ydjc_assetNo);
                    //showToast("与资产编号为:"+ydjc_assetNo+"的电表匹配失败");
                }
                //alert(compare_assetNo_type+"=compare_assetNo_type");
                db_execut_oneSQL(null,"update YJ_S_INSPECT_RSLT set ZT=? where dtl_id=? and cr_id=?",[compare_assetNo_type,cons_info.dtl_id,cons_info.cr_id],null,null);
            },null);
}

/************处理资产编号****************/
function getlastassetno1(assetno) {
    if(!sessionStorage.ORG_NO) {
        sessionStorage.ORG_NO = "3240101";
    }
    var ass_org = assetNoHandle(sessionStorage.ORG_NO, assetno);
    return ass_org;
}

//电能表p_code
//老资产编号前缀
var g_ASSET_NO_PREFIX = new Object();
g_ASSET_NO_PREFIX["32101"] = "";
g_ASSET_NO_PREFIX["32401"] = "A";
g_ASSET_NO_PREFIX["32402"] = "B";
g_ASSET_NO_PREFIX["32403"] = "C";
g_ASSET_NO_PREFIX["32404"] = "D";
g_ASSET_NO_PREFIX["32405"] = "E";
g_ASSET_NO_PREFIX["32406"] = "F";
g_ASSET_NO_PREFIX["32407"] = "G";
g_ASSET_NO_PREFIX["32408"] = "H";
g_ASSET_NO_PREFIX["32409"] = "J";
g_ASSET_NO_PREFIX["32410"] = "K";
g_ASSET_NO_PREFIX["32411"] = "L";
g_ASSET_NO_PREFIX["32412"] = "M";
g_ASSET_NO_PREFIX["32413"] = "N";
    
var g_asset_no_type="07";
function assetNoHandle(orgNo, assetNo) {
    var str=assetNo.indexOf("-");
    if(str!=-1){
        assetNo=assetNo.substring(0,str);
    }
    assetNo = assetNo.replace(/[ ]/g, "");
    // 去掉前面与后面的空格
    orgNo = orgNo.replace(/[ ]/g, "");
    var sResult = assetNo + "";

    if(assetNo.length == 13) {
        g_asset_no_type="97";
        sResult = g_ASSET_NO_PREFIX[orgNo.substr(0, 5)] + assetNo.substring(4, assetNo.length);
    }else if(assetNo.length == 22) {
        g_asset_no_type="07";
        // 截取第12位到第21位共10位作为资产编号
        sResult = assetNo.substr(11, 10);
    }
    return sResult;
}
/************处理资产编号结束****************/
//点击更新电表信息按钮
$("#test_Btud").click(function(){
	//opendailog("businessList_laoding_view");
	$("#businessList_laoding_view").show();//弹出加载效果框
	var PKG='{"MOD":"2003","FUN":"1014","LEN":39,"ORG_NO":"'+sessionStorage.ORG_NO+'","PKG":{"CONS_ID":"'+cons_info.cons_id+'","DTL_ID":"'+cons_info.dtl_id+'"}}'
	send_data("1014","2003",PKG,function(e){
		
		var msg = JSON.parse(e);
		    
		if(msg==null){
			$("#businessList_laoding_view").hide();//关闭加载效果框
	          $("#yxzypt_msg").html("无数据可更新，已是最新数据！");//给弹出框赋对应的提示消息
	          onchange_val();
	          $("#yxzypt_dailog").show();
	          return;
		}
		msg = msg.PKG.PKG.YJ_MP_METER;
		
		var sqldArray = new Array();		
		var param = new Array();
		msg_size = msg.length;
		for(var i = 0;i < msg.length; i++){	
			
			var msgi = msg[i];
			param.push(null);
			sqldArray.push("delete from YJ_MP_METER where DTL_ID="+msg[i].DTL_ID+" and METER_ID="+msg[i].METER_ID);
		}
		db_batch_data(null,sqldArray,param,function(tx,res){
			
			$("#businessList_laoding_view").hide();//关闭加载效果框
		},function(e){
			
			$("#businessList_laoding_view").hide();//关闭加载效果框
		});
	
		for(var i =0;i<msg.length; i++){
			upDateMessage(msg[i]);		
		};

	},function(e){
		
		$("#businessList_laoding_view").hide();//关闭加载效果框
		$("#yxzypt_msg").html("网络连接异常！");//给弹出框赋对应的提示消息
        onchange_val();
        $("#yxzypt_dailog").show();		
		
	}); 
});

function upDateMessage(msg){
	db_execut_oneSQL(null,"insert into YJ_MP_METER (MP_ID,MADE_DATE,MANUFACTURER,METER_ID,DTL_ID,ASSET_NO) values (?,?,?,?,?,?)",[msg.MP_ID,msg.MADE_DATE,msg.MANUFACTURER,msg.METER_ID,msg.DTL_ID,msg.ASSET_NO],function(tx,res){	
		msg_length++;
		if(msg_length==msg_size){
		   msg_length=0;
		$("#businessList_laoding_view").hide();//关闭加载效果框
		$("#yxzypt_msg").html("数据更新成功！");//给弹出框赋对应的提示消息
        onchange_val();
        $("#yxzypt_dailog").show();		
		}
	},function(e){
		$("#businessList_laoding_view").hide();//关闭加载效果框
	});
	$("#businessList_laoding_view").hide();//关闭加载效果框);
}
</script>