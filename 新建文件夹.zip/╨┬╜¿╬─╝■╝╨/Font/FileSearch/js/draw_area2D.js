//2D面积图数据模型
function setArea2D_data(){
	var area2D_data={
		render: '',
		data: '',
		animation :true,
		border:{
			enable:false
		},
		align: 'center',
		title: '',
		footnote: '',
		width: 400,
		height: 400,
		background_color: null,
		legend:{
			enable : false,
			row:1,
			column : 'max',
			valign:'top',
			sign:'bar',
			background_color:null,
			offsetx:-80,
			border : true
		},
		tip:{
				enable : true,
				listeners:{
					//tip:提示框对象、name:数据名称、value:数据值、text:当前文本、i:数据点的索引
					parseText:function(tip,name,value,text,i){
						return "地区:北京"+"<br/>平均温度:20℃";
					}
				},
				type:"fixed"
		},crosshair:{
					enable:true,
					line_color:'#62bce9',
					line_width:2
				},
		sub_option:{
			label:false,
			area_color:function(T){
				return T.avgLinearGradient(this.x,this.y,this.x,this.y-this.get('height'),['rgba(255,255,255,0)','rgba(255,255,255,0)']);
			},
			point_size:0,
			hollow_inside: false
		},
		danwei:'%',
		coordinate:{
			width:300,
			height:180,
			axis:{
				color:'#dcdcdc',
				width:0
			},
			scale2grid: false,
			grids:{
                 horizontal:{
                   way:'share_alike',
                   value:8
                 }
            }, 
			scale:[{
				   position:'left',	
				   start_scale:100,
					end_scale:0,
					scale_space:0,
					scale_size:0,

				   label: {
						color: '#9da4b5',
						fontsize: 25,
						font:'微软雅黑',
						fontweight: 120
					}
					
				},{
				   position:'bottom',	
				   labels:'',
				   label: {
						color: '#9da4b5',
						fontsize: 16,
						font:'微软雅黑',
						fontweight: 100
					}
				}]
		}
	};
	return area2D_data;
}


//绘制2D面积图
function drawArea2D(area2D_data){
	var chart =  new iChart.Area2D({
		listeners:{
				/**
				* d:相当于data[0],即是一个线段的对象
				* v:相当于data[0].value
				* x:计算出来的横坐标
				* x:计算出来的纵坐标
				* j:序号 从0开始 
				*/
				parsePoint:function(d,v,x,y,j){
					return {ignored:(v==0)}//ignored为true表示忽略该点
				}
			},
		render: area2D_data.render,
		data: area2D_data.data,
		animation: area2D_data.animation,
		border:{
			enable: area2D_data.border.enable
		},
		align: area2D_data.align,
		title: area2D_data.title,
		footnote: area2D_data.footnote,
		width: area2D_data.width,
		height: area2D_data.height,
		background_color: area2D_data.background_color,
		legend:{
			enable: area2D_data.legend.enable,
			row: area2D_data.legend.row,
			column: area2D_data.legend.column,
			valign: area2D_data.legend.valign,
			sign: area2D_data.legend.sign,
			background_color: area2D_data.legend.background_color,
			offsetx: area2D_data.legend.offsetx,
			border: area2D_data.legend.border
		},tip:{
				enable : area2D_data.tip.enable,
				listeners:{
					//tip:提示框对象、name:数据名称、value:数据值、text:当前文本、i:数据点的索引
					parseText:area2D_data.tip.text
				},
				type:area2D_data.tip.type
		},crosshair:{
					enable:area2D_data.crosshair.enable,
					line_color:area2D_data.crosshair.line_color,
					line_width:area2D_data.crosshair.line_width
				},
		sub_option:{
			label: area2D_data.sub_option.label,
			area_color: area2D_data.sub_option.area_color,
			point_size: area2D_data.sub_option.point_size,
			hollow_inside: area2D_data.sub_option.hollow_inside
		},
		coordinate:{
			
			width: area2D_data.coordinate.width,
			height: area2D_data.coordinate.height,
			axis:{
				color: area2D_data.coordinate.axis.color,
				width: area2D_data.coordinate.axis.width
			},
			scale2grid: area2D_data.coordinate.scale2grid,
			grids:{
                 horizontal:{
                   way: area2D_data.coordinate.grids.horizontal.way,
                   value: area2D_data.coordinate.grids.horizontal.value
                 }
            }, 
			scale:[{
				position: area2D_data.coordinate.scale[0].position,
				start_scale: area2D_data.coordinate.scale[0].start_scale,
				end_scale: area2D_data.coordinate.scale[0].end_scale,
				scale_space: area2D_data.coordinate.scale[0].scale_space,
				scale_size: area2D_data.coordinate.scale[0].scale_size,
				label:{
					color:  area2D_data.coordinate.scale[0].label.color,
					fontsize: area2D_data.coordinate.scale[0].label.fontsize,
					font: area2D_data.coordinate.scale[0].label.font,
					fontweight: area2D_data.coordinate.scale[0].label.fontweight
				}
				
			},{
				position: area2D_data.coordinate.scale[1].position,
				labels: area2D_data.coordinate.scale[1].labels,
				label: {
					color: area2D_data.coordinate.scale[1].label.color,
					fontsize: area2D_data.coordinate.scale[1].label.fontsize,
					font: area2D_data.coordinate.scale[1].label.font,
					fontweight: area2D_data.coordinate.scale[1].label.fontweight
				}
			}]
		}
	});
	chart.plugin(new iChart.Custom({
		drawFn:function(){
			//计算位置
			var coo = chart.getCoordinate(),
			x = coo.get('originx'),
			y = coo.get('originy'),
		    w = coo.get('width'),
			h = coo.get('height');
			//在左上侧的位置，渲染一个单位的文字
			chart.target.textAlign('start')
			.textBaseline('bottom')
			.textFont('600 14px Verdana')
			.fillText(area2D_data.danwei,x-20,y-14,false,'#9da4b5');
						
		}
	}));
	chart.draw();
}