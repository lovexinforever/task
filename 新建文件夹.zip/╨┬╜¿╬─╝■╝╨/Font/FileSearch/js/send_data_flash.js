var Send_Data_flash=function(){
	
};

Send_Data_flash.prototype.send_Data_flash=function(argument,successCallBack,faileCallBack){
	return PhoneGap.exec(successCallBack,faileCallBack,'Send_data_flashPlugin_yczl','action_send_data_flash',[argument])
}

cordova.addConstructor(function() {
	cordova.addPlugin("send_data_flash", new Send_Data_flash());
	});

/**
 * 用电趋势请求
 */
function send_data_flash(dat,successCallBack,faileCallBack){
	var intercept = localStorage.ACHIEVE_URL;
	var data = intercept+dat;	
	window.plugins.send_data_flash.send_Data_flash(data,successCallBack,faileCallBack);	
}


 

 