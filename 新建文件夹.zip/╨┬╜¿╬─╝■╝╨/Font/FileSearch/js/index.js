// JavaScript Document
var windowheight=0;
var topheight=0;
var TabIndex = 0;
var leftMenuStates = true;
var deviceIdList = [];
var userIdList = [];
var elecIdList = [];
var inputNO = '';
var listIndex = 0;
var leftNum = 0;
//点击左侧树中的用户获取的数据
var userData_user=[];
var indexDeviceData = '';
var cx_elec_data="";
var cx_elec_dataList = [];
var indexDeviceDataList = [];
var elec_title_str="";
$(function(){
	business_com.loadToolKit();
	$(".sbutton").click(function(e) {
		$(".menu_inner>li").html("");
		indexDeviceData = '';
		userData_user=[];
		cx_elec_data="";
		leftNum +=1;
		deviceIdList = [];
		userIdList = [];
		elecIdList = [];
		leftMenuStates = true;
		cx_elec_dataList = [];
		indexDeviceDataList = [];
        var queryText = $(".search_select").text().trim();
		inputNO = $(".sinput > input").val().trim();
		if(inputNO != ''){
			//$(".menu_inner>li").html("");
			if("用户编号" == queryText ) {
				TabIndex = 0;
				$("#contenmlist").load('../user/user.html');
			}else if("终端资产号" == queryText){
				TabIndex =1;
				$("#contenmlist").load('../terminal/teminal.html');
			}else{
				TabIndex = 2;
				$("#contenmlist").load('../electricenergymeter/electricenergymeter.html');
			}
		}else{
			alert('请输入'+queryText);	
		}
		pagerefresh3();
    });
    
    //设置登录人及地市
    $("nav p:eq(1)").html(localStorage.area+"-"+localStorage.user_name_str+"-"+localStorage.user_name);
})
function get_barcode(barcode) {
	barcode = getlastassetno(barcode);
	var queryText = $(".search_select").text().trim();
	if("用户编号" != queryText){
		$(".menu_inner>li").html("");
		indexDeviceData = '';
		userData_user=[];
		cx_elec_data="";
		leftNum +=1;
		deviceIdList = [];
		userIdList = [];
		elecIdList = [];
		leftMenuStates = true;
		cx_elec_dataList = [];
		indexDeviceDataList = [];
		inputNO = barcode;
		$(".sinput > input").val(barcode);
		if(inputNO != ''){
			if("终端资产号" == queryText){
				TabIndex =1;
				$("#contenmlist").load('../terminal/teminal.html');
			}else{
				TabIndex = 2;
				$("#contenmlist").load('../electricenergymeter/electricenergymeter.html');
			}
		}
	}
}
//左侧菜单收缩
var slideDownUp = function(e){
	pagerefresh();		
	tabClass(e);
	var $this = $(e);
	var ul =$this.parent().children("ul");
	if ($this.hasClass("close")) {
		ul.slideDown();
		$this.removeClass("close").siblings("li").children("ul").slideUp().parent().addClass("close");
	}else{
		ul.slideUp();
		$this.addClass("close");
	}  	
}

//样式切换
var tabClass = function(e){
	//var $this = $(e);
	$(".m_top").css("background","#a7bdbd url(../images/z.png) left no-repeat")
	$(".left_user div").css("background","url(../images/u.png) 15px no-repeat")
	$(".leftElec li").css("background","url(../images/d.png) 30px no-repeat")
	//$(".menu_inner>li").find(".menu_checked").removeClass("menu_checked");
   // $this.addClass("menu_checked");
}

//页面滑动
var myScroll1,myScroll2
function loadscroll(){
	myScroll1 = new iScroll('leftmenue', {
		hScrollbar: false,
		vScrollbar: true,
		hideScrollbar:true
	});
	
	myScroll2 = new iScroll('rightmenue', {
		hScrollbar: false,
		vScrollbar: true,
		hideScrollbar:true
	});

}
//页面刷新
function pagerefresh(){
 setTimeout(function(){
   myScroll1.refresh();
   myScroll2.refresh();
 },500)
}
//页面重新加载

function pagerefresh3(){
	myScroll1.scrollTo(0,0)
	myScroll2.scrollTo(0,0)
setTimeout(function(){
   myScroll1.refresh();
   myScroll2.refresh();
 },500)

  // myScroll1.destroy()
   //myScroll2.destroy()
  // setTimeout(function(){
//	   loadscroll()
  // },500)
}
function pagerefresh4(){
	//myScroll2.scrollTo(0,0)
setTimeout(function(){
   myScroll2.refresh();
 },500)
}
function pagerefresh2(){
	pagerefresh3();
}
setTimeout(function(){
	windowheight=$("body").height()
	topheight=$(".toplist").height(); 
	$(".box").css("height",windowheight-topheight+"px");
	$(".left_menu").css("height",windowheight-topheight+"px");
	$(".rigth_content").css("height",windowheight-topheight+"px")
	setTimeout(function(){
      loadscroll();
	},500)
},500)
///////////////////////////
$(document).ready(function(e) {
//关闭对话框
var scenFlage=true
$("#changescren").click(function(){
	if(scenFlage){
		setTimeout(function(){scenFlage=false},500);
		$("#changescren").html("<<关闭菜单")
		$(".left_menu").css({"width":"278px","border-right":"2px solid #fff"})
	}else{
		setTimeout(function(){scenFlage=true},500);
		$("#changescren").html("<<展开菜单")
		$(".left_menu").css({"width":"0px","border-right":"0px solid #fff"})
	}
});
	$(".top_search div").click(function(){
		var getlistnum = $(".top_search div").index(this);
		$(".top_search div").removeClass("search_select");
		$(".top_search div:eq("+getlistnum+")").addClass("search_select");
		if(getlistnum==0){
			$(".sname").html("用户编号")
		}else if(getlistnum==1){
			$(".sname").html("终端资产号")
		}else if(getlistnum==2){
			$(".sname").html("电能表")
		}
	})
//加载内容
//终端档案'../terminal/teminal.html'
//电能表、用户用电视图 '../electricenergymeter/electricenergymeter.html'
//用户基本信息'../user/user.html'
//$("#contenmlist").load('../terminal/teminal.html');

})

function drawMenuHtml(data){
	try{
		if(TabIndex==0){
			leftMenuStates = true;
			userMenuHtml(data);
		}else if(TabIndex==1){
			leftMenuStates = true;
			deviceMenuHtml(data);
		}else if(TabIndex==2){
			leftMenuStates = true;
			elcMenuHtml(data);
		}
		if(leftMenuStates ){
			//点击左侧终端
			var states = true;
			$(".m_top").click(function() {
				if(states){
					
					leftMenuStates = false;
					//slideDownUp(this);
					listIndex = $(".m_top").index(this);
					//alert("终端"+deviceIdList[listIndex])
					tabClass(this);
					$(".m_top:eq("+listIndex+")").css("background","url(../images/z.png) left no-repeat,-webkit-gradient(linear, left top, left bottom, color-stop(0, #c8e4e4), color-stop(1, #fff), color-stop(2, #c8e4e4))")
					$("#contenmlist").load('../terminal/teminal.html')
					pagerefresh4();
					states = false;
					setTimeout(function(){
						states = true;
						leftMenuHide();
					},10);
				}
				
				//drawDeviceContentHtml(deviceIdList[listIndex]);
			});
			//点击左侧用户查询
			$(".left_user>div").click(function(){
				if(states){
					leftMenuStates = false;
					//slideDownUp(this);
					tabClass(this);
					listIndex = $(".left_user>div").index(this);
					//alert("用户"+listIndex)
					$(".left_user>div:eq("+listIndex+")").css("background","url(../images/u.png) 15px no-repeat,-webkit-gradient(linear, left top, left bottom, color-stop(0, #c8e4e4), color-stop(1, #fff), color-stop(2, #c8e4e4))");
					$("#contenmlist").load('../user/user.html');
					pagerefresh4();
					states = false;
					setTimeout(function(){
						states = true;
						leftMenuHide();
					},10);
				}
				
				//drawUserContentHtml(userIdList[listIndex]);
			});
			
			//点击左侧电能表
			$(".leftElec > li").click(function() {
				if(states){
					leftMenuStates = false;
					tabClass(this);
					listIndex = $(".leftElec > li").index(this);
					elec_title_str=$(".leftElec > li:eq("+listIndex+")").text();
					//alert("电能表"+listIndex);
					$(".leftElec > li:eq("+listIndex+")").css("background","url(../images/d.png) 30px no-repeat,-webkit-gradient(linear, left top, left bottom, color-stop(0, #c8e4e4), color-stop(1, #fff), color-stop(2, #c8e4e4))")
					$("#contenmlist").load('../electricenergymeter/electricenergymeter.html');
					pagerefresh4();
					states = false;
					setTimeout(function(){
						states = true;
						leftMenuHide();
					},10);
				}
				//drawElecContentHtml(elecIdList[listIndex]);
			});
		}
	}catch(e){
		
	}
}
function leftMenuHide(){
	setTimeout(function(){scenFlage=true},500);
		$("#changescren").html("<<展开菜单")
		$(".left_menu").css({"width":"0px","border-right":"0px solid #fff"})

}
//用户编号填充左边菜单
function userMenuHtml(jsonData) {
	try{
	var domStr = '';
	//终端信息
	var infoList = jsonData.tmnlInfoList;
	for(var i = 0; i < infoList.length; i++) {
		var temp = infoList[i];
		//用户信息
		var userInfo = temp.consInfoList;
		userData_user.push('');
		//电能表信息
		var meterList = userInfo.meterInfoList;
		deviceIdList.push(temp.TMNLASSETNO);
		userIdList.push(userInfo.CONSNO);
		indexDeviceDataList.push("");
		domStr += '<li><div class="m_top">' + temp.CPNAME + '</div><ul id="menu_1"><li class="left_user"><div style="background:url(../images/u.png) 15px no-repeat,-webkit-gradient(linear, left top, left bottom, color-stop(0, #c8e4e4), color-stop(1, #fff), color-stop(2, #c8e4e4))">' + userInfo.CONSNAME + '</div><ul id="menu_2"><li><ul id="menu_3" class="leftElec">';
		for(var j = 0; j < meterList.length; j++) {
			domStr += '<li>电能表' + (j + 1) + '</li>';
			cx_elec_dataList.push("");
			elecIdList.push(meterList[j].METERASSETNO);
		}
		domStr += '</ul></li></ul></li></ul></li>';
	}

	$(".menu_inner").html(domStr);
	pagerefresh();
	}catch(e){
		userData_user=[];
		$(".menu_inner").html("");
	}
}
//终端资产号查询左边菜单
function deviceMenuHtml(jsonData){
	try{
	var deviceData = jsonData.tmnlInfo;
	//alert(JSON.stringify(deviceData));
	deviceIdList.push(deviceData.TMNLASSETNO);
	var domStr = '<li><div class="m_top" style="background:url(../images/z.png) left no-repeat,-webkit-gradient(linear, left top, left bottom, color-stop(0, #c8e4e4), color-stop(1, #fff), color-stop(2, #c8e4e4))">' + deviceData.CPNAME + '</div><ul id="menu_1">';
	var userData = deviceData.consInfoList;
	var userLen = userData.length;
	for(var i=0;i<userLen;i++){
		userData_user.push('');
		userIdList.push(userData[i].CONSNO);
		domStr +='<li class="left_user"><div>'+userData[i].CONSNAME+'</div><ul id="menu_2"><li><ul id="menu_3" class="leftElec">';
		var elecData = userData[i].meterInfoList;
		var elecLen = elecData.length;
		for(var j=0;j<elecLen;j++){
			cx_elec_dataList.push("");
			elecIdList.push(elecData[j].METERASSETNO);
			domStr +='<li>电能表'+(j+1)+'</li>';	
		}
         domStr +=' </ul></li></ul></li>';
         	
	}
	domStr +='</ul></li>';
	$(".menu_inner").html(domStr);
	pagerefresh();
	}catch(e){
		console.log("终端资产号菜单异常："+e)
		indexDeviceData = '';
		$(".menu_inner").html("");
	}
}
//电能表查询左边菜单
function elcMenuHtml(jsonData){
	try{
	var domStr = '';
	var deviceData = jsonData.tmnlInfoList;
	var deviceLen = deviceData.length;
	for(var i=0;i<deviceLen;i++){
		userData_user.push('');
		indexDeviceDataList.push("");
		deviceIdList.push(deviceData[i].TMNLASSETNO);
		userIdList.push(deviceData[i].consInfo.CONSNO);
		elecIdList.push(deviceData[i].consInfo.meterInfoList.ASSETNO);
		domStr +='<li><div class="m_top">'+deviceData[i].CPNAME+'</div><ul id="menu_1"><li class="left_user"><div>'+deviceData[i].consInfo.CONSNAME+'</div><ul id="menu_2"><li><ul id="menu_3"  class="leftElec"> <li style="background:url(../images/d.png) 30px no-repeat,-webkit-gradient(linear, left top, left bottom, color-stop(0, #c8e4e4), color-stop(1, #fff), color-stop(2, #c8e4e4))">电能表1</li></ul></li></ul></li></ul></li>';
	}
	//alert(JSON.stringify(deviceIdList));
	console.log("电能表查询左菜单："+domStr);
	$(".menu_inner").html(domStr);
	pagerefresh();
	}catch(e){
		cx_elec_data="";
		$(".menu_inner").html("");
	}
}
function showMsg(){
	alert("当前用户没有权限！")	;
}