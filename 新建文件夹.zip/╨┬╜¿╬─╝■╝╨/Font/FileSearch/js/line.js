// JavaScript Document
/**************************************************************************************/
function  set_line2D_data(){
		var line2D_data = {
			render : '',
			data: '',
			labels:'',
			align:'center',
			border:{
				enable:false
			},
			animation:false,
			width : 440,
			height : 380,
			sub_option:{
				smooth : false,//平滑曲线
				hollow_inside:true,
				point_size:2,
				label:false
			},
			background_color:'rgba(0,0,0,0)',
			offsetx:0,
			offsety:0,
			listeners:0,
			coordinate:{
				width:370,
				height:280,
				background_color:'#fff',
				axis:{
					color:'#b1b1b1',
					width:[0,0,2,2]
				},
				scale:[{
					 position:'left',	
					 start_scale:0,
					 end_scale:60,
					 scale_space:10,
					 scale_size:2,
					 label: {
						color: '#9da4b5',
						fontsize: 25,
						font:'微软雅黑',
						fontweight: 120
					},
					 scale_color:'#9f9f9f',
					 
				},{
					 position:'bottom',	
					 labels:['0','','','','4','','','','8','','','','12','','','','16','','','','20','','','23'],
					 label: {
						color: '#9da4b5',
						fontsize: 16,
						font:'微软雅黑',
						fontweight: 100
					}
				},{
						 position:'right',	
						 start_scale:0,
						 scale_space:0.2,
						 end_scale:1,
						 scale_enable : false,
						 scaleAlign:'right',
						 label:false
					}]
			},
			label:{
				rotate:0,
				textBaseline:'middle',
				textAlign:'center',
				color:'#646464',
				fontsize:18,
				font:'微软雅黑',
				offsetx:0,
			},
			plugin:{
				textfont:'600 18px 微软雅黑',
				y_label:{
					name:'KW',
					color:'#939393'	
				},
				x_label:{
					name:'(时)',
					color:'#939393'	
				},
				left_label:''
			}
		}
		return line2D_data;
}
function drawHP_Line2D(line2D_data){
	var line = new iChart.LineBasic2D({
			render : line2D_data.render,
			data: line2D_data.data,
			align:line2D_data.align,
			border:{
				enable:line2D_data.border.enable
			},
			background_color:line2D_data.background_color,
			animation:line2D_data.animation,
			width : line2D_data.width,
			height : line2D_data.height,
			sub_option:{
				smooth : line2D_data.sub_option.smooth,//平滑曲线
				hollow_inside:line2D_data.sub_option.hollow_inside,
				point_size:line2D_data.sub_option.point_size,
				label:line2D_data.sub_option.label
			},
			offsetx:line2D_data.offsetx,
			offsety:line2D_data.offsety,
			listeners:{
				/**
				* d:相当于data[0],即是一个线段的对象
				* v:相当于data[0].value
				* x:计算出来的横坐标
				* x:计算出来的纵坐标
				* j:序号 从0开始 
				*/
				parsePoint:function(d,v,x,y,j){
					return {ignored:(v==line2D_data.listeners)}//ignored为true表示忽略该点
				}
			},
			crosshair:{
				enable:false,
				line_color:'#62bce9',
				line_width:2
			}, 
			tip:{
				enable : false,
				shadow:true,
				move_duration:400,
				border:{
				enable:true,
				radius : 5,
				width:2,
				color:'#3f8695'
				}, 
				listeners:{
					//tip:提示框对象、name:数据名称、value:数据值、text:当前文本、i:数据点的索引
					parseText:function(tip,name,value,text,i){
						return name+":"+value+"kw";
					}
				},
				type:"fixed"
			},
			tipMocker:function(tips,i){
				return tips.join("<br/>");
			}, 
			coordinate:{
				width:line2D_data.coordinate.width,
				height:line2D_data.coordinate.height,
				background_color:line2D_data.coordinate.background_color,
				axis:{
					color:line2D_data.coordinate.axis.color,
					width:line2D_data.coordinate.axis.width
				},
				offsety:-10,
				scale:[{
					 position:line2D_data.coordinate.scale[0].position,	
					 start_scale:line2D_data.coordinate.scale[0].start_scale,
					 end_scale:line2D_data.coordinate.scale[0].end_scale,
					 scale_space:line2D_data.coordinate.scale[0].scale_space,
					 scale_size:line2D_data.coordinate.scale[0].scale_size,
					 label: {
						color: line2D_data.coordinate.scale[0].label.color,
						fontsize: line2D_data.coordinate.scale[0].label.fontsize,
						fontweight: line2D_data.coordinate.scale[0].label.fontweight
					},
					 scale_color:line2D_data.coordinate.scale[0].scale_color 
					 
				},{
					 position:line2D_data.coordinate.scale[1].position,	
					 labels:line2D_data.coordinate.scale[1].labels,
					 label: {
						color: line2D_data.coordinate.scale[1].label.color,
						fontsize: line2D_data.coordinate.scale[1].label.fontsize,
						fontweight: line2D_data.coordinate.scale[1].label.fontweight
					}
				}]
			}
		});
		line.plugin(new iChart.Custom({
						drawFn:function(){
							//计算位置
							var coo = line.getCoordinate(),
								x = coo.get('originx'),
								y = coo.get('originy'),
								w = coo.get('width'),
								h = coo.get('height');
							//在左上侧的位置，渲染一个单位的文字
							line.target.textAlign('start')
							.textBaseline('bottom')
							.textFont(line2D_data.plugin.textfont)
							.fillText(line2D_data.plugin.y_label.name,x-35,y-16,false,line2D_data.plugin.y_label.color)
							.textBaseline('top')
							.fillText(line2D_data.plugin.x_label.name,x+w-12,y+h+30,false,line2D_data.plugin.x_label.color);
							
						}
				}));
		line.draw();
}
//取得最小值
function getMin_Data(m,t){
	if(m>t){
		if(t==0){
			return m;	
		}else{
			return t;
		}
	}else{
		return m;	
	}
}
//取得最大值
function getMax_Data(m,t){
	if(m<t){
		return t;	
	}else{
		return m;	
	}
}
	//计算刻度
	function getScals(v,t){
		if(v<1 && t<1){
			var m = miniToScale(v,0);
			var m_a=miniToScale(t,1);
			var sp = (m_a-m)/5;
			return [m,sp,m_a];
		}else{
			var t1 = t.toFixed(0);
			var len = (t1+"").length;
			var v1 = v.toFixed(0);
			var len1 = (v1+"").length;
			var m_a = 0;
			if(len==3){
				 m_a = mathToScale(t,0,1);
			}else{
				 m_a = mathToScale(t,1,1);	
			}
			var m = 0;
			if(len1==3){
				m =mathToScale(99,0,0);	
			}else{
				m =mathToScale(v,0,0);
			}
			var sp = (m_a-m)/5
			return [m,sp,m_a];		
		}
	}
	function mathToScale(v,t,k){
		v = v.toFixed(0);
		var len = (v+"").length;
		var s = Number((v+"").charAt(0));
		var m=0;
		if(len==1){
			if(k==1){
			if(s<=5){
				m=5;	
			}else{
				m=10;	
			}
			}else{
				m=0;	
			}
		}else{
			 m =Math.pow(10,len-1)*(s+t);
			 if(k==1){
				 if(len>=3){
					 var h = Number((v+"").charAt(len-1));
					 var f = (v+"").substring(0,len-1);
					 if(h<5){
						 m = Number(f+5);	 
					 }else{
						 m = Number((Number(f)+1)+"0"); 
					 }
				 }else{
				 	 var tm = Math.pow(10,len-2)*5;
					 if((v-m)>tm){
						 m = Math.pow(10,len-1)*(s+t+1)
					 }else if(0<(v-m)<tm){
						m = m+tm; 
					 }
				 }
			 }
		}
		return m;
	}
	function miniToScale(v,k){
		var arr = (v.toExponential([0])+"").split("e-");
		var v1 = Number(arr[0])-1;
		var v2 = Number(arr[1]);
		var tm = 0;
		if(k==0){
			if(v1<5){
				tm=0;
			}else{
				tm=0;	
			}
		}else{
			if(v1<5){
				tm=5;
			}else{
				tm=10;	
			}
		}
		return tm/Math.pow(10,v2);
	}