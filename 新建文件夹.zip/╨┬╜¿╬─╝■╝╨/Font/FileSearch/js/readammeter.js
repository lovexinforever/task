//电能表p_code
//老资产编号前缀
var g_ASSET_NO_PREFIX = new Object();
g_ASSET_NO_PREFIX["32101"] = "";
g_ASSET_NO_PREFIX["32401"] = "A";
g_ASSET_NO_PREFIX["32402"] = "B";
g_ASSET_NO_PREFIX["32403"] = "C";
g_ASSET_NO_PREFIX["32404"] = "D";
g_ASSET_NO_PREFIX["32405"] = "E";
g_ASSET_NO_PREFIX["32406"] = "F";
g_ASSET_NO_PREFIX["32407"] = "G";
g_ASSET_NO_PREFIX["32408"] = "H";
g_ASSET_NO_PREFIX["32409"] = "J";
g_ASSET_NO_PREFIX["32410"] = "K";
g_ASSET_NO_PREFIX["32411"] = "L";
g_ASSET_NO_PREFIX["32412"] = "M";
g_ASSET_NO_PREFIX["32413"] = "N";

document.addEventListener("deviceready",devicereay,false);
function devicereay() {
	//连接蓝牙
	blue_connect();
	function blue_connect(){
		bluetooth_conn(function(e){
			if(e.msg == 1){
			}else if(e.msg==3){
				showToast("扫描设备未设置");
			}else{
				showToast("连接失败");
			}

		});
	}
}

function assetNoHandle(orgNo, assetNo) {
	var str=assetNo.indexOf("-");
	if(str!=-1){
		assetNo=assetNo.substring(0,str);
	}
	assetNo = assetNo.replace(/[ ]/g, "");
	// 去掉前面与后面的空格
	orgNo = orgNo.replace(/[ ]/g, "");
	var sResult = assetNo + "";

	if(assetNo.length == 13) {
		sResult = g_ASSET_NO_PREFIX[orgNo.substr(0, 5)] + assetNo.substring(4, assetNo.length);
	} else if(assetNo.length == 22) {
		// 截取第12位到第21位共10位作为资产编号
		sResult = assetNo.substr(11, 10);
	}
	return sResult;
}

/************处理资产编号****************/
function getlastassetno(assetno) {
	if(!sessionStorage.ORG_NO) {
		sessionStorage.ORG_NO = "3240101";
	}
	var ass_org = assetNoHandle(sessionStorage.ORG_NO, assetno);
	return ass_org;
}

