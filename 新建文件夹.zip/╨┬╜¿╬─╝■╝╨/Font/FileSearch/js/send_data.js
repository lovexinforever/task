var Send_Data=function(){
	
};


Send_Data.prototype.send_Data=function(argument,successCallBack,faileCallBack){
	return PhoneGap.exec(successCallBack,faileCallBack,'Send_dataPlugin','action_send_data',[argument])
}

Send_Data.prototype.get_Tid=function(successCallBack,faileCallBack){
	return PhoneGap.exec(successCallBack,faileCallBack,'Send_dataPlugin','action_get_tid',[null])
}
Send_Data.prototype.get_Sim=function(successCallBack,faileCallBack){
	return PhoneGap.exec(successCallBack,faileCallBack,'Send_dataPlugin','action_get_sim',[null])
}
Send_Data.prototype.get_URL=function(successCallBack,faileCallBack){
	return PhoneGap.exec(successCallBack,faileCallBack,'Send_dataPlugin','action_get_url',[null])
}
cordova.addConstructor(function() {
	cordova.addPlugin("send_data", new Send_Data());
});

/**
 * 公用的发送请求的方法
 * @param fun	功能号
 * @param mod 模块号
 * @param pkg	包内容
 * @param successCallBack
 * @param faileCallBack
 * @return
 */ 
function send_data(fun,mod,pkg,successCallBack,faileCallBack){
 	window.plugins.send_data.get_Tid(getTidSuc,null);
 	function getTidSuc(tid){
		var data = '{"FUN":"'+fun+'","LEN":"'+getlength(pkg)+'","MOD":"'+mod+'","PKG":'+pkg+',"REQ":"0","TID":"'+tid+'","SSN":"'+localStorage.SSN+'","USR":"'+localStorage.user_name+'"}';
		console.log(data);
		window.plugins.send_data.send_Data(data,successCallBack,faileCallBack);
	 
	}
 
}
function getlength(pkg){
	return pkg.replace(/[\u4e00-\u9fa5]/g, "aa").length;
}
/**
 * 终端登录的请求方法
 * data 请求参数
 */
function welcome_login(data,successCallBack,faileCallBack){	
	//alert(data);
	window.plugins.send_data.send_Data(data,successCallBack,faileCallBack);	
}

function getTid(successCallBack,faileCallBack){
	window.plugins.send_data.get_Tid(successCallBack,faileCallBack);
}

function getSim(successCallBack,faileCallBack){
	window.plugins.send_data.get_Sim(successCallBack,faileCallBack);
}

function getURL(successCallBack,faileCallBack){
	window.plugins.send_data.get_URL(successCallBack,faileCallBack);
}
/**
 * 根据错误代码，返回对应的错误信息
 * @param errorCode
 * @return
 */
function getErrorMsg(errorCode){
	switch(errorCode){
	case "01":
		return "会话失效";
	case "02":
		return "通信失败";
	case "03":
		return "请求模板错误，没有该模块";
	case "04":
		return "请求业务功能错误，没有该业务功能";
  
	case "10":
		return "终端没有注册";
	case "11":
		return "用户名、密码错误";
	case "12":
		return "用户禁用、锁定";
	case "13":
		return "该用户没有操作权限";
	case "14":
		return "用户没有设备使用权限";
	case "20":
		return "请求数据不能为空";
	case "21":
		return "请求数据格式错误，长度错误";
	
	case "22":
		return "请求数据格式错误";
	case "23":
		return "终端状态是”维护”";
	case "24":
		return "终端状态是”在库”";
	case "25":
		return "终端状态是”丢失”";
	case "26":
		return "终端状态是”报废”";
	case "27":
		return "终端状态是”出库”";
	case "28":
		return "设备与SIM卡不匹配";
	case "29":
		return "设备已经锁定";
	case "90":
		return "无法找到业务接口地址";
	case "91":
		return "请求业务接口执行失败";
	case "92":
		return "业务处理器执行超时";
	case "99":
		return "系统未知错误";
		
	default:
		return "网络连接失败";
	}
}
 

 