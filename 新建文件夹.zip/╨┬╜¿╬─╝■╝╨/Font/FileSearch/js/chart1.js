
var ifs=1
//折线图
 function line2d(das,labels,canvasid){
				var line = new iChart.LineBasic2D({
					render : canvasid,
					data: das,
					sub_option : {
			label : false,
			border : {
			width : 2,
			color : '#ffffff'
			}
		},
		footnote_align:'left',
		border:{
			enable:false
			},
		width :400,
		height :280,
		animation : false,//开启过渡动画
		animation_duration:1000,//600ms完成动画
		background_color: null,
		
		legend:{
			align : 'center',
			valign : 'bottom',
			row:1,
			column:'max'

		},tip:{
					enable:true,
					showType:'fixed'
				},
					coordinate:{
			grid_color:'rgba(0,0,0,0)',
			background_color :null,
			width:300,
			valid_width:(300-300/labels.length),
			height:180,
			axis : { 
					enable : true, //是否有坐标线
					width : [0, 0, 1, 0], //坐标线宽度，顺序依次是上边线、右边线、下边线、左边线
					color : 'rgba(0,0,0,0)',//坐标线颜色
			},scale : [{
						position : 'right',
						scale_size:2,
						label : {
							fontsize:11,
							fontweight:600,
							color : '#666666',

						}
					}]

		}
				});
			//开始画图
			line.draw();
 }
			 








//柱状图
function loadtablelist(dates,canvasid,date_labels,lineif){
	if(lineif){
	 ifs=1
	}else{
		 ifs=0
	}
	var chart =new iChart.ColumnMulti2D({
		render : canvasid,
		data: dates,
		labels:date_labels,
		sub_option : {
			label : false,
			border : {
			width : 2,
			color : '#ffffff'
			}
		},
		label:{
			rotate:45,
			textBaseline:'middle',
			textAlign:'center',
			offsety:5

		},
		footnote_align:'left',
		border:{
			enable:false
			},
		width :400,
		height :280,
		animation : false,//开启过渡动画
		animation_duration:1000,//600ms完成动画
		background_color: null,
		legend:{
			align : 'center',
			valign : 'bottom',
			row:1,
			column:'max'

		},tip:{
					enable:true,
					showType:'fixed'
				},

		coordinate:{
			background_color :null,
			width:300,
			height:180,
			axis : { 
					enable : true, //是否有坐标线
					width : [0, 0, 1, 0], //坐标线宽度，顺序依次是上边线、右边线、下边线、左边线
					color : '#777',//坐标线颜色
			},scale : [{
						position : 'left',
						label : {
							fontsize:11,
							fontweight:600,
							color : '#666666',

						}
					}]

		}
	});
	
	
     
			//利用自定义组件构造左侧说明文本
			chart.plugin(new iChart.Custom({
					drawFn:function(){
						//计算位置
						var coo = chart.getCoordinate(),
							x = coo.get('originx'),
							y = coo.get('originy');
						//在左上侧的位置，渲染一个单位的文字
						chart.target.textAlign('start')
						.textBaseline('bottom')
						.textFont('300 13px 微软雅黑')
						.fillText('单位：kWh',x-30,y-6,false,'#999')

						//在右上侧的位置，渲染一个单位的文字
						
						if(lineif){
						chart.target.textAlign('end')
						.textBaseline('bottom')
						.textFont('300 13px 微软雅黑')
						.fillText('单位：%',x+20+coo.get('width'),y-10,false,'#999')
						}
						
					}
			}));


		chart.draw();
}

