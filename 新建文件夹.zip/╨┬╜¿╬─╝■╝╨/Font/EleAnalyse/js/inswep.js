// JavaScript Document
var pageflage=[];
var flagelen;
var flagemove=true;
//地市切换状态
var areatrue=true;
var areaFlage=true;
var changedate= true;
var changepageNum = 1;//控制当前的菜单不能点击
var idName = "#contne1";
var chartHtmlUrl = "province/province_chart.html";
var tableHtmlUrl = "province/province_table.html";
var titleName = "全省用电情况";
var orgNames = ['江苏省','南京','无锡','徐州','常州','苏州','南通','连云港','淮安','盐城','扬州','镇江','泰州','宿迁'];
var detaildate_index=0;
var qs_flag = 0;
var areaListIndex = 0;

//各个业务模块的临时数据存储定义
var temp_data = null ;

//各个模块时间控件显示的时间定义
var province_time_top=null,province_time_bottom=null;
var society_time_top=null,society_time_bottom=null;
var industry_time_top=null,industry_time_bottom=null;
var yield_time_top=null,yield_time_bottom=null;
var vocation_time_top=null,vocation_time_bottom=null,vocation_time_rank=null;
var quantity_time_top=null,quantity_time_bottom=null;
var charge_time_top=null,charge_time_bottom=null;
var kLine_time_top=null,kLine_time_bottom=null;

//标示是否需要将时间值初始化(true为当点击左边树时初始化,false为点击页面翻转时(chart切table)不初始化)
var time_init_flag=true;
//地市代号(每次进入自己的页面时候需重新置为32101)
var elec_org_no='32101';
//全局w5、w10、w20线选择状态
var w5_sel=1,w10_sel=1,w20_sel=1; 
//全局有效工作日和剔除节假日选择状态
var k_validDay=1,k_festDay=1;
//全局K线类型
var kline_types=0;
//K线树选中索引
var tree_index=0;
//如果是点击w线后发送的请求,则只画w线,不重绘K线
var is_wline=false;
//K线标题
var kline_title='';
//判断K线是在chart页面还是在table页面
var kline_isChart=false;
//判断当前页面是否在K线页面
var page_is_kline=false;

//定义记录年行业用电量下拉菜单项的游标值
var vocationNameStates_year = 0;
//定义记录企业用电量排名中下拉菜单项的游标值
var vocationNameStates_rank = 0;

//获取屏幕的高度
var printheight = document.body.offsetHeight;

var h = printheight - 100 -48;
$('.contentchangepage').height(printheight - 100);
$("#contentPageOne").height(h);
$("#contentPageTwo").height(h);

//用电分析模块页面进入次数,3次之前提示用户点击按钮进行图表和表格的切换,超过3此则不再提示
if(localStorage.elecAnalysePageTimes==undefined){
	localStorage.elecAnalysePageTimes=0;
}

//当页面请求完成后,检查其进入次数,如果再3此以内,则显示提示框
function checkPageTimes(){
	localStorage.elecAnalysePageTimes = parseInt(localStorage.elecAnalysePageTimes,10)+1;
	if(parseInt(localStorage.elecAnalysePageTimes,10)<=3){
		detailTip();
	}else{
		//避免数据一直加加到很大超出存储范围
		localStorage.elecAnalysePageTimes=4;
	}
}


//页面第一次加载
function loadDefault(){
	loadscroll();
	initVarAndTime();
	$(idName).load(chartHtmlUrl);
	refresh1();

}
//首页目录的点击事件
function changepage(e,t){
	
	if(flagemove && changepageNum != e) {
		$("#areaName").html("江苏省")
		initVarAndTime();
		time_init_flag = true;
		vocationNameStates_year = 0;
		vocationNameStates_rank = 0;
		changepageNum = e;
		changedate = true;
		myScroll1.destroy()
		myScroll2.destroy()
		for(var i = 1; i < 9; i++) {
			document.getElementById('m' + i).style.textShadow = " 0px 0px 20px rgba(255,255,255,0)";
			document.getElementById('m' + i).style.borderLeft = "0px solid #fff";
		}
		t.style.textShadow = " 0px 0px 20px rgba(255,255,255,1)";
		t.style.borderLeft = "2px solid #fff"
		flagemove = false;
		//
		document.getElementById('leftMenu').style.backgroundPosition = "88px " + (22 + 119 * e) + "px";
		if(pageflage.length == 0) {
			idName = "#contne2";
		} else {
			idName = "#contne1";
		}
		
		if(e==8){
			page_is_kline=true;
		}else{
			page_is_kline=false;
		}
		
		switch(e) {
			case 1:
				//全省用电
				titleName = "全省用电情况";
				chartHtmlUrl = "province/province_chart.html";
				tableHtmlUrl = "province/province_table.html";
				break;
			case 2:
				//社会用电
				titleName = "社会用电情况";
				chartHtmlUrl = "society/society_chart.html";
				tableHtmlUrl = "society/society_table.html";
				break;
			case 3:
				//工业用电
				titleName = "工业用电情况";
				chartHtmlUrl = "industry/industry_chart.html";
				tableHtmlUrl = "industry/industry_table.html";
				break;
			case 4:
				//产业用电
				titleName = "产业用电情况";
				chartHtmlUrl = "yield/yield_chart.html";
				tableHtmlUrl = "yield/yield_table.html";
				break;
			case 5:
				//行业用电
				titleName = "行业用电情况";
				chartHtmlUrl = "vocation/vocation_chart.html";
				tableHtmlUrl = "vocation/vocation_table.html";
				break;
			case 6:
				//网供电量
				titleName = "网供电量情况";
				chartHtmlUrl = "elec_quantity/quantity_chart.html";
				tableHtmlUrl = "elec_quantity/quantity_table.html";
				break;
			case 7:
				//网供负荷
				titleName = "网供负荷情况";
				chartHtmlUrl = "charge/charge_chart.html";
				tableHtmlUrl = "charge/charge_table.html";
				break;
			case 8:
				//K线
				titleName = "K线情况";
				chartHtmlUrl = "K_line/kline_chart.html";
				tableHtmlUrl = "K_line/kline_table.html";
				break;
		}
		$("#topName").html(titleName);
		$(idName).load(chartHtmlUrl);
		changecontent();
		//
		setTimeout(function() {
			flagemove = true;
		}, 1600)
	}
}
function refresh1(){
	myScroll1.scrollTo(0,0)
	myScroll2.scrollTo(0,0)
	setTimeout(function(){myScroll1.refresh();myScroll2.refresh()},500)
}
function refresh2(){
	setTimeout(function(){myScroll1.refresh();myScroll2.refresh()},500)
}
//页面转场动画
function changecontent(){
	flagelen=pageflage.length;
	loadscroll();
	myScroll1.scrollTo(0,0)
	myScroll2.scrollTo(0,0)
	if(flagelen==0){
	pageflage.push("1")
	document.getElementById("contentPageOne").style.zIndex="1";
	document.getElementById("contentPageTwo").style.zIndex="2";
	document.getElementById("contentPageOne").className="flash3";
	document.getElementById("contentPageTwo").className="flash4";
	setTimeout(function(){
	document.getElementById("contentPageOne").className="flash2";
	document.getElementById("contentPageTwo").className="flash1";
	},800)
	}else if(flagelen==1){
	pageflage=[];
	document.getElementById("contentPageOne").style.zIndex="2";
	document.getElementById("contentPageTwo").style.zIndex="1";
	document.getElementById("contentPageOne").className="flash4";
	document.getElementById("contentPageTwo").className="flash3";
	setTimeout(function(){
	document.getElementById("contentPageOne").className="flash1";
	document.getElementById("contentPageTwo").className="flash2";
	},800)
	}
	
	setTimeout(function(){
		myScroll1.refresh()
	    myScroll2.refresh()
	},2000)
	//
}
//首页TAB切换
//document.getElementById("area_ml").click(function(){
//alert(11111)
//})
//页面容器滑动
var  myScroll1,myScroll2,myScroll3;
function loadscroll(){
myScroll1 = new iScroll('contentPageOne', {
			hScrollbar: false,
			vScrollbar: true,
			hideScrollbar:true,
			onBeforeScrollStart: function (e) {
				var target = e.target;
				while (target.nodeType != 1) target = target.parentNode;
				if (target.tagName != 'SELECT' && target.tagName != 'INPUT' && target.tagName != 'TEXTAREA')
					e.preventDefault();
			}
		});
myScroll2 = new iScroll('contentPageTwo', {
			hScrollbar: false,
			vScrollbar: true,
			hideScrollbar:true,
			onBeforeScrollStart: function (e) {
				var target = e.target;
				while (target.nodeType != 1) target = target.parentNode;
				if (target.tagName != 'SELECT' && target.tagName != 'INPUT' && target.tagName != 'TEXTAREA')
					e.preventDefault();
			}		
		});
//地区滑动

myScroll3 = new iScroll('areaheight', {
			hScrollbar: false,
			vScrollbar: true,
			hideScrollbar:true
		});
}
//首页地市切换




function areachange(){
	if(!page_is_kline){
		$("#areaheight").html('<div><div class="arealisttitle">'+titleName+'</div><ul style=" display:block" id="area_ul_id"><li class="arealist">江苏省</li></ul></div>')
	    $("#area_ul_id").html('<li class="arealist">江苏省</li>')
		if ("null" == localStorage.province_Data || undefined == localStorage.province_Data || "undefined" == localStorage.province_Data) {
			$("#area_ul_id").html('<li class="arealist">江苏省</li>')
		}else{
			var areaData= JSON.parse(localStorage.province_Data).org_list;
			var areaListLen= areaData.length;
			for(var i=0;i<areaListLen;i++){
				var area_li_str = '<li class="arealist">'+areaData[i].org_name+'</li>';
				$("#area_ul_id").append(area_li_str)
				}
			$("#area_ul_id li").removeClass("selected");
			$("#area_ul_id li:eq("+areaListIndex+")").addClass("selected");
			if($("#areaName").html()=="江苏省"){
			$("#area_ul_id li").removeClass("selected");
			$("#area_ul_id li:eq(0)").addClass("selected");
				}
		}
		hideArea();
		
		
		var area_flag = true;
		$("#area_ul_id li").click(function(e) {
			if (area_flag) {
			area_flag = false;
			setTimeout(function() {
				area_flag = true;
			}, 500)
			

			var listIndex = parseInt($("#area_ul_id li").index(this));
			areaListIndex = listIndex;
			var data = JSON.parse(localStorage.province_Data).org_list;
			$("#area_ul_id li").removeClass("selected");
			$("#area_ul_id li:eq("+listIndex+")").addClass("selected");
			if(areaListIndex==0){
				request_area(32101);
			}else{
				request_area(data[areaListIndex-1].org_no);
			}
			$("#areaName").text($("#area_ul_id li:eq("+listIndex+")").text())
			
			hideArea();
			}
	   });
	}else{
		hideArea();
		//K线树
		if(kline_isChart){
			analyTree(temp_data.org_list);
		}else{
			analyTree2(temp_data.org_list);
		}
	}
}


function hideArea(){
	if(areatrue){
		areatrue=false;
		setTimeout(function(){areatrue=true},1000)
		document.getElementById('areaheight').style.height=printheight+"px";
		if(areaFlage){
			areaFlage=false;
			document.getElementById("content").style.marginLeft="-435px";
			document.getElementById('body').style.backgroundPosition="-150px";
		}else{
			areaFlage=true;
			document.getElementById("content").style.marginLeft="0px";
			document.getElementById('body').style.backgroundPosition="0px";
		}
	}
}
//首页表格跟图表切换

function changetabledate(){
	//切换图表和表格时，关掉提示界面
	if($(".showslide").css("display")=="block"){
		tipFinish();
	}
	
	time_init_flag=false;
	$(idName).removeClass("contneflash")
		setTimeout(function(){
		$(idName).addClass("contneflash")
	},1)
	if(changedate){
		changedate=false;
		setTimeout(function(){
			$(idName).load(tableHtmlUrl)
			refresh1()
		},800)
	}else{
		changedate=true;
		setTimeout(function(){
			$(idName).load(chartHtmlUrl)
			refresh1()
		},800)
	}
}


/*通过ajax获取数据的方法
 
 pathName:接口url最后部分
 jsonData:json数据请求域
 successCallback: 请求成功的回调函数
 failCallback: 请求失败的回调函数
*/
function getAjaxData(pathName,jsonData,successCallback,failCallback){
	var intercept = localStorage.ACHIEVE_URL;
	var xmlHttp = $.ajax({
		type:"GET",
		dataType:"jsonp",
		async:false,  
		url:intercept+"IATEC-IS/terminal/"+pathName,
		data:"info="+JSON.stringify(jsonData),
		jsonp:"jsonpCallback",
		success: successCallback,
	  	error: failCallback
		});
    //ajax请求超时时间为30秒
    setTimeout(function(){
    	if(xmlHttp){
    		var readyState = xmlHttp.readyState;
    		if(readyState!=4){
    			alert("数据返回超时!");
    		   //中断ajax请求
    		   xmlHttp.abort();
    		}
    	}
    },30000);
	console.log("请求地址："+intercept+"IATEC-IS/terminal/"+pathName+"?info="+JSON.stringify(jsonData));
	}


//============================================得到当前日期方法
function getNowTime(state) {
	var date = new Date();
	var year = date.getFullYear();
	var month = date.getMonth() + 1;
	var day = date.getDate();
	if(state == 1) {
		return year
	} else if(state == 2) {
		return year + "-" + add_zero(month)
	} else if(state == 3) {
		return year + "-" + add_zero(month) + "-" + add_zero(day)
	}
}

function getSomeDay(s,addTime){
	var date = new Date(s);
	date.setDate(date.getDate()+addTime);
	var year2 =date.getFullYear();
	var month2=date.getMonth()+1;
	var day2=date.getDate();
	return year2+"-"+add_zero(month2)+"-"+add_zero(day2)
				
}

function add_zero(time) {
	return time<10?("0"+time):time;
}

function changeDateFH(dateStr) {
	return dateStr.replace(/-/g, "/")
}

function changeNullTo0(str) {
	return (str == null || str == "" || str == "null")?0:str;
}

function loading() {
	$(".showslide").load("loading/loading.html")
	$(".showslide").css("display", "block")
	$(".showslide").css("height", "100%")
}

function finish() {
	$(".showslide").load("loading/loading.html")

	$(".showslide").css("height", "0%")
	setTimeout(function() {
		//隐藏下拉菜单界面
		$(".showslide").css("display", "none")
	}, 800)
}


/*
 每次点击左边树时,如果时间超过2个小时，或隔日、隔月、隔年,则清空localStorage数据
 * 
*/
function initVarAndTime(){
	if(null == localStorage.first_time||undefined==localStorage.first_time) {
		var currDate = new Date();
		localStorage.first_time = currDate.getFullYear() + "-" + add_zero(currDate.getMonth() + 1) + "-" + add_zero(currDate.getDate());
		//存放小时数
		localStorage.first_hour = currDate.getHours();
	}

	var nowDate = new Date();
	var nowYear = nowDate.getFullYear();
	var nowMonth = nowDate.getMonth()+1;
	var nowdDate = nowDate.getDate();
	//当前小时数目
	var nowHour = nowDate.getHours();
	var timeArray = localStorage.first_time.split("-");
	if(nowYear>Number(timeArray[0]) || nowMonth>Number(timeArray[1]) || nowdDate>Number(timeArray[2]) || (nowHour-Number(localStorage.first_hour)>=2)) {
		//全省用电模块数据存储定义
		localStorage.province_Data = null;
		//社会用电模块数据存储定义
		localStorage.society_Data = null;
		//工业用电模块数据存储定义
		localStorage.industry_Data = null;
		//产业用电模块数据存储定义
		localStorage.yield_Data = null;
		//行业用电模块数据存储定义
		localStorage.vocation_Data = null;
		//网供电量模块数据存储定义
		localStorage.quantity_Data = null;
		//网供负荷模块数据存储定义
		localStorage.charge_Data = null;
		//K线模块数据存储定义
		localStorage.kLine_Data = null;
		temp_data = null;

		//对第一次存储时间重新赋值
		localStorage.first_time = nowYear + "-" + add_zero(nowMonth) + "-" + add_zero(nowdDate);
		localStorage.first_hour = nowHour;
	}
}

//业务第一次加载增加提示信息
function detailTip() {
	setTimeout(function(){
	$(".topdate").css("z-index","999999")
	$(".showslide").load("loading/tip.html")
	$(".showslide").css("display", "block")
	$(".showslide").css("height", "100%")
	$(".showslide").css("background", "rgba(0,0,0,0.8)")
	},801)
}