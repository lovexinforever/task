//表格显示
function showTableData(array,num,units,data){
	var dataTitle = "";
	if(data!=""){
		dataTitle = "<table style=\"width:100%\" id =\"dataTable\"><thead>";
		var dataSize = data.data1.length;
		if(dataSize>0){
			//循环标题
			if(array!=null){
				dataTitle += "<th>&nbsp;</th>"; 
			}
			//dataTitle += "<th>全社会用电</th>";
			//dataTitle +="<th>&nbsp;</th>";	
			for(var i=0;i<dataSize;i++){
				dataTitle += "<th>"+data.data1[i].type+"</th>";
			}
			dataTitle +=  "</thead>";
			//循环数据
			if(dataSize>0){
				dataTitle += "<tbody>";
				for(var i=0;i<num;i++){
					//第一列标题
					dataTitle += "<tr onMouseOver=\"hoverTable(this)\" onClick=\"clickTable(this)\" onMouseOut=\"outTable(this)\">"
						if(array!=null){
							dataTitle += "<th style='color:"+array[i].color+"'>"+array[i].name+"</th>";
						}
					for(var j=0;j<dataSize;j++){
						if(i==0){
							dataTitle += "<th>"+data.data1[j].num1+units+"</th>";
						}else if(i==1){
							dataTitle += "<th>"+data.data1[j].num2+units+"</th>";
						}else if(i==2){
							dataTitle += "<th>"+data.data1[j].num3+units+"</th>";
						}else if(i==3){
							dataTitle += "<th>"+data.data1[j].num4+units+"</th>";
						}						
					}
					dataTitle += "</tr>";
				}
				dataTitle += "</tbody>";
			}			
		}
		dataTitle += "</table>";
		document.getElementById("dataTableShow").innerHTML = dataTitle;
	}
}


//地区情况表格
function showTableData_area(array,num,units,data){
	var dataTitle = "";
	if(data!=""){
		dataTitle = "<table style=\"width:100%\" id =\"dataTable\"><thead>";
		var dataSize = data.data1.length;
		if(dataSize>0){
			//循环标题
			if(array!=null){
				dataTitle += "<th>&nbsp;</th>"; 
			}
			//dataTitle += "<th>全社会用电</th>";
			//dataTitle +="<th>&nbsp;</th>";	
			for(var i=0;i<dataSize;i++){
				dataTitle += "<th>"+data.data1[i].type+"</th>";
			}
			dataTitle +=  "</thead>";
			//循环数据
			if(dataSize>0){
				dataTitle += "<tbody>";
				for(var i=0;i<num;i++){
					//第一列标题
					dataTitle += "<tr onMouseOver=\"hoverTable(this)\" onClick=\"clickTable(this)\" onMouseOut=\"outTable(this)\">"
						if(array!=null){
							dataTitle += "<th style='color:"+array[i].color+"'>"+array[i].name+"</th>";
						}
					for(var j=0;j<dataSize;j++){
						if(i==0){
							dataTitle += "<th>"+data.data1[j].num1+"</th>";
						}else if(i==1){
							dataTitle += "<th>"+data.data1[j].num2+"</th>";
						}else if(i==2){
							dataTitle += "<th>"+data.data1[j].rate1+units+"</th>";
						}else if(i==3){
							dataTitle += "<th>"+data.data1[j].rate2+units+"</th>";
						}						
					}
					dataTitle += "</tr>";
				}
				dataTitle += "</tbody>";
			}			
		}
		dataTitle += "</table>";
		document.getElementById("dataTableShow").innerHTML = dataTitle;
	}
}


//表格显示
function showTableData1(num,units,data){
	var dataTitle = "";
	if(data!=""){
		dataTitle = "<table style=\"width:100%\" id =\"dataTable\"><thead>";
		var dataSize = data.data1.length;
		if(dataSize>0){
			//循环标题
			//dataTitle += "<th>&nbsp;</th>"; 
			for(var i=0;i<dataSize;i++){
				dataTitle += "<th>"+data.data1[i].type+"</th>";
			}
			dataTitle +=  "</thead>";
			//循环数据
			if(dataSize>0){
				dataTitle += "<tbody>";
				for(var i=0;i<num;i++){
					//第一列标题
					dataTitle += "<tr onMouseOver=\"hoverTable(this)\" onClick=\"clickTable(this)\" onMouseOut=\"outTable(this)\">"
					//dataTitle +="<th>"+data.dataSource[i][0]+"</th>";	
					for(var j=0;j<dataSize;j++){
						if(i==0){
							dataTitle += "<th>"+data.data1[j].rate1+units+"</th>";
						}else if(i==1){
							dataTitle += "<th>"+data.data1[j].rate2+units+"</th>";
						}else if(i==2){
							dataTitle += "<th>"+data.data1[j].rate3+units+"</th>";
						}else if(i==3){
							dataTitle += "<th>"+data.data1[j].rate4+units+"</th>";
						}						
					}
					dataTitle += "</tr>";
				}
				dataTitle += "</tbody>";
			}			
		}
		dataTitle += "</table>";
		document.getElementById("dataTableShow").innerHTML = dataTitle;
	}
}

//悬浮时的样式
function hoverTable(obj){
	if(obj.className == "trBgClick"){
		obj.className = "trBgClick";
	}else{
		obj.className = "trBgHover";
	}
}
//选中的样式
function clickTable(obj){
	var allTr = document.getElementById("dataTable").rows;
	for(var i=0;i<allTr.length;i++){
		allTr[i].className="";
	}
	obj.className = "trBgClick";
}
//离开时移除样式
function outTable(obj){
	var allTr = document.getElementById("dataTable").rows;
	for(var i=0;i<allTr.length;i++){
		if(allTr[i].className=="trBgClick"){
			allTr[i].className="trBgClick";
		}else if(allTr[i].className=="trBgHover"){
			allTr[i].className="";
		}
	}
}