
/************************************************************************/
/**            柱状配置项												   **/
/************************************************************************/

function getColumeConfig(){
	var column_config ={
			data:'',			//数据源	
			data_labels:'',		//折线图的底部标签值		
			align : 'center',	
			title:{				//标题
				text:'',		//标题内容
				color:'#fff',		//标题颜色
				font:'微软雅黑',
				fontsize:20
			},
			subtitle:{
				text:'',  //标题内容
				color:'#fff',   //副标题颜色
				fontsize:18,
				font:'微软雅黑',
			},
			anim:{				//显示动画
				enable:true,	//是否启用
				time:1000		//动画时间
			},
			size:{				//画布大小
				width:1000,		//画布宽
				height:800		//画布高
			},
			label_x : 65,//
			label_w : 40,//
			colwidth:20,
			coordinate:{		//坐标设置
				width:800,
				height:600,
				grid_color:'rgba(0,255,10,0.1)', //网格线颜色
				scale:[{		//x轴
					position:'left',	//向左对齐 
					start_scale:0,		//起始值
					end_scale:20,		//结束值
					scale_space:5,		//间隔值
					scale2grid : true, //是否有网格线
					scale_color : '#fd0', //坐标轴颜色
					label:{
						fontsize:18
					},
					color : 'rgba(255,255,0,0.5)', //设置坐标轴数据的颜色
					fontsize : 20,
				},{
					 position:'bottom',	
					 labels:''
				}],
				axis : { 
					enable : true, //是否有坐标线
					width : [0, 0, 1, 1], //坐标线宽度，顺序依次是上边线、右边线、下边线、左边线
					color : '#ff0',//坐标线颜色
				},
				shadow_color : 'rgba(16,40,2,0.1)', //底部是否阴影颜色
				back_color:'rgba(80,20,180,0)'  //图表区域背景色
			},
			border:{				//边框设置
				enable:true,		//边框是否可见
				color:'rgba(255,255,0,0)', //边框颜色
				width:2,			//边框
				radius:5  			//边框是否圆角
			},
			rectangle : {//Y轴值
				color : '#ff9', //Y轴字体颜色
				fontsize : 12, //Y轴字体大小
				label_name:''
			},
			footnote : {//底部备注
				text : '',
				color : '#95ff00',
				offsety : 10,
				offsetx : -20,
				fontsize : 16,
				font : '微软雅黑'
			},
			segment_style : {   //折线图中的点的大小
				point_size : 3,
				point_hollow : true,
			},
			legend : {			//图例配置项
				enable : false,
				align : 'center',
				valign : 'bottom', 
				row:1,
				column:'max',
				background_color:'rgba(255,255,0,0)',
				border:{
					enable:true
				},
				offsetx:0,
				offsety:0,
				fontsize:20,
				font:'微软雅黑',
			},
			label:{ //横轴的标签
				rotate:0,
				textBaseline:'top',
				textAlign:'center',
				color:'#fff',
				fontsize:18
			},
			sub_option:{
				smooth : true,
				label:{
					fontsize:12,
					color:'#fff',
				},
				border : {//图表整个的外边框
					width : 2, //边线宽
					radius : '0 0 0 0',//圆角弧度
					color : 'rgba(255,255,0,0)' //外边框颜色
				},
			},
			back_color:'rgba(80,20,180,0)'   //画布背景色
		};
	return column_config;
	
}


/************************************************************************/
/**            柱形统计图												   **/
/************************************************************************/
function draw_Column(column_config,canvasId){
	new iChart.Column3D({
		render : canvasId,
		data : column_config.data,
		align : column_config.align,	
		title : {
			text : column_config.title.text,
			color : column_config.title.color,
			fontsize: column_config.title.fontsize
		},
		anim:{	
			enable:column_config.anim.enable,
			time:column_config.anim.time
		},
		width : column_config.size.width,
		height : column_config.size.height,
		background_color : column_config.back_color,
		colwidth:column_config.colwidth,
		coordinate : {
			width : column_config.coordinate.width, //图表宽
			height : column_config.coordinate.height, //图表长
			grid_color : column_config.coordinate.grid_color,
			scale : [{
				position : column_config.coordinate.scale[0].position,
				start_scale : column_config.coordinate.scale[0].start_scale,
				end_scale : column_config.coordinate.scale[0].end_scale,
				scale_space : column_config.coordinate.scale[0].scale_space,
			}],
			shadow_color : column_config.coordinate.shadow_color,
			background_color : column_config.coordinate.back_color
		},
		border : {
			enable : column_config.border.enable,
			color : column_config.border.color,
			width : column_config.border.width,
			radius : column_config.border.radius
		},
		legend : {			//图例配置项
			enable : column_config.legend.enable,
			align : column_config.legend.align,
			valign : column_config.legend.valign, 
			row:column_config.legend.row,
			column:column_config.legend.column,
			background_color:column_config.legend.background_color,
			border:{
				enable:column_config.legend.border.enable
			},
			offsetx:column_config.legend.offsetx,
			offsety:column_config.legend.offsety,
			fontsize:column_config.legend.fontsizse,
			font:column_config.legend.font
		},
		label:{ //横轴的标签
			rotate:column_config.label.rotate,
			textBaseline:column_config.label.textBaseline,
			textAlign:column_config.label.textAlign,
			color:column_config.label.color,
			fontsize:column_config.label.fontsize
		},
		sub_option:{
            label:{
                fontsize:column_config.sub_option.label.fontsize,
                color:column_config.sub_option.label.color,
            },
            border : {//图表整个的外边框
                width : column_config.sub_option.border.width, //边线宽
                radius :column_config.sub_option.border.radius,//圆角弧度
                color : column_config.sub_option.border.color,//外边框颜色
            },
        }
	}).draw();
}


/************************************************************************/
/**            多个柱图												   **/
/************************************************************************/
function draw_ColumnMulti(column_config,canvasId){
	new iChart.ColumnMulti2D({
		render : canvasId,
		data: column_config.data,
		labels:column_config.data_labels,
		title : {
			text:column_config.title.text,
			color:column_config.title.color
		},
		subtitle : {
			text:column_config.subtitle.text,
			color:column_config.subtitle.color
		},
		anim:{	
			enable:line_config.anim.enable,
			time:line_config.anim.time
		},
		footnote : column_config.footnote.text,
		width : column_config.size.width,
		height : column_config.size.height,
		background_color : column_config.back_color,
		legend:{
			enable:true,
			background_color : column_config.legend.background_color,
			border : {
				enable : column_config.legend.border.enable
			},
			align : column_config.legend.align,
			valign : column_config.legend.valign, 
			row:column_config.legend.row,
			column:column_config.legend.column,
			offsetx:column_config.legend.offsetx,
			offsety:column_config.legend.offsety,
			fontsize:column_config.legend.fontsize,
			font:column_config.legend.font,
			line_height:40
		},
		coordinate:{
			background_color : column_config.coordinate.back_color,
			grid_color : column_config.coordinate.grid_color, //网格线颜色
			axis : {
				enable : column_config.coordinate.axis.enable, //是否有坐标线
				width : column_config.coordinate.axis.width, //坐标线宽度，顺序依次是上边线、右边线、下边线、左边线
				color : column_config.coordinate.axis.color,//坐标线颜色
			},
			scale : [{
				position:column_config.coordinate.scale.position,	//底部值轴
				start_scale : column_config.coordinate.scale.start_scale, //开始刻度
				end_scale : column_config.coordinate.scale.end_scale, //结束刻度
				scale_space : column_config.coordinate.scale.scale_space, //刻度间距
				scale2grid : column_config.coordinate.scale.scale2grid, //是否有网格线
				scale_color : column_config.coordinate.scale.scale_color, //坐标轴颜色
				color : column_config.coordinate.scale.color, //设置坐标轴数据的颜色
				fontsize : column_config.coordinate.scale.fontsize,
				label:{
					fontsize:column_config.coordinate.scale.label.fontsize,
				}
			}]
		},
		border : {//图表整个的外边框
			enable : column_config.border.enable, //是否有外边框
			color : column_config.border.color, //外边框颜色
			width : column_config.border.width, //边线宽
			radius : column_config.border.radius//圆角弧度
		},
		label:{
			fontsize:column_config.label.fontsize,
		},
		sub_option:{
			label:{
				fontsize:column_config.sub_option.label.fontsize,
				color:column_config.sub_option.label.color,
			},
		}
	}).draw();
}

/************************************************************************/
/**            折线配置项												   **/
/************************************************************************/
function getLineConfig(){
	var line_config ={
			data:'',			//数据源	
			data_labels:'',		//折线图的底部标签值	
			align : 'center',	
			offsetx:0,
			offsety:0,
			title:{				//标题
				text:'',		//标题内容
				color:'#fff',		//标题颜色
				font:'微软雅黑',
				fontsize:20
			},
			subtitle:{
				text:'',  //标题内容
				color:'#fff',   //副标题颜色
				fontsize:18,
				font:'微软雅黑',
			},
			anim:{				//显示动画
				enable:true,	//是否启用
				time:1000		//动画时间
			},
			size:{				//画布大小
				width:1000,		//画布宽
				height:770		//画布高
			},
			label_x : 65,//还没定义
			label_w : 40,//还没定义
			colwidth:40,
			coordinate:{		//坐标设置
				width:800,
				height:600,
				first_point:0,
				point_space:30,
				grid_color:'rgba(0,255,10,0.1)', //网格线颜色
				scale:[{		//x轴
					position:'left',	//向左对齐 
					start_scale:0,		//起始值
					end_scale:20,		//结束值
					scale_space:5,		//间隔值
					scale2grid : true, //是否有网格线
					scale_color : '#fd0', //坐标轴颜色
					label:{
						fontsize:18
					},
					color : 'rgba(255,255,0,0.5)', //设置坐标轴数据的颜色
					fontsize : 20,
				},{
					 position:'bottom',	
					 labels:'',
					 fontsize:24
				}],
				axis : { 
					enable : true, //是否有坐标线
					width : [0, 0, 1, 1], //坐标线宽度，顺序依次是上边线、右边线、下边线、左边线
					color : '#ff0',//坐标线颜色
				},
				shadow_color : 'rgba(16,40,2,0.1)', //底部是否阴影颜色
				back_color:'rgba(80,20,180,0)'  //图表区域背景色
			},
			border:{				//边框设置
				enable:true,		//边框是否可见
				color:'rgba(255,255,0,0)', //边框颜色
				width:2,			//边框
				radius:5  			//边框是否圆角
			},
			rectangle : {//Y轴值
				color : '#ff9', //Y轴字体颜色
				fontsize : 18, //Y轴字体大小
				label_name:''
			},
			footnote : {//底部备注
				text : '',
				color : '#95ff00',
				offsety : 10,
				offsetx : -20,
				fontsize : 16,
				font : '微软雅黑'
			},
			segment_style : {   //折线图中的点的大小
				point_size : 3,
				point_hollow : false,
			},
			legend : {			//图例配置项
				enable : false,
				align : 'center',
				valign : 'bottom', 
				row:1,
				column:'max',
				background_color:'rgba(255,255,0,0)',
				border:{
					enable:false
				},
				offsetx:0,
				offsety:0,
				fontsize:20,
				font:'微软雅黑',
				
			},
			label:{ //横轴的标签
				rotate:-45,
				textBaseline:'middle',
				textAlign:'right',
				color:'#fff',
				fontsize:18
			},
			sub_option:{
				smooth : true,
				label:{
					fontsize:20,
					color:'#fff',
				},
				border : {//图表整个的外边框
					width : 2, //边线宽
					radius : '0 0 0 0',//圆角弧度
					color : 'rgba(255,255,0,0)' //外边框颜色
				},
			},
			back_color:'rgba(80,20,180,0)'   //画布背景色
		};
	return line_config;
	
}


/************************************************************************/
/**            折线统计图												   **/
/************************************************************************/
function draw_Line(line_config,canvasId,danwei){
	var chart = new iChart.LineBasic2D({
		render : canvasId,
		data : line_config.data,
		align : line_config.align,
		offsety : line_config.offsety,
		offsetx : line_config.offsetx,
		segment_style : {
			point_size : line_config.segment_style.point_size,
			point_hollow : line_config.segment_style.point_hollow,
		},
		anim:{	
			enable:line_config.anim.enable,
			time:line_config.anim.time
		},
		label_x : line_config.label_x,
		label_w : line_config.label_w,
		background_color : line_config.back_color,
		width : line_config.size.width,
		height : line_config.size.height,
		data_labels : line_config.data_labels,
		coordinate : {
			width : line_config.coordinate.width, //图表宽
			height : line_config.coordinate.height, //图表长
			first_point:line_config.coordinate.first_point,
			point_space:line_config.coordinate.point_space,
			grid_color : line_config.coordinate.grid_color, //网格线颜色
			scale : [{
				position:line_config.coordinate.scale[0].position,	//底部值轴
				start_scale : line_config.coordinate.scale[0].start_scale, //开始刻度
				end_scale : line_config.coordinate.scale[0].end_scale, //结束刻度
				scale_space : line_config.coordinate.scale[0].scale_space, //刻度间距
				scale2grid : line_config.coordinate.scale[0].scale2grid, //是否有网格线
				scale_color : line_config.coordinate.scale[0].scale_color, //坐标轴颜色
				color : line_config.coordinate.scale[0].color, //设置坐标轴数据的颜色
				fontsize : line_config.coordinate.scale.fontsize
			},{
				 position:line_config.coordinate.scale[1].position,	
				 labels:line_config.coordinate.scale[1].labels
			}],
			axis : {
				enable : line_config.coordinate.axis.enable, //是否有坐标线
				width : line_config.coordinate.axis.width, //坐标线宽度，顺序依次是上边线、右边线、下边线、左边线
				color : line_config.coordinate.axis.color //坐标线颜色
			},
			shadow_color : line_config.coordinate.shadow_color,
			back_color : line_config.coordinate.back_color
		},
		legend : {
			enable : line_config.legend.enable,
			background_color : line_config.legend.background_color,
			border : {
				enable : line_config.legend.border.enable
			},
			align : line_config.legend.align,
			valign : line_config.legend.valign, 
			row:line_config.legend.row,
			column:line_config.legend.column,
			offsetx:line_config.legend.offsetx,
			offsety:line_config.legend.offsety,
			fontsize:line_config.legend.fontsize,
			font:line_config.legend.font,
			line_height:40,
			sign:'square-bar',
		}, //图轴各种颜色代表项
		border : {//图表整个的外边框
			enable : line_config.border.enable, //是否有外边框
			color : line_config.border.color, //外边框颜色
			width : line_config.border.width, //边线宽
			radius : line_config.border.radius//圆角弧度
		},
		title : {//大标题
			text : line_config.title.text,
			color : line_config.title.color,
			font : line_config.title.font,
			fontsize:line_config.title.fontsize
		},
		subtitle : {//副标题
			text : line_config.subtitle.text,
			color : line_config.subtitle.color,
			font : line_config.subtitle.font,
			fontsize:line_config.subtitle.fontsize
		},
		footnote : {//底部备注
			text : line_config.footnote.text,
			color : line_config.footnote.color,
			offsety : line_config.footnote.offsety,
			offsetx : line_config.footnote.offsetx,
			fontsize : line_config.footnote.fontsize,
			font : line_config.footnote.font,
			fontsize : line_config.footnote.fontsize
		}
	});
	chart.plugin(new iChart.Custom({
				drawFn:function(){
				//计算位置
				var coo = chart.getCoordinate(),
				x = coo.get('originx'),
				y = coo.get('originy');
				//在左上侧的位置，渲染一个单位的文字
				chart.target.textAlign('start')
				.textBaseline('bottom')
				.textFont('600 20px Verdana')
				.fillText(danwei,x-60,y-28,false,'#fff');
				}
				}));
	chart.draw();
}


//获得0-255之间随机数
function random(min,max){
	return Math.floor(min+Math.random()*(max-min));
}


/**
 * 3D柱状图数据源
 */
var Column3D_data ={
	data:'',			//数据源	
	data_labels:'',		//折线图的底部标签值	
	align : 'center',		
	title:{				//标题
		text:'',		//标题内容
		color:'#fff',		//标题颜色
		font:'微软雅黑',
		fontsize:20
	},
	subtitle:{
		text:'',  //标题内容
		color:'#fff',   //副标题颜色
		fontsize:18,
		font:'微软雅黑',
	},
	anim:{				//显示动画
		enable:true,	//是否启用
		time:1000		//动画时间
	},
	size:{				//画布大小
		width:1000,		//画布宽
		height:800		//画布高
	},
	label_x : 65,//
	label_w : 40,//
	colwidth:5,
	coordinate:{		//坐标设置
		width:800,
		height:600,
		grid_color:'rgba(0,255,10,0.1)', //网格线颜色
		scale:{
			position:'left',	//向左对齐
			start_scale:-15,		//起始值
			end_scale:30,		//结束值
			scale_space:5,		//间隔值
			scale2grid : false, //是否有网格线
			scale_color : '#fd0', //坐标轴颜色
			label:{
				fontsize:18
			},
			color : 'rgba(255,255,0,0.5)', //设置坐标轴数据的颜色
			fontsize : 18,
		},
		axis : { 
			enable : true, //是否有坐标线
			width : [0, 0, 1, 1], //坐标线宽度，顺序依次是上边线、右边线、下边线、左边线
			color : '#ff0',//坐标线颜色
		},
		shadow_color : 'rgba(16,40,2,0.1)', //底部是否阴影颜色
		back_color:'rgba(80,20,180,0)'  //图表区域背景色
	},
	border:{				//边框设置
		enable:true,		//边框是否可见
		color:'rgba(255,255,0,0)', //边框颜色
		width:2,			//边框
		radius:5  			//边框是否圆角
	},
	rectangle : {//Y轴值
		color : '#ff9', //Y轴字体颜色
		fontsize : 12, //Y轴字体大小
		label_name:''
	},
	footnote : {//底部备注
		text : '',
		color : '#95ff00',
		offsety : 10,
		offsetx : -20,
		fontsize : 16,
		font : '微软雅黑'
	},
	segment_style : {   //折线图中的点的大小
		point_size : 3,
		point_hollow : true,
	},
	legend : {			//图例配置项
		enable : true,
		align : 'center',
		valign : 'bottom', 
		row:1,
		column:'max',
		background_color:'rgba(255,255,0,0)',
		border:{
			enable:false
		},
		offsetx:0,
		offsety:0,
		fontsize:20,
		font:'微软雅黑',
	},
	label:{ //横轴的标签
		rotate:-45,
		textBaseline:'middle',
		textAlign:'right',
		color:'#fff',
		fontsize:18
	},
	sub_option:{
		smooth : true,
		label:{
			fontsize:12,
			color:'#fff',
		},
		border : {//图表整个的外边框
			width : 2, //边线宽
			radius : '0 0 0 0',//圆角弧度
			color : 'rgba(255,255,0,0)' //外边框颜色
		},
	},
	back_color:'rgba(80,20,180,0)'   //画布背景色
};


/************************************************************************/
/**            2D多个柱状图的画图方法                                                                                              **/
/************************************************************************/
function draw_ColumnMulti2D(canvasId){
	new iChart.ColumnMulti2D({
		render : canvasId,
		data: Column3D_data.data,
		align : Column3D_data.align,
		labels:Column3D_data.data_labels,
		colwidth:Column3D_data.colwidth,
		title : {
			text:Column3D_data.title.text,
			color:Column3D_data.title.color
		},
		subtitle : {
			text:Column3D_data.subtitle.text,
			color:Column3D_data.subtitle.color
		},
		animation : Column3D_data.anim.enable,
		duration_animation_duration : Column3D_data.anim.time,
		footnote : Column3D_data.footnote.text,
		width : Column3D_data.size.width,
		height : Column3D_data.size.height,
		background_color : Column3D_data.back_color,
		legend:{
			enable:Column3D_data.legend.enable,
			background_color : Column3D_data.legend.background_color,
			border : {
				enable : Column3D_data.legend.border.enable
			},
			align : Column3D_data.legend.align,
			valign : Column3D_data.legend.valign, 
			row:Column3D_data.legend.row,
			column:Column3D_data.legend.column,
			offsetx:Column3D_data.legend.offsetx,
			fontsize:Column3D_data.legend.fontsize,
			font:Column3D_data.legend.font,
			line_height:40
		},
		coordinate:{
			width:Column3D_data.coordinate.width,
			height:Column3D_data.coordinate.height,
			background_color : Column3D_data.coordinate.back_color,
			grid_color : Column3D_data.coordinate.grid_color, //网格线颜色
			axis : {
				enable : Column3D_data.coordinate.axis.enable, //是否有坐标线
				width : Column3D_data.coordinate.axis.width, //坐标线宽度，顺序依次是上边线、右边线、下边线、左边线
				color : Column3D_data.coordinate.axis.color,//坐标线颜色
			},
			scale : [{
				position:Column3D_data.coordinate.scale.position,	//底部值轴
				start_scale : Column3D_data.coordinate.scale.start_scale, //开始刻度
				end_scale : Column3D_data.coordinate.scale.end_scale, //结束刻度
				scale_space : Column3D_data.coordinate.scale.scale_space, //刻度间距
				scale2grid : Column3D_data.coordinate.scale.scale2grid, //是否有网格线
				scale_color : Column3D_data.coordinate.scale.scale_color, //坐标轴颜色
				color : Column3D_data.coordinate.scale.color, //设置坐标轴数据的颜色
				fontsize : Column3D_data.coordinate.scale.fontsize,
				label:{
					fontsize:Column3D_data.coordinate.scale.label.fontsize,
				}
			}]
		},
		border : {//图表整个的外边框
			enable : Column3D_data.border.enable, //是否有外边框
			color : Column3D_data.border.color, //外边框颜色
			width : Column3D_data.border.width, //边线宽
			radius : Column3D_data.border.radius//圆角弧度
		},
		label:{
			fontsize:Column3D_data.label.fontsize,
		},
		sub_option:{
			label:{
				fontsize:Column3D_data.sub_option.label.fontsize,
				color:Column3D_data.sub_option.label.color,
			},
		},
	}).draw();
}

