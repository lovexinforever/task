// JavaScript Document
//下面JS作为头部滑动使用
$(document).ready(function() {
	ininMenu();
});
///上面JS作头部滑动使用
var touchZt = true;
function ininMenu() {
	var liCount = $("#lb_info").find("li").length;//滑动菜单的个数
	//初始化左右箭头
	if(liCount<=2){
		$(".power_stage_leftico").css("opacity", 0.2);
		$(".power_stage_rightico").css("opacity", 0.2);
	}else{
		$(".power_stage_leftico").css("opacity", 0.2);
		$(".power_stage_rightico").css("opacity", 1);	
	}
	
	var MachineTouchStart = 0;
	var MachineTouchend = 0;
	var movei_lb = 0;
	
	$("#lb_info").bind({
		touchstart : function() {
			var touch = event.touches[0];
			MachineTouchStart = touch.pageX;
		},
		touchmove : function() {
			var touch = event.touches[0];
			MachineTouchend = touch.pageX;
			var moveheig = document.getElementById("lb_info").offsetHeight;
			if(MachineTouchStart - MachineTouchend < 0 && touchZt) {//向右滑动
			touchZt=false;
				if(movei_lb>0){
					movei_lb--;
				}
				for(var i=movei_lb+1;i<=liCount;i++){
					$(".stage_menuico0"+i).show("slow");
				}
				setTimeout(function(){touchZt=true},500)
			} else if(MachineTouchStart - MachineTouchend > 0 && touchZt) {//向左滑动
			    touchZt=false;
			    setTimeout(function(){touchZt=true},500)
				if(movei_lb+1<=liCount-2){
					movei_lb++;
				}
				for(var i=1;i<=movei_lb;i++){
					$(".stage_menuico0"+i).hide("slow");
				}
			}
			if(liCount<=2){
				$(".power_stage_leftico").css("opacity", 0.2);
				$(".power_stage_rightico").css("opacity", 0.2);
			}else{
				//箭头的样式
				if(movei_lb == 0) {
					$(".power_stage_leftico").css("opacity", 0.2);
					$(".power_stage_rightico").css("opacity", 1);
				}else if(movei_lb==liCount-2){
					$(".power_stage_leftico").css("opacity", 1);
					$(".power_stage_rightico").css("opacity", 0.2);
				}else{
					$(".power_stage_leftico").css("opacity", 1);
					$(".power_stage_rightico").css("opacity", 1);
				}
			}
		}
	});
}