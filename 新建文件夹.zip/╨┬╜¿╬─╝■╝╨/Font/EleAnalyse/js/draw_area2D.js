//2D面积图数据模型
function setArea2D_data(){
	var argLength=arguments.length;
	var area2D_data={
		render: '',
		data: '',
		animation :false,
		border:{
			enable:false
		},
		align: 'center',
		title: '',
		footnote: '',
		width: 560,
		height: 400,
		background_color: null,
		legend:{
			enable : false,
			row:1,
			column : 'max',
			valign:'top',
			sign:'bar',
			background_color:null,
			offsetx:-80,
			border : true
		},
		sub_option:{
			label:false,
			area_color:function(T){
				if(argLength==1){
					return T.avgLinearGradient(this.x,this.y,this.x,this.y-this.get('height'),['rgba(255,255,255,0)','rgba(255,255,255,0)']);
				}
				return T.avgLinearGradient(this.x,this.y,this.x,this.y-this.get('height'),['rgba(255,255,255,0.6)',this.get('f_color')]);
			},
			point_size:10,
			hollow_inside: false
		},
		danwei:'%',
		danwei2:'时',
		coordinate:{
			width:480,
			height:240,
			offsety:0,
			valid_width:'100%',
			grid_color:'rgba(223,226,233,1)',
			axis:{
				color:'#dcdcdc',
				width:0
			},
			scale2grid: false,
			grids:{
                 horizontal:{
                   way:'share_alike',
                   value:5
                 }
            }, 
			scale:[{
				   position:'left',	
				   start_scale:0,
				   end_scale:0,
				   scale_space:0,
				   scale_size:0,
				   label: {
						color: '#9da4b5',
						fontsize: 15,
						font:'微软雅黑',
						fontweight: 600
					},
					listeners:{
						parseText: function(t, x, y){
							if(Number(t)==0){
								t='0';
							}
							return {
							   text: t
							}
						}
					}
				},{
				   position:'bottom',	
				   labels:'',
				   scale_enable:true,
				   label: {
						color: '#9da4b5',
						fontsize: 24,
						font:'微软雅黑',
						fontweight: 100
					}
				}]
		}
	};
	return area2D_data;
}


//绘制2D面积图
function drawArea2D(area2D_data){
	var chart =  new iChart.Area2D({
		render: area2D_data.render,
		data: area2D_data.data,
		animation: area2D_data.animation,
		border:{
			enable: area2D_data.border.enable
		},
		align: area2D_data.align,
		title: area2D_data.title,
		footnote: area2D_data.footnote,
		width: area2D_data.width,
		height: area2D_data.height,
		background_color: area2D_data.background_color,
		legend:{
			enable: area2D_data.legend.enable,
			row: area2D_data.legend.row,
			column: area2D_data.legend.column,
			valign: area2D_data.legend.valign,
			sign: area2D_data.legend.sign,
			background_color: area2D_data.legend.background_color,
			offsetx: area2D_data.legend.offsetx,
			border: area2D_data.legend.border
		},
		sub_option:{
			label: area2D_data.sub_option.label,
			area_color: area2D_data.sub_option.area_color,
			point_size: area2D_data.sub_option.point_size,
			hollow_inside: area2D_data.sub_option.hollow_inside
		},
		coordinate:{
			width: area2D_data.coordinate.width,
			height: area2D_data.coordinate.height,
			offsety:area2D_data.coordinate.offsety,
			valid_width:area2D_data.coordinate.valid_width,
			grid_color: area2D_data.coordinate.grid_color,
			offsetx:10,
			axis:{
				color: area2D_data.coordinate.axis.color,
				width: area2D_data.coordinate.axis.width
			},
			scale2grid: area2D_data.coordinate.scale2grid,
			grids:{
               horizontal:{
                   way: area2D_data.coordinate.grids.horizontal.way,
                   value: area2D_data.coordinate.grids.horizontal.value
                 }
            }, 
			scale:[{
				position: area2D_data.coordinate.scale[0].position,
				start_scale: area2D_data.coordinate.scale[0].start_scale,
				end_scale: area2D_data.coordinate.scale[0].end_scale,
				scale_space: area2D_data.coordinate.scale[0].scale_space,
				scale_size: area2D_data.coordinate.scale[0].scale_size,
				label:{
					color:  area2D_data.coordinate.scale[0].label.color,
					fontsize: area2D_data.coordinate.scale[0].label.fontsize,
					font: area2D_data.coordinate.scale[0].label.font,
					fontweight: area2D_data.coordinate.scale[0].label.fontweight
				},
				listeners:area2D_data.coordinate.scale[0].listeners
			},{
				position: area2D_data.coordinate.scale[1].position,
				labels: area2D_data.coordinate.scale[1].labels,
				scale_enable: area2D_data.coordinate.scale[1].scale_enable,
				label: {
					color: area2D_data.coordinate.scale[1].label.color,
					fontsize: area2D_data.coordinate.scale[1].label.fontsize,
					font: area2D_data.coordinate.scale[1].label.font,
					fontweight: area2D_data.coordinate.scale[1].label.fontweight
				}
			}]
		}
	});
	chart.plugin(new iChart.Custom({
		drawFn:function(){
			//计算位置
			var coo = chart.getCoordinate(),
			x = coo.get('originx'),
			y = coo.get('originy'),
		    w = coo.get('width'),
			h = coo.get('height');
			//在左上侧的位置，渲染一个单位的文字
			chart.target.textAlign('start')
			.textBaseline('bottom')
			.textFont('600 20px Verdana')
			.fillText(area2D_data.danwei,x-40,y-14,false,'#9da4b5')
			.textAlign('end')
			.fillText(area2D_data.danwei2,x+10,y+coo.get('height')+55,false,'#9da4b5');
		}
	}));
	chart.draw();
}